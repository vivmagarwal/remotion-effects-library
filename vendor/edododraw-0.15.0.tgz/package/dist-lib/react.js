import { jsx } from "react/jsx-runtime";
import { useRef, useEffect } from "react";
import { E as EdodoDraw } from "./chunks/EdodoDraw-nvsraggA.js";
function EdodoDrawView({ source, className, style, colorScheme, onReady, onDiagnostics, onState, ...opts }) {
  const hostRef = useRef(null);
  const eddRef = useRef(null);
  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    const edd = new EdodoDraw(host, opts);
    eddRef.current = edd;
    if (colorScheme !== void 0) edd.setColorScheme(colorScheme);
    if (onDiagnostics) edd.on("diagnostics", onDiagnostics);
    if (onState) edd.on("state", onState);
    onReady?.(edd);
    return () => {
      edd.destroy();
      eddRef.current = null;
    };
  }, []);
  useEffect(() => {
    void eddRef.current?.render(source);
  }, [source]);
  useEffect(() => {
    eddRef.current?.setColorScheme(colorScheme ?? null);
  }, [colorScheme]);
  return /* @__PURE__ */ jsx("div", { ref: hostRef, className, style: { width: "100%", height: "100%", ...style } });
}
export {
  EdodoDraw,
  EdodoDrawView
};
//# sourceMappingURL=react.js.map
