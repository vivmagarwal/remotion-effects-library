import { d as dagreRoute, r as resolveEndpoints, a as routePoints, s as smoothPath, c as centerlinePath, p as pathLength, D as DiagnosticBag, g as getStylePreset, e as effectivePreset, b as presetTheme, f as runViz, h as emptyScene } from "./chunks/EdodoDraw-nvsraggA.js";
import { A, C, i, j, k, l, m, n, o, q, t, u, E, F, v, H, w, x, I, y, z, L, B, M, G, S, J, T, V, K, N, O, P, Q, R, U, W, X, Y, Z, _, $, a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, aa, ab, ac, ad, ae, af, ag, ah, ai, aj, ak, al, am, an, ao, ap, aq, ar, as, at, au, av, aw, ax, ay, az, aA, aB, aC, aD, aE, aF, aG, aH, aI, aJ, aK, aL, aM, aN, aO, aP, aQ, aR, aS, aT, aU, aV, aW, aX, aY, aZ, a_, a$, b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, ba, bb, bc, bd, be, bf, bg, bh, bi, bj, bk, bl, bm, bn, bo, bp, bq, br, bs, bt, bu, bv, bw, bx, by, bz, bA, bB, bC, bD, bE, bF, bG, bH, bI, bJ, bK, bL, bM, bN, bO, bP, bQ, bR, bS, bT, bU, bV, bW, bX, bY, bZ, b_, b$, c0, c1, c2, c3, c4, c5, c6 } from "./chunks/EdodoDraw-nvsraggA.js";
import { VIZ_ANIMATION_DEFAULTS, VIZ_DEMOS, animateVizSource, animatedVizDemo, getVizDemo, injectVizOptions, listVizDemoCategories, listVizDemos, listVizDemosInCategory } from "./demos.js";
function edgeCenterline(scene, edgeId) {
  const edge = scene.edges.find((e) => e.id === edgeId);
  return edge ? centerlineOf(scene, edge) : null;
}
function edgeCenterlines(scene) {
  return scene.edges.map((e) => centerlineOf(scene, e));
}
function centerlineOf(scene, edge) {
  const routed = dagreRoute(scene, edge);
  let points;
  let smooth;
  if (routed) {
    points = routed;
    smooth = true;
  } else {
    const { a, b } = resolveEndpoints(scene, edge);
    points = routePoints(edge, a, b);
    smooth = edge.routing === "curved" && points.length === 3;
  }
  const d = smooth ? smoothPath(points) : centerlinePath(points, edge.routing);
  return { id: edge.id, d, points, length: pathLength(points), style: edge.style, smooth };
}
const DASH_MARCH_CYCLE_PX = 18;
const ARROW_ANIMATIONS = {
  flow: { dashCycle: -18, dashArray: "10 8", strokeWidthScale: 1.2, durationSec: 0.9, easing: "linear", alternate: false, opacityOnly: false },
  "dash-march": { dashCycle: -18, dashArray: "10 8", strokeWidthScale: 1.2, durationSec: 0.9, easing: "linear", alternate: false, opacityOnly: false },
  electric: { dashCycle: -9, dashArray: "2 7", strokeWidthScale: 1.6, durationSec: 0.5, easing: "steps-3", alternate: false, opacityOnly: false },
  "gradient-flow": { dashCycle: -30, dashArray: "16 10", strokeWidthScale: 2.4, durationSec: 1.2, easing: "linear", alternate: false, opacityOnly: false },
  // length-relative: dash = the whole path, offset sweeps len -> 0 and back
  "draw-on": { dashCycle: null, dashArray: null, strokeWidthScale: 1.3, durationSec: 1.4, easing: "ease-in-out", alternate: true, opacityOnly: false },
  // length-relative: a bright segment of max(24, 14% of len) flying end to end
  comet: { dashCycle: null, dashArray: null, strokeWidthScale: 2.2, durationSec: 1.6, easing: "linear", alternate: false, opacityOnly: false },
  pulse: { dashCycle: null, dashArray: null, strokeWidthScale: 1.2, durationSec: 1.3, easing: "ease-in-out", alternate: false, opacityOnly: true }
};
const COMET_HEAD_FRACTION = 0.14;
const COMET_HEAD_MIN_PX = 24;
const FLOW_GRADIENT_URL = "url(#eddFlowGradient)";
function arrowFrameStyle(edge, timeSec, opts = {}) {
  const kind = opts.animation ?? edge.style.animation;
  if (!kind || kind === "none") return null;
  const spec = ARROW_ANIMATIONS[kind];
  if (!spec) return null;
  const len = Math.max(1, opts.length ?? edge.length);
  const speed = opts.speed ?? edge.style.animationSpeed ?? 1;
  const duration = spec.durationSec / (speed || 1);
  const sw = edge.style.strokeWidth * spec.strokeWidthScale;
  let t2 = cycleFraction(timeSec, duration);
  if (spec.alternate) t2 = t2 < 0.5 ? t2 * 2 : 2 - t2 * 2;
  t2 = ease(t2, spec.easing);
  const base = {
    stroke: kind === "gradient-flow" ? FLOW_GRADIENT_URL : edge.style.stroke,
    strokeWidth: sw,
    strokeDasharray: "",
    strokeDashoffset: 0,
    strokeLinecap: kind === "pulse" ? "butt" : "round",
    fill: "none",
    opacity: 1
  };
  switch (kind) {
    case "flow":
    case "dash-march":
    case "electric":
    case "gradient-flow":
      base.strokeDasharray = spec.dashArray;
      base.strokeDashoffset = spec.dashCycle * t2;
      return base;
    case "draw-on":
      base.strokeDasharray = String(len);
      base.strokeDashoffset = len * (1 - t2);
      return base;
    case "comet": {
      const head = Math.max(COMET_HEAD_MIN_PX, len * COMET_HEAD_FRACTION);
      base.strokeDasharray = `${head} ${len}`;
      base.strokeDashoffset = len + (-COMET_HEAD_FRACTION * len - len) * t2;
      base.filter = "drop-shadow(0 0 4px currentColor)";
      return base;
    }
    case "pulse":
      base.opacity = 0.15 + 0.7 * (1 - Math.abs(2 * t2 - 1));
      return base;
    default:
      return null;
  }
}
function cycleFraction(timeSec, durationSec) {
  if (!(durationSec > 0)) return 0;
  const f = timeSec / durationSec % 1;
  return f < 0 ? f + 1 : f;
}
function ease(t2, kind) {
  switch (kind) {
    case "ease-in-out":
      return t2 * t2 * (3 - 2 * t2);
    case "steps-3":
      return Math.floor(t2 * 3) / 3;
    // CSS steps(3) == steps(3, jump-end)
    default:
      return t2;
  }
}
function vizToScene(specs, opts = {}) {
  const diags = opts.diagnostics ?? new DiagnosticBag();
  const mode = opts.mode ?? "light";
  const preset = getStylePreset(opts.style) ?? effectivePreset(void 0, mode);
  if (opts.style && !getStylePreset(opts.style)) {
    diags.warn("W-STYLE-PRESET", `unknown style preset '${opts.style}'`, { line: 1, col: 1, start: 0, end: 0 }, { hint: "see docs/STYLES_GUIDE for the built-in preset names" });
  }
  const scene = emptyScene(mode);
  scene.theme = presetTheme(preset);
  scene.theme.mode = mode;
  scene.meta.style = preset.name;
  scene.meta.layout = "manual";
  const list = Array.isArray(specs) ? specs : [specs];
  let cursorY = 40;
  for (const spec of list) {
    const result = runViz(normalizeSpec(spec), preset, mode, diags);
    if (!result) continue;
    const dx = 40 - result.bounds.x;
    const dy = cursorY - result.bounds.y;
    for (const n2 of result.nodes) {
      n2.x += dx;
      n2.y += dy;
      scene.nodes.push(n2);
    }
    for (const e of result.edges) {
      if (e.from.point) e.from = { ...e.from, point: { x: e.from.point.x + dx, y: e.from.point.y + dy } };
      if (e.to.point) e.to = { ...e.to, point: { x: e.to.point.x + dx, y: e.to.point.y + dy } };
      if (e.points) e.points = e.points.map((p) => ({ x: p.x + dx, y: p.y + dy }));
      scene.edges.push(e);
    }
    for (const a of result.annotations) scene.annotations.push(a);
    cursorY += result.bounds.h + (opts.gap ?? 100);
  }
  return { scene, diagnostics: diags };
}
let specSeq = 0;
function normalizeSpec(spec) {
  return {
    ...spec,
    id: spec.id || `viz${++specSeq}`,
    options: spec.options ?? {},
    items: (spec.items ?? []).map(normalizeItem)
  };
}
function normalizeItem(item) {
  return {
    kind: item.kind ?? "item",
    id: item.id ?? slug(item.label) ?? "item",
    label: item.label,
    detail: item.detail,
    value: item.value ?? item.values?.[0],
    values: item.values ?? (item.value !== void 0 ? [item.value] : []),
    strings: item.strings ?? [],
    to: item.to,
    color: item.color,
    icon: item.icon,
    opts: item.opts ?? {},
    children: (item.children ?? []).map(normalizeItem)
  };
}
function vizItem(label, value, extra = {}) {
  return normalizeItem({ ...extra, label, value: value ?? extra.value });
}
function slug(label) {
  const s = label.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 24);
  return s || void 0;
}
export {
  ARROW_ANIMATIONS,
  A as AnnotationLayer,
  C as CHARACTER_LABEL_GAP,
  i as CHARACTER_NODE_DEFAULT_HEIGHT,
  j as CLASSIC_COLOR_PRESET,
  k as CLASSIC_DARK_PRESET,
  l as CLASSIC_PRESET,
  m as CLASSIC_ROUGH_PRESET,
  COMET_HEAD_FRACTION,
  COMET_HEAD_MIN_PX,
  n as CameraController,
  o as DARK_THEME,
  DASH_MARCH_CYCLE_PX,
  DiagnosticBag,
  q as EASINGS,
  t as EXCALIFONT_FAMILY,
  u as EditController,
  E as EdodoDraw,
  F as FILL_PALETTE,
  FLOW_GRADIENT_URL,
  v as FONT_FAMILY,
  H as HAND_CLEAN_DARK_PRESET,
  w as HAND_CLEAN_PRESET,
  x as HAND_FONT_WOFF2_DATA_URI,
  I as ICON_LABEL_GAP,
  y as ICON_NODE_DEFAULT_SIZE,
  z as ICON_VIEWBOX,
  L as LIGHT_THEME,
  B as LiveAnnotationController,
  M as MARKER_PALETTE,
  G as MERMAID_INSTALL_HINT,
  S as STROKE_PALETTE,
  J as SvgRenderer,
  T as TimelinePlayer,
  V as VIZ_ALIASES,
  VIZ_ANIMATION_DEFAULTS,
  VIZ_DEMOS,
  K as VizContext,
  N as addEdge,
  O as addNode,
  animateVizSource,
  animatedVizDemo,
  P as applyLayout,
  Q as applyOverrides,
  arrowFrameStyle,
  R as bboxCenter,
  U as bboxOfPoints,
  W as bboxSize,
  X as bboxToRect,
  Y as bboxUnion,
  Z as borderPointToward,
  _ as cameraForBBox,
  $ as cameraForCenter,
  centerlinePath,
  a0 as characterNodeBox,
  a1 as characterNodeSpec,
  a2 as clamp,
  a3 as compileEdd,
  a4 as computeHiddenAt,
  a5 as contrastInk,
  a6 as convertMermaid,
  a7 as darken,
  a8 as defaultEdgeStyle,
  a9 as defaultNodeSize,
  aa as defaultNodeStyle,
  ab as deleteElements,
  ac as dist,
  ad as downloadJSON,
  ae as downloadPNG,
  af as downloadSVG,
  ag as drawCharacter,
  ah as easingByName,
  ai as edgeBBox,
  edgeCenterline,
  edgeCenterlines,
  aj as edgeRoughOptions,
  effectivePreset,
  ak as elementBBox,
  al as elementsBBox,
  am as ellipseBorderToward,
  an as emitCharacterNode,
  ao as emptyBBox,
  emptyScene,
  ap as ensureEngineStyles,
  aq as ensurePluginStyles,
  ar as expandBBox,
  as as exportPNGBlob,
  at as exportSVGString,
  au as extractMermaidBlocks,
  av as formatDiagnostic,
  aw as getAnnotationPlugin,
  ax as getArrowAnimation,
  ay as getCharacterPose,
  az as getEdge,
  aA as getGroup,
  aB as getLayoutPlugin,
  aC as getNode,
  aD as getShapePlugin,
  getStylePreset,
  aE as getViz,
  getVizDemo,
  aF as groupBBox,
  aG as hashString,
  aH as hitTestEdge,
  aI as hitTestNode,
  aJ as iconEntry,
  aK as iconNodeBox,
  aL as iconNodeGlyph,
  aM as iconNodeSpec,
  aN as iconPath,
  aO as injectMermaid,
  injectVizOptions,
  aP as isEmptyBBox,
  aQ as isLightColor,
  aR as isMermaidAvailable,
  aS as itemsOf,
  aT as lerp,
  aU as lighten,
  aV as listAnnotationPlugins,
  aW as listArrowAnimations,
  aX as listCharacterAccessories,
  aY as listCharacterEmotions,
  aZ as listCharacterFx,
  a_ as listCharacterHair,
  a$ as listCharacterNodes,
  b0 as listCharacterPoses,
  b1 as listCharacterShirts,
  b2 as listIconNodes,
  b3 as listIcons,
  b4 as listLayoutPlugins,
  b5 as listReferencePresets,
  b6 as listShapePlugins,
  b7 as listStyleChoices,
  b8 as listStylePresets,
  b9 as listViz,
  ba as listVizAliases,
  listVizDemoCategories,
  listVizDemos,
  listVizDemosInCategory,
  bb as listVizItems,
  bc as listVizTemplates,
  bd as luma,
  be as makeEdge,
  bf as makeNode,
  bg as measureBlock,
  bh as measureCharacterNode,
  bi as measureText,
  bj as mix,
  bk as mixCameras,
  bl as nodeBBox,
  bm as nodeRect,
  bn as nodeRectOf,
  bo as optBool,
  bp as optNum,
  bq as optStr,
  br as pairedStrokeForFill,
  bs as paletteColor,
  bt as parseHex,
  pathLength,
  bu as pointInRect,
  bv as presetDeclaresRoughTuning,
  bw as presetEdgeDefaults,
  bx as presetNodeDefaults,
  presetTheme,
  by as rampOpacity,
  bz as rectCenter,
  bA as rectToBBox,
  bB as registerAnnotation,
  bC as registerArrowAnimation,
  bD as registerCharacterAccessory,
  bE as registerCharacterEmotion,
  bF as registerCharacterFx,
  bG as registerCharacterHair,
  bH as registerCharacterPose,
  bI as registerCharacterShirt,
  bJ as registerIcon,
  bK as registerLayout,
  bL as registerShape,
  bM as registerStylePreset,
  bN as registerViz,
  bO as registerVizAlias,
  bP as renameNode,
  bQ as renderSceneToSVGString,
  bR as renderSceneWithAnnotations,
  bS as resolveAnchor,
  bT as resolveCameraDirective,
  resolveEndpoints,
  bU as resolveFill,
  bV as resolveMarker,
  bW as resolveStroke,
  bX as roleStyle,
  bY as roughTuning,
  routePoints,
  runViz,
  bZ as sceneBBox,
  smoothPath,
  b_ as stepStateAt,
  b$ as styleNode,
  c0 as toHex,
  c1 as tunePreset,
  vizItem,
  c2 as vizItemMembers,
  vizToScene,
  c3 as whenFontsReady,
  c4 as withAlpha,
  c5 as wrapText,
  c6 as writeOverrides
};
//# sourceMappingURL=index.js.map
