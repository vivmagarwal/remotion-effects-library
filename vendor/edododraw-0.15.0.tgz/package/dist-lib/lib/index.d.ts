/**
 * `edododraw` — public npm entry point.
 *
 * Two levels of API:
 *   - High-level facade: `new EdodoDraw(el).render(source)` — mount a diagram
 *     with camera, timeline, live annotations, and export in one object.
 *   - Low-level engine: `compileEdd`, `SvgRenderer`, `CameraController`,
 *     `registerShape`, the Scene IR types, etc. — compose your own.
 *
 * A React wrapper is available at `edododraw/react`.
 */
export { EdodoDraw } from "./EdodoDraw.js";
export type { EdodoDrawOptions, RenderResult, EdodoEvent } from "./EdodoDraw.js";
export * from "../engine/index.js";
export { convertMermaid, extractMermaidBlocks, injectMermaid, isMermaidAvailable, MERMAID_INSTALL_HINT } from "../engine/import/mermaid.js";
export type { MermaidFragment } from "../engine/import/mermaid.js";
//# sourceMappingURL=index.d.ts.map