/**
 * EdodoDraw — the framework-agnostic embedding facade.
 *
 * One class that mounts a diagram into any DOM element and exposes the full
 * feature set (render, camera magic-move, timeline, live annotations, export)
 * behind a small, stable API. The React wrapper and the playground both build
 * on this, so the published package is exactly what we dogfood.
 *
 *   const edd = new EdodoDraw(document.getElementById("diagram"));
 *   await edd.render(`scene { a[Hello] --> b[World] }`);
 *   edd.play();
 */
import { LiveAnnotationController, type LiveState } from "../engine/annotate/interact.js";
import { EditController, type EditState } from "../engine/edit/controller.js";
import { CameraController } from "../engine/camera/controller.js";
import type { Diagnostic } from "../engine/dsl/diagnostics.js";
import { type ExportOptions } from "../engine/export.js";
import { SvgRenderer } from "../engine/render/svgRenderer.js";
import type { Scene } from "../engine/scene/types.js";
import { TimelinePlayer, type PlayerState } from "../engine/timeline/player.js";
import { type StepState } from "../engine/timeline/stepState.js";
export interface EdodoDrawOptions {
    /** Enable pan (drag) + zoom (wheel) + live-annotation pointer handling. */
    interactive?: boolean;
    /** Draw a dotted grid that pans/zooms with the camera. Default true. */
    grid?: boolean;
    /** Fit the whole diagram after each render. Default true. */
    autoFit?: boolean;
    /** Padding (screen px) used when fitting. */
    padding?: number;
    /**
     * Deterministic frame rendering for screenshot/video consumers: disables
     * ALL wall-clock CSS (visibility transitions, animated arrows, reveal
     * animations). Drive motion explicitly — stepState()/applyStepState(),
     * setRevealProgress(), camera. See docs/INTEGRATION_GUIDE.
     */
    static?: boolean;
    /**
     * Mount with every node/edge hidden (and no annotations) so choreographed
     * embeds never flash the full diagram before the host applies its first
     * state. Reveal via applyStepState()/timeline or applyVisibility.
     */
    startHidden?: boolean;
}
export type EdodoEvent = "render" | "state" | "live" | "diagnostics" | "edit" | "editstate";
export interface RenderResult {
    scene: Scene;
    diagnostics: Diagnostic[];
}
export declare class EdodoDraw {
    readonly container: HTMLElement;
    private opts;
    private renderer;
    private controller;
    private annotations;
    private player;
    private live;
    private edit;
    private mode;
    private scene;
    private source;
    private renderSeq;
    private hasFitted;
    private fitOnce;
    private listeners;
    private textInput;
    private closeInput;
    private colorScheme;
    private stylePreset;
    private hasRendered;
    private cleanup;
    private editUndoStack;
    private editRedoStack;
    constructor(container: HTMLElement, options?: EdodoDrawOptions);
    private onCameraFrame;
    /** Apply a source edit from direct manipulation. Records the pre-edit source
     *  on the undo stack, keeps `source` fresh for chained edits, and notifies the
     *  host, which re-renders (single render). */
    private applyEdit;
    /** Undo the last diagram edit (move/resize/add/delete/rename/style/…). */
    editUndo(): boolean;
    /** Redo the last undone diagram edit. */
    editRedo(): boolean;
    /** Clear the diagram-edit history (e.g. when loading a fresh document). */
    clearEditHistory(): void;
    private emitEditState;
    on(event: "state", cb: (s: PlayerState) => void): () => void;
    on(event: "live", cb: (s: LiveState) => void): () => void;
    on(event: "diagnostics", cb: (d: Diagnostic[]) => void): () => void;
    on(event: "render", cb: (r: RenderResult) => void): () => void;
    on(event: "edit", cb: (source: string) => void): () => void;
    on(event: "editstate", cb: (s: EditState) => void): () => void;
    private emit;
    /**
     * Compile + render EDodoDraw source. Async because a `mermaid` block may need
     * the (lazy-loaded) Mermaid runtime. Safe to call on every keystroke; stale
     * runs are discarded.
     */
    render(source: string): Promise<RenderResult>;
    /**
     * Render a programmatic Scene directly (skip the DSL). Pair with
     * `vizToScene()` / `runViz()` / hand-built Scene IR to create diagrams on
     * the fly. Note: direct-manipulation editing round-trips through `.edd`
     * source, so canvas edits are inert for scenes rendered this way — use
     * `render()`/`appendSource()` when you need the code round-trip.
     */
    renderScene(scene: Scene): void;
    /**
     * Append a DSL fragment to the current source and re-render — grow a
     * diagram at runtime while keeping the text as the single source of truth:
     *   await edd.appendSource(`annotate { circle-mark api "hot path" }`);
     */
    appendSource(fragment: string): Promise<RenderResult>;
    getScene(): Scene;
    getSource(): string;
    /**
     * Force light/dark rendering, overriding the diagram's declared theme. Affects
     * the canvas background, the dotted grid, and the diagram's default ink
     * (strokes/text adapt for contrast on the dark canvas; explicit colors are
     * kept). Pass `null` to fall back to the DSL's own theme. Re-renders the
     * current source. Cheap and idempotent — no-ops if the scheme is unchanged.
     */
    setColorScheme(mode: "light" | "dark" | null): void;
    getColorScheme(): "light" | "dark" | null;
    /**
     * Force a style preset by name (see docs/STYLES_GUIDE), overriding the
     * diagram's `meta { style: … }`. Pass `null` to fall back to the source's own
     * declaration. Re-renders the current source; unknown names warn and keep the
     * classic look.
     */
    setStylePreset(name: string | null): void;
    getStylePreset(): string | null;
    fit(animate?: boolean): void;
    focus(ids: string[], opts?: {
        zoom?: number;
        padding?: number;
    }): Promise<void>;
    zoomBy(factor: number): void;
    reset(): void;
    get camera(): CameraController;
    play(): void;
    pause(): void;
    next(): void;
    prev(): void;
    goto(i: number): void;
    restart(): void;
    get timeline(): TimelinePlayer;
    /** Pure render-state for step `index` (-1 = overview) — no clock, no DOM. */
    stepState(index: number): StepState;
    /**
     * Apply a StepState instantly (no tweens): visibility, annotations, and the
     * step's sticky camera. Call per frame with states from stepState() to drive
     * the timeline's own semantics frame-accurately (pair with {static: true};
     * interpolate cameras yourself via mixCameras() for magic-move).
     */
    applyStepState(state: StepState): void;
    /**
     * Host-driven draw-on: sweep an element's strokes on, then fade its labels.
     * `id` = node id, edge id, or viz-item key ("block.item"); `p` = 0..1.
     */
    setRevealProgress(id: string, p: number): void;
    /**
     * Batch draw-on, and the ONLY safe form when frames are produced out of order
     * (Remotion seeks, a scrubber): every drawable NOT named in `map` is restored
     * to fully drawn, so the picture is a total function of the map rather than
     * of whatever the previous frame happened to mutate.
     *
     *   edd.setRevealProgressAll({ api: 0.4, db: 0 });  // everything else = done
     */
    setRevealProgressAll(map: Record<string, number>): void;
    /**
     * Resolve once the embedded hand-drawn font is decoded — wire it to your
     * host's "hold this frame" primitive (Remotion's `delayRender`), or a
     * headless capture will screenshot with fallback metrics and shifted text.
     */
    whenFontsReady(): Promise<void>;
    /** The renderer this facade owns — for engine-level calls the facade doesn't wrap. */
    get view(): SvgRenderer;
    /** Hide/show elements directly (ids to hide; others become visible). */
    applyVisibility(hiddenIds: Iterable<string>): void;
    /** Select the active tool. Edit tools (select/hand/rect/ellipse/diamond/
     *  text/arrow) manipulate the diagram; annotation tools (highlight/underline/
     *  mark-box/mark-circle/point/note) overlay annotations. */
    setTool(tool: string): void;
    /** Resting cursor for the active edit tool (hover overrides it live). */
    private baseCursor;
    /** Fit the whole diagram on the next render (used when loading an example). */
    fitNext(): void;
    get editor(): EditController;
    applyStyle(id: string, style: {
        fill?: string;
        stroke?: string;
        shape?: string;
    }): void;
    /** Apply a style to several nodes in one undo step. */
    applyStyleMany(ids: string[], style: {
        fill?: string;
        stroke?: string;
        shape?: string;
    }): void;
    duplicateSelected(): void;
    deleteSelected(): void;
    renameSelected(): void;
    /** Undo the current mode's last action (diagram edit, or annotation). */
    undo(): void;
    redo(): void;
    clearAnnotations(): void;
    /** Serialize live annotations into an `annotate { … }` block. */
    annotationsToCode(): string;
    get annotator(): LiveAnnotationController;
    toSVG(): Promise<string>;
    /** Synchronous `toSVG()` — nothing in the export path awaits (the font is
     *  embedded, not fetched), so it is safe inside a React `useMemo`. */
    toSVGSync(opts?: ExportOptions): string;
    toPNG(): Promise<Blob>;
    toJSON(): Scene;
    downloadSVG(): Promise<void>;
    downloadPNG(): Promise<void>;
    downloadJSON(): void;
    resize(): void;
    destroy(): void;
    private updateGrid;
    private localPoint;
    private bindInteraction;
    /** Inline text editor for renaming a node (double-click / new node). */
    private showRenameInput;
    private showTextInput;
    /**
     * Shared inline text-entry field (used for rename + sticky notes). One code
     * path so the create/focus/commit/teardown lifecycle is race-free: the blur
     * listener is detached before removal and every settle is idempotent, so
     * dismissing one input to open another can't double-remove a DOM node.
     */
    private openInlineInput;
}
//# sourceMappingURL=EdodoDraw.d.ts.map