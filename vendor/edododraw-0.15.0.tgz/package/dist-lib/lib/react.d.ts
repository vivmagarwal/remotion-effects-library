/**
 * `edododraw/react` — a thin React wrapper over the EdodoDraw facade.
 *
 *   <EdodoDrawView source={code} interactive onReady={(edd) => …} />
 *
 * React is a peer dependency; nothing here is imported by the core entry.
 */
import type { CSSProperties } from "react";
import { EdodoDraw, type EdodoDrawOptions } from "./EdodoDraw.js";
import type { Diagnostic } from "../engine/dsl/diagnostics.js";
import type { PlayerState } from "../engine/timeline/player.js";
export interface EdodoDrawViewProps extends EdodoDrawOptions {
    /** EDodoDraw source to render (re-renders whenever it changes). */
    source: string;
    className?: string;
    style?: CSSProperties;
    /**
     * Force light/dark rendering, overriding the diagram's declared theme.
     * `null`/omitted follows the DSL's own theme. See `EdodoDraw.setColorScheme`.
     */
    colorScheme?: "light" | "dark" | null;
    /** Called once with the imperative instance after mount. */
    onReady?: (edd: EdodoDraw) => void;
    onDiagnostics?: (diags: Diagnostic[]) => void;
    onState?: (state: PlayerState) => void;
}
export declare function EdodoDrawView({ source, className, style, colorScheme, onReady, onDiagnostics, onState, ...opts }: EdodoDrawViewProps): import("react").JSX.Element;
export { EdodoDraw } from "./EdodoDraw.js";
export type { EdodoDrawOptions } from "./EdodoDraw.js";
//# sourceMappingURL=react.d.ts.map