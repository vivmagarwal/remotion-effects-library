/**
 * Engine-owned CSS: @font-face for the hand-drawn fonts and the keyframes that
 * power animated arrows and annotation reveals. Injected once per document by
 * ensureEngineStyles(). Kept as a TS string so the engine is self-contained and
 * has no build-time CSS dependency.
 *
 * Fonts are the OFL-licensed Excalifont + Virgil copied from the Excalidraw
 * project into /public/fonts.
 */
/**
 * The exact `font-family` NAME of the embedded hand-drawn face — what you pass
 * to `document.fonts.load()` / `document.fonts.check()`. `FONT_FAMILY.hand` is
 * the full CSS stack (with fallbacks); this is the one family that must
 * actually be decoded before a headless frame is captured, or text is measured
 * and laid out with fallback metrics and every label shifts.
 */
export declare const EXCALIFONT_FAMILY = "Excalifont";
/** The embedded font itself, as a `data:` URI — no network fetch, ever. */
export { HAND_FONT_WOFF2_DATA_URI } from "./fontData.js";
export declare const FONT_FAMILY: {
    readonly hand: "\"Excalifont\", \"Virgil\", \"Segoe Print\", \"Comic Sans MS\", cursive";
    readonly normal: "\"Nunito\", \"Assistant\", system-ui, -apple-system, sans-serif";
    readonly code: "\"Cascadia Code\", \"Cascadia\", ui-monospace, \"SF Mono\", Menlo, monospace";
    readonly serif: "Georgia, \"Iowan Old Style\", \"Times New Roman\", serif";
};
export declare function ensureEngineStyles(doc?: Document): void;
/**
 * Resolve once the embedded hand-drawn font is actually DECODED and usable.
 *
 * `ensureEngineStyles` injects the `@font-face` fire-and-forget, so a headless
 * or frame-driven renderer can screenshot before the face is ready and get
 * fallback metrics — every label shifts, and the frame is silently wrong. Wire
 * this into whatever your host uses to hold a frame:
 *
 *   const handle = delayRender("edododraw fonts");
 *   whenFontsReady().then(() => continueRender(handle), cancelRender);
 *
 * Injects the styles first (so there is something to load), never rejects, and
 * resolves immediately in environments with no FontFaceSet (jsdom, older
 * browsers) — callers must not block forever on a missing API.
 */
export declare function whenFontsReady(doc?: Document): Promise<void>;
//# sourceMappingURL=theme.css.d.ts.map