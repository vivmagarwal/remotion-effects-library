/**
 * Paint the "figure" nodes — `character` (sketchnote person) and `icon` (line
 * glyph + caption). Their strokes are drawn INSIDE the node's own
 * <g data-node="…">, so visibility, reveal, annotations, camera focus and
 * setRevealProgress (which sweeps every stroke under the node group in DOM
 * order) all work with no special cases elsewhere in the renderer. The
 * character's strokes come from the character library as ordinary Scene IR
 * primitives; the icon is the library path scaled into the glyph square.
 */
import type rough from "roughjs";
import type { Scene, SceneNode } from "../scene/types.js";
import { type RoughRenderTuning } from "./shapes.js";
type RoughSVG = ReturnType<(typeof rough)["svg"]>;
/** Text painter supplied by the renderer (its own textBlock helper). */
export type TextPainter = (text: string, cx: number, cy: number, fontSize: number, color: string, family: SceneNode["style"]["fontFamily"], align?: SceneNode["style"]["textAlign"], weight?: number) => SVGTextElement;
export interface FigureRender {
    /** Figure body (+ any text marks the figure emits, e.g. a "?" fx). */
    body: SVGGElement;
    /** Vertical centre for the node label (inside the box, under the figure). */
    labelCy: number;
    /**
     * Ink for that caption. Figure nodes have NO filled body, so the caption sits
     * straight on the canvas — it cannot inherit the "text on top of this fill"
     * colour a filled shape gets (under `mono-accent` that is white, i.e.
     * invisible). Derived from the preset like the figure's own ink.
     */
    labelColor: string;
}
/**
 * Draw the figure for `node` and return the body group. The caller appends
 * the node label at `labelCy` (centred) like any other node.
 */
export declare function renderCharacterNode(rc: RoughSVG, scene: Scene, node: SceneNode, doc: Document, paintText: TextPainter, tune?: RoughRenderTuning): FigureRender;
/**
 * Draw the glyph for an `icon` node (stroke = node ink, no fill — sketched by
 * rough.js like every icon in the viz templates) and return the body group;
 * the caller appends the caption at `labelCy`.
 */
export declare function renderIconNode(rc: RoughSVG, scene: Scene, node: SceneNode, doc: Document, tune?: RoughRenderTuning): FigureRender;
export {};
//# sourceMappingURL=figures.d.ts.map