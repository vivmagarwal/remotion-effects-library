/**
 * Edge geometry + rendering.
 *
 * An edge is drawn as:
 *   1. a hand-drawn (rough.js) base stroke following the routed centerline,
 *   2. optional arrowheads at each end (rough, matched to the stroke),
 *   3. an optional CLEAN overlay <path> that carries the animation
 *      (flow / dash-march / draw-on / comet / gradient-flow / pulse / electric),
 *   4. an optional label chip at the midpoint.
 *
 * The clean overlay follows the exact same centerline so animations read as
 * "energy flowing along the drawn line".
 */
import type rough from "roughjs";
import type { Options } from "roughjs/bin/core";
import type { Point } from "../geometry.js";
import type { EdgeStyle, Scene, SceneEdge } from "../scene/types.js";
import { type RoughRenderTuning } from "./shapes.js";
type RoughSVG = ReturnType<(typeof rough)["svg"]>;
export declare function edgeRoughOptions(style: EdgeStyle, tune?: RoughRenderTuning): Options;
/** Resolve the two endpoints of an edge in world space, border-aware. */
export declare function resolveEndpoints(scene: Scene, edge: SceneEdge): {
    a: Point;
    b: Point;
};
/** Build the routed polyline (world points) for an edge. */
export declare function routePoints(edge: SceneEdge, a: Point, b: Point): Point[];
/** SVG path `d` for the clean overlay following the same routed points. */
export declare function centerlinePath(points: Point[], routing: SceneEdge["routing"]): string;
/**
 * Route an edge through dagre's computed waypoints (so it dodges nodes in dense
 * graphs). Returns null when there are no usable waypoints or the edge is a
 * fanned parallel edge (which handles its own bow). Endpoints are re-clipped to
 * the node borders aimed at the first/last bend.
 */
export declare function dagreRoute(scene: Scene, edge: SceneEdge): Point[] | null;
/** Catmull-Rom smooth path through points (for the animated overlay). */
export declare function smoothPath(points: Point[]): string;
export interface RenderedEdge {
    group: SVGGElement;
    points: Point[];
    centerline: string;
    length: number;
}
export declare function pathLength(points: Point[]): number;
/**
 * Render one edge into a <g>. `animId` uniquely identifies the animation
 * overlay so we can wire per-edge gradients/keyframes. `opts.static` skips the
 * animated overlay entirely (deterministic frame rendering — the hand-drawn
 * base stroke and arrowheads already depict the edge fully).
 */
export declare function renderEdge(rc: RoughSVG, scene: Scene, edge: SceneEdge, opts?: {
    static?: boolean;
} & RoughRenderTuning): RenderedEdge;
export {};
//# sourceMappingURL=edges.d.ts.map