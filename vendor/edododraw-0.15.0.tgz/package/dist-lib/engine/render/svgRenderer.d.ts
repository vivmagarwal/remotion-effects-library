/**
 * SvgRenderer — imperative renderer that owns an <svg> and paints a Scene into
 * it. React only provides the mount container; this class manages the SVG DOM
 * directly (like Excalidraw manages its canvas outside React) for full control
 * over the camera transform, animated overlays, and annotation layers.
 *
 * Layer stack (bottom -> top), all inside the camera-transformed world group
 * except the screen background/overlay:
 *   bg (screen)  <  grid  <  groups  <  edges  <  nodes  <  annotations  <  screen-overlay
 */
import type { Point } from "../geometry.js";
import type { Scene } from "../scene/types.js";
export interface CameraTransform {
    cx: number;
    cy: number;
    zoom: number;
}
export interface SvgRendererOptions {
    /**
     * Deterministic frame-by-frame rendering for screenshot/video consumers
     * (Remotion, Puppeteer, export pipelines): disables ALL wall-clock CSS —
     * visibility transitions, animated-arrow keyframes (the overlay isn't even
     * emitted), and reveal animations — so any captured frame is final, never
     * mid-transition. Drive motion explicitly via applyVisibility/applyCamera/
     * setRevealProgress instead.
     */
    static?: boolean;
    /**
     * Paint the scene's ALWAYS-ON annotations (`scene.annotations`, i.e. the
     * top-level `annotate { … }` block) as part of `render()`. Default true —
     * without it a plain `renderer.render(scene)` silently drops every mark and
     * the caller has to know to build an `AnnotationLayer` itself. Set false
     * only when something else owns the annotations layer (TimelinePlayer and
     * the `EdodoDraw` facade both re-render it right after, so they're
     * unaffected either way).
     */
    annotations?: boolean;
    /**
     * Stamp `vector-effect="non-scaling-stroke"` on every generated drawable, so
     * a 2px line stays 2px at any camera zoom instead of becoming 8px at 4x.
     * Default false (an interactive canvas wants strokes to zoom like the
     * drawing); video/punch-in hosts want it on. Pairs with
     * `setRoughnessScale()`: one holds stroke WIDTH constant on screen, the
     * other holds stroke JITTER constant.
     */
    nonScalingStroke?: boolean;
    /**
     * Initial roughness scale — see `setRoughnessScale()`. Default 1.
     */
    roughnessScale?: number;
}
export declare class SvgRenderer {
    readonly container: HTMLElement;
    /** True when constructed with `{ static: true }` — see SvgRendererOptions. */
    readonly isStatic: boolean;
    /** See SvgRendererOptions.annotations. */
    readonly paintsAnnotations: boolean;
    /** See SvgRendererOptions.nonScalingStroke. */
    readonly nonScalingStroke: boolean;
    svg: SVGSVGElement;
    private defs;
    private bg;
    world: SVGGElement;
    private layers;
    screenLayer: SVGGElement;
    private rc;
    private camera;
    private viewport;
    private scene;
    private roughnessScale;
    constructor(container: HTMLElement, options?: SvgRendererOptions);
    /** The render-time rough knobs, as every draw call wants them. */
    private roughTune;
    /** Current roughness scale — see `setRoughnessScale()`. */
    getRoughnessScale(): number;
    /**
     * Scale every `roughness` and `maxRandomnessOffset` by `k` and repaint.
     *
     * rough.js perturbs geometry in WORLD units and the camera is a
     * `scale(zoom)` on the world group, so on-screen jitter is `zoom x world
     * jitter`: a punch-in magnifies the scratchiness along with the drawing. A
     * frame-driven host cancels that by passing `k = 1/zoom`.
     *
     * Regenerating strokes is a full re-render (single-digit ms for a normal
     * diagram, but not free), so QUANTISE the zoom — e.g.
     * `k = 1 / 2 ** Math.round(Math.log2(zoom))` — and this will regenerate a
     * handful of times per composition instead of once per frame. Calling it
     * with the value it already has is a no-op, so quantised callers are safe to
     * call it every frame.
     *
     * Seeds are untouched, so the strokes stay deterministic: the same scene at
     * the same scale always draws identically.
     */
    setRoughnessScale(k: number): void;
    /**
     * Apply this renderer's stroke policy to a subtree someone else painted into
     * one of its layers (the annotation layer does exactly that). No-op unless
     * `nonScalingStroke` is on.
     */
    applyStrokePolicy(root: Element): void;
    mount(): void;
    destroy(): void;
    private defsMarkup;
    /** Read the container size; call on mount + resize. */
    measure(): {
        w: number;
        h: number;
    };
    /**
     * State the viewport explicitly instead of measuring the container.
     *
     * `measure()` reads `clientWidth`/`clientHeight`, which a frame-driven host
     * often cannot rely on: Remotion mounts a composition inside a 0x0
     * off-screen wrapper during the layout pass, so a `measure()` call from a
     * `useLayoutEffect` sees 0x0 and pins the camera viewport at 1x1 — every
     * later `applyCamera` then translates by half a pixel and the diagram lands
     * in the top-left corner. Such a host knows the real size already
     * (Remotion's `useVideoConfig()`), so it should say so.
     *
     * Non-finite or non-positive dimensions are clamped to 1, exactly as
     * `measure()` clamps them. Re-applies the current camera so the world
     * transform matches the new viewport immediately.
     */
    setViewport(size: {
        w: number;
        h: number;
    }): {
        w: number;
        h: number;
    };
    getViewportSize(): {
        w: number;
        h: number;
    };
    getCamera(): CameraTransform;
    applyCamera(cam: CameraTransform): void;
    worldToScreen(p: Point): Point;
    screenToWorld(p: Point): Point;
    getLayer(name: "grid" | "groups" | "edges" | "nodes" | "annotations" | "live"): SVGGElement;
    /** Show/hide nodes+edges for timeline reveal. `hidden` = ids to fade out. */
    applyVisibility(hidden: Set<string>): void;
    /**
     * Play a per-beat reveal animation (`fade` | `pop` | `sweep`) on the named
     * element groups. Clears any prior reveal classes first and forces a reflow so
     * re-entering the same beat restarts the animation. `fx` = id -> effect.
     */
    playReveal(fx: Record<string, string> | undefined): void;
    /**
     * Drive a hand-drawn "draw-on" reveal of one element from host code: strokes
     * sweep on in draw order (stroke-dashoffset), then labels fade in. `id` is a
     * node id, edge id, or viz-item key ("block.item" — all member elements sweep
     * as one continuous drawing). `progress` is 0..1; ≥1 restores the untouched
     * rendering (original dash patterns included), ≤0 hides the element. Built
     * for frame-driven hosts (Remotion, capture pipelines) — pair with
     * `{ static: true }` so no wall-clock CSS competes with it.
     */
    setRevealProgress(id: string, progress: number): void;
    /**
     * Batch form of {@link setRevealProgress} for frame-driven hosts, and the
     * ONLY safe one when frames are produced out of order (Remotion seeks, a
     * scrubber, a re-render worker).
     *
     * `setRevealProgress` MUTATES an element's dash pattern and only restores it
     * at `p >= 1`, so a frame that simply stops mentioning an id leaves that
     * element frozen mid-draw forever. This method takes the whole picture at
     * once: every drawable in the SVG that the map does NOT mention is restored
     * to `1` (fully drawn), so the DOM is always a total function of the map —
     * the same map always yields the same frame, whatever ran before it.
     *
     * Pass `0` to keep something un-drawn; omit an id to mean "finished".
     *
     *   renderer.setRevealProgressAll({ api: 0.4, db: 0 });   // everything else = done
     *
     * Ids are node ids, edge ids, and viz-item keys (`"block.item"`). Partial
     * progress wins over the implied restore when both address the same element
     * (a viz item and the nodes inside it), so nesting behaves as authored.
     */
    setRevealProgressAll(map: Record<string, number>): void;
    render(scene: Scene): void;
    /** The scene the last `render()` painted (null before the first one). */
    getScene(): Scene | null;
    private annotationLayerCache;
    /** Lazily-built layer for the always-on annotations painted by render(). */
    private annotationLayer;
    /** Cache of gradient-fill defs created this mount: spec -> def id. */
    private gradientIds;
    /**
     * Turn a `linear-gradient(#from,#to)` fill (emitted by gradient style
     * presets) into an SVG <linearGradient> def and return a url() reference.
     * Plain fills pass through untouched.
     */
    private resolveGradientFill;
    /** Surface viz-item membership as DOM attributes so hosts can select one
     *  data item's elements as a unit: [data-viz-item="loads.intrinsic"]. */
    private applyVizTags;
    private renderNode;
    private textBlock;
    private edgeLabel;
    private renderGroupFrame;
}
//# sourceMappingURL=svgRenderer.d.ts.map