/**
 * Shape body generation. Each ShapeKind is turned into one or more rough.js
 * drawables and returned as a single <g>. Text is NOT drawn here (the renderer
 * overlays it). Composite shapes (cylinder, cloud, document, note, actor) are
 * built from hand-authored SVG path strings so rough.js can "sketch" them.
 */
import type rough from "roughjs";
import type { Options } from "roughjs/bin/core";
import type { NodeStyle, Scene, ShapeKind } from "../scene/types.js";
type RoughSVG = ReturnType<(typeof rough)["svg"]>;
/** rough.js's own default for `maxRandomnessOffset` (generator.js). */
export declare const DEFAULT_MAX_RANDOMNESS_OFFSET = 2;
/**
 * Render-time knobs that are NOT part of the scene: how much of the authored
 * roughness to actually draw, and whether strokes should resist the camera.
 * Both come from the renderer, so the same Scene can be painted crisp for a
 * 4x punch-in and normal at 1x without recompiling.
 */
export interface RoughRenderTuning {
    /**
     * Multiplier on `roughness` and `maxRandomnessOffset`. rough.js jitters in
     * WORLD units and the camera is `scale(zoom)` on the world group, so a host
     * that passes `1/zoom` keeps SCREEN-space jitter constant through a zoom.
     */
    roughnessScale?: number;
    /** Stamp `vector-effect="non-scaling-stroke"` on every generated drawable. */
    nonScalingStroke?: boolean;
}
/**
 * Apply `vector-effect="non-scaling-stroke"` to every drawable under `root`
 * (inclusive). Under a `scale(4)` camera an SVG stroke normally quadruples
 * with it; this keeps a 2px line 2px at any zoom.
 */
export declare function applyNonScalingStroke(root: Element): void;
/**
 * rough.js options for a drawable that belongs to the diagram as a whole
 * rather than to one styled element — group frames and annotation marks. Their
 * roughness constants were tuned against `classic` (roughness 1.15), so the
 * diagram's declared roughness is applied as a RATIO of that baseline: a
 * `hand-clean` diagram gets marks a third as wobbly, a `crayon` one gets marks
 * as wobbly as its strokes, and a diagram that declared nothing gets exactly
 * the constants it always got.
 */
export declare function sceneRoughOptions(scene: Scene, baseRoughness: number, roughnessScale?: number, baseBowing?: number): {
    roughness: number;
    bowing: number;
    maxRandomnessOffset: number;
    preserveVertices: boolean;
    disableMultiStroke: boolean;
};
/** Map a NodeStyle to rough.js Options. */
export declare function nodeRoughOptions(style: NodeStyle, filled: boolean, tune?: RoughRenderTuning): Options;
export interface ShapeRect {
    x: number;
    y: number;
    w: number;
    h: number;
}
/**
 * Data payload for the data-driven primitive shapes (polygon, polyline, path,
 * sector, ring, arc, block-arrow, chevron). Generators — especially the viz
 * templates — set these on `node.data` to describe parametric geometry that
 * scales with the node box.
 */
export interface ShapeData {
    /** polygon/polyline: points normalized 0..1 within the node box. */
    points?: Array<[number, number]>;
    /** polyline: close the path back to the first point. */
    closed?: boolean;
    /** path: an SVG path in design-space local coordinates… */
    d?: string;
    /** …designed at this size; the renderer scales it to the node box. */
    vw?: number;
    vh?: number;
    /** sector/arc: angles in degrees (0 = east, clockwise). */
    start?: number;
    end?: number;
    /** sector/ring: inner radius as a fraction of the outer (donut hole). */
    inner?: number;
    /** block-arrow/chevron: direction. */
    dir?: "right" | "left" | "up" | "down";
    /** block-arrow: arrowhead length as a fraction of the long axis. */
    headRatio?: number;
    /** block-arrow: shaft thickness as a fraction of the short axis. */
    bodyRatio?: number;
    /** chevron: notch depth as a fraction of the long axis. */
    notch?: number;
}
/**
 * Draw a node body and return a <g> ready to append. Never returns text.
 * `data` carries parametric geometry for the data-driven primitives (see
 * ShapeData) — undefined for the classic shapes.
 */
export declare function renderShapeBody(rc: RoughSVG, shape: ShapeKind, rect: ShapeRect, style: NodeStyle, data?: Record<string, unknown>, tune?: RoughRenderTuning): SVGGElement;
/**
 * Shapes whose label hangs below the body instead of centering inside it.
 * Only `actor` (stick figure) qualifies — a `text` node's label IS its content
 * and must render inside its box, otherwise every text block sits half a block
 * lower than its scene geometry (which broke viz label placement).
 */
export declare function labelBelow(shape: ShapeKind): boolean;
export {};
//# sourceMappingURL=shapes.d.ts.map