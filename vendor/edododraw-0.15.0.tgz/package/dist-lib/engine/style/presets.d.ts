/**
 * Style presets — named, whole-diagram visual identities (palette, fill
 * treatment, stroke, typography, background) reverse-engineered from the
 * designer reference set in visualization_demo-lab. A preset restyles BOTH
 * classic diagrams (nodes/edges) and the viz templates through one code path:
 *
 *   meta { style: vibrant-strokes }
 *
 * Application happens in the compiler (dsl/compile.ts): the preset provides
 * base node/edge defaults below the user's `defaults`/classes/inline attrs in
 * the cascade, an ordered categorical palette (`roleStyle`) for series/items,
 * and the scene theme (background/mode/ink).
 *
 * Two palette architectures (from the reference set):
 *  - multi-hue wheel: series pick consecutive hues (fillMode solid/soft/…)
 *  - single-accent ramp: ONE color whose fill-opacity steps encode the series
 *    (fillMode "ramp") — the i-th of n series gets an evenly spaced opacity
 *    ending at 1.0 for the last.
 *
 * "Seam" strokes: several styles outline shapes in the CANVAS BACKGROUND color
 * so adjacent solids read as flat cut-outs separated by gaps (strokeMode
 * "seam"). Recomputed automatically if the background changes.
 */
import type { EdgeStyle, FillStyle, FontKind, NodeStyle, RoughTuning, SceneRough, Theme } from "../scene/types.js";
export interface PresetFonts {
    /** CSS stack (or a FontKind name like "hand") for body/labels. */
    body: string;
    /** CSS stack for section headings / emphasized labels. */
    heading: string;
    /** CSS stack for the diagram title (defaults to heading). */
    title?: string;
    /** Weight for body text (some styles set everything bold). */
    bodyWeight?: number;
    headingWeight?: number;
}
export interface StylePreset extends RoughTuning {
    /** kebab-case id used in `meta { style: <name> }`. */
    name: string;
    /** Former ids that still resolve to this preset (backwards-compatible renames). */
    aliases?: string[];
    label: string;
    description: string;
    mode: "light" | "dark";
    background: string;
    /** Ordered categorical palette. Ramp presets hold their single accent here. */
    palette: string[];
    /** The universal "other/inactive" series color. */
    neutral: string;
    /**
     * How a palette color becomes a shape's fill:
     *  - solid: flat fill in the palette color
     *  - soft: pastel fill (lightened toward white)
     *  - outline: no fill (line art)
     *  - translucent: palette color at fillOpacity
     *  - gradient: vertical linear-gradient derived from the palette color
     *  - ramp: single accent at an opacity step determined by series index/count
     */
    fillMode: "solid" | "soft" | "outline" | "translucent" | "gradient" | "ramp";
    /** rough.js fill technique (solid for clean styles, hachure for sketchy). */
    fillStyle: FillStyle;
    /** Stroke derivation: darken/same hue, neutral ink, canvas seam, or none. */
    strokeMode: "darken" | "same" | "ink" | "seam" | "none";
    strokeWidth: number;
    /**
     * Hand-drawn intensity (0..3). The inherited RoughTuning fields (`bowing`,
     * `maxRandomnessOffset`, `preserveVertices`, `disableMultiStroke`) tune the
     * SHAPE of that wobble; leaving them unset keeps rough.js's defaults, which
     * is what every preset written before video mattered does.
     */
    roughness: number;
    fonts: PresetFonts;
    /** Primary text/ink on the canvas. */
    ink: string;
    /** Secondary/muted text. */
    mutedInk: string;
    /** Connector/edge stroke. */
    edge: string;
    /** Cycle palette colors onto plain nodes that declare no color of their own. */
    autoColorNodes: boolean;
    cornerRadius: number | null;
    /** translucent fillMode: 0..1. */
    fillOpacity?: number;
    /** soft fillMode: how far toward white the fill is pushed. */
    softAmount?: number;
    /** gradient fillMode tuning. */
    gradient?: {
        to: "lighter" | "darker";
        amount: number;
    };
    /** Spot accent for the focal element (e.g. silver-beam's terracotta). */
    emphasis?: string;
}
/** The style a viz generator applies to the i-th series/item shape. */
export interface RoleStyle extends RoughTuning {
    stroke: string;
    fill: string | null;
    fillStyle: FillStyle;
    strokeWidth: number;
    roughness: number;
    /** Ink that reads on top of this fill (labels inside the shape). */
    textColor: string;
    fontFamily: FontKind;
    roundness: number | null;
    /** The raw palette color this role is based on (for labels/icons/accents). */
    color: string;
    /** A pale companion tint of the color (containers, zone washes). */
    softFill: string;
}
export interface RoleOptions {
    /** Total series count (needed by opacity-ramp presets). */
    n?: number;
    /** Explicit color override (user set `color:` on the item). */
    color?: string;
    /** Use the preset's emphasis/spot accent. */
    emphasis?: boolean;
    /** Use the preset's neutral "other" color. */
    neutral?: boolean;
}
/** Palette color for series i (wraps around, then lightens on later cycles). */
export declare function paletteColor(preset: StylePreset, i: number): string;
/** Opacity for the i-th of n series in a ramp preset (ends at 1.0). */
export declare function rampOpacity(i: number, n: number): number;
/** Derive the full shape style for series/item i under this preset. */
export declare function roleStyle(preset: StylePreset, i: number, opts?: RoleOptions): RoleStyle;
/**
 * The preset's rough.js tuning as a spreadable object, with UNSET fields
 * omitted entirely — spreading `{ bowing: undefined }` over a cascade would
 * clobber a value someone else set, and every pre-video preset leaves all four
 * unset.
 */
export declare function roughTuning(src: RoughTuning): RoughTuning;
/** True when a preset carries rough tuning of its own (i.e. it was authored
 *  with video in mind). Only the `hand-clean` family does today. */
export declare function presetDeclaresRoughTuning(preset: StylePreset): boolean;
/**
 * A copy of `preset` with the diagram's declared roughness folded in, so viz
 * templates and figures — which read `preset.roughness` directly rather than a
 * per-element style — obey `defaults { node { roughness: … } }` like everything
 * else. Returns the preset untouched when nothing was declared.
 */
export declare function tunePreset(preset: StylePreset, rough: SceneRough | undefined): StylePreset;
/** Scene theme derived from a preset. */
export declare function presetTheme(preset: StylePreset): Theme;
/** Base node style defaults a preset contributes below the user cascade. */
export declare function presetNodeDefaults(preset: StylePreset): Partial<NodeStyle>;
/** Base edge style defaults a preset contributes below the user cascade. */
export declare function presetEdgeDefaults(preset: StylePreset): Partial<EdgeStyle>;
export declare function registerStylePreset(p: StylePreset): void;
export declare function getStylePreset(name: string | undefined): StylePreset | undefined;
/** Canonical presets only (aliases don't appear as separate entries). */
export declare function listStylePresets(): StylePreset[];
/**
 * The archetypal Excalidraw look: black-and-white hand-drawn ink on white
 * paper — thick wobbly outlines, bold hand lettering, no fills. Monochrome even
 * for viz (single-ink palette), so it reads as a clean pen sketch everywhere.
 */
/**
 * The default look: black-and-white hand-drawn ink, hand lettering, no fills.
 *
 * **The strokes are deliberately CLEAN.** Up to 0.14.0 this preset ran at
 * `roughness: 1.15` with rough.js's defaults, which means two overlapping passes
 * per edge, free-floating corners and ±2px of jitter in *world* units. That
 * looks fine on a web page at scale 1 and bad anywhere a camera moves: the
 * camera is a `scale(zoom)` on the world group, so screen jitter is
 * `zoom x world jitter` and stroke width magnifies with it. Measured on a
 * 320x140 rect: 1.71px of corner error at 1x became **4.84px at 4x**, and the
 * doubled pass darkened every outline unevenly.
 *
 * `preserveVertices` pins corners to their exact coordinates (corner error ->
 * 0.00px), `disableMultiStroke` draws one confident pass instead of two, and the
 * lower `roughness`/`bowing`/`maxRandomnessOffset` keep a hand-drawn wobble
 * without the scratch. It still reads as drawn by a person; it no longer reads
 * as drawn twice.
 *
 * The pre-0.15 values live on as `classic-rough` for anyone who wants them.
 */
export declare const CLASSIC_PRESET: StylePreset;
/**
 * `classic` exactly as it was up to 0.14.0 — two passes, free corners, the full
 * ±2px jitter budget. Kept so the old look is one word away, and so a diagram
 * that WANTS to look hastily sketched can still say so.
 *
 * Do not reach for this if the camera is going to move.
 */
export declare const CLASSIC_ROUGH_PRESET: StylePreset;
/** Black-and-white classic on a dark canvas — the default when a diagram is
 *  viewed dark with no explicit style. */
export declare const CLASSIC_DARK_PRESET: StylePreset;
/** The soft-pastel COLORED hand-drawn look — a first-class style choice. */
export declare const CLASSIC_COLOR_PRESET: StylePreset;
/**
 * Hand Clean — the hand-drawn look built for VIDEO and for punch-ins.
 *
 * Everything scratchy about a rough.js stroke is a world-space perturbation,
 * so a camera `scale(4)` multiplies it by four: `classic` (roughness 1.15)
 * lands 1.71px off its ideal corners at 1x and 4.84px at 4x, and the two
 * overlapping passes double-darken every edge. This preset keeps the human
 * wobble but takes the noise out of it — `preserveVertices` pins every corner
 * exactly (corner error 1.71px -> 0.00px), `maxRandomnessOffset: 1` halves the
 * jitter budget, `bowing: 0.35` flattens the mid-segment bulge, and
 * `disableMultiStroke` draws one confident pass instead of two (path bytes
 * 1236 -> 363). Measured deviation from the ideal edge: 0.19px.
 *
 * The design: warm paper rather than clinical white, pale tints of each hue
 * under a matching outline, gently rounded corners, and connectors a step
 * softer than the ink so the boxes come forward and the wiring recedes.
 */
export declare const HAND_CLEAN_PRESET: StylePreset;
/**
 * Hand Clean on a dark stage — designed dark, not inverted. The fills become
 * translucent glass (16% of the hue over charcoal) instead of pastel blobs,
 * the palette lifts to low-chroma tints that glow without vibrating, and the
 * ink is a warm off-white so hand lettering reads as chalk rather than pixels.
 */
export declare const HAND_CLEAN_DARK_PRESET: StylePreset;
/** The reference styles (excludes the classic family and the dark auto-variants). */
export declare function listReferencePresets(): StylePreset[];
/**
 * User-facing style choices in display order (Classic B&W first — the default,
 * then Classic Colored, then the reference looks). Excludes the internal
 * `classic-dark` auto-variant.
 */
export declare function listStyleChoices(): StylePreset[];
/** Resolve the effective preset for a scene: explicit name, else the B&W classic. */
export declare function effectivePreset(name: string | undefined, mode: "light" | "dark"): StylePreset;
//# sourceMappingURL=presets.d.ts.map