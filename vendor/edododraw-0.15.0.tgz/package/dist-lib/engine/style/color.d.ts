/**
 * Small pure color helpers used by the style presets and viz generators.
 * Hex-only on purpose: presets are authored as hex tokens, and every derived
 * color must serialize straight into SVG attributes.
 */
export interface RGB {
    r: number;
    g: number;
    b: number;
}
export declare function parseHex(c: string): RGB | null;
export declare function toHex(rgb: RGB): string;
/** Linear mix of two hex colors; t=0 -> a, t=1 -> b. Non-hex inputs return `a`. */
export declare function mix(a: string, b: string, t: number): string;
export declare function lighten(c: string, t: number): string;
export declare function darken(c: string, t: number): string;
/** 8-digit hex with alpha (0..1). Falls back to the color when unparseable. */
export declare function withAlpha(c: string, alpha: number): string;
/** Perceived luma 0..255 (BT.601). Unparseable colors count as light. */
export declare function luma(c: string): number;
/** Pick a readable ink for text sitting on `bg`. */
export declare function contrastInk(bg: string | null | undefined, dark?: string, light?: string): string;
//# sourceMappingURL=color.d.ts.map