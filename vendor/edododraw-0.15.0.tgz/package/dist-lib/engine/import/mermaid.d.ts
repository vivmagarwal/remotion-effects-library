/**
 * Mermaid import — converts a mermaid diagram string into EDodoDraw Scene IR
 * fragments (nodes + edges) via @excalidraw/mermaid-to-excalidraw. Node ids are
 * preserved (mermaid ids like `grafana`), so the timeline/annotate layers can
 * reference imported elements directly.
 *
 * Runs in the browser only (mermaid renders to a hidden SVG). The pure DSL
 * compiler stays synchronous; the app awaits this and injects the result.
 */
import type { SceneEdge, SceneNode } from "../scene/types.js";
/**
 * The install hint every "mermaid didn't work" path must end with. Mermaid is
 * an OPTIONAL PEER dependency: `@excalidraw/mermaid-to-excalidraw` drags in
 * mermaid -> d3 -> cytoscape -> katex (122 packages / 66 MB versus 8 / 4.2 MB
 * without it), so `npm i edododraw` no longer installs it and diagrams that use
 * a `mermaid` block must ask for it explicitly.
 */
export declare const MERMAID_INSTALL_HINT = "the optional peer dependency @excalidraw/mermaid-to-excalidraw is not installed \u2014 run `npm i @excalidraw/mermaid-to-excalidraw` to enable `mermaid \"\"\" \u2026 \"\"\"` blocks (the rest of the diagram renders without it)";
/**
 * Is the Mermaid runtime installed? Resolves without throwing, so a host can
 * warn up front (or hide a Mermaid affordance) instead of failing per block.
 */
export declare function isMermaidAvailable(): Promise<boolean>;
export interface MermaidFragment {
    nodes: SceneNode[];
    edges: SceneEdge[];
}
/** Convert a mermaid definition into Scene IR fragments. */
export declare function convertMermaid(definition: string, mode?: "light" | "dark"): Promise<MermaidFragment>;
/**
 * Merge a mermaid fragment into a scene. If a node id already exists (e.g. a
 * `grafana:::signal` class-application placeholder), keep its cascaded style but
 * adopt the mermaid geometry/shape/label.
 */
export declare function injectMermaid(scene: import("../scene/types.js").Scene, frag: MermaidFragment): void;
/** Extract `mermaid """ … """` block bodies from EDodoDraw source. */
export declare function extractMermaidBlocks(source: string): string[];
//# sourceMappingURL=mermaid.d.ts.map