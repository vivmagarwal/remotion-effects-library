/**
 * Built-in plugin shapes — also a worked example of how a senior engineer adds
 * a new shape without touching the renderer's core switch.
 *
 * Registration is exposed as an idempotent function AND called from the
 * renderer on mount, so the built-ins survive a tree-shaking library build
 * (a bare side-effect import can be dropped by bundlers when nothing "uses" it).
 */
export declare function registerBuiltinShapes(): void;
//# sourceMappingURL=builtins.d.ts.map