/**
 * Viz module barrel.
 */
import "./generators/index.js";
export { VizContext } from "./context.js";
export type { LabelOptions, LineOptions, ShapeOptions } from "./context.js";
export { registerViz, registerVizAlias, getViz, listViz, listVizAliases, listVizTemplates, runViz } from "./registry.js";
export type { VizTemplateInfo } from "./registry.js";
export { VIZ_ALIASES } from "./aliases.js";
export { VIZ_DEMOS, listVizDemos, getVizDemo, listVizDemoCategories, listVizDemosInCategory, animatedVizDemo, animateVizSource, injectVizOptions, VIZ_ANIMATION_DEFAULTS, } from "./demos.js";
export type { VizDemo, VizAnimationOptions } from "./demos.js";
export { measureText, measureBlock, wrapText } from "./text.js";
export { iconPath, iconEntry, registerIcon, listIcons, ICON_VIEWBOX } from "./icons.js";
export { vizToScene, vizItem } from "./compose.js";
export { drawCharacter, registerCharacterPose, getCharacterPose, listCharacterPoses, registerCharacterEmotion, listCharacterEmotions, registerCharacterShirt, listCharacterShirts, registerCharacterHair, listCharacterHair, registerCharacterAccessory, listCharacterAccessories, registerCharacterFx, listCharacterFx, } from "./characters.js";
export type { CharacterPose, CharacterOptions, CharacterFrame } from "./characters.js";
export { characterNodeSpec, characterNodeBox, measureCharacterNode, emitCharacterNode, CHARACTER_NODE_DEFAULT_HEIGHT, CHARACTER_LABEL_GAP, } from "./characterNode.js";
export type { CharacterNodeSpec, CharacterNodeBox, CharacterNodeEmit } from "./characterNode.js";
export { iconNodeSpec, iconNodeBox, iconNodeGlyph, ICON_NODE_DEFAULT_SIZE, ICON_LABEL_GAP } from "./iconNode.js";
export type { IconNodeSpec, IconNodeBox } from "./iconNode.js";
export type { VizComposeOptions, VizComposeResult, VizItemInput, VizSpecInput } from "./compose.js";
export type { VizBounds, VizDef, VizGenerate, VizItem, VizOptionDoc, VizResult, VizSpec } from "./types.js";
export { itemsOf, optBool, optNum, optStr } from "./types.js";
//# sourceMappingURL=index.d.ts.map