/**
 * Visual-metaphor and comparison visualizations: balance, podium, spectrum,
 * bridge/challenges, vision, hole, trend, race, dialogue, pillar, bottleneck,
 * iceberg. Geometry per design-notes/viz-import/LAYOUT_RECIPES.md.
 */
export {};
//# sourceMappingURL=metaphor.d.ts.map