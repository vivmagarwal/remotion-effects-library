/**
 * Grid / panel visualizations: swot, pestel, quadrant, table, pros-and-cons,
 * versus, problem-solution, transformation.
 * Geometry per design-notes/viz-import/LAYOUT_RECIPES.md.
 */
export {};
//# sourceMappingURL=grid.d.ts.map