/**
 * Radial visualizations: pie, gauge, cycle, bullseye, relationship, porters,
 * impact, performance. Geometry per design-notes/viz-import/LAYOUT_RECIPES.md.
 */
export {};
//# sourceMappingURL=radial.d.ts.map