/**
 * Venn diagrams — a symmetric rosette of N equal overlapping circles (2–7),
 * exactly like the reference set: circle centres sit on a ring, adjacent
 * circles overlap, and the ring radius grows with N so 2 circles read as a
 * lens and 6–7 as a pinwheel rosette. Set labels + icons hug each circle's
 * outer lobe; `overlap [a, b] "Label"` / `overlap all "Label"` label the
 * shared regions.
 */
export {};
//# sourceMappingURL=venn.d.ts.map