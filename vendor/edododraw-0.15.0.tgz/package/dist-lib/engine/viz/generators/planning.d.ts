/**
 * Planning & analysis visualizations (viz roadmap tier 2, 2026-07):
 * okr, kanban, decision-tree, heatmap, slope-chart, tug-of-war.
 * See design-notes/viz-roadmap-2026-07.md for the selection rationale.
 */
export {};
//# sourceMappingURL=planning.d.ts.map