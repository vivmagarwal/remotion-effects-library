/**
 * Process & timeline visualizations: flowchart, sequence, timeline, journey,
 * stairs. Geometry per design-notes/viz-import/LAYOUT_RECIPES.md.
 */
export {};
//# sourceMappingURL=flow.d.ts.map