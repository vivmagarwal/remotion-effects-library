/**
 * Sketchnote-native visualizations (learned from the classic sketchnoting
 * vocabulary — skeleton library, character work, containers): personas,
 * quote, clouds, fishbone. Characters come from ../characters.ts.
 */
export {};
//# sourceMappingURL=sketchnote.d.ts.map