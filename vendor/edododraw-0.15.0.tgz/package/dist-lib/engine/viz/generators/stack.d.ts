/**
 * Stacked-band visualizations: funnel, pyramid, list, key-ideas.
 * Geometry follows design-notes/viz-import/LAYOUT_RECIPES.md.
 */
export {};
//# sourceMappingURL=stack.d.ts.map