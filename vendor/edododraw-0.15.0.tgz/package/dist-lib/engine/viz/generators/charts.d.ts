/**
 * Data charts: bar, bar-horizontal, stacked-bar(±horizontal), line, area,
 * waterfall, dumbbell-vertical/horizontal, gantt, sankey, drop-off.
 * Geometry per design-notes/viz-import/LAYOUT_RECIPES.md.
 */
export {};
//# sourceMappingURL=charts.d.ts.map