/**
 * Tree/fan-shaped visualizations: mindmap (+ side/orientation variants),
 * decision, root-causes, converge/lens, diverge, prism.
 * Geometry follows design-notes/viz-import/LAYOUT_RECIPES.md.
 */
export {};
//# sourceMappingURL=tree.d.ts.map