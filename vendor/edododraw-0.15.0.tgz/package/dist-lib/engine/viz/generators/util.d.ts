/**
 * Shared geometry/label helpers for the built-in viz generators.
 */
import type { VizContext } from "../context.js";
import type { VizBounds } from "../types.js";
import type { TextAlign } from "../../scene/types.js";
export declare const rad: (deg: number) => number;
export declare const lerp: (a: number, b: number, t: number) => number;
export declare const polar: (cx: number, cy: number, r: number, deg: number) => [number, number];
export declare function fmtNum(v: number): string;
/** Horizontal alignment for a label sitting outside a circle at `deg`. */
export declare function radialAlign(deg: number): TextAlign;
/**
 * Place a label+detail block outside a circle of radius `r` at angle `deg`,
 * guaranteed clear of the figure for ANY block size: the block is measured
 * first (wrapping included) and its center pushed out along the radial
 * direction by the block's own projected half-extent, so even a long
 * multi-line description never crosses the shape.
 */
export declare function radialLabel(ctx: VizContext, cx: number, cy: number, r: number, deg: number, label: string, detail: string | undefined, color: string, opts?: {
    maxW?: number;
    gap?: number;
    size?: number;
}): VizBounds;
/**
 * Closed scalloped cloud outline: `bumps` outward arc bulges around an
 * ellipse, in local path coords inside a (2rx × 2ry) box. Deterministic
 * wobble (index-driven) keeps re-renders stable.
 */
export declare function scallopedBlob(rx: number, ry: number, bumps: number): string;
//# sourceMappingURL=util.d.ts.map