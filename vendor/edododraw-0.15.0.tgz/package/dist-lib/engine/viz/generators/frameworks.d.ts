/**
 * Frameworks & metaphors, round 3 (viz roadmap tier 3, 2026-07):
 * business-model-canvas, ecosystem, swimlane-flow, bullet-chart,
 * domino, lighthouse, magnet.
 * See design-notes/viz-roadmap-2026-07.md for the selection rationale.
 */
export {};
//# sourceMappingURL=frameworks.d.ts.map