/**
 * Strategy & planning visualizations (viz roadmap tier 1, 2026-07):
 * flywheel, radar, roadmap-lanes, milestone-path, value-chain, pricing-tiers.
 * See design-notes/viz-roadmap-2026-07.md for the selection rationale.
 */
export {};
//# sourceMappingURL=strategy.d.ts.map