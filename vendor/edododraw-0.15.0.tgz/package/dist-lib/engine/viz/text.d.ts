/**
 * Pure text metrics for viz generators — the compiler is DOM-free, so widths
 * are estimated from per-font average character widths. Estimates err slightly
 * wide so labels never overflow their reserved space.
 */
import type { FontKind } from "../scene/types.js";
/** Estimated pixel width of a single line. */
export declare function measureText(text: string, fontSize: number, font?: FontKind): number;
/** Widest line of a multi-line string. */
export declare function measureBlock(text: string, fontSize: number, font?: FontKind): {
    w: number;
    h: number;
    lines: number;
};
/** Greedy word-wrap to a max pixel width; keeps explicit newlines. */
export declare function wrapText(text: string, maxWidth: number, fontSize: number, font?: FontKind, maxLines?: number): string;
//# sourceMappingURL=text.d.ts.map