/**
 * The visualization demo catalog — one runnable `.edd` demo per registered viz
 * template, grouped by category, plus the animated (`animate:` / `hold:` /
 * `animateCamera:`) form of each.
 *
 * This is the single source of truth for the site's Visualizations gallery, the
 * docs examples, the visual QA sweep, and any consumer of the package (a
 * Remotion gallery, an LLM prompt builder, a screenshot farm). It ships inside
 * the published package — `import { VIZ_DEMOS } from "edododraw"`, or
 * `from "edododraw/demos"` for the catalog alone.
 *
 * Deliberately dependency-free: this module imports nothing, so `edododraw/demos`
 * costs a consumer a few KB of strings and pulls in no renderer, no dagre and no
 * rough.js. `tests/viz-demos.test.ts` is what keeps it honest — it asserts the
 * catalog covers every name in `listVizTemplates()`, that every demo compiles
 * with zero error diagnostics, and that each one produces the viz type it claims.
 */
export interface VizDemo {
    /** viz type name — matches a `listVizTemplates()` entry exactly. */
    type: string;
    /** Catalog grouping (a presentation category, not the registry category). */
    category: string;
    /** Human title for a card or heading. */
    title: string;
    /** One line on what the template is for and which options matter. */
    description: string;
    /** Runnable `.edd` source. Compiles with zero error diagnostics. */
    code: string;
}
export declare const VIZ_DEMOS: VizDemo[];
/** Every demo, in catalog order (one per registered template). */
export declare function listVizDemos(): VizDemo[];
/** The demo for one viz template name (exact, then case-insensitive). */
export declare function getVizDemo(type: string): VizDemo | undefined;
/** Catalog categories in presentation order (a gallery's section headings). */
export declare function listVizDemoCategories(): string[];
/** The demos in one category, in catalog order. */
export declare function listVizDemosInCategory(category: string): VizDemo[];
/** Options for `animatedVizDemo` / `animateVizSource`. */
export interface VizAnimationOptions {
    /**
     * Reveal effect per beat: `"draw-on"` (default), `"fade"`, `"pop"`, `"sweep"`,
     * or `true` for the compiler default. `false` omits the option entirely —
     * which, since `animate:` is what switches auto-choreography on, means no
     * timeline at all.
     */
    animate?: "draw-on" | "fade" | "pop" | "sweep" | true | false;
    /** Auto-advance dwell per beat, in seconds (default 1.5). `false` omits it. */
    hold?: number | false;
    /** Focus each item with a magic-move camera (default true). */
    animateCamera?: boolean;
}
/** What `animatedVizDemo(type)` injects when you pass no options. */
export declare const VIZ_ANIMATION_DEFAULTS: {
    readonly animate: "draw-on";
    readonly hold: 1.5;
    readonly animateCamera: true;
};
/**
 * Inject block-level options into every top-level `viz … { … }` block of an
 * `.edd` source, skipping any option the source already sets. Pure text
 * surgery — it never reformats the rest of the file — and quote-, comment- and
 * brace-aware so a `"""…"""` mermaid block or a nested `{ … }` can't fool it.
 */
export declare function injectVizOptions(code: string, lines: string[]): string;
/**
 * The animated form of an `.edd` source: the same diagram with
 * `animate: draw-on`, `hold: 1.5` and `animateCamera: true` added to each
 * top-level `viz` block, which is what makes the compiler synthesize a
 * multi-beat storyboard — an overview beat, one captioned beat per data item
 * (with `autoAdvanceMs` from `hold`), and a closing fit-all — in `scene.steps`.
 */
export declare function animateVizSource(code: string, opts?: VizAnimationOptions): string;
/**
 * The animated form of a catalog demo, ready for a frame-driven host:
 *
 * ```ts
 * const { scene } = compileEdd(animatedVizDemo("flowchart"));
 * scene.steps; // overview + one captioned beat per item + fit-all
 * ```
 *
 * Throws on an unknown template name — pass a `listVizDemos()` type.
 */
export declare function animatedVizDemo(type: string, opts?: VizAnimationOptions): string;
//# sourceMappingURL=demos.d.ts.map