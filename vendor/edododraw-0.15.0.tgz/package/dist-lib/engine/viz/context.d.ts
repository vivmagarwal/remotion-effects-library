/**
 * VizContext — the toolkit a viz generator draws with. Wraps the Scene IR
 * factories with viz-friendly helpers (role colors from the active style
 * preset, measured/wrapped text blocks, primitive shapes, arrows) and collects
 * the emitted elements. Coordinates are generator-local; the compiler offsets
 * the finished block into place.
 */
import type { Annotation, EdgeStyle, FontKind, NodeStyle, SceneEdge, SceneNode, ShapeKind, TextAlign } from "../scene/types.js";
import type { DiagnosticBag } from "../dsl/diagnostics.js";
import { type RoleOptions, type RoleStyle, type StylePreset } from "../style/presets.js";
import { type CharacterOptions } from "./characters.js";
import type { VizBounds, VizItem, VizResult } from "./types.js";
export interface LabelOptions {
    size?: number;
    color?: string;
    align?: TextAlign;
    /** Vertical anchor of the block relative to y: "middle" (default) | "top". */
    vAnchor?: "middle" | "top";
    weight?: number;
    /** "body" | "heading" | "title" (preset fonts) or a raw FontKind/CSS stack. */
    font?: string;
    /** Wrap to this pixel width. */
    maxW?: number;
    maxLines?: number;
    id?: string;
    z?: number;
    opacity?: number;
    /** Semantic tag ("label" | "value" | "detail" | …) — see VizContext.item(). */
    role?: string;
}
export interface ShapeOptions {
    id?: string;
    label?: string;
    z?: number;
    data?: Record<string, unknown>;
    style?: Partial<NodeStyle>;
    /** Semantic tag ("shape" | "icon" | …) — see VizContext.item(). */
    role?: string;
}
export interface LineOptions {
    id?: string;
    color?: string;
    width?: number;
    dash?: boolean;
    dotted?: boolean;
    z?: number;
    /** Draw an arrowhead at the end (as part of the polyline node group). */
    arrow?: boolean;
}
export declare class VizContext {
    readonly vizId: string;
    readonly preset: StylePreset;
    readonly mode: "light" | "dark";
    readonly diags: DiagnosticBag;
    /** From the block's `showValues:` option — generators consult showValue(). */
    readonly showValues: boolean;
    readonly nodes: SceneNode[];
    readonly edges: SceneEdge[];
    readonly annotations: Annotation[];
    /** Set by generators that place the title themselves (e.g. below the chart). */
    titleHandled: boolean;
    private seq;
    private usedIds;
    private currentItem;
    constructor(vizId: string, preset: StylePreset, mode: "light" | "dark", diags: DiagnosticBag, 
    /** From the block's `showValues:` option — generators consult showValue(). */
    showValues?: boolean);
    /**
     * Run `fn` with every emitted element tagged as belonging to data item
     * `itemId`: members carry `data.vizItem = "<vizId>.<itemId>"` (plus a
     * `data.vizRole` semantic tag) and surface in the DOM as
     * `data-viz-item`/`data-viz-role` attributes, so hosts can select or
     * choreograph one item's elements as a unit. Query members with
     * vizItemMembers(); `<vizId>.<itemId>` also works as an annotation/camera/
     * reveal target.
     */
    item<T>(itemId: string, fn: () => T): T;
    /** The `data` payload for an element emitted under the current item scope. */
    private tagged;
    /** Should this item's numeric value be printed? (block `showValues:` +
     *  per-item `showValue:` — values still drive geometry either way). */
    showValue(item: VizItem): boolean;
    get ink(): string;
    get mutedInk(): string;
    /** Role style for series/item i under the active preset. */
    role(i: number, opts?: RoleOptions): RoleStyle;
    /** Resolve a font slot name to a FontKind/CSS stack. */
    font(slot: string | undefined): FontKind;
    uid(hint?: string): string;
    /** Emit a shape node styled by a RoleStyle (or raw style overrides). */
    shape(shape: ShapeKind, x: number, y: number, w: number, h: number, role: RoleStyle | Partial<NodeStyle>, opts?: ShapeOptions): SceneNode;
    /** Polygon from absolute local points (auto-normalized into a node box). */
    poly(points: Array<[number, number]>, role: RoleStyle | Partial<NodeStyle>, opts?: ShapeOptions): SceneNode;
    /** Open polyline from absolute local points (stroke only). */
    line(points: Array<[number, number]>, opts?: LineOptions): SceneNode;
    /** Chevron arrowhead at (x2,y2) aimed from (x1,y1). */
    arrowhead(x1: number, y1: number, x2: number, y2: number, color: string, width?: number, z?: number): SceneNode;
    /** Straight arrow drawn as polyline + head (all local coords). */
    arrow(x1: number, y1: number, x2: number, y2: number, opts?: LineOptions): void;
    /** A path shape designed at (vw × vh), placed in box x/y/w/h. */
    path(d: string, vw: number, vh: number, x: number, y: number, w: number, h: number, role: RoleStyle | Partial<NodeStyle>, opts?: ShapeOptions): SceneNode;
    /** A known line-icon glyph, centered at (cx, cy). Unknown names no-op. */
    icon(name: string | undefined, cx: number, cy: number, size: number, color: string, z?: number): SceneNode | null;
    /** Scene edge between two emitted nodes (or free points via `at`). */
    edge(from: string | {
        x: number;
        y: number;
    }, to: string | {
        x: number;
        y: number;
    }, opts?: {
        id?: string;
        label?: string;
        style?: Partial<EdgeStyle>;
        routing?: SceneEdge["routing"];
        fromAnchor?: string;
        toAnchor?: string;
    }): SceneEdge;
    measure(text: string, size: number, font?: string): number;
    wrap(text: string, maxWidth: number, size: number, font?: string, maxLines?: number): string;
    /**
     * Emit a text node. `x` is the anchor per `align` (center by default);
     * `y` is the vertical center of the block ("top" anchors the first line).
     */
    label(text: string, x: number, y: number, opts?: LabelOptions): SceneNode;
    /** Measure the label+detail block exactly as labelBlock will lay it out. */
    measureLabelBlock(label: string, detail: string | undefined, opts?: {
        maxW?: number;
        size?: number;
    }): {
        w: number;
        h: number;
    };
    /** Item label (fs 20, colored) + optional detail (fs 15, ink) block. */
    labelBlock(label: string, detail: string | undefined, x: number, y: number, opts?: {
        color?: string;
        align?: TextAlign;
        maxW?: number;
        vAnchor?: "middle" | "top" | "bottom";
        size?: number;
    }): VizBounds;
    /** Sketchnote character with its feet at (cx, groundY) — see characters.ts
     *  for poses, emotions, and props. Returns the drawn bounds. */
    character(pose: string, cx: number, groundY: number, h: number, opts?: Omit<CharacterOptions, "pose">): VizBounds;
    /** Diagram title in the preset's title font. */
    title(text: string, cx: number, y: number, opts?: {
        size?: number;
        color?: string;
    }): SceneNode;
    bounds(): VizBounds;
    result(): VizResult;
}
//# sourceMappingURL=context.d.ts.map