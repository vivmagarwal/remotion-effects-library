/**
 * BODY STYLES — the `shirt:` axis. Each drawer paints the figure's torso.
 *
 * THE BEAN. The default body is an oval that is narrow at the shoulders,
 * widest just under the chest and tucked at the hem (`bodyHalfWidth` in
 * types.ts). This is the single change that separates a drawn person from an
 * assembled diagram: a rectangle reads as furniture, an oval reads as a body.
 * v1 drew a 0.20-wide rounded rectangle and every figure looked like a fridge.
 *
 * AUTHORING RULE — never write a raw unit x in this file. Use `f.B(k, y)`,
 * where k is a fraction of the body's half-width at that height (-1 = left
 * edge, +1 = right edge). A collar written as `f.B(-0.55, 0.27)` stays on the
 * collarbone if the body is ever reshaped; a collar written as `-0.055` does
 * not. `f.B` already carries the lean shear, so clothes tilt with the body.
 *
 * `f.accent` carries the caller's shirtColor (fills, stripes, ties).
 */
export {};
//# sourceMappingURL=shirts.d.ts.map