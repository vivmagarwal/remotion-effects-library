/**
 * Hair styles — drawn on and around the head circle (crown = the top arc,
 * angles 200°→340° in the frame's y-down convention). `f.accent` is the hair
 * colour. Masses are placed at the sides/crown so they never cover the face,
 * which is painted after hair.
 *
 * THE BROW RULE (v2, 2026-08-23). No hair stroke may dip into the band just
 * above the eyes. v1's `bob` drew a fringe as a chevron — high at the temples,
 * dipping to mid-forehead — which is, stroke for stroke, an angry unibrow: the
 * whole cast read as scowling at `emotion: neutral` and the film had to be
 * rejected before anyone traced it to the hair. A fringe must curve WITH the
 * crown (∩) or not exist. Keep every mass above `head.cy - r*0.5` or outside
 * the rim, and check any new style against `emotion: neutral` before shipping.
 */
export {};
//# sourceMappingURL=hair.d.ts.map