/**
 * The character renderer. Builds a CharacterFrame (all coordinates
 * pre-transformed) and drives the per-axis drawers in paint order:
 *
 *   shadow → legs+feet → body/shirt → arms+hands → head → hair → face
 *          → accessory → motion+prop → fx
 *
 * Three rules carry the whole look (see types.ts for where they come from):
 *   1. NO NECK. The head's chin lands on the body's top edge and the head is
 *      painted last over it, so the join is a single clean silhouette.
 *   2. ARMS LEAVE THE BODY. Each arm's root snaps onto the body outline at its
 *      own height, so arms never float beside the figure or start inside it —
 *      whatever body shape or garment is in use.
 *   3. HANDS AND FEET ARE LOOPS, not blobs. A small open circle at the tip of
 *      a limb is the single most characteristic stroke of this drawing style.
 *
 * The lean model is the key correctness invariant: the upper body (head,
 * neck, torso, arms, face, hair, accessory) is SHEARED forward by the pose's
 * `lean` — everything above the hips tilts together, so a leaning figure's
 * head never floats off its torso. Legs are never sheared, so the feet stay
 * planted where the pose authored them.
 */
import type { VizContext } from "../context.js";
import type { StylePreset } from "../../style/presets.js";
import { type CharacterOptions } from "./types.js";
/**
 * The ink a figure is actually drawn in.
 *
 * A character is LINE ART: if its stroke matches the canvas the whole figure
 * disappears. Some presets legitimately hand shapes a background-coloured
 * outline — `mono-accent`'s `strokeMode: "seam"` makes adjacent solid blocks
 * read as cut-outs — which is right for a filled rectangle and fatal for a
 * stick figure. So the requested ink is checked against the preset background
 * and, when it would vanish, falls back to the preset ink (then to plain
 * contrast ink). Nothing is hardcoded: every candidate comes from the preset.
 * Non-hex colours are trusted as-is (we can't measure them).
 */
export declare function characterInk(want: string | undefined, preset: StylePreset): string;
/**
 * The ground shadow's fill: the preset's background nudged ~7% toward its ink.
 * Derived, never hardcoded, so a dark preset gets a lighter shadow and a light
 * one gets a darker shadow, and neither ever competes with the figure.
 */
export declare function shadowInk(preset: StylePreset): string;
/**
 * Draw a character with its FEET at `(cx, groundY)` and total height `h`.
 * Emits ordinary scene elements through `ctx` (so item scoping, presets, and
 * deterministic strokes all apply). Returns the drawn bounds.
 */
export declare function drawCharacter(ctx: VizContext, cx: number, groundY: number, h: number, opts?: CharacterOptions): {
    x: number;
    y: number;
    w: number;
    h: number;
};
//# sourceMappingURL=draw.d.ts.map