/**
 * Facial expressions — the workbook's eyes+mouth grid, reimplemented as
 * strokes. Each drawer paints only the face (eyes, brows, mouth, and any
 * face-local tears/blush); floating marks like "?" or sweat live in fx.ts.
 * Geometry is read from `f.face` (eye/mouth anchors, already sheared).
 */
export {};
//# sourceMappingURL=faces.d.ts.map