/**
 * Pose library — limb polylines in the unit frame (see types.ts). Arms are
 * authored UN-sheared; the renderer shears them forward with the pose's
 * `lean`, so a forward-leaning pose only needs to describe the gesture, not
 * compensate for the tilt. Grounded feet MUST end at y = 1.0 (GROUND_Y);
 * lifted feet stay above and skip the foot tick. Poses that leave the ground
 * set `airborne: true`.
 *
 * DEFAULT EMOTION — every pose declares `emotion:` EXPLICITLY. It is the face
 * a figure wears when the author wrote no `emotion:` of their own, so it must
 * never be a loaded expression: `neutral` is the deliberate choice for any
 * pose whose mood is ambiguous (effort, locomotion, gesturing). No pose
 * defaults to `determined` or `angry` — a figure nobody gave a mood must not
 * arrive on screen scowling. Authors opt IN to `determined` (now a firm,
 * level-browed resolve — see faces.ts) when the beat calls for it.
 */
export {};
//# sourceMappingURL=poses.d.ts.map