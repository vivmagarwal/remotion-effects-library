/**
 * Runtime registries for every character axis. Each axis is a Map keyed by
 * name, preserving insertion order (so listings are stable and the built-ins
 * come first). Consumers extend any axis at runtime:
 *
 *   registerCharacterPose("dabbing", { armL, armR, legL, legR });
 *   registerCharacterEmotion("smirk", (f) => { … });
 *   registerCharacterHair("mohawk", (f) => { … });
 *
 * The gallery and llms.txt enumerate these lists, so a registered variant is
 * discoverable everywhere the built-ins are.
 */
import type { CharacterPose, FaceDrawer, ShirtDrawer, HairDrawer, AccessoryDrawer, FxDrawer } from "./types.js";
/** Register a pose (consumers may add their own or shadow built-ins). */
export declare function registerCharacterPose(name: string, pose: CharacterPose): void;
export declare function getCharacterPose(name: string): CharacterPose | undefined;
export declare function listCharacterPoses(): string[];
export declare function registerCharacterEmotion(name: string, draw: FaceDrawer): void;
export declare function getCharacterEmotion(name: string): FaceDrawer | undefined;
export declare function listCharacterEmotions(): string[];
export declare function shirtDrawsArms(name: string | undefined): boolean;
/** Declare that a registered body style draws its own arms. */
export declare function registerSelfArmedShirt(name: string): void;
export declare function registerCharacterShirt(name: string, draw: ShirtDrawer): void;
export declare function getCharacterShirt(name: string): ShirtDrawer | undefined;
export declare function listCharacterShirts(): string[];
export declare function registerCharacterHair(name: string, draw: HairDrawer): void;
export declare function getCharacterHair(name: string): HairDrawer | undefined;
export declare function listCharacterHair(): string[];
export declare function registerCharacterAccessory(name: string, draw: AccessoryDrawer): void;
export declare function getCharacterAccessory(name: string): AccessoryDrawer | undefined;
export declare function listCharacterAccessories(): string[];
export declare function registerCharacterFx(name: string, draw: FxDrawer): void;
export declare function getCharacterFx(name: string): FxDrawer | undefined;
export declare function listCharacterFx(): string[];
//# sourceMappingURL=registry.d.ts.map