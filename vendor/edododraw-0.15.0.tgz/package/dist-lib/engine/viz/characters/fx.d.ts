/**
 * Emanata — the floating "state marks" of comic/sketchnote grammar (sweat,
 * "?", idea bulb, anger vein, sparkles…). Each floats near the head; `f.accent`
 * is the mark colour. A pose can set a default (e.g. `exhausted` → sweat) and
 * a call can override with `fx:`.
 */
export {};
//# sourceMappingURL=fx.d.ts.map