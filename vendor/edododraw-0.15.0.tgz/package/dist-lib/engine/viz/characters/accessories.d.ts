/**
 * Worn accessories — drawn over the face/head (glasses, hats, facial hair,
 * headphones…). `f.accent` is the accessory colour. These paint last on the
 * head so they read as "on top of" the figure.
 */
export {};
//# sourceMappingURL=accessories.d.ts.map