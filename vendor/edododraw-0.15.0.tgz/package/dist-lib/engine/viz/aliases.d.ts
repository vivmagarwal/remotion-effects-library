/**
 * LLM-friendly aliases — the natural words a person or model reaches for when
 * describing an intent ("leaderboard", "conversion funnel", "cause and effect",
 * "constraint") mapped to the canonical `viz` template that renders it. Kept in
 * ONE place (not scattered across generators) so the whole synonym surface is
 * auditable and collision-checked (`registerVizAlias` skips duplicates).
 *
 * These are IN ADDITION to each generator's own inline `aliases`. Canonical
 * names and existing inline aliases are never re-listed here.
 */
export declare const VIZ_ALIASES: Record<string, string[]>;
/** Register every alias in VIZ_ALIASES against its canonical template. */
export declare function applyVizAliases(): void;
//# sourceMappingURL=aliases.d.ts.map