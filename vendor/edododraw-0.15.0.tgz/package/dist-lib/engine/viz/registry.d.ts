/**
 * Viz template registry — like the shape plugin registry, this is the seam
 * that makes new visualization types a no-grammar-change addition: register a
 * generator and `viz <name> { … }` works immediately.
 */
import type { DiagnosticBag } from "../dsl/diagnostics.js";
import type { StylePreset } from "../style/presets.js";
import type { VizDef, VizOptionDoc, VizResult, VizSpec } from "./types.js";
export declare function registerViz(def: VizDef): void;
/**
 * Register an extra LLM-friendly alias for an already-registered template.
 * Silently skips (and warns in dev) on a name/alias collision so one careless
 * synonym can never shadow a real template.
 */
export declare function registerVizAlias(alias: string, canonical: string): void;
export declare function getViz(name: string): VizDef | undefined;
/** Every alias -> canonical-name mapping (for docs + the language spec). */
export declare function listVizAliases(): Array<{
    alias: string;
    canonical: string;
}>;
/** Machine-readable catalog entry — see listVizTemplates(). */
export interface VizTemplateInfo {
    name: string;
    aliases: string[];
    category: string;
    summary: string;
    entryKinds: string[];
    options: VizOptionDoc[];
    sweetSpot?: {
        min: number;
        max: number;
    };
}
/**
 * Machine-readable template catalog (name, aliases, entry kinds, options,
 * sweet-spot item counts) so tooling can validate `.edd` viz blocks before
 * rendering. Every template also accepts `showValues: false` (suppress printed
 * numbers) and per-item `color:` / `icon:` / `detail:` attributes.
 */
export declare function listVizTemplates(): VizTemplateInfo[];
/** Unique defs (aliases deduped), sorted by category then name. */
export declare function listViz(): VizDef[];
/**
 * Run the generator for a spec. Adds the title above the content when the
 * generator didn't place it itself. Returns null (with a diagnostic) for
 * unknown types.
 */
export declare function runViz(spec: VizSpec, preset: StylePreset, mode: "light" | "dark", diags: DiagnosticBag): VizResult | null;
//# sourceMappingURL=registry.d.ts.map