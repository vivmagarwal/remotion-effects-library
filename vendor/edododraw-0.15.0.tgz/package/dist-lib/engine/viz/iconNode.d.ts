/**
 * Standalone `icon` nodes — one line-glyph from the icon library with a
 * caption under it, as an ordinary Scene IR node:
 *
 *   icon ramp "Scaffold" { icon: scaffold, size: 72 }
 *   icon wheelchair "Wheelchair"          // icon name defaults to the id
 *
 * `{ shape: "icon", data: { icon: IconNodeSpec } }` with a real bbox (glyph
 * square + label row), so it lays out, connects, focuses, reveals, annotates
 * and draws on like any node. The classic sketchnote "icon + word" unit.
 */
import type { NodeStyle, SceneNode } from "../scene/types.js";
/** Glyph size (scene units) when `size:` is omitted. */
export declare const ICON_NODE_DEFAULT_SIZE = 64;
export declare const ICON_NODE_MIN_SIZE = 12;
/** Gap between the glyph and its caption. */
export declare const ICON_LABEL_GAP = 8;
export interface IconNodeSpec {
    /** Registered icon name (or alias). Unknown → nothing drawn, label kept. */
    name: string;
    /** Glyph square size in scene units. */
    size: number;
}
/** Read the spec off a node (null when it isn't an icon node). */
export declare function iconNodeSpec(node: SceneNode): IconNodeSpec | null;
export interface IconNodeBox {
    w: number;
    h: number;
    labelH: number;
}
/** Size the node box: glyph square ∪ label width, plus the label row. */
export declare function iconNodeBox(spec: IconNodeSpec, label: string, style: NodeStyle): IconNodeBox;
/**
 * Where the glyph sits inside the node box (centred in the area above the
 * label row, scaled down if the box was shrunk) + the path to draw. `null`
 * path when the icon name is unknown.
 */
export declare function iconNodeGlyph(node: SceneNode): {
    x: number;
    y: number;
    size: number;
    d: string | null;
    viewBox: number;
    labelH: number;
};
//# sourceMappingURL=iconNode.d.ts.map