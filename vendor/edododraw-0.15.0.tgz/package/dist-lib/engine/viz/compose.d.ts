/**
 * Programmatic viz composition — build visualizations on the fly, no DSL text
 * required. A host constructs VizSpec objects (plain data: type + items +
 * options), and vizToScene() turns them into a render-ready Scene exactly the
 * way the compiler does for `viz { … }` blocks: same generators, same style
 * presets, same vertical stacking. Pure and DOM-free (like compileEdd), so it
 * works in Node, workers, and build steps.
 *
 *   const { scene } = vizToScene({
 *     type: "funnel", id: "sales", title: "Pipeline",
 *     items: [vizItem("Leads", 1200), vizItem("Won", 36)],
 *   }, { style: "chalkboard" });
 *   edd.renderScene(scene);
 */
import { DiagnosticBag } from "../dsl/diagnostics.js";
import type { Scene } from "../scene/types.js";
import type { VizItem } from "./types.js";
export interface VizComposeOptions {
    /** Style preset name (see docs/STYLES_GUIDE); default = Classic B&W. */
    style?: string;
    mode?: "light" | "dark";
    /** Vertical gap between stacked blocks (px). Default 100, like the DSL. */
    gap?: number;
    diagnostics?: DiagnosticBag;
}
export interface VizComposeResult {
    scene: Scene;
    diagnostics: DiagnosticBag;
}
/** A VizItem where only `label` is required — defaults are filled in. */
export type VizItemInput = Partial<VizItem> & {
    label: string;
};
/** A VizSpec where only `type` is required — defaults are filled in. */
export interface VizSpecInput {
    type: string;
    id?: string;
    title?: string;
    options?: Record<string, unknown>;
    items?: VizItemInput[];
}
/**
 * Generate one or more viz specs into a Scene (blocks stack vertically in
 * order). Unknown types / bad data surface on `diagnostics`, never throw.
 */
export declare function vizToScene(specs: VizSpecInput | VizSpecInput[], opts?: VizComposeOptions): VizComposeResult;
/** Sugar for building VizSpec items: vizItem("Leads", 1200, { icon: "user" }). */
export declare function vizItem(label: string, value?: number, extra?: Partial<VizItem>): VizItem;
//# sourceMappingURL=compose.d.ts.map