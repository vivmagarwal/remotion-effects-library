/**
 * Minimal line-icon glyph library for viz templates (`icon: rocket` on an
 * item). Hand-authored 24×24 stroke-only paths, sketched by rough.js like any
 * other shape so they inherit the hand-drawn look. Unknown names render
 * nothing (generators lay out fine without icons).
 */
export declare const ICON_VIEWBOX = 24;
/**
 * Register a custom icon usable from any viz item (`icon: mylogo`) — stroke
 * paths only (they're sketched by rough.js like everything else, so filled
 * paths won't look right). `viewBox` is the square design size the path was
 * authored at (default 24, like the built-ins). Re-registering a name
 * replaces it; built-in names can be shadowed.
 */
export declare function registerIcon(name: string, d: string, opts?: {
    viewBox?: number;
    aliases?: string[];
}): void;
/** Resolve an icon name (or alias) to its path + design viewBox. */
export declare function iconEntry(name: string | undefined): {
    d: string;
    viewBox: number;
} | undefined;
export declare function iconPath(name: string | undefined): string | undefined;
export declare function listIcons(): string[];
//# sourceMappingURL=icons.d.ts.map