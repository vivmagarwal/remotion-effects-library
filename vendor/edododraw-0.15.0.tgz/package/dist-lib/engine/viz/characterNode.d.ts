/**
 * Standalone `character` nodes — a sketchnote figure that stands next to a
 * diagram as ONE ordinary Scene IR node:
 *
 *   character brad "Brad" { pose: thinking, emotion: curious, hair: short,
 *                           shirt: hoodie, accessory: glasses, fx: question,
 *                           prop: bulb, height: 240, flip: true }
 *
 * The node is `{ shape: "character", data: { character: CharacterNodeSpec } }`
 * with a real bbox (the figure's drawn extents at `height`, plus the label
 * under the feet), so layouts, edge anchors, camera focus, reveal, annotate
 * and setRevealProgress all treat it like any other node. This module is the
 * bridge between that node and the parametric character library
 * (viz/characters): the compiler uses `characterNodeBox()` to size the node
 * (pure, DOM-free) and the renderer uses `emitCharacterNode()` to get the
 * figure's strokes as sub-elements to paint inside the node's <g>.
 *
 * Deterministic: the figure is emitted through a VizContext keyed by the node
 * id, so every stroke's rough seed derives from `<nodeId>.<part>` — identical
 * across compile-time measuring, re-renders, and render workers.
 */
import type { NodeStyle, SceneNode } from "../scene/types.js";
import type { StylePreset } from "../style/presets.js";
import { type CharacterOptions } from "./characters.js";
import type { VizBounds } from "./types.js";
/** Figure height (feet → top of head, scene units) when `height:` is omitted. */
export declare const CHARACTER_NODE_DEFAULT_HEIGHT = 200;
/** Smallest figure we will draw (smaller just turns to mush). */
export declare const CHARACTER_NODE_MIN_HEIGHT = 24;
/** Gap between the feet/ground line and the label block under it. */
export declare const CHARACTER_LABEL_GAP = 10;
/** What `node.data.character` carries. Every axis name is a registry key. */
export interface CharacterNodeSpec {
    pose: string;
    emotion?: string;
    shirt?: string;
    hair?: string;
    accessory?: string;
    fx?: string;
    /** Any icon name, held at the pose's prop anchor. */
    prop?: string;
    /** Figure height in scene units (feet → top of head). */
    height: number;
    /** Mirror left↔right. */
    flip?: boolean;
    /** "minimal" | "plain" | "detailed" — how much of the figure is drawn. */
    fidelity?: "minimal" | "plain" | "detailed";
    /** Soft ground shadow under a grounded figure (default true). */
    shadow?: boolean;
    shirtColor?: string;
    hairColor?: string;
    accessoryColor?: string;
    fxColor?: string;
    propColor?: string;
    /**
     * Figure extents relative to the ground point (cx = 0, groundY = 0) at
     * `height`, as measured by the compiler. Informational for hosts (where the
     * feet are inside the node box); the renderer re-measures, so it may be
     * omitted on programmatic scenes.
     */
    figure?: VizBounds;
}
/** Read the spec off a node (null when the node isn't a character node). */
export declare function characterNodeSpec(node: SceneNode): CharacterNodeSpec | null;
/** Translate the spec + the node's resolved style into drawCharacter options.
 *  Ink = the node's stroke (preset ink / auto-color role / author `stroke:`);
 *  the shirt accent falls back to the node's fill so a filled preset dresses
 *  the figure in the same pastel the other shapes wear. Never hardcoded. */
export declare function characterDrawOptions(spec: CharacterNodeSpec, style: NodeStyle): CharacterOptions;
/**
 * Measure a figure: its drawn extents (limbs, hair, prop, fx marks, motion
 * streaks — everything the library emits) relative to the ground point
 * (cx = 0, groundY = 0) at the spec's height. Pure: runs the character drawer
 * into a scratch context and takes the union bbox of what it emitted.
 */
export declare function measureCharacterNode(spec: CharacterNodeSpec, style: NodeStyle, preset: StylePreset, mode: "light" | "dark"): VizBounds;
export interface CharacterNodeBox {
    /** Node box size: figure extents ∪ label block. */
    w: number;
    h: number;
    /** Figure extents relative to the ground point (see measureCharacterNode). */
    figure: VizBounds;
    /** Height reserved for the label block (0 when unlabelled). */
    labelH: number;
}
/** Size the node box for a spec + label: figure extents plus the label row. */
export declare function characterNodeBox(spec: CharacterNodeSpec, label: string, style: NodeStyle, preset: StylePreset, mode: "light" | "dark"): CharacterNodeBox;
export interface CharacterNodeEmit {
    /** The figure's strokes as pinned sub-nodes in WORLD coordinates. */
    nodes: SceneNode[];
    /** Where the figure landed (world). */
    figure: VizBounds;
    /** Ground/feet line (world y) — the label hangs below this. */
    groundY: number;
    /** Label block height reserved at the bottom of the node box. */
    labelH: number;
}
/**
 * Emit the figure for a character node, placed inside the node's box:
 * horizontally centred, feet on the ground line just above the label row.
 * If the box was resized (override / programmatic w,h) the figure scales to
 * fit; for a compiler-sized box the scale is exactly 1.
 */
export declare function emitCharacterNode(node: SceneNode, preset: StylePreset, mode: "light" | "dark"): CharacterNodeEmit;
//# sourceMappingURL=characterNode.d.ts.map