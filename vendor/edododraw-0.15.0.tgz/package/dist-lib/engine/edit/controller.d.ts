/**
 * EditController — direct manipulation of the rendered diagram (Excalidraw-like)
 * with every edit rounding back to the `.edd` source, so code stays the single
 * source of truth. Driven by the EdodoDraw facade, which routes pointer events
 * here when an edit tool is active.
 *
 * Tools: select (marquee/move/resize/rename/delete), hand (pan), rect/ellipse/
 * diamond/text (add nodes), arrow (connect nodes). Move/resize/nudge write an
 * `overrides` block; rename/style/add/delete/duplicate surgically patch source.
 *
 * Selection is a SET of node ids (shift-click toggles, drag-on-empty marquees),
 * so several nodes move, restyle, duplicate and delete together. Resize handles
 * appear only for a single selection.
 */
import type { Point } from "../geometry.js";
import type { Scene, SceneNode } from "../scene/types.js";
import type { SvgRenderer } from "../render/svgRenderer.js";
export type EditTool = "select" | "hand" | "rect" | "ellipse" | "diamond" | "text" | "arrow";
export interface EditState {
    tool: EditTool;
    /** Selected node ids (ordered; the last one is the "primary"). */
    selected: string[];
    /** Selected edge id (mutually exclusive with node selection). */
    selectedEdge?: string | null;
    /** History availability — filled in by the facade, not the controller. */
    canUndo?: boolean;
    canRedo?: boolean;
}
interface Callbacks {
    getScene: () => Scene;
    getSource: () => string;
    onSource: (next: string) => void;
    onState: (s: EditState) => void;
    onRequestRename: (id: string, current: string, screen: Point) => void;
    /** Hover/drag cursor feedback (facade sets it on the canvas host). */
    onCursor?: (cursor: string) => void;
}
export declare class EditController {
    private r;
    private cb;
    private overlay;
    private tool;
    private selected;
    private selectedEdge;
    private renamingEdge;
    private hoverId;
    private clipboard;
    private pasteSeq;
    private drag;
    constructor(renderer: SvgRenderer, cb: Callbacks);
    setTool(t: EditTool): void;
    getTool(): EditTool;
    /** All selected ids (a copy). */
    getSelected(): string[];
    /** The primary (last-selected) node, used for the inspector + rename. */
    getSelectedNode(): SceneNode | null;
    private selectedNodes;
    getSelectedEdge(): string | null;
    private selectedEdgeObj;
    clearSelection(): void;
    selectAll(): void;
    state(): EditState;
    private emit;
    private cursor;
    render(): void;
    private edgeScreenPoints;
    private drawEdgeSelection;
    private drawReconnectPreview;
    private screenRect;
    private boxFor;
    private handlePoints;
    private rect;
    private drawCreatePreview;
    private drawMarquee;
    private drawConnectPreview;
    /** Which end (if any) of the selected edge is under the cursor. */
    private hitEdgeHandle;
    private worldTol;
    private hitHandle;
    /** returns true if handled (facade should not pan). */
    pointerDown(world: Point, screen: Point, mods?: {
        shift?: boolean;
    }): boolean;
    pointerMove(world: Point, screen?: Point): void;
    /** Nearest routed edge to the point, or null (screen-tolerance aware). */
    private edgeAt;
    /** Idle hover: set the cursor + a faint outline so the canvas feels alive. */
    private hover;
    private marqueeSelection;
    pointerUp(world: Point): void;
    private applyResize;
    /**
     * Commit the current node geometry. Freezes EVERY node's position into
     * overrides (the Excalidraw-like "you've taken manual control" model), so
     * moving some nodes never reshuffles the auto-layout of the rest. Existing
     * size overrides are preserved; pass `sizeId`/`size` for a resized node.
     */
    private commitPositions;
    private finishCreate;
    private uniqueId;
    private freshId;
    requestRenameSelected(): void;
    dblclick(world: Point): boolean;
    applyRename(id: string, label: string): void;
    /** Style one node. */
    applyStyle(id: string, style: {
        fill?: string;
        stroke?: string;
        shape?: string;
    }): void;
    /** Style several nodes in one source patch (a single undo step). */
    applyStyleMany(ids: string[], style: {
        fill?: string;
        stroke?: string;
        shape?: string;
    }): void;
    deleteSelected(): void;
    private specOf;
    /** Clone the selection in place with a small offset (Cmd/Ctrl-D). */
    duplicateSelected(): boolean;
    /** Copy the selection into the in-memory clipboard (Cmd/Ctrl-C). */
    copySelected(): boolean;
    /** Paste the clipboard (Cmd/Ctrl-V), offset so copies don't stack exactly. */
    paste(): boolean;
    private cloneSpecs;
    handleKey(e: KeyboardEvent): boolean;
    dispose(): void;
}
export {};
//# sourceMappingURL=controller.d.ts.map