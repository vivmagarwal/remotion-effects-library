/**
 * Apply position/size overrides to a scene. Overrides come from the DSL
 * `overrides { … }` block (what direct canvas edits write back to). Applied
 * before layout so overridden nodes are pinned at their coordinates and the
 * auto-layout arranges everything else around them. Idempotent — safe to call
 * again after Mermaid injection so imported nodes can be overridden too.
 */
import type { Scene } from "./types.js";
export declare function applyOverrides(scene: Scene): void;
//# sourceMappingURL=overrides.d.ts.map