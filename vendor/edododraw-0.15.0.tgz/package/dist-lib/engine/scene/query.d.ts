/**
 * Read-only queries over a Scene: element lookup and bounding boxes in world
 * space. Used by the camera (fit/focus), layout, and annotation anchoring.
 */
import type { BBox, Rect } from "../geometry.js";
import type { Scene, SceneEdge, SceneGroup, SceneNode } from "./types.js";
export declare function getNode(scene: Scene, id: string): SceneNode | undefined;
export declare function getEdge(scene: Scene, id: string): SceneEdge | undefined;
export declare function getGroup(scene: Scene, id: string): SceneGroup | undefined;
export declare function nodeBBox(n: SceneNode): BBox;
export declare function edgeBBox(e: SceneEdge): BBox;
export declare function groupBBox(scene: Scene, g: SceneGroup): BBox;
/**
 * Element ids emitted for the viz data item `key` ("<blockId>.<itemId>").
 * Viz generators tag every element they emit for an item with
 * `data.vizItem = key`, so one data entry can be addressed as a unit.
 */
export declare function vizItemMembers(scene: Scene, key: string): string[];
/** Every distinct viz-item key ("<blockId>.<itemId>") present in the scene. */
export declare function listVizItems(scene: Scene): string[];
/** Ids of every standalone `character` node in the scene (shape "character";
 *  the figure spec lives in `node.data.character`). Companion to listVizItems
 *  for hosts planning beats/draw-ons. */
export declare function listCharacterNodes(scene: Scene): string[];
/** Ids of every standalone `icon` node (shape "icon"; spec in `node.data.icon`). */
export declare function listIconNodes(scene: Scene): string[];
/** Resolve any element id (node/group; edges included if routed; viz-item
 *  keys resolve to the union of their members) to a bbox. */
export declare function elementBBox(scene: Scene, id: string): BBox | undefined;
/** Union bbox of several element ids. */
export declare function elementsBBox(scene: Scene, ids: string[]): BBox;
/** BBox covering every node (and routed edge) in the scene. */
export declare function sceneBBox(scene: Scene): BBox;
export declare function nodeRectOf(n: SceneNode): Rect;
/** Topmost node whose bounding box contains the given world point, or null. */
export declare function hitTestNode(scene: Scene, p: {
    x: number;
    y: number;
}): SceneNode | null;
/** Nearest routed edge within `tol` world units of the point, or null. */
export declare function hitTestEdge(scene: Scene, p: {
    x: number;
    y: number;
}, tol: number): SceneEdge | null;
//# sourceMappingURL=query.d.ts.map