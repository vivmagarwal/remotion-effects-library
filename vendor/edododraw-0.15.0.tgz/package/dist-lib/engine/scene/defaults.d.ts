/**
 * Default styles, theme, and factory helpers for building Scene elements.
 * Factories assign deterministic rough seeds (hash of id) so re-rendering an
 * unchanged element never re-jitters its hand-drawn strokes.
 */
import type { EdgeStyle, NodeStyle, Scene, SceneEdge, SceneNode, ShapeKind, Theme } from "./types.js";
export declare const LIGHT_THEME: Theme;
export declare const DARK_THEME: Theme;
export declare function defaultNodeStyle(seed: number, mode?: "light" | "dark"): NodeStyle;
export declare function defaultEdgeStyle(seed: number, mode?: "light" | "dark"): EdgeStyle;
/** Default box size for a node given its label (rough auto-size fallback). */
export declare function defaultNodeSize(shape: ShapeKind, label: string): {
    w: number;
    h: number;
};
export interface MakeNodeInput {
    id: string;
    shape?: ShapeKind;
    label?: string;
    x?: number;
    y?: number;
    w?: number;
    h?: number;
    style?: Partial<NodeStyle>;
    group?: string;
    z?: number;
    pinned?: boolean;
    data?: Record<string, unknown>;
    mode?: "light" | "dark";
}
export declare function makeNode(input: MakeNodeInput): SceneNode;
export interface MakeEdgeInput {
    id: string;
    from: string;
    to: string;
    fromAnchor?: string;
    toAnchor?: string;
    label?: string;
    style?: Partial<EdgeStyle>;
    routing?: SceneEdge["routing"];
    z?: number;
    data?: Record<string, unknown>;
    mode?: "light" | "dark";
}
export declare function makeEdge(input: MakeEdgeInput): SceneEdge;
export declare function emptyScene(mode?: "light" | "dark"): Scene;
//# sourceMappingURL=defaults.d.ts.map