/**
 * Anchor resolution — maps an anchor spec on a node to a concrete world point.
 *
 * EDodoDraw exposes far more connection points than Excalidraw's 4:
 *  - 8 compass points + center: n s e w ne nw se sw c
 *  - aliases: top bottom left right center
 *  - fractional side positions: "top:0.3" (30% along the top edge, l->r)
 *    also right:0.75, bottom:0.5, left:0.2
 *  - polar angle from center: "angle:45" (degrees, 0 = east, CW)
 *  - auto (undefined): border point aimed at the other endpoint
 */
import type { Point, Rect } from "../geometry.js";
import type { SceneNode } from "./types.js";
export declare function nodeRect(n: SceneNode): Rect;
/**
 * Resolve a named/parametric anchor to a world point.
 * `toward` is the opposite endpoint (used for "auto"/border computation).
 */
export declare function resolveAnchor(node: SceneNode, anchor: string | undefined, toward?: Point): Point;
//# sourceMappingURL=anchors.d.ts.map