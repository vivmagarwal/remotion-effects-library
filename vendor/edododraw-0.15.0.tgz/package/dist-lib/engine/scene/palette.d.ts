/**
 * Color palette matched to Excalidraw's Open-Colors selection, plus named
 * "semantic" colors the DSL exposes (e.g. `fill: green`). Each semantic name
 * maps to a stroke + a soft background so `fill: green` yields the pleasant
 * Excalidraw green box with a matching darker green outline.
 */
export declare const STROKE_PALETTE: {
    readonly black: "#1e1e1e";
    readonly gray: "#495057";
    readonly red: "#e03131";
    readonly pink: "#c2255c";
    readonly grape: "#9c36b5";
    readonly violet: "#6741d9";
    readonly blue: "#1971c2";
    readonly cyan: "#0c8599";
    readonly teal: "#099268";
    readonly green: "#2f9e44";
    readonly lime: "#66a80f";
    readonly yellow: "#f08c00";
    readonly orange: "#e8590c";
    readonly brown: "#846358";
    readonly white: "#ffffff";
};
/** Soft fill backgrounds (Excalidraw's lighter shade for each hue). */
export declare const FILL_PALETTE: {
    readonly transparent: string | null;
    readonly none: string | null;
    readonly black: "#e9ecef";
    readonly gray: "#e9ecef";
    readonly red: "#ffc9c9";
    readonly pink: "#fcc2d7";
    readonly grape: "#eebefa";
    readonly violet: "#d0bfff";
    readonly blue: "#a5d8ff";
    readonly cyan: "#99e9f2";
    readonly teal: "#96f2d7";
    readonly green: "#b2f2bb";
    readonly lime: "#d8f5a2";
    readonly yellow: "#ffec99";
    readonly orange: "#ffd8a8";
    readonly brown: "#e5dbd4";
    readonly white: "#ffffff";
};
export type ColorName = keyof typeof STROKE_PALETTE;
/**
 * Perceived-luminance test for a color, used to pick a contrasting "ink"
 * (stroke/text) in dark mode: a light fill wants dark ink, a dark (or absent)
 * fill wants light ink. Only hex is measured precisely; named/rgb() colors —
 * which in this engine are almost always the light Open-Colors pastels — default
 * to "light" so their ink stays dark and readable.
 */
export declare function isLightColor(color: string | null | undefined): boolean;
/**
 * Resolve a color token to a hex string.
 * - Named strokes: "green" -> #2f9e44
 * - Hex passthrough: "#ff0000" -> "#ff0000"
 * - "transparent"/"none" -> null-safe handled by caller
 */
export declare function resolveStroke(token: string | undefined, fallback: string): string;
/** Resolve a fill token: named -> soft bg, hex passthrough, transparent -> null. */
export declare function resolveFill(token: string | undefined): string | null;
/**
 * When a user writes `fill: green` we also nudge the stroke to the matching
 * darker green (if the stroke is still the default black). This returns the
 * "paired" stroke for a fill color name, or null if there's no pairing.
 */
export declare function pairedStrokeForFill(fillToken: string | undefined): string | null;
/** Highlighter/marker colors (semi-transparent) for annotations. */
export declare const MARKER_PALETTE: {
    readonly yellow: "#ffe066";
    readonly green: "#8ce99a";
    readonly blue: "#74c0fc";
    readonly pink: "#faa2c1";
    readonly orange: "#ffc078";
    readonly violet: "#b197fc";
    readonly red: "#ff8787";
};
export declare function resolveMarker(token: string | undefined, fallback?: "#ffe066"): string;
//# sourceMappingURL=palette.d.ts.map