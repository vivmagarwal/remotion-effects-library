/**
 * Geometry primitives shared across the engine.
 * All engine coordinates are in "world" space (unbounded, y-down) unless a
 * function name says otherwise. The camera converts world <-> screen.
 */
export interface Point {
    x: number;
    y: number;
}
export interface Size {
    w: number;
    h: number;
}
/** Axis-aligned rectangle by top-left corner + size. */
export interface Rect {
    x: number;
    y: number;
    w: number;
    h: number;
}
/** Axis-aligned bounding box by extents. */
export interface BBox {
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
}
export declare const clamp: (v: number, lo: number, hi: number) => number;
export declare const lerp: (a: number, b: number, t: number) => number;
export declare const dist: (a: Point, b: Point) => number;
export declare const rectCenter: (r: Rect) => Point;
export declare const rectToBBox: (r: Rect) => BBox;
export declare const bboxToRect: (b: BBox) => Rect;
export declare const bboxCenter: (b: BBox) => Point;
export declare const bboxSize: (b: BBox) => Size;
export declare const emptyBBox: () => BBox;
export declare const isEmptyBBox: (b: BBox) => boolean;
export declare const bboxUnion: (a: BBox, b: BBox) => BBox;
export declare const bboxOfPoints: (points: Point[]) => BBox;
export declare const expandBBox: (b: BBox, pad: number) => BBox;
export declare const pointInRect: (p: Point, r: Rect) => boolean;
/**
 * Intersection of the segment from the rect center toward `target` with the
 * rect border. Used to make an edge touch a node's border instead of its
 * center. Returns the border point (falls back to center if degenerate).
 */
export declare const borderPointToward: (r: Rect, target: Point) => Point;
/**
 * Border point for an ellipse toward a target (used for ellipse/circle nodes so
 * edges meet the curve, not the bounding rect).
 */
export declare const ellipseBorderToward: (r: Rect, target: Point) => Point;
/** Deterministic 32-bit hash of a string — used for stable rough.js seeds. */
export declare const hashString: (s: string) => number;
//# sourceMappingURL=geometry.d.ts.map