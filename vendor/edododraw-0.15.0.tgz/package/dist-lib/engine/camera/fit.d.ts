/**
 * Pure camera math: compute the { cx, cy, zoom } that frames a bbox (or the
 * whole scene) inside a viewport with padding. Shared by fitAll/focus and the
 * animated CameraController (M3).
 */
import type { BBox, Size } from "../geometry.js";
import type { CameraTransform } from "../render/svgRenderer.js";
export interface FitOptions {
    /** Screen-space padding around the target, in px. */
    padding?: number;
    minZoom?: number;
    maxZoom?: number;
}
/** Camera that frames `bbox` within `viewport`. */
export declare function cameraForBBox(bbox: BBox, viewport: Size, opts?: FitOptions): CameraTransform;
/** Camera that centers a target zoomed to an explicit factor. */
export declare function cameraForCenter(center: {
    x: number;
    y: number;
}, zoom: number): CameraTransform;
/**
 * Interpolate between two cameras exactly like the animated CameraController
 * does (zoom in log space, position linear). `t` is 0..1, already eased —
 * frame-driven hosts pair this with easingByName() + resolveCameraDirective()
 * to reproduce the magic-move deterministically.
 */
export declare function mixCameras(a: CameraTransform, b: CameraTransform, t: number): CameraTransform;
//# sourceMappingURL=fit.d.ts.map