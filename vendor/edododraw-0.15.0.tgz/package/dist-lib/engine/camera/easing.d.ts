/**
 * Easing catalog for camera magic-move and annotation reveals.
 * All functions map t in [0,1] -> eased value (usually [0,1], some overshoot).
 */
import type { EasingName } from "../scene/types.js";
export type EasingFn = (t: number) => number;
export declare const EASINGS: Record<EasingName, EasingFn>;
export declare function easingByName(name: EasingName | undefined): EasingFn;
//# sourceMappingURL=easing.d.ts.map