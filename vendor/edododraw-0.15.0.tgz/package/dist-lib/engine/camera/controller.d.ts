/**
 * CameraController — drives the SvgRenderer's camera with interruptible,
 * retargetable rAF tweens ("magic move"). Zoom is interpolated in log space so
 * fast/slow zooms feel natural; position is eased linearly.
 */
import type { BBox, Point } from "../geometry.js";
import type { EasingName, Scene } from "../scene/types.js";
import type { CameraTransform, SvgRenderer } from "../render/svgRenderer.js";
export interface MoveOptions {
    durationMs?: number;
    easing?: EasingName;
    padding?: number;
}
export declare class CameraController {
    private renderer;
    private tween;
    private raf;
    /** notified every applied frame (for grid/overlay sync). */
    onFrame?: (cam: CameraTransform) => void;
    constructor(renderer: SvgRenderer);
    get current(): CameraTransform;
    /** Snap immediately (used by user pan/zoom). Cancels any tween. */
    setImmediate(cam: CameraTransform): void;
    stop(): void;
    /** Animate to a target camera, retargeting smoothly if already animating. */
    animateTo(to: CameraTransform, opts?: MoveOptions): Promise<void>;
    private frame;
    /** Duration heuristic: further travel + bigger zoom change => longer. */
    private autoDuration;
    fitAll(scene: Scene, opts?: MoveOptions): Promise<void>;
    focus(scene: Scene, ids: string[], opts?: MoveOptions & {
        zoom?: number;
    }): Promise<void>;
    focusBBox(box: BBox, opts?: MoveOptions & {
        zoom?: number;
    }): Promise<void>;
    /** Zoom by a factor around a screen anchor (default: viewport center). */
    zoomBy(factor: number, anchorScreen?: Point): void;
    /** Pan by a screen-space delta. */
    panByScreen(dx: number, dy: number): void;
}
/** Auto-move duration (ms): further travel + bigger zoom change => longer, clamped 420..1300. */
export declare function autoDuration(from: CameraTransform, to: CameraTransform): number;
export declare function lerp(a: number, b: number, t: number): number;
/** Interpolate zoom in log space so 1x->4x passes through 2x at t=0.5. */
export declare function logLerp(a: number, b: number, t: number): number;
//# sourceMappingURL=controller.d.ts.map