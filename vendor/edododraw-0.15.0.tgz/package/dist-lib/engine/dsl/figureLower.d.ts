/**
 * Lowering for the two "figure" node shapes — `character` (a sketchnote
 * person) and `icon` (a line glyph with a caption). Both validate their names
 * against the live registries. Unknown names never blank the diagram: they
 * produce a warning that lists the valid values and fall back (`standing` /
 * `neutral` / the library default; an unknown icon keeps its caption), so
 * something always renders.
 */
import { type CharacterNodeSpec } from "../viz/characterNode.js";
import { type IconNodeSpec } from "../viz/iconNode.js";
import type { AttrBlock, Span, Value } from "./ast.js";
import { DiagnosticBag } from "./diagnostics.js";
/** Attribute keys a character node understands (besides the common node attrs). */
export declare const CHARACTER_ATTR_KEYS: readonly ["pose", "emotion", "shirt", "hair", "accessory", "fx", "prop", "height", "flip", "fidelity", "shadow", "shirtColor", "hairColor", "accessoryColor", "fxColor", "propColor"];
/**
 * Build the spec. `attrs` is the node's layered attribute cascade (defaults →
 * classes → inline) so `style .hero { pose: waving }` works like any style.
 * `fallbackSpan` positions diagnostics when an attr has no span of its own.
 */
export declare function lowerCharacterNode(attrs: AttrBlock, tokens: Map<string, Value>, diags: DiagnosticBag, fallbackSpan: Span): CharacterNodeSpec;
/** Attribute keys an icon node understands (besides the common node attrs). */
export declare const ICON_ATTR_KEYS: readonly ["icon", "size", "iconSize"];
/**
 * Build an icon node spec: `icon: <name>` (defaults to the node id, so
 * `icon rocket "Launch"` just works) and `size: <n>` / `iconSize: <n>`.
 */
export declare function lowerIconNode(id: string, attrs: AttrBlock, diags: DiagnosticBag, fallbackSpan: Span): IconNodeSpec;
//# sourceMappingURL=figureLower.d.ts.map