/**
 * Public DSL entrypoint: source text -> { scene, diagnostics }.
 * This is the "100% code -> diagram" contract.
 */
import { DiagnosticBag } from "./diagnostics.js";
import type { Scene } from "../scene/types.js";
export interface CompileEddResult {
    scene: Scene;
    diagnostics: DiagnosticBag;
    /** Formatted, human-readable diagnostics (one block each). */
    report: string[];
}
export interface CompileEddOptions {
    /** Force light/dark render mode, overriding the DSL's declared theme. */
    mode?: "light" | "dark";
    /** Force a style preset by name, overriding `meta { style: … }`. */
    stylePreset?: string;
}
export declare function compileEdd(source: string, opts?: CompileEddOptions): CompileEddResult;
export { parse } from "./parser.js";
export { compileProgram } from "./compile.js";
export { lex } from "./lexer.js";
export { DiagnosticBag, formatDiagnostic } from "./diagnostics.js";
export type { Diagnostic } from "./diagnostics.js";
//# sourceMappingURL=index.d.ts.map