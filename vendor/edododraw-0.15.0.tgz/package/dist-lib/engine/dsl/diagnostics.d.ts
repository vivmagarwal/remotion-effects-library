/**
 * Diagnostics — structured, multi-error, with source spans and fix hints
 * (language spec §12.8). The parser and resolver accumulate these; none of them
 * abort the pipeline (except a total lexer failure, which can't happen since the
 * lexer is permissive).
 */
export type Severity = "error" | "warning" | "info";
export interface Diagnostic {
    severity: Severity;
    code: string;
    message: string;
    line: number;
    col: number;
    start: number;
    end: number;
    expected?: string;
    found?: string;
    hint?: string;
}
export declare class DiagnosticBag {
    readonly items: Diagnostic[];
    add(d: Diagnostic): void;
    error(code: string, message: string, at: {
        line: number;
        col: number;
        start: number;
        end: number;
    }, extra?: Partial<Diagnostic>): void;
    warn(code: string, message: string, at: {
        line: number;
        col: number;
        start: number;
        end: number;
    }, extra?: Partial<Diagnostic>): void;
    get hasErrors(): boolean;
    get errors(): Diagnostic[];
}
/** Nearest match from a closed menu (Levenshtein) — for "did you mean" hints. */
export declare function nearest(word: string, menu: Iterable<string>): string | null;
/** Human-readable formatting of a diagnostic against the source (spec §12.8). */
export declare function formatDiagnostic(d: Diagnostic, source: string, file?: string): string;
//# sourceMappingURL=diagnostics.d.ts.map