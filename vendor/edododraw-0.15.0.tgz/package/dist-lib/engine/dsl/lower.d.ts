/**
 * Lowering helpers: map DSL surface enums/glyphs onto Scene IR values.
 * Kept separate from the parser so the same tables document the language and
 * drive the compiler.
 */
import type { ArrowAnimationKind, ArrowheadKind, EdgeRouting, EasingName, FillStyle, ShapeKind, StrokeStyle } from "../scene/types.js";
import type { Value } from "./ast.js";
/** DSL shape name -> renderable ShapeKind. */
export declare const SHAPE_MAP: Record<string, ShapeKind>;
export declare function mapShape(name: string | undefined): ShapeKind;
export interface GlyphLowering {
    strokeStyle: StrokeStyle;
    startArrowhead: ArrowheadKind;
    endArrowhead: ArrowheadKind;
    animation?: ArrowAnimationKind;
    strokeWidthMul?: number;
    routing?: EdgeRouting;
}
/** Edge glyph -> default styling (spec §6.2). Overridable by the trailing block. */
export declare function lowerGlyph(glyph: string): GlyphLowering;
export declare function mapStrokeWidth(v: Value): number | undefined;
export declare function mapRoughness(v: Value): number | undefined;
/** `bowing: 0.35` / `bowing: none|slight|normal|loose` -> a rough.js bowing. */
export declare function mapBowing(v: Value): number | undefined;
/** A boolean attribute, written as `true`/`false` or `yes`/`no`/`on`/`off`. */
export declare function mapBool(v: Value): boolean | undefined;
export declare function mapFillStyle(v: Value): FillStyle | undefined;
export declare function mapStrokeStyle(v: Value): StrokeStyle | undefined;
export declare function mapRouting(v: Value): EdgeRouting | undefined;
export declare function mapArrowhead(v: Value): ArrowheadKind | undefined;
export declare function mapAnimation(v: Value): {
    kind: ArrowAnimationKind;
    speed?: number;
} | undefined;
export declare function mapEasing(v: Value | undefined): EasingName;
/** Resolve a color-ish value to a hex/CSS string, following $token indirection. */
export declare function resolveColor(v: Value, tokens: Map<string, Value>, kind: "stroke" | "fill", depth?: number): string | null;
export declare function numberOf(v: Value | undefined): number | undefined;
//# sourceMappingURL=lower.d.ts.map