/**
 * Recursive-descent parser for the EDodoDraw DSL.
 *
 * Strategy (spec §12.1): keyword-dispatched, LL(2). Two lookahead spots need
 * care: node-vs-edge (§12.3) and brace-role D1 (§12.4). Shape sugar (`[Label]`,
 * `((Label))`, `{Label}` …) is captured RAW from the source by offset, so the
 * permissive lexer never has to understand label contents.
 *
 * Errors are recovered at statement/block boundaries and accumulated; the
 * parser returns a best-effort AST plus a DiagnosticBag.
 */
import { DiagnosticBag } from "./diagnostics.js";
import type { Program } from "./ast.js";
export interface ParseResult {
    program: Program;
    diagnostics: DiagnosticBag;
}
export declare function parse(source: string): ParseResult;
//# sourceMappingURL=parser.d.ts.map