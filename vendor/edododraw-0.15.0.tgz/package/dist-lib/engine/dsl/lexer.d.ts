/**
 * Lexer for the EDodoDraw DSL. Permissive (never throws), position-tracking,
 * maximal-munch for edge operators. See tokens.ts for the token model and the
 * language spec §3/§12 for rules.
 */
import { type Token } from "./tokens.js";
export declare function lex(source: string): Token[];
//# sourceMappingURL=lexer.d.ts.map