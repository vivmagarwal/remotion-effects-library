/**
 * Lower a parsed `viz` block (AST) to the engine's plain-data VizSpec.
 * Keeps all AST knowledge on the DSL side so the viz generators stay
 * DSL-independent (embedders can build VizSpecs programmatically).
 */
import type { VizSpec } from "../viz/types.js";
import type { Value, VizDecl } from "./ast.js";
export declare function lowerViz(decl: VizDecl, index: number, tokens: Map<string, Value>): VizSpec;
//# sourceMappingURL=vizLower.d.ts.map