/**
 * Source patcher — turns direct canvas edits into surgical edits of the `.edd`
 * source, so the code stays the single source of truth (you drag a node and
 * watch the code update). Uses the parser's AST spans to edit precisely and
 * leave the rest of the source untouched.
 *
 *  - move / resize  -> a machine-managed `overrides { … }` block (works for
 *    every node: declared, auto-created from an edge, or Mermaid-imported)
 *  - rename         -> replace the node's label (or add a `label:` attr)
 *  - restyle        -> upsert `fill` / `stroke` / `shape` attrs on the decl
 *  - add node/edge  -> append a declaration to the scene block
 *  - delete         -> remove the node's decl, its edges, and its override
 */
export interface OverrideEntry {
    id: string;
    x: number;
    y: number;
    w?: number;
    h?: number;
}
/** Regenerate the `overrides { … }` block (replace, append, or remove). */
export declare function writeOverrides(source: string, entries: OverrideEntry[]): string;
/** Rename a node (replace its label string, or add a `label:` attr / decl). */
export declare function renameNode(source: string, id: string, label: string): string;
/** Set fill / stroke / shape on a node (upsert attrs, or create a decl). */
export declare function styleNode(source: string, id: string, style: {
    fill?: string;
    stroke?: string;
    shape?: string;
}): string;
/** Insert a new node declaration into the (first) scene block. */
export declare function addNode(source: string, node: {
    id: string;
    shape: string;
    label: string;
}): string;
/** Append an edge to the (first) scene block. */
export declare function addEdge(source: string, edge: {
    from: string;
    to: string;
    glyph?: string;
    label?: string;
}): string;
/**
 * Delete the edge producing the `from -> to` pair. A simple two-node edge is
 * removed whole; for a fan/chain statement the whole statement is removed
 * (safe, no partial rewrite) — canvas-drawn arrows are always simple, so this
 * matches "delete this arrow" exactly.
 */
export declare function deleteEdge(source: string, from: string, to: string): string;
/** Re-point one end of a simple edge to a different node (drag an endpoint). */
export declare function reconnectEdge(source: string, from: string, to: string, which: "from" | "to", newId: string): string;
/** Set / replace the trailing label of a simple edge (no attr block). */
export declare function setEdgeLabel(source: string, from: string, to: string, label: string): string;
/** Delete a node: remove its decl, any edges mentioning it, and its override. */
export declare function deleteElements(source: string, ids: string[]): string;
//# sourceMappingURL=patch.d.ts.map