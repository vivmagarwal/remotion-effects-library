/**
 * Compiler: EDodoDraw AST -> Scene IR. Applies the style cascade (theme tokens
 * -> defaults -> classes -> inline), expands edge chains/fan-outs, lifts
 * annotate blocks and timeline beats into the IR, then runs auto-layout.
 */
import "../viz/generators/index.js";
import type { Annotation, Scene } from "../scene/types.js";
import type { AnnotationCmd, Program, Value } from "./ast.js";
import { DiagnosticBag } from "./diagnostics.js";
export interface CompileOptions {
    diagnostics?: DiagnosticBag;
    /**
     * Force the render mode, overriding the mode derived from the active theme
     * name. Used by the app/embedder's light/dark toggle so any diagram can be
     * viewed dark without editing its source. `undefined` = derive from the DSL.
     */
    mode?: "light" | "dark";
    /**
     * Force a style preset by name, overriding `meta { style: … }`. Lets a host
     * app offer a style switcher without editing the source.
     */
    stylePreset?: string;
}
export interface CompileResult {
    scene: Scene;
    diagnostics: DiagnosticBag;
}
export declare function compileProgram(program: Program, opts?: CompileOptions): CompileResult;
export declare function annotationFromCmd(cmd: AnnotationCmd, tokens: Map<string, Value>, origin: "script" | "live"): Annotation | null;
//# sourceMappingURL=compile.d.ts.map