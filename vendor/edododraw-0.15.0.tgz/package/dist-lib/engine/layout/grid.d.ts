/**
 * Grid layout — arrange nodes on a uniform square grid, row-major.
 *
 * Columns = ceil(sqrt(n)). The cell is a square sized to the largest single
 * node dimension (width OR height) plus the gap, so neighbouring cells can
 * never overlap regardless of how the nodes are shaped. Each node is centred
 * inside its cell, which keeps mixed-size grids visually aligned.
 */
import type { SceneNode } from "../scene/types.js";
/** Lay `nodes` out on a grid, mutating each node's top-left x/y in place. */
export declare function layoutGrid(nodes: SceneNode[], gap: number): void;
//# sourceMappingURL=grid.d.ts.map