/**
 * Directed-acyclic (layered) layout via dagre.
 *
 * dagre works in CENTRE coordinates; the Scene IR stores TOP-LEFT, so read-back
 * subtracts half the node size. Scene groups become dagre compound clusters so
 * that grouped members are kept adjacent in the final layering.
 */
import type { Scene, SceneNode } from "../scene/types.js";
export type RankDir = "TB" | "BT" | "LR" | "RL";
export interface DagOptions {
    /** dagre rank direction. */
    rankdir: RankDir;
    /** Separation between nodes in the same rank (px). */
    nodesep: number;
    /** Separation between ranks (px). */
    ranksep: number;
    /** Graph margin on both axes (px). */
    margin: number;
}
/**
 * Lay out the given `movable` nodes with dagre and write their top-left x/y.
 *
 * Only nodes in `movable` are fed to the graph (pinned nodes are excluded by
 * the caller). Edges are included only when both endpoints are real nodes that
 * are present in the graph. Throws if dagre returns a non-finite position so
 * the caller can fall back to another layout.
 */
export declare function layoutDag(scene: Scene, movable: SceneNode[], opts: DagOptions): void;
//# sourceMappingURL=dag.d.ts.map