/**
 * Auto-layout — assigns world positions to a Scene's nodes.
 *
 * `applyLayout(scene)` reads `scene.meta.layout` and mutates each non-pinned
 * node's top-left `x`/`y` in place. Supported modes:
 *
 *   - "dag" / "dag-lr" / "dag-rl" / "dag-bt" — layered graph layout via dagre
 *   - "grid"   — uniform square grid, row-major
 *   - "radial" — hub node at origin, the rest on a circle
 *   - "manual" — no-op (author already positioned everything)
 *
 * Cross-cutting rules:
 *   - Any node with `pinned === true` is a fixed obstacle: it is excluded from
 *     every auto-layout mode and its coordinates are never changed.
 *   - The function never throws. If dagre fails (or a graph is empty/degenerate)
 *     it falls back to grid; an empty scene is a no-op.
 *   - After arranging, the laid-out nodes are shifted so their bounding box
 *     starts at a small positive margin (~40,40). Pinned nodes anchor an
 *     absolute frame and are not shifted; when nothing is pinned this is
 *     exactly "translate the whole diagram".
 *
 * The public surface is `applyLayout`; per-mode maths lives in dag/grid/radial.
 */
import type { Scene } from "../scene/types.js";
/**
 * Assign positions to `scene.nodes` according to `scene.meta.layout`.
 * Mutates node `x`/`y` (top-left, world space) in place. Never throws.
 */
export declare function applyLayout(scene: Scene): void;
//# sourceMappingURL=index.d.ts.map