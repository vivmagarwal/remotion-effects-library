/**
 * Radial layout — a hub node at the world origin with the remaining nodes
 * distributed evenly around a circle.
 *
 * The hub is either the node whose id matches the requested `centerId`, or the
 * first node when no match is found. Ring radius = max(radiusFloor, n * 40),
 * which grows the circle as the node count rises so labels stay legible.
 */
import type { SceneNode } from "../scene/types.js";
/**
 * Place `nodes` radially, mutating each node's top-left x/y in place.
 *
 * @param nodes       nodes to arrange (hub + ring)
 * @param centerId    preferred hub node id; falls back to the first node
 * @param radiusFloor minimum ring radius in world px
 */
export declare function layoutRadial(nodes: SceneNode[], centerId: string | undefined, radiusFloor?: number): void;
//# sourceMappingURL=radial.d.ts.map