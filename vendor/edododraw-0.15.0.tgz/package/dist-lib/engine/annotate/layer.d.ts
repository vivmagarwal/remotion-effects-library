/**
 * AnnotationLayer — renders annotations (scripted or live) into the renderer's
 * world-space annotation layer so they track the camera and the elements they
 * anchor to. Hand-drawn via rough.js to match the aesthetic.
 *
 * The same layer serves M3 (scripted timeline annotations) and M4 (real-time
 * user annotations) — both are just `Annotation` records.
 */
import type { Annotation, Scene } from "../scene/types.js";
import type { SvgRenderer } from "../render/svgRenderer.js";
/**
 * One call for the common case: paint a scene AND its annotations.
 *
 * `SvgRenderer.render()` already paints the scene's always-on annotations, so
 * this helper exists for the case that still needs a second object — painting
 * a SPECIFIC set, e.g. one timeline step's marks:
 *
 *   renderSceneWithAnnotations(renderer, scene);                              // always-on
 *   renderSceneWithAnnotations(renderer, scene, stepStateAt(scene, 2).annotations);
 */
export declare function renderSceneWithAnnotations(renderer: SvgRenderer, scene: Scene, annotations?: Annotation[], animate?: boolean): AnnotationLayer;
export declare class AnnotationLayer {
    private renderer;
    private rc;
    private root;
    /** The scene currently being drawn — supplies the diagram-wide rough tuning. */
    private scene;
    constructor(renderer: SvgRenderer, layer?: "annotations" | "live");
    /**
     * Fold the diagram's declared roughness and the renderer's zoom compensation
     * into one of the mark constants below. A mark on a `hand-clean` diagram
     * comes out as clean as the diagram; a mark on a diagram that declared
     * nothing comes out exactly as it always did (the ratio is 1 and the scale
     * is 1, so every field lands back on its literal value).
     */
    private ink;
    clear(): void;
    /** Render a set of annotations (replaces current). */
    render(scene: Scene, annotations: Annotation[], animate?: boolean): void;
    private targetBBox;
    private draw;
    private drawHighlight;
    private drawUnderline;
    private drawStrike;
    private drawBox;
    private drawCircle;
    private drawPointAt;
    private drawCallout;
    private drawNoteMarker;
    private drawSpotlight;
    private drawConnector;
    private drawSticky;
    private label;
}
//# sourceMappingURL=layer.d.ts.map