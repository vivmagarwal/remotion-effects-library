/**
 * LiveAnnotationController — real-time interactive annotation editing.
 *
 * Tools:
 *   select     — pick / move / delete existing live annotations
 *   highlight  — click an element to marker-highlight it
 *   underline  — click an element to underline it
 *   box        — click an element to draw a box around it
 *   circle     — click an element to ring it
 *   arrow      — drag to draw a pointer arrow (endpoints snap to elements)
 *   text       — click to drop a sticky note (then type)
 *
 * Live annotations live in the renderer's 'live' world layer, so they track the
 * camera and their anchored elements automatically. Everything is undoable and
 * serializable back to EDodoDraw code (commit-to-code).
 */
import type { Point } from "../geometry.js";
import type { Annotation, Scene } from "../scene/types.js";
import type { SvgRenderer } from "../render/svgRenderer.js";
export type Tool = "select" | "highlight" | "underline" | "box" | "circle" | "arrow" | "text";
export interface LiveState {
    tool: Tool;
    count: number;
    canUndo: boolean;
    canRedo: boolean;
    selected: string | null;
}
export declare class LiveAnnotationController {
    private renderer;
    private getScene;
    private layer;
    private live;
    private tool;
    private selected;
    private draft;
    private undoStack;
    private redoStack;
    private seq;
    private dragging;
    onChange?: (s: LiveState) => void;
    onRequestText?: (id: string, world: Point) => void;
    constructor(renderer: SvgRenderer, getScene: () => Scene);
    private emit;
    setTool(t: Tool): void;
    getTool(): Tool;
    getAnnotations(): Annotation[];
    private snapshot;
    private id;
    render(): void;
    private drawSelection;
    private anchorBBox;
    /** returns true if the controller handled the event (skip camera pan). */
    pointerDown(world: Point, _screen: Point): boolean;
    pointerMove(world: Point): void;
    pointerUp(world: Point): void;
    private liveWith;
    private hitLive;
    handleKey(e: KeyboardEvent): boolean;
    setText(id: string, text: string): void;
    deleteSelected(): void;
    undo(): void;
    redo(): void;
    clear(): void;
    /** Serialize live annotations back into an EDodoDraw `annotate { … }` block. */
    commitToCode(): string;
    private serialize;
    private cardinalBetween;
}
//# sourceMappingURL=interact.d.ts.map