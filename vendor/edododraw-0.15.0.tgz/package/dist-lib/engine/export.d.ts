/**
 * Export helpers: turn the live diagram into a self-contained SVG (with the
 * hand-drawn font embedded as base64 so it renders anywhere), a PNG raster, the
 * raw scene JSON, or the source code. All framing uses the scene's content
 * bbox, independent of the current camera.
 */
import type { Scene } from "./scene/types.js";
import type { SvgRenderer } from "./render/svgRenderer.js";
export interface ExportOptions {
    padding?: number;
    embedFont?: boolean;
    scale?: number;
    background?: string | null;
}
/**
 * Build a standalone SVG string of the whole scene at content coordinates —
 * SYNCHRONOUSLY. Nothing in this path awaits (the hand-drawn font is embedded
 * as a base64 data URI, not fetched), so frame-driven hosts can call it inside
 * a React `useMemo` / render pass without a promise round-trip.
 *
 * `exportSVGString` is the async wrapper kept for compatibility.
 */
export declare function renderSceneToSVGString(renderer: SvgRenderer, scene: Scene, opts?: ExportOptions): string;
/**
 * Async wrapper around {@link renderSceneToSVGString}, kept so existing callers
 * (`await edd.toSVG()`, downloadSVG, exportPNGBlob) keep working unchanged.
 * There is no asynchronous work — prefer the synchronous function in new code.
 */
export declare function exportSVGString(renderer: SvgRenderer, scene: Scene, opts?: ExportOptions): Promise<string>;
export declare function exportPNGBlob(renderer: SvgRenderer, scene: Scene, opts?: ExportOptions): Promise<Blob>;
export declare function download(filename: string, data: Blob | string, type?: string): void;
export declare function downloadSVG(renderer: SvgRenderer, scene: Scene): Promise<void>;
export declare function downloadPNG(renderer: SvgRenderer, scene: Scene): Promise<void>;
export declare function downloadJSON(scene: Scene): void;
//# sourceMappingURL=export.d.ts.map