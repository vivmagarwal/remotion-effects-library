/**
 * TimelinePlayer — plays a scene's steps as a magic-move presentation.
 * Each step diffs against the running state: camera (sticky), visibility
 * (sticky), and beat-scoped annotations (replaced each step). Always-on
 * scene.annotations render underneath every step.
 */
import type { AnnotationLayer } from "../annotate/layer.js";
import type { CameraController } from "../camera/controller.js";
import type { SvgRenderer } from "../render/svgRenderer.js";
import type { Scene } from "../scene/types.js";
export interface PlayerState {
    index: number;
    total: number;
    caption: string;
    playing: boolean;
    stepName: string;
}
export declare class TimelinePlayer {
    private renderer;
    private controller;
    private annotations;
    private scene;
    private steps;
    private idx;
    private playing;
    private timer;
    onChange?: (state: PlayerState) => void;
    constructor(renderer: SvgRenderer, controller: CameraController, annotations: AnnotationLayer);
    get hasTimeline(): boolean;
    load(scene: Scene): void;
    private emit;
    goto(i: number, animate?: boolean): Promise<void>;
    private runCamera;
    next(): void;
    prev(): void;
    restart(): void;
    play(): void;
    private scheduleNext;
    pause(): void;
    dispose(): void;
}
//# sourceMappingURL=player.d.ts.map