import rough$1 from "roughjs";
import dagre from "@dagrejs/dagre";
const clamp$3 = (v, lo, hi) => v < lo ? lo : v > hi ? hi : v;
const lerp$3 = (a, b, t) => a + (b - a) * t;
const dist = (a, b) => Math.hypot(b.x - a.x, b.y - a.y);
const rectCenter = (r2) => ({ x: r2.x + r2.w / 2, y: r2.y + r2.h / 2 });
const rectToBBox = (r2) => ({
  minX: r2.x,
  minY: r2.y,
  maxX: r2.x + r2.w,
  maxY: r2.y + r2.h
});
const bboxToRect = (b) => ({
  x: b.minX,
  y: b.minY,
  w: b.maxX - b.minX,
  h: b.maxY - b.minY
});
const bboxCenter = (b) => ({
  x: (b.minX + b.maxX) / 2,
  y: (b.minY + b.maxY) / 2
});
const bboxSize = (b) => ({
  w: b.maxX - b.minX,
  h: b.maxY - b.minY
});
const emptyBBox = () => ({
  minX: Infinity,
  minY: Infinity,
  maxX: -Infinity,
  maxY: -Infinity
});
const isEmptyBBox = (b) => !Number.isFinite(b.minX) || b.maxX < b.minX || b.maxY < b.minY;
const bboxUnion = (a, b) => ({
  minX: Math.min(a.minX, b.minX),
  minY: Math.min(a.minY, b.minY),
  maxX: Math.max(a.maxX, b.maxX),
  maxY: Math.max(a.maxY, b.maxY)
});
const bboxOfPoints = (points) => {
  const b = emptyBBox();
  for (const p of points) {
    if (p.x < b.minX) b.minX = p.x;
    if (p.y < b.minY) b.minY = p.y;
    if (p.x > b.maxX) b.maxX = p.x;
    if (p.y > b.maxY) b.maxY = p.y;
  }
  return b;
};
const expandBBox = (b, pad) => ({
  minX: b.minX - pad,
  minY: b.minY - pad,
  maxX: b.maxX + pad,
  maxY: b.maxY + pad
});
const pointInRect = (p, r2) => p.x >= r2.x && p.x <= r2.x + r2.w && p.y >= r2.y && p.y <= r2.y + r2.h;
const borderPointToward = (r2, target) => {
  const c = rectCenter(r2);
  const dx = target.x - c.x;
  const dy = target.y - c.y;
  if (dx === 0 && dy === 0) return c;
  const hw = r2.w / 2;
  const hh = r2.h / 2;
  const scaleX = dx !== 0 ? hw / Math.abs(dx) : Infinity;
  const scaleY = dy !== 0 ? hh / Math.abs(dy) : Infinity;
  const s = Math.min(scaleX, scaleY);
  return { x: c.x + dx * s, y: c.y + dy * s };
};
const ellipseBorderToward = (r2, target) => {
  const c = rectCenter(r2);
  const dx = target.x - c.x;
  const dy = target.y - c.y;
  if (dx === 0 && dy === 0) return c;
  const rx = r2.w / 2;
  const ry = r2.h / 2;
  const denom = Math.sqrt(dx * dx / (rx * rx) + dy * dy / (ry * ry));
  if (denom === 0) return c;
  return { x: c.x + dx / denom, y: c.y + dy / denom };
};
const hashString = (s) => {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
};
const shapePlugins = /* @__PURE__ */ new Map();
function registerShape(name, fn) {
  shapePlugins.set(name, fn);
}
function getShapePlugin(name) {
  return shapePlugins.get(name);
}
function listShapePlugins() {
  return [...shapePlugins.keys()];
}
const arrowAnimations = /* @__PURE__ */ new Map();
let pluginCssVersion = 0;
function registerArrowAnimation(kind, def) {
  arrowAnimations.set(kind, def);
  if (def.css) pluginCssVersion++;
}
function getArrowAnimation(kind) {
  return arrowAnimations.get(kind);
}
function listArrowAnimations() {
  return [...arrowAnimations.keys()];
}
function ensurePluginStyles(doc) {
  const id = "edd-plugin-styles";
  let style = doc.getElementById(id);
  if (style && Number(style.dataset.version) === pluginCssVersion) return;
  if (!style) {
    style = doc.createElement("style");
    style.id = id;
    doc.head.appendChild(style);
  }
  style.dataset.version = String(pluginCssVersion);
  style.textContent = [...arrowAnimations.values()].map((d) => d.css ?? "").join("\n");
}
const annotationPlugins = /* @__PURE__ */ new Map();
function registerAnnotation(kind, fn) {
  annotationPlugins.set(kind, fn);
}
function getAnnotationPlugin(kind) {
  return annotationPlugins.get(kind);
}
function listAnnotationPlugins() {
  return [...annotationPlugins.keys()];
}
const layoutPlugins = /* @__PURE__ */ new Map();
function registerLayout(name, fn) {
  layoutPlugins.set(name, fn);
}
function getLayoutPlugin(name) {
  return layoutPlugins.get(name);
}
function listLayoutPlugins() {
  return [...layoutPlugins.keys()];
}
function nodeRect(n) {
  return { x: n.x, y: n.y, w: n.w, h: n.h };
}
const COMPASS = {
  c: (r2) => rectCenter(r2),
  center: (r2) => rectCenter(r2),
  n: (r2) => ({ x: r2.x + r2.w / 2, y: r2.y }),
  top: (r2) => ({ x: r2.x + r2.w / 2, y: r2.y }),
  s: (r2) => ({ x: r2.x + r2.w / 2, y: r2.y + r2.h }),
  bottom: (r2) => ({ x: r2.x + r2.w / 2, y: r2.y + r2.h }),
  e: (r2) => ({ x: r2.x + r2.w, y: r2.y + r2.h / 2 }),
  right: (r2) => ({ x: r2.x + r2.w, y: r2.y + r2.h / 2 }),
  w: (r2) => ({ x: r2.x, y: r2.y + r2.h / 2 }),
  left: (r2) => ({ x: r2.x, y: r2.y + r2.h / 2 }),
  ne: (r2) => ({ x: r2.x + r2.w, y: r2.y }),
  nw: (r2) => ({ x: r2.x, y: r2.y }),
  se: (r2) => ({ x: r2.x + r2.w, y: r2.y + r2.h }),
  sw: (r2) => ({ x: r2.x, y: r2.y + r2.h })
};
function resolveAnchor(node, anchor, toward) {
  const r2 = nodeRect(node);
  if (!anchor || anchor === "auto") {
    const target = toward ?? rectCenter(r2);
    if (node.shape === "ellipse" || node.shape === "circle") {
      return ellipseBorderToward(r2, target);
    }
    return borderPointToward(r2, target);
  }
  const key = anchor.trim().toLowerCase();
  if (key in COMPASS) return COMPASS[key](r2);
  const uv = key.match(/^@\(?(-?[0-9.]+),\s*(-?[0-9.]+)\)?$/);
  if (uv) {
    return { x: r2.x + r2.w * parseFloat(uv[1]), y: r2.y + r2.h * parseFloat(uv[2]) };
  }
  const frac = key.match(/^(top|bottom|left|right|n|s|e|w)\s*:\s*([0-9.]+)$/);
  if (frac) {
    const side = frac[1];
    const t = Math.max(0, Math.min(1, parseFloat(frac[2])));
    switch (side) {
      case "top":
      case "n":
        return { x: r2.x + r2.w * t, y: r2.y };
      case "bottom":
      case "s":
        return { x: r2.x + r2.w * t, y: r2.y + r2.h };
      case "left":
      case "w":
        return { x: r2.x, y: r2.y + r2.h * t };
      case "right":
      case "e":
        return { x: r2.x + r2.w, y: r2.y + r2.h * t };
    }
  }
  const ang = key.match(/^angle\s*:\s*(-?[0-9.]+)$/);
  if (ang) {
    const deg = parseFloat(ang[1]);
    const rad2 = deg * Math.PI / 180;
    const c = rectCenter(r2);
    const far = { x: c.x + Math.cos(rad2) * 1e5, y: c.y + Math.sin(rad2) * 1e5 };
    if (node.shape === "ellipse" || node.shape === "circle") {
      return ellipseBorderToward(r2, far);
    }
    return borderPointToward(r2, far);
  }
  return rectCenter(r2);
}
function getNode(scene, id) {
  return scene.nodes.find((n) => n.id === id);
}
function getEdge(scene, id) {
  return scene.edges.find((e) => e.id === id);
}
function getGroup(scene, id) {
  return scene.groups.find((g) => g.id === id);
}
function nodeBBox(n) {
  return rectToBBox(nodeRect(n));
}
function edgeBBox(e) {
  if (e.points && e.points.length) return bboxOfPoints(e.points);
  return emptyBBox();
}
function groupBBox(scene, g) {
  let b = emptyBBox();
  for (const id of g.members) {
    const n = getNode(scene, id);
    if (n) b = bboxUnion(b, nodeBBox(n));
  }
  return b;
}
function vizItemMembers(scene, key) {
  const out = [];
  for (const n of scene.nodes) if (n.data?.vizItem === key) out.push(n.id);
  for (const e of scene.edges) if (e.data?.vizItem === key) out.push(e.id);
  return out;
}
function listVizItems(scene) {
  const keys = /* @__PURE__ */ new Set();
  for (const n of scene.nodes) {
    const k = n.data?.vizItem;
    if (k) keys.add(k);
  }
  for (const e of scene.edges) {
    const k = e.data?.vizItem;
    if (k) keys.add(k);
  }
  return [...keys];
}
function listCharacterNodes(scene) {
  return scene.nodes.filter((n) => n.shape === "character").map((n) => n.id);
}
function listIconNodes(scene) {
  return scene.nodes.filter((n) => n.shape === "icon").map((n) => n.id);
}
function elementBBox(scene, id) {
  const n = getNode(scene, id);
  if (n) return nodeBBox(n);
  const g = getGroup(scene, id);
  if (g) return groupBBox(scene, g);
  const e = getEdge(scene, id);
  if (e) {
    const b = edgeBBox(e);
    return Number.isFinite(b.minX) ? b : void 0;
  }
  const members = vizItemMembers(scene, id);
  if (members.length) {
    let b = emptyBBox();
    for (const m of members) {
      const mb = elementBBox(scene, m);
      if (mb) b = bboxUnion(b, mb);
    }
    return Number.isFinite(b.minX) ? b : void 0;
  }
  return void 0;
}
function elementsBBox(scene, ids) {
  let b = emptyBBox();
  for (const id of ids) {
    const eb = elementBBox(scene, id);
    if (eb) b = bboxUnion(b, eb);
  }
  return b;
}
function sceneBBox(scene) {
  let b = emptyBBox();
  for (const n of scene.nodes) b = bboxUnion(b, nodeBBox(n));
  for (const e of scene.edges) {
    const eb = edgeBBox(e);
    if (Number.isFinite(eb.minX)) b = bboxUnion(b, eb);
  }
  return b;
}
function nodeRectOf(n) {
  return nodeRect(n);
}
function hitTestNode(scene, p) {
  let best = null;
  for (const n of scene.nodes) {
    if (p.x >= n.x && p.x <= n.x + n.w && p.y >= n.y && p.y <= n.y + n.h) {
      if (!best || n.z >= best.z) best = n;
    }
  }
  return best;
}
function distToSegment(p, a, b) {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const len2 = dx * dx + dy * dy;
  if (len2 === 0) return Math.hypot(p.x - a.x, p.y - a.y);
  let t = ((p.x - a.x) * dx + (p.y - a.y) * dy) / len2;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(p.x - (a.x + t * dx), p.y - (a.y + t * dy));
}
function hitTestEdge(scene, p, tol) {
  let best = null;
  let bestD = tol;
  for (const e of scene.edges) {
    const pts = e.points;
    if (!pts || pts.length < 2) continue;
    for (let i = 0; i < pts.length - 1; i++) {
      const d = distToSegment(p, pts[i], pts[i + 1]);
      if (d <= bestD) {
        bestD = d;
        best = e;
      }
    }
  }
  return best;
}
const STROKE_PALETTE = {
  black: "#1e1e1e",
  gray: "#495057",
  red: "#e03131",
  pink: "#c2255c",
  grape: "#9c36b5",
  violet: "#6741d9",
  blue: "#1971c2",
  cyan: "#0c8599",
  teal: "#099268",
  green: "#2f9e44",
  lime: "#66a80f",
  yellow: "#f08c00",
  orange: "#e8590c",
  brown: "#846358",
  white: "#ffffff"
};
const FILL_PALETTE = {
  transparent: null,
  none: null,
  black: "#e9ecef",
  gray: "#e9ecef",
  red: "#ffc9c9",
  pink: "#fcc2d7",
  grape: "#eebefa",
  violet: "#d0bfff",
  blue: "#a5d8ff",
  cyan: "#99e9f2",
  teal: "#96f2d7",
  green: "#b2f2bb",
  lime: "#d8f5a2",
  yellow: "#ffec99",
  orange: "#ffd8a8",
  brown: "#e5dbd4",
  white: "#ffffff"
};
function isLightColor(color) {
  if (!color) return false;
  const c = color.trim().toLowerCase();
  let hex = c.startsWith("#") ? c.slice(1) : "";
  if (hex.length === 3) hex = hex.replace(/./g, (ch) => ch + ch);
  if (hex.length !== 6 || /[^0-9a-f]/.test(hex)) return true;
  const r2 = parseInt(hex.slice(0, 2), 16);
  const g = parseInt(hex.slice(2, 4), 16);
  const b = parseInt(hex.slice(4, 6), 16);
  return 0.299 * r2 + 0.587 * g + 0.114 * b > 150;
}
function resolveStroke(token, fallback) {
  if (!token) return fallback;
  const t = token.trim().toLowerCase();
  if (t === "transparent" || t === "none") return fallback;
  if (t.startsWith("#")) return token.trim();
  if (t in STROKE_PALETTE) return STROKE_PALETTE[t];
  return token.trim();
}
function resolveFill(token) {
  if (!token) return null;
  const t = token.trim().toLowerCase();
  if (t === "transparent" || t === "none") return null;
  if (t.startsWith("#")) return token.trim();
  if (t in FILL_PALETTE) return FILL_PALETTE[t];
  return token.trim();
}
function pairedStrokeForFill(fillToken) {
  if (!fillToken) return null;
  const t = fillToken.trim().toLowerCase();
  if (t in STROKE_PALETTE) return STROKE_PALETTE[t];
  return null;
}
const MARKER_PALETTE = {
  yellow: "#ffe066",
  green: "#8ce99a",
  blue: "#74c0fc",
  pink: "#faa2c1",
  orange: "#ffc078",
  violet: "#b197fc",
  red: "#ff8787"
};
function resolveMarker(token, fallback = MARKER_PALETTE.yellow) {
  if (!token) return fallback;
  const t = token.trim().toLowerCase();
  if (t.startsWith("#")) return token.trim();
  if (t in MARKER_PALETTE) return MARKER_PALETTE[t];
  return resolveStroke(token, fallback);
}
const SVG_NS$7 = "http://www.w3.org/2000/svg";
const DEFAULT_MAX_RANDOMNESS_OFFSET = 2;
const STROKED = "path,line,polyline,polygon,circle,ellipse,rect";
function applyNonScalingStroke(root) {
  if (root.matches?.(STROKED)) root.setAttribute("vector-effect", "non-scaling-stroke");
  root.querySelectorAll(STROKED).forEach((el) => el.setAttribute("vector-effect", "non-scaling-stroke"));
}
function withTuning(opts, style, tune) {
  const k = tune.roughnessScale ?? 1;
  if (k !== 1 && opts.roughness !== void 0) opts.roughness = opts.roughness * k;
  opts.bowing = style.bowing ?? opts.bowing ?? 1;
  opts.preserveVertices = style.preserveVertices ?? opts.preserveVertices ?? false;
  opts.disableMultiStroke = style.disableMultiStroke ?? false;
  opts.maxRandomnessOffset = (style.maxRandomnessOffset ?? DEFAULT_MAX_RANDOMNESS_OFFSET) * k;
  return opts;
}
function sceneRoughOptions(scene, baseRoughness, roughnessScale = 1, baseBowing = 1) {
  const r2 = scene.meta.rough;
  const relative = r2?.roughness !== void 0 ? r2.roughness / CLASSIC_ROUGHNESS : 1;
  return {
    roughness: baseRoughness * relative * roughnessScale,
    bowing: baseBowing * (r2?.bowing ?? 1),
    maxRandomnessOffset: (r2?.maxRandomnessOffset ?? DEFAULT_MAX_RANDOMNESS_OFFSET) * roughnessScale,
    preserveVertices: r2?.preserveVertices ?? false,
    disableMultiStroke: r2?.disableMultiStroke ?? false
  };
}
const CLASSIC_ROUGHNESS = 1.15;
function nodeRoughOptions(style, filled, tune = {}) {
  const opts = withTuning(
    {
      stroke: style.stroke,
      strokeWidth: style.strokeWidth,
      roughness: style.roughness,
      seed: style.seed,
      bowing: 1,
      preserveVertices: false
    },
    style,
    tune
  );
  if (filled && style.fill && style.fillStyle !== "none") {
    opts.fill = style.fill;
    opts.fillStyle = style.fillStyle;
    opts.fillWeight = Math.max(1, style.strokeWidth * 0.9);
    opts.hachureGap = Math.max(6, style.fontSize * 0.4);
    opts.hachureAngle = -41;
  }
  if (style.strokeStyle === "dashed") opts.strokeLineDash = [8, 8];
  else if (style.strokeStyle === "dotted") opts.strokeLineDash = [1.6, 6];
  return opts;
}
function roundedRectPath(x, y, w, h, r2) {
  const rr = Math.min(r2, w / 2, h / 2);
  return [
    `M${x + rr},${y}`,
    `L${x + w - rr},${y}`,
    `Q${x + w},${y} ${x + w},${y + rr}`,
    `L${x + w},${y + h - rr}`,
    `Q${x + w},${y + h} ${x + w - rr},${y + h}`,
    `L${x + rr},${y + h}`,
    `Q${x},${y + h} ${x},${y + h - rr}`,
    `L${x},${y + rr}`,
    `Q${x},${y} ${x + rr},${y}`,
    "Z"
  ].join(" ");
}
function documentPath(x, y, w, h) {
  const wave = h * 0.14;
  const midY = y + h - wave;
  return [
    `M${x},${y}`,
    `L${x + w},${y}`,
    `L${x + w},${midY}`,
    `C${x + w * 0.75},${midY + wave * 1.5} ${x + w * 0.25},${midY - wave * 1.5} ${x},${midY}`,
    "Z"
  ].join(" ");
}
function notePaths(x, y, w, h) {
  const fold = Math.min(w, h) * 0.24;
  const body = [
    `M${x},${y}`,
    `L${x + w - fold},${y}`,
    `L${x + w},${y + fold}`,
    `L${x + w},${y + h}`,
    `L${x},${y + h}`,
    "Z"
  ].join(" ");
  const foldPath = [
    `M${x + w - fold},${y}`,
    `L${x + w - fold},${y + fold}`,
    `L${x + w},${y + fold}`
  ].join(" ");
  return { body, fold: foldPath };
}
function cloudPath(x, y, w, h) {
  const cx = x + w / 2;
  const t = y + h * 0.32;
  const b = y + h * 0.82;
  const l = x + w * 0.12;
  const r2 = x + w * 0.88;
  return [
    `M${l},${b}`,
    `C${x - w * 0.02},${b} ${x - w * 0.02},${t + h * 0.05} ${l + w * 0.06},${t + h * 0.02}`,
    `C${x + w * 0.1},${y + h * 0.02} ${x + w * 0.34},${y - h * 0.04} ${cx - w * 0.04},${t - h * 0.02}`,
    `C${x + w * 0.5},${y - h * 0.02} ${x + w * 0.74},${y + h * 0} ${r2 - w * 0.08},${t + h * 0.02}`,
    `C${x + w * 1.02},${t} ${x + w * 1.02},${b - h * 0.02} ${r2},${b}`,
    "Z"
  ].join(" ");
}
function polygonPoints(pts) {
  return pts;
}
function polarPoint(cx, cy, rx, ry, deg) {
  const a = deg * Math.PI / 180;
  return [cx + Math.cos(a) * rx, cy + Math.sin(a) * ry];
}
function sectorPath(x, y, w, h, start, end, inner) {
  const cx = x + w / 2;
  const cy = y + h / 2;
  const rx = w / 2;
  const ry = h / 2;
  const irx = rx * inner;
  const iry = ry * inner;
  const sweep = Math.min(359.999, Math.max(1e-3, end - start));
  const large = sweep > 180 ? 1 : 0;
  const [ox1, oy1] = polarPoint(cx, cy, rx, ry, start);
  const [ox2, oy2] = polarPoint(cx, cy, rx, ry, start + sweep);
  if (inner <= 1e-3) {
    return [`M${cx},${cy}`, `L${ox1},${oy1}`, `A${rx},${ry} 0 ${large} 1 ${ox2},${oy2}`, "Z"].join(" ");
  }
  const [ix1, iy1] = polarPoint(cx, cy, irx, iry, start + sweep);
  const [ix2, iy2] = polarPoint(cx, cy, irx, iry, start);
  return [
    `M${ox1},${oy1}`,
    `A${rx},${ry} 0 ${large} 1 ${ox2},${oy2}`,
    `L${ix1},${iy1}`,
    `A${irx},${iry} 0 ${large} 0 ${ix2},${iy2}`,
    "Z"
  ].join(" ");
}
function blockArrowPoints(x, y, w, h, dir, headRatio, bodyRatio) {
  const long = dir === "up" || dir === "down" ? h : w;
  const short = dir === "up" || dir === "down" ? w : h;
  const head = Math.min(long, Math.max(8, long * headRatio));
  const bodyHalf = short * bodyRatio / 2;
  const midS = short / 2;
  const pts = [
    [0, midS - bodyHalf],
    [long - head, midS - bodyHalf],
    [long - head, 0],
    [long, midS],
    [long - head, short],
    [long - head, midS + bodyHalf],
    [0, midS + bodyHalf]
  ];
  return pts.map(([l, s]) => {
    switch (dir) {
      case "left":
        return [x + (w - l), y + s];
      case "up":
        return [x + s, y + (h - l)];
      case "down":
        return [x + s, y + l];
      default:
        return [x + l, y + s];
    }
  });
}
function chevronPoints(x, y, w, h, dir, notch) {
  const long = dir === "up" || dir === "down" ? h : w;
  const short = dir === "up" || dir === "down" ? w : h;
  const n = Math.min(long * 0.49, Math.max(0, long * notch));
  const pts = [
    [0, 0],
    [long - n, 0],
    [long, short / 2],
    [long - n, short],
    [0, short],
    [n, short / 2]
  ];
  return pts.map(([l, s]) => {
    switch (dir) {
      case "left":
        return [x + (w - l), y + s];
      case "up":
        return [x + s, y + (h - l)];
      case "down":
        return [x + s, y + l];
      default:
        return [x + l, y + s];
    }
  });
}
function renderShapeBody(rc, shape, rect, style, data, tune = {}) {
  const g = document.createElementNS(SVG_NS$7, "g");
  const { x, y, w, h } = rect;
  const filledOpts = nodeRoughOptions(style, true, tune);
  const strokeOpts = nodeRoughOptions(style, false, tune);
  const sd = data ?? {};
  const add = (el) => g.appendChild(el);
  switch (shape) {
    case "rectangle": {
      if (style.roundness && style.roundness > 0) {
        add(rc.path(roundedRectPath(x, y, w, h, style.roundness), filledOpts));
      } else {
        add(rc.rectangle(x, y, w, h, filledOpts));
      }
      break;
    }
    case "round-rectangle": {
      add(rc.path(roundedRectPath(x, y, w, h, style.roundness ?? Math.min(w, h) * 0.18), filledOpts));
      break;
    }
    case "pill": {
      add(rc.path(roundedRectPath(x, y, w, h, h / 2), filledOpts));
      break;
    }
    case "ellipse": {
      add(rc.ellipse(x + w / 2, y + h / 2, w, h, filledOpts));
      break;
    }
    case "circle": {
      const d = Math.min(w, h);
      add(rc.ellipse(x + w / 2, y + h / 2, d, d, filledOpts));
      break;
    }
    case "diamond": {
      add(
        rc.polygon(
          polygonPoints([
            [x + w / 2, y],
            [x + w, y + h / 2],
            [x + w / 2, y + h],
            [x, y + h / 2]
          ]),
          filledOpts
        )
      );
      break;
    }
    case "triangle": {
      add(
        rc.polygon(
          polygonPoints([
            [x + w / 2, y],
            [x + w, y + h],
            [x, y + h]
          ]),
          filledOpts
        )
      );
      break;
    }
    case "hexagon": {
      const dx = w * 0.22;
      add(
        rc.polygon(
          polygonPoints([
            [x + dx, y],
            [x + w - dx, y],
            [x + w, y + h / 2],
            [x + w - dx, y + h],
            [x + dx, y + h],
            [x, y + h / 2]
          ]),
          filledOpts
        )
      );
      break;
    }
    case "parallelogram": {
      const sk = w * 0.2;
      add(
        rc.polygon(
          polygonPoints([
            [x + sk, y],
            [x + w, y],
            [x + w - sk, y + h],
            [x, y + h]
          ]),
          filledOpts
        )
      );
      break;
    }
    case "trapezoid": {
      const inset = w * 0.2;
      add(
        rc.polygon(
          polygonPoints([
            [x + inset, y],
            [x + w - inset, y],
            [x + w, y + h],
            [x, y + h]
          ]),
          filledOpts
        )
      );
      break;
    }
    case "cylinder": {
      const rx = w / 2;
      const ry = Math.min(h * 0.14, 22);
      const bodyTop = y + ry;
      const bodyBot = y + h - ry;
      const body = [
        `M${x},${bodyTop}`,
        `L${x},${bodyBot}`,
        `A${rx},${ry} 0 0 0 ${x + w},${bodyBot}`,
        `L${x + w},${bodyTop}`,
        `A${rx},${ry} 0 0 0 ${x},${bodyTop}`,
        "Z"
      ].join(" ");
      add(rc.path(body, filledOpts));
      add(rc.ellipse(x + w / 2, bodyTop, w, ry * 2, strokeOpts));
      break;
    }
    case "cloud": {
      add(rc.path(cloudPath(x, y, w, h), filledOpts));
      break;
    }
    case "document": {
      add(rc.path(documentPath(x, y, w, h), filledOpts));
      break;
    }
    case "note": {
      const { body, fold } = notePaths(x, y, w, h);
      add(rc.path(body, filledOpts));
      add(rc.path(fold, strokeOpts));
      break;
    }
    case "actor": {
      const cx = x + w / 2;
      const headR = Math.min(w, h) * 0.16;
      const headY = y + headR + 2;
      const shoulderY = headY + headR + 4;
      const hipY = y + h * 0.66;
      const footY = y + h;
      add(rc.ellipse(cx, headY, headR * 2, headR * 2, strokeOpts));
      add(rc.line(cx, shoulderY, cx, hipY, strokeOpts));
      add(rc.line(x + w * 0.2, shoulderY + 8, x + w * 0.8, shoulderY + 8, strokeOpts));
      add(rc.line(cx, hipY, x + w * 0.28, footY, strokeOpts));
      add(rc.line(cx, hipY, x + w * 0.72, footY, strokeOpts));
      break;
    }
    case "text": {
      break;
    }
    // ---- data-driven primitives (viz building blocks) ----------------------
    case "polygon": {
      const pts = (sd.points ?? []).map(([u, v]) => [x + u * w, y + v * h]);
      if (pts.length >= 3) add(rc.polygon(pts, filledOpts));
      break;
    }
    case "polyline": {
      const pts = (sd.points ?? []).map(([u, v]) => [x + u * w, y + v * h]);
      if (pts.length >= 2) {
        if (sd.closed) add(rc.polygon(pts, filledOpts));
        else add(rc.linearPath(pts, strokeOpts));
      }
      break;
    }
    case "path": {
      if (sd.d) {
        const vw = sd.vw ?? w;
        const vh = sd.vh ?? h;
        const el = rc.path(sd.d, filledOpts);
        const inner = document.createElementNS(SVG_NS$7, "g");
        inner.setAttribute("transform", `translate(${x} ${y}) scale(${w / vw} ${h / vh})`);
        inner.appendChild(el);
        add(inner);
      }
      break;
    }
    case "sector": {
      add(rc.path(sectorPath(x, y, w, h, sd.start ?? 0, sd.end ?? 90, sd.inner ?? 0), filledOpts));
      break;
    }
    case "ring": {
      add(rc.path(sectorPath(x, y, w, h, 0, 359.999, sd.inner ?? 0.6), filledOpts));
      break;
    }
    case "arc": {
      const cx = x + w / 2;
      const cy = y + h / 2;
      const rx = w / 2;
      const ry = h / 2;
      const start = sd.start ?? 180;
      const end = sd.end ?? 360;
      const sweep = Math.min(359.999, Math.max(1e-3, end - start));
      const large = sweep > 180 ? 1 : 0;
      const [x1, y1] = polarPoint(cx, cy, rx, ry, start);
      const [x2, y2] = polarPoint(cx, cy, rx, ry, start + sweep);
      add(rc.path(`M${x1},${y1} A${rx},${ry} 0 ${large} 1 ${x2},${y2}`, strokeOpts));
      break;
    }
    case "block-arrow": {
      add(rc.polygon(blockArrowPoints(x, y, w, h, sd.dir ?? "right", sd.headRatio ?? 0.35, sd.bodyRatio ?? 0.55), filledOpts));
      break;
    }
    case "chevron": {
      add(rc.polygon(chevronPoints(x, y, w, h, sd.dir ?? "right", sd.notch ?? 0.22), filledOpts));
      break;
    }
    default: {
      const plugin = getShapePlugin(shape);
      if (plugin) {
        const pg = plugin(rc, rect, style, data);
        if (tune.nonScalingStroke) applyNonScalingStroke(pg);
        return pg;
      }
      add(rc.path(roundedRectPath(x, y, w, h, 8), filledOpts));
      break;
    }
  }
  if (tune.nonScalingStroke) applyNonScalingStroke(g);
  return g;
}
function labelBelow(shape) {
  return shape === "actor";
}
const SVG_NS$6 = "http://www.w3.org/2000/svg";
const BIG = 2e5;
function renderSceneWithAnnotations(renderer, scene, annotations = scene.annotations, animate = false) {
  renderer.render(scene);
  const layer = new AnnotationLayer(renderer);
  layer.render(scene, annotations, animate);
  return layer;
}
class AnnotationLayer {
  renderer;
  rc;
  root;
  /** The scene currently being drawn — supplies the diagram-wide rough tuning. */
  scene = null;
  constructor(renderer, layer = "annotations") {
    this.renderer = renderer;
    this.rc = rough$1.svg(renderer.svg);
    this.root = renderer.getLayer(layer);
  }
  /**
   * Fold the diagram's declared roughness and the renderer's zoom compensation
   * into one of the mark constants below. A mark on a `hand-clean` diagram
   * comes out as clean as the diagram; a mark on a diagram that declared
   * nothing comes out exactly as it always did (the ratio is 1 and the scale
   * is 1, so every field lands back on its literal value).
   */
  ink(o) {
    if (!this.scene) return o;
    return { ...o, ...sceneRoughOptions(this.scene, o.roughness ?? 1, this.renderer.getRoughnessScale(), o.bowing ?? 1) };
  }
  clear() {
    this.root.replaceChildren();
  }
  /** Render a set of annotations (replaces current). */
  render(scene, annotations, animate = true) {
    this.clear();
    this.scene = scene;
    const sorted = [...annotations].sort((a, b) => rank(a.kind) - rank(b.kind));
    for (const an of sorted) {
      try {
        const g = this.draw(scene, an);
        if (g) {
          if (animate && !this.renderer.isStatic) g.classList.add(revealClass(an.kind));
          this.root.appendChild(g);
        }
      } catch (err) {
        console.warn("annotation render failed", an.kind, err);
      }
    }
    this.renderer.applyStrokePolicy(this.root);
  }
  targetBBox(scene, an) {
    const members = an.options.members ?? [];
    if (members.length) {
      let b = emptyBBox();
      for (const id of members) {
        const eb = elementBBox(scene, id);
        if (eb) b = bboxUnion(b, eb);
      }
      return Number.isFinite(b.minX) ? b : null;
    }
    if (an.target.rect) {
      const r2 = an.target.rect;
      return { minX: r2.x, minY: r2.y, maxX: r2.x + r2.w, maxY: r2.y + r2.h };
    }
    if (an.target.ref) {
      return elementBBox(scene, an.target.ref) ?? null;
    }
    if (an.target.point) {
      const p = an.target.point;
      return { minX: p.x - 4, minY: p.y - 4, maxX: p.x + 4, maxY: p.y + 4 };
    }
    return null;
  }
  draw(scene, an) {
    const g = document.createElementNS(SVG_NS$6, "g");
    g.setAttribute("data-annotation", an.id);
    g.setAttribute("class", "edd-annotation");
    const box = this.targetBBox(scene, an);
    const plugin = getAnnotationPlugin(an.kind);
    if (plugin) {
      plugin(an, {
        scene,
        rc: this.rc,
        g,
        box,
        resolveBBox: (id) => elementBBox(scene, id),
        label: (text, at2, color, anchor = "middle", size) => this.label(g, text, at2, color, anchor, size)
      });
      return g.childNodes.length ? g : null;
    }
    switch (an.kind) {
      case "highlight":
        if (box) this.drawHighlight(g, box, an);
        break;
      case "underline":
        if (box) this.drawUnderline(g, box, an);
        break;
      case "strike":
        if (box) this.drawStrike(g, box, an);
        break;
      case "box":
      case "box-around":
        if (box) this.drawBox(g, box, an);
        break;
      case "circle-mark":
      case "circle-around":
        if (box) this.drawCircle(g, box, an);
        break;
      case "point-at":
        if (box) this.drawPointAt(g, box, an);
        break;
      case "callout":
        if (box) this.drawCallout(g, box, an);
        break;
      case "spotlight":
        if (box) this.drawSpotlight(g, box, an);
        break;
      case "emphasize":
        if (box) this.drawCircle(g, box, an, true);
        break;
      case "note-marker":
      case "badge":
        if (box) this.drawNoteMarker(g, box, an);
        break;
      case "connector":
        this.drawConnector(scene, g, an);
        break;
      case "sticky":
      case "text":
        this.drawSticky(g, an);
        break;
      default:
        if (box) this.drawBox(g, box, an);
        break;
    }
    return g.childNodes.length ? g : null;
  }
  // ---- primitives ---------------------------------------------------------
  drawHighlight(g, box, an) {
    const color = resolveMarker(an.color);
    const pad = 6;
    const r2 = document.createElementNS(SVG_NS$6, "rect");
    r2.setAttribute("x", String(box.minX - pad));
    r2.setAttribute("y", String(box.minY - pad));
    r2.setAttribute("width", String(box.maxX - box.minX + pad * 2));
    r2.setAttribute("height", String(box.maxY - box.minY + pad * 2));
    r2.setAttribute("rx", "6");
    r2.setAttribute("fill", color);
    r2.setAttribute("opacity", "0.42");
    r2.style.mixBlendMode = "multiply";
    g.appendChild(r2);
  }
  drawUnderline(g, box, an) {
    const color = an.color || "#1971c2";
    const y = box.maxY - 4;
    const opts = this.ink({ stroke: color, strokeWidth: 3, roughness: 1.8, bowing: 3, seed: 7 });
    const style = String(an.options.style ?? "solid");
    if (style === "wavy") {
      const pts = [];
      const steps = 12;
      for (let i = 0; i <= steps; i++) {
        const x = box.minX + (box.maxX - box.minX) * i / steps;
        pts.push([x, y + Math.sin(i * 1.3) * 3]);
      }
      g.appendChild(this.rc.curve(pts, opts));
    } else {
      g.appendChild(this.rc.line(box.minX, y, box.maxX, y, opts));
      if (style === "double") g.appendChild(this.rc.line(box.minX, y + 5, box.maxX, y + 5, opts));
    }
  }
  drawStrike(g, box, an) {
    const color = an.color || "#e03131";
    const y = (box.minY + box.maxY) / 2;
    g.appendChild(this.rc.line(box.minX, y, box.maxX, y, this.ink({ stroke: color, strokeWidth: 3, roughness: 1.5, seed: 9 })));
  }
  drawBox(g, box, an) {
    const color = an.color || "#1971c2";
    const b = expandBBox(box, 14);
    g.appendChild(
      this.rc.rectangle(b.minX, b.minY, b.maxX - b.minX, b.maxY - b.minY, this.ink({
        stroke: color,
        strokeWidth: 2.4,
        roughness: 1.5,
        seed: 11
      }))
    );
    if (an.text) this.label(g, an.text, { x: b.minX + 6, y: b.minY - 8 }, color, "start");
  }
  drawCircle(g, box, an, pulse = false) {
    const color = an.color || "#e8590c";
    const c = bboxCenter(box);
    const w = (box.maxX - box.minX) * 1.35 + 24;
    const h = (box.maxY - box.minY) * 1.35 + 24;
    const ring2 = this.rc.ellipse(c.x, c.y, w, h, this.ink({ stroke: color, strokeWidth: 2.6, roughness: 1.6, seed: 13 }));
    if (pulse) ring2.classList.add("edd-anim-pulse"), ring2.style.animationDuration = "1.3s";
    g.appendChild(ring2);
    if (an.text) this.label(g, an.text, { x: c.x, y: box.minY - h * 0.18 }, color, "middle");
  }
  drawPointAt(g, box, an) {
    const color = an.color || "#1971c2";
    const c = bboxCenter(box);
    const from = String(an.options.from ?? "ne");
    const dir = dirVec(from);
    const dist2 = 90;
    const tail = { x: c.x + dir.x * dist2, y: c.y + dir.y * dist2 };
    const tip = { x: c.x + dir.x * ((box.maxX - box.minX) / 2 + 14), y: c.y + dir.y * ((box.maxY - box.minY) / 2 + 14) };
    const ctrl = { x: (tail.x + tip.x) / 2 + dir.y * 20, y: (tail.y + tip.y) / 2 - dir.x * 20 };
    g.appendChild(this.rc.curve([[tail.x, tail.y], [ctrl.x, ctrl.y], [tip.x, tip.y]], this.ink({ stroke: color, strokeWidth: 2.4, roughness: 1.4, seed: 17 })));
    const ang = Math.atan2(tip.y - ctrl.y, tip.x - ctrl.x);
    const sz = 14;
    g.appendChild(
      this.rc.linearPath(
        [
          [tip.x - Math.cos(ang - 0.4) * sz, tip.y - Math.sin(ang - 0.4) * sz],
          [tip.x, tip.y],
          [tip.x - Math.cos(ang + 0.4) * sz, tip.y - Math.sin(ang + 0.4) * sz]
        ],
        this.ink({ stroke: color, strokeWidth: 2.4, roughness: 1, seed: 17 })
      )
    );
    if (an.text) {
      const anchor = dir.x < -0.3 ? "end" : dir.x > 0.3 ? "start" : "middle";
      this.label(g, an.text, { x: tail.x + dir.x * 6, y: tail.y + dir.y * 6 }, color, anchor);
    }
  }
  drawCallout(g, box, an) {
    const color = an.color || "#1971c2";
    const placement = String(an.options.placement ?? "bottom");
    const c = bboxCenter(box);
    const dir = dirVec(placement);
    const gap = 46;
    const anchor = {
      x: c.x + dir.x * ((box.maxX - box.minX) / 2 + 8),
      y: c.y + dir.y * ((box.maxY - box.minY) / 2 + 8)
    };
    const bubble = { x: anchor.x + dir.x * gap, y: anchor.y + dir.y * gap };
    const text = an.text ?? "";
    const w = Math.max(70, text.length * 8.4 + 20);
    const h = 34;
    const bx = bubble.x - (dir.x < -0.3 ? w : dir.x > 0.3 ? 0 : w / 2);
    const by = bubble.y - h / 2;
    g.appendChild(this.rc.line(anchor.x, anchor.y, dir.x < -0.3 ? bx + w : dir.x > 0.3 ? bx : bx + w / 2, by + h / 2, this.ink({ stroke: color, strokeWidth: 2, roughness: 1.2, seed: 19 })));
    g.appendChild(this.rc.rectangle(bx, by, w, h, this.ink({ stroke: color, strokeWidth: 2, roughness: 1.2, seed: 21, fill: "#ffffff", fillStyle: "solid" })));
    this.label(g, text, { x: bx + w / 2, y: by + h / 2 }, color, "middle", 15);
  }
  drawNoteMarker(g, box, an) {
    const color = an.color || "#1971c2";
    const p = { x: box.minX - 6, y: box.minY - 6 };
    g.appendChild(this.rc.circle(p.x, p.y, 30, this.ink({ stroke: color, strokeWidth: 2, roughness: 1, seed: 23, fill: "#ffffff", fillStyle: "solid" })));
    this.label(g, an.text ?? "●", p, color, "middle", 14);
  }
  drawSpotlight(g, box, an) {
    const dim = clamp$2(numOr(an.options.dim, 0.68), 0, 0.95);
    const pad = numOr(an.options.pad, 18);
    const b = expandBBox(box, pad);
    const maskId = `edd-spot-${an.id.replace(/[^a-z0-9]/gi, "")}`;
    const mask = document.createElementNS(SVG_NS$6, "mask");
    mask.setAttribute("id", maskId);
    const full = document.createElementNS(SVG_NS$6, "rect");
    full.setAttribute("x", String(-BIG));
    full.setAttribute("y", String(-BIG));
    full.setAttribute("width", String(BIG * 2));
    full.setAttribute("height", String(BIG * 2));
    full.setAttribute("fill", "white");
    const hole = document.createElementNS(SVG_NS$6, "rect");
    hole.setAttribute("x", String(b.minX));
    hole.setAttribute("y", String(b.minY));
    hole.setAttribute("width", String(b.maxX - b.minX));
    hole.setAttribute("height", String(b.maxY - b.minY));
    hole.setAttribute("rx", "14");
    hole.setAttribute("fill", "black");
    mask.appendChild(full);
    mask.appendChild(hole);
    g.appendChild(mask);
    const shade = document.createElementNS(SVG_NS$6, "rect");
    shade.setAttribute("x", String(-BIG));
    shade.setAttribute("y", String(-BIG));
    shade.setAttribute("width", String(BIG * 2));
    shade.setAttribute("height", String(BIG * 2));
    shade.setAttribute("fill", "#0b1021");
    shade.setAttribute("opacity", String(dim));
    shade.setAttribute("mask", `url(#${maskId})`);
    g.appendChild(shade);
  }
  drawConnector(scene, g, an) {
    const color = an.color || "#1971c2";
    const fromPoint = an.options.fromPoint;
    const fromRef = an.options.fromRef;
    let tail = fromPoint ?? null;
    if (!tail && fromRef) {
      const b = elementBBox(scene, fromRef);
      if (b) tail = bboxCenter(b);
    }
    let tip = an.target.point ?? null;
    if (!tip && an.target.ref) {
      const b = elementBBox(scene, an.target.ref);
      if (b) tip = bboxCenter(b);
    }
    if (!tail || !tip) return;
    if (an.target.ref) {
      const b = elementBBox(scene, an.target.ref);
      if (b) {
        const c = bboxCenter(b);
        const dx = tail.x - c.x;
        const dy = tail.y - c.y;
        const len = Math.hypot(dx, dy) || 1;
        tip = { x: c.x + dx / len * ((b.maxX - b.minX) / 2 + 8), y: c.y + dy / len * ((b.maxY - b.minY) / 2 + 8) };
      }
    }
    g.appendChild(this.rc.line(tail.x, tail.y, tip.x, tip.y, this.ink({ stroke: color, strokeWidth: 2.4, roughness: 1.3, seed: 29 })));
    const ang = Math.atan2(tip.y - tail.y, tip.x - tail.x);
    const sz = 14;
    g.appendChild(
      this.rc.linearPath(
        [
          [tip.x - Math.cos(ang - 0.4) * sz, tip.y - Math.sin(ang - 0.4) * sz],
          [tip.x, tip.y],
          [tip.x - Math.cos(ang + 0.4) * sz, tip.y - Math.sin(ang + 0.4) * sz]
        ],
        this.ink({ stroke: color, strokeWidth: 2.4, roughness: 1, seed: 29 })
      )
    );
    if (an.text) this.label(g, an.text, { x: tail.x, y: tail.y - 12 }, color, "middle");
  }
  drawSticky(g, an) {
    const p = an.target.point;
    if (!p) return;
    const color = an.color || "#e8590c";
    const text = an.text ?? "";
    const w = Math.max(90, text.length * 8.6 + 24);
    const h = 40;
    g.appendChild(
      this.rc.rectangle(p.x - w / 2, p.y - h / 2, w, h, this.ink({
        stroke: color,
        strokeWidth: 2,
        roughness: 1.1,
        seed: 31,
        fill: "#fff9db",
        fillStyle: "solid"
      }))
    );
    this.label(g, text, p, "#5c3d00", "middle", 16);
  }
  label(g, text, at2, color, anchor, size = 17) {
    const t = document.createElementNS(SVG_NS$6, "text");
    const lines = text.split("\n");
    t.setAttribute("text-anchor", anchor);
    t.setAttribute("font-family", '"Excalifont", "Virgil", cursive');
    t.setAttribute("font-size", String(size));
    t.setAttribute("fill", color);
    t.setAttribute("dominant-baseline", "middle");
    const startY = at2.y - (lines.length - 1) * size * 1.2 / 2;
    lines.forEach((line, i) => {
      const ts = document.createElementNS(SVG_NS$6, "tspan");
      ts.setAttribute("x", String(at2.x));
      ts.setAttribute("y", String(startY + i * size * 1.2));
      ts.textContent = line;
      t.appendChild(ts);
    });
    g.appendChild(t);
  }
}
function dirVec(name) {
  const map = {
    n: { x: 0, y: -1 },
    top: { x: 0, y: -1 },
    s: { x: 0, y: 1 },
    bottom: { x: 0, y: 1 },
    e: { x: 1, y: 0 },
    right: { x: 1, y: 0 },
    w: { x: -1, y: 0 },
    left: { x: -1, y: 0 },
    ne: { x: 0.7, y: -0.7 },
    nw: { x: -0.7, y: -0.7 },
    se: { x: 0.7, y: 0.7 },
    sw: { x: -0.7, y: 0.7 }
  };
  return map[name] ?? map.ne;
}
function rank(kind) {
  return kind === "spotlight" ? 0 : 1;
}
function revealClass(kind) {
  if (kind === "spotlight") return "edd-reveal-fade";
  if (kind === "highlight") return "edd-reveal-sweep";
  return "edd-reveal-pop";
}
function numOr(v, d) {
  return typeof v === "number" ? v : d;
}
function clamp$2(v, lo, hi) {
  return v < lo ? lo : v > hi ? hi : v;
}
const SVG_NS$5 = "http://www.w3.org/2000/svg";
const DEFAULTS = {
  highlight: { kind: "highlight", color: "yellow", options: {} },
  underline: { kind: "underline", color: "#1971c2", options: { style: "solid" } },
  box: { kind: "box", color: "#1971c2", options: {} },
  circle: { kind: "circle-mark", color: "#e8590c", options: {} }
};
class LiveAnnotationController {
  renderer;
  getScene;
  layer;
  live = [];
  tool = "select";
  selected = null;
  draft = null;
  undoStack = [];
  redoStack = [];
  seq = 0;
  dragging = null;
  onChange;
  onRequestText;
  constructor(renderer, getScene) {
    this.renderer = renderer;
    this.getScene = getScene;
    this.layer = new AnnotationLayer(renderer, "live");
  }
  // ---- state --------------------------------------------------------------
  emit() {
    this.onChange?.({
      tool: this.tool,
      count: this.live.length,
      canUndo: this.undoStack.length > 0,
      canRedo: this.redoStack.length > 0,
      selected: this.selected
    });
  }
  setTool(t) {
    this.tool = t;
    this.draft = null;
    if (t !== "select") this.selected = null;
    this.render();
    this.emit();
  }
  getTool() {
    return this.tool;
  }
  getAnnotations() {
    return this.live;
  }
  snapshot() {
    this.undoStack.push(structuredClone(this.live));
    if (this.undoStack.length > 100) this.undoStack.shift();
    this.redoStack = [];
  }
  id(kind) {
    return `live_${kind}_${this.seq++}`;
  }
  // ---- render -------------------------------------------------------------
  render() {
    const scene = this.getScene();
    const items = this.draft ? [...this.live, this.draft] : this.live;
    this.layer.render(scene, items, false);
    this.drawSelection();
  }
  drawSelection() {
    if (!this.selected) return;
    const an = this.live.find((a) => a.id === this.selected);
    if (!an) return;
    const box = this.anchorBBox(an);
    if (!box) return;
    const root = this.renderer.getLayer("live");
    const rect = document.createElementNS(SVG_NS$5, "rect");
    const pad = 10;
    rect.setAttribute("x", String(box.minX - pad));
    rect.setAttribute("y", String(box.minY - pad));
    rect.setAttribute("width", String(box.maxX - box.minX + pad * 2));
    rect.setAttribute("height", String(box.maxY - box.minY + pad * 2));
    rect.setAttribute("fill", "none");
    rect.setAttribute("stroke", "#6741d9");
    rect.setAttribute("stroke-width", "1.5");
    rect.setAttribute("stroke-dasharray", "5 4");
    rect.setAttribute("rx", "6");
    root.appendChild(rect);
  }
  anchorBBox(an) {
    const scene = this.getScene();
    if (an.target.ref) return elementBBox(scene, an.target.ref) ?? null;
    if (an.target.point) {
      const p = an.target.point;
      const r2 = an.kind === "sticky" || an.kind === "text" ? 50 : 20;
      return { minX: p.x - r2, minY: p.y - r2, maxX: p.x + r2, maxY: p.y + r2 };
    }
    return null;
  }
  // ---- pointer ------------------------------------------------------------
  /** returns true if the controller handled the event (skip camera pan). */
  pointerDown(world, _screen) {
    const scene = this.getScene();
    if (this.tool === "select") {
      const hit = this.hitLive(world);
      this.selected = hit?.id ?? null;
      if (hit) {
        this.dragging = { id: hit.id, start: world, orig: structuredClone(hit) };
        this.render();
        this.emit();
        return true;
      }
      this.render();
      this.emit();
      return false;
    }
    if (this.tool === "arrow") {
      const node = hitTestNode(scene, world);
      this.draft = {
        id: this.id("connector"),
        kind: "connector",
        target: { ref: null, point: world },
        color: "#1971c2",
        options: node ? { fromRef: node.id } : { fromPoint: world },
        z: 0,
        origin: "live"
      };
      this.render();
      return true;
    }
    if (this.tool === "text") {
      const an = {
        id: this.id("sticky"),
        kind: "sticky",
        target: { ref: null, point: world },
        text: "note",
        color: "#e8590c",
        options: {},
        z: 0,
        origin: "live"
      };
      this.snapshot();
      this.live.push(an);
      this.selected = an.id;
      this.render();
      this.emit();
      this.onRequestText?.(an.id, world);
      return true;
    }
    const def = DEFAULTS[this.tool];
    if (def) {
      const node = hitTestNode(scene, world);
      if (!node) return false;
      const an = {
        id: this.id(def.kind),
        kind: def.kind,
        target: { ref: node.id },
        color: def.color,
        options: { ...def.options },
        z: 0,
        origin: "live"
      };
      this.snapshot();
      this.live.push(an);
      this.selected = an.id;
      this.render();
      this.emit();
      return true;
    }
    return false;
  }
  pointerMove(world) {
    if (this.draft) {
      const scene = this.getScene();
      const node = hitTestNode(scene, world);
      if (node) {
        this.draft.target = { ref: node.id };
      } else {
        this.draft.target = { ref: null, point: world };
      }
      this.render();
      return;
    }
    if (this.dragging) {
      const an = this.live.find((a) => a.id === this.dragging.id);
      if (an && an.target.point) {
        const dx = world.x - this.dragging.start.x;
        const dy = world.y - this.dragging.start.y;
        const o = this.dragging.orig.target.point;
        an.target.point = { x: o.x + dx, y: o.y + dy };
        if (an.options.fromPoint) {
          const fo = this.dragging.orig.options.fromPoint;
          an.options.fromPoint = { x: fo.x + dx, y: fo.y + dy };
        }
        this.render();
      }
    }
  }
  pointerUp(world) {
    if (this.draft) {
      const scene = this.getScene();
      const node = hitTestNode(scene, world);
      if (node) this.draft.target = { ref: node.id };
      else this.draft.target = { ref: null, point: world };
      this.snapshot();
      this.live.push(this.draft);
      this.selected = this.draft.id;
      this.draft = null;
      this.render();
      this.emit();
      return;
    }
    if (this.dragging) {
      const before = this.dragging.orig;
      const cur = this.live.find((a) => a.id === this.dragging.id);
      if (cur && JSON.stringify(before.target) !== JSON.stringify(cur.target)) {
        this.undoStack.push(this.liveWith(this.dragging.id, before));
        this.redoStack = [];
      }
      this.dragging = null;
      this.emit();
    }
  }
  liveWith(id, replacement) {
    return this.live.map((a) => a.id === id ? structuredClone(replacement) : structuredClone(a));
  }
  hitLive(world) {
    for (let i = this.live.length - 1; i >= 0; i--) {
      const an = this.live[i];
      const box = this.anchorBBox(an);
      if (box && world.x >= box.minX - 12 && world.x <= box.maxX + 12 && world.y >= box.minY - 12 && world.y <= box.maxY + 12) {
        return an;
      }
    }
    return null;
  }
  // ---- keyboard / edit ----------------------------------------------------
  handleKey(e) {
    const meta = e.metaKey || e.ctrlKey;
    if (meta && e.key.toLowerCase() === "z") {
      if (e.shiftKey) this.redo();
      else this.undo();
      return true;
    }
    if ((e.key === "Delete" || e.key === "Backspace") && this.selected) {
      this.deleteSelected();
      return true;
    }
    return false;
  }
  setText(id, text) {
    const an = this.live.find((a) => a.id === id);
    if (!an) return;
    an.text = text;
    this.render();
  }
  deleteSelected() {
    if (!this.selected) return;
    this.snapshot();
    this.live = this.live.filter((a) => a.id !== this.selected);
    this.selected = null;
    this.render();
    this.emit();
  }
  undo() {
    const prev = this.undoStack.pop();
    if (!prev) return;
    this.redoStack.push(structuredClone(this.live));
    this.live = prev;
    this.selected = null;
    this.render();
    this.emit();
  }
  redo() {
    const next = this.redoStack.pop();
    if (!next) return;
    this.undoStack.push(structuredClone(this.live));
    this.live = next;
    this.render();
    this.emit();
  }
  clear() {
    if (!this.live.length) return;
    this.snapshot();
    this.live = [];
    this.selected = null;
    this.render();
    this.emit();
  }
  // ---- serialization ------------------------------------------------------
  /** Serialize live annotations back into an EDodoDraw `annotate { … }` block. */
  commitToCode() {
    if (!this.live.length) return "";
    const lines = ['annotate "live" {'];
    const scene = this.getScene();
    for (const an of this.live) {
      lines.push("  " + this.serialize(an, scene));
    }
    lines.push("}");
    return lines.join("\n");
  }
  serialize(an, scene) {
    const color = an.color;
    const ref = an.target.ref;
    switch (an.kind) {
      case "highlight":
        return `highlight ${ref} { color: ${color} }`;
      case "underline":
        return `underline ${ref} { color: ${color} }`;
      case "box":
        return `box [${ref}]${an.text ? ` "${an.text}"` : ""} { color: ${color} }`;
      case "circle-mark":
        return `circle-mark ${ref}${an.text ? ` "${an.text}"` : ""} { color: ${color} }`;
      case "connector": {
        const fromRef = an.options.fromRef;
        if (ref && fromRef) {
          return `point-at ${ref} { from: ${this.cardinalBetween(fromRef, ref, scene)}, color: ${color} }`;
        }
        if (ref) return `point-at ${ref} { color: ${color} }`;
        return `// free arrow (no element anchor) — not representable in code`;
      }
      case "sticky":
      case "text": {
        const p = an.target.point;
        return `// note "${an.text ?? ""}" at (${Math.round(p?.x ?? 0)}, ${Math.round(p?.y ?? 0)})`;
      }
      default:
        return `// ${an.kind} ${ref ?? ""}`;
    }
  }
  cardinalBetween(fromRef, toRef, scene) {
    const a = elementBBox(scene, fromRef);
    const b = elementBBox(scene, toRef);
    if (!a || !b) return "ne";
    const ca = bboxCenter(a);
    const cb = bboxCenter(b);
    const dx = ca.x - cb.x;
    const dy = ca.y - cb.y;
    const h = Math.abs(dx) > Math.abs(dy) * 0.5;
    const v = Math.abs(dy) > Math.abs(dx) * 0.5;
    const ns = dy < 0 ? "n" : "s";
    const ew = dx < 0 ? "w" : "e";
    if (h && v) return ns + ew;
    if (v) return ns;
    return ew;
  }
}
class DiagnosticBag {
  items = [];
  add(d) {
    this.items.push(d);
  }
  error(code, message, at2, extra) {
    this.items.push({ severity: "error", code, message, ...at2, ...extra });
  }
  warn(code, message, at2, extra) {
    this.items.push({ severity: "warning", code, message, ...at2, ...extra });
  }
  get hasErrors() {
    return this.items.some((d) => d.severity === "error");
  }
  get errors() {
    return this.items.filter((d) => d.severity === "error");
  }
}
function nearest(word, menu) {
  let best = null;
  let bestD = Infinity;
  for (const m of menu) {
    const d = levenshtein(word.toLowerCase(), m.toLowerCase());
    if (d < bestD) {
      bestD = d;
      best = m;
    }
  }
  return best !== null && bestD <= Math.max(2, Math.floor(word.length / 3)) ? best : null;
}
function levenshtein(a, b) {
  const m = a.length;
  const n = b.length;
  if (m === 0) return n;
  if (n === 0) return m;
  const dp = new Array(n + 1);
  for (let j = 0; j <= n; j++) dp[j] = j;
  for (let i = 1; i <= m; i++) {
    let prev = dp[0];
    dp[0] = i;
    for (let j = 1; j <= n; j++) {
      const tmp = dp[j];
      dp[j] = Math.min(dp[j] + 1, dp[j - 1] + 1, prev + (a[i - 1] === b[j - 1] ? 0 : 1));
      prev = tmp;
    }
  }
  return dp[n];
}
function formatDiagnostic(d, source, file = "input.edd") {
  const lines = source.split("\n");
  const srcLine = lines[d.line - 1] ?? "";
  const caret = " ".repeat(Math.max(0, d.col - 1)) + "^".repeat(Math.max(1, d.end - d.start));
  let out = `${d.severity} [${d.code}] ${file}:${d.line}:${d.col}: ${d.message}
  ${srcLine}
  ${caret}`;
  if (d.expected || d.found) out += `
  expected: ${d.expected ?? "?"} ; found: ${d.found ?? "?"}`;
  if (d.hint) out += `
  hint: ${d.hint}`;
  return out;
}
var T = /* @__PURE__ */ ((T2) => {
  T2["Newline"] = "Newline";
  T2["Semi"] = "Semi";
  T2["Ident"] = "Ident";
  T2["String"] = "String";
  T2["Raw"] = "Raw";
  T2["Number"] = "Number";
  T2["Color"] = "Color";
  T2["Bool"] = "Bool";
  T2["TokenRef"] = "TokenRef";
  T2["TripleColon"] = "TripleColon";
  T2["EdgeOp"] = "EdgeOp";
  T2["At"] = "At";
  T2["Amp"] = "Amp";
  T2["Pipe"] = "Pipe";
  T2["Colon"] = "Colon";
  T2["Comma"] = "Comma";
  T2["Dot"] = "Dot";
  T2["Slash"] = "Slash";
  T2["Eq"] = "Eq";
  T2["LBrace"] = "LBrace";
  T2["RBrace"] = "RBrace";
  T2["LBracket"] = "LBracket";
  T2["RBracket"] = "RBracket";
  T2["LParen"] = "LParen";
  T2["RParen"] = "RParen";
  T2["Symbol"] = "Symbol";
  T2["EOF"] = "EOF";
  return T2;
})(T || {});
const EDGE_GLYPHS = [
  "<-->",
  "<--",
  "<->",
  "-.->",
  "--->",
  "-->",
  "==>",
  "===",
  "..>",
  "--o",
  "--x",
  "---",
  "<-",
  "->",
  "~>",
  "-o",
  "-x",
  "--"
];
const SHAPE_KEYWORDS = /* @__PURE__ */ new Set([
  "rect",
  "rectangle",
  "round-rect",
  "round-rectangle",
  "roundrect",
  "ellipse",
  "circle",
  "diamond",
  "decision",
  "cylinder",
  "db",
  "database",
  "hexagon",
  "parallelogram",
  "trapezoid",
  "cloud",
  "actor",
  "note",
  "document",
  "stadium",
  "pill",
  "subroutine",
  "triangle",
  "star",
  "text",
  "image",
  "frame",
  "custom",
  "speech-bubble",
  "starburst",
  "ribbon",
  "paper-fold",
  "character",
  "icon"
]);
const IDENT_START = /[A-Za-z_]/;
const IDENT_PART = /[A-Za-z0-9_]/;
const DIGIT = /[0-9]/;
const HEX = /[0-9a-fA-F]/;
const EDGE_START = /* @__PURE__ */ new Set(["-", "<", "=", "~", "."]);
const UNITS = ["turn", "deg", "rad", "px", "pt", "em", "fr", "ms", "s", "x", "%"];
const BOOLS = { true: true, false: false, yes: true, no: false };
function lex(source) {
  const tokens = [];
  const len = source.length;
  let pos = 0;
  let line = 1;
  let lineStart = 0;
  const col = () => pos - lineStart + 1;
  const push = (kind, start, extra = {}) => {
    tokens.push({ kind, text: source.slice(start, pos), start, end: pos, line, col: start - lineStart + 1, ...extra });
  };
  const newline = () => {
    const start = pos;
    pos++;
    tokens.push({ kind: T.Newline, text: "\n", start, end: pos, line, col: col() });
    line++;
    lineStart = pos;
  };
  while (pos < len) {
    const c = source[pos];
    if (c === " " || c === "	" || c === "\r") {
      pos++;
      continue;
    }
    if (c === "\n") {
      newline();
      continue;
    }
    if (c === "/" && source[pos + 1] === "/") {
      while (pos < len && source[pos] !== "\n") pos++;
      continue;
    }
    if (c === "%" && source[pos + 1] === "%") {
      while (pos < len && source[pos] !== "\n") pos++;
      continue;
    }
    if (c === "/" && source[pos + 1] === "*") {
      let depth = 1;
      pos += 2;
      while (pos < len && depth > 0) {
        if (source[pos] === "/" && source[pos + 1] === "*") {
          depth++;
          pos += 2;
        } else if (source[pos] === "*" && source[pos + 1] === "/") {
          depth--;
          pos += 2;
        } else {
          if (source[pos] === "\n") {
            line++;
            lineStart = pos + 1;
          }
          pos++;
        }
      }
      continue;
    }
    if (c === ";") {
      const start = pos;
      pos++;
      push(T.Semi, start);
      continue;
    }
    if (c === '"' && source[pos + 1] === '"' && source[pos + 2] === '"') {
      const start = pos;
      const startLine = line;
      const startLineStart = lineStart;
      pos += 3;
      let body = "";
      while (pos < len && !(source[pos] === '"' && source[pos + 1] === '"' && source[pos + 2] === '"')) {
        if (source[pos] === "\n") {
          line++;
          lineStart = pos + 1;
        }
        body += source[pos];
        pos++;
      }
      pos += 3;
      tokens.push({ kind: T.Raw, text: body.replace(/^\n/, ""), start, end: pos, line: startLine, col: start - startLineStart + 1 });
      continue;
    }
    if (c === '"' || c === "'") {
      const start = pos;
      const quote = c;
      pos++;
      let value = "";
      while (pos < len && source[pos] !== quote) {
        if (source[pos] === "\\") {
          const n = source[pos + 1];
          value += n === "n" ? "\n" : n === "t" ? "	" : n === "r" ? "\r" : n ?? "";
          pos += 2;
        } else {
          if (source[pos] === "\n") {
            line++;
            lineStart = pos + 1;
          }
          value += source[pos];
          pos++;
        }
      }
      pos++;
      tokens.push({ kind: T.String, text: value, start, end: pos, line, col: start - lineStart + 1 });
      continue;
    }
    if (c === "#" && HEX.test(source[pos + 1] ?? "")) {
      const start = pos;
      pos++;
      while (pos < len && HEX.test(source[pos])) pos++;
      push(T.Color, start);
      continue;
    }
    if (c === "$" && IDENT_START.test(source[pos + 1] ?? "")) {
      const start = pos;
      pos++;
      const nameStart = pos;
      while (pos < len && IDENT_PART.test(source[pos])) pos++;
      tokens.push({ kind: T.TokenRef, text: source.slice(start, pos), name: source.slice(nameStart, pos), start, end: pos, line, col: start - lineStart + 1 });
      continue;
    }
    if (c === ":" && source[pos + 1] === ":" && source[pos + 2] === ":") {
      const start = pos;
      pos += 3;
      push(T.TripleColon, start);
      continue;
    }
    if (EDGE_START.has(c)) {
      const glyph = matchEdge(source, pos);
      if (glyph) {
        const start = pos;
        pos += glyph.length;
        push(T.EdgeOp, start);
        continue;
      }
      if (c === ".") {
        const start = pos;
        pos++;
        push(T.Dot, start);
        continue;
      }
      if (c === "=") {
        const start = pos;
        pos++;
        push(T.Eq, start);
        continue;
      }
      if (c !== "-") {
        const start = pos;
        pos++;
        push(T.Symbol, start);
        continue;
      }
    }
    if (DIGIT.test(c) || c === "-" && DIGIT.test(source[pos + 1] ?? "")) {
      const start = pos;
      if (c === "-") pos++;
      while (pos < len && DIGIT.test(source[pos])) pos++;
      if (source[pos] === "." && DIGIT.test(source[pos + 1] ?? "")) {
        pos++;
        while (pos < len && DIGIT.test(source[pos])) pos++;
      }
      const numText = source.slice(start, pos);
      const unit = matchUnit(source, pos);
      if (unit) pos += unit.length;
      tokens.push({ kind: T.Number, text: source.slice(start, pos), num: parseFloat(numText), unit: unit ?? null, start, end: pos, line, col: start - lineStart + 1 });
      continue;
    }
    if (IDENT_START.test(c)) {
      const start = pos;
      pos++;
      while (pos < len) {
        const ch = source[pos];
        if (IDENT_PART.test(ch)) {
          pos++;
        } else if (ch === "-" && IDENT_PART.test(source[pos + 1] ?? "")) {
          pos++;
        } else {
          break;
        }
      }
      const text = source.slice(start, pos);
      const low = text.toLowerCase();
      if (low in BOOLS) {
        tokens.push({ kind: T.Bool, text, bool: BOOLS[low], start, end: pos, line, col: start - lineStart + 1 });
      } else {
        push(T.Ident, start);
      }
      continue;
    }
    const single = {
      "@": T.At,
      "&": T.Amp,
      "|": T.Pipe,
      ":": T.Colon,
      ",": T.Comma,
      "/": T.Slash,
      "{": T.LBrace,
      "}": T.RBrace,
      "[": T.LBracket,
      "]": T.RBracket,
      "(": T.LParen,
      ")": T.RParen
    };
    if (c in single) {
      const start = pos;
      pos++;
      push(single[c], start);
      continue;
    }
    {
      const start = pos;
      pos++;
      push(T.Symbol, start);
    }
  }
  tokens.push({ kind: T.EOF, text: "", start: pos, end: pos, line, col: col() });
  return tokens;
}
function matchEdge(source, pos) {
  for (const g of EDGE_GLYPHS) {
    if (source.startsWith(g, pos)) return g;
  }
  return null;
}
function matchUnit(source, pos) {
  for (const u of UNITS) {
    if (source.startsWith(u, pos)) {
      const after = source[pos + u.length] ?? "";
      if (u === "%" || !IDENT_PART.test(after)) return u;
    }
  }
  return null;
}
const SUGAR = [
  { open: "((", close: "))", shape: "circle" },
  { open: "([", close: "])", shape: "pill" },
  { open: "[[", close: "]]", shape: "rectangle" },
  { open: "[(", close: ")]", shape: "cylinder" },
  { open: "[/", close: "/]", shape: "parallelogram" },
  { open: "[/", close: "\\]", shape: "trapezoid" },
  { open: "[\\", close: "/]", shape: "trapezoid" },
  { open: "[\\", close: "\\]", shape: "parallelogram" },
  { open: "{{", close: "}}", shape: "hexagon" },
  { open: "[", close: "]", shape: "rectangle" },
  { open: "(", close: ")", shape: "round-rectangle" },
  { open: "{", close: "}", shape: "diamond" }
];
function parse(source) {
  const p = new Parser(source);
  const program = p.parseProgram();
  return { program, diagnostics: p.diags };
}
class Parser {
  toks;
  i = 0;
  source;
  diags = new DiagnosticBag();
  constructor(source) {
    this.source = source;
    this.toks = lex(source);
  }
  // ---- cursor -------------------------------------------------------------
  cur() {
    return this.toks[this.i];
  }
  peek(n = 1) {
    return this.toks[Math.min(this.i + n, this.toks.length - 1)];
  }
  is(kind) {
    return this.cur().kind === kind;
  }
  isKw(text) {
    const t = this.cur();
    return t.kind === T.Ident && t.text === text;
  }
  advance() {
    const t = this.toks[this.i];
    if (this.i < this.toks.length - 1) this.i++;
    return t;
  }
  eat(kind) {
    if (this.is(kind)) return this.advance();
    return null;
  }
  atEnd() {
    return this.is(T.EOF);
  }
  spanFrom(t) {
    const end = this.toks[Math.max(0, this.i - 1)];
    return { start: t.start, end: end.end, line: t.line, col: t.col };
  }
  tokSpan(t) {
    return { start: t.start, end: t.end, line: t.line, col: t.col };
  }
  /** consume newline/semi/comma separators (commas are interchangeable). */
  skipSeps() {
    while (this.is(T.Newline) || this.is(T.Semi) || this.is(T.Comma)) this.advance();
  }
  isSep() {
    return this.is(T.Newline) || this.is(T.Semi) || this.is(T.EOF) || this.is(T.RBrace);
  }
  /** move cursor to the first token whose start offset >= off (for raw sugar). */
  seekOffset(off) {
    while (this.i < this.toks.length - 1 && this.cur().start < off) this.i++;
  }
  error(code, message, at2, extra) {
    this.diags.error(code, message, this.tokSpan(at2), { found: at2.text || at2.kind, ...extra });
  }
  /** skip to the next SEP for statement-level recovery. */
  recoverStmt() {
    let depth = 0;
    while (!this.atEnd()) {
      const k = this.cur().kind;
      if (depth === 0 && (k === T.Newline || k === T.Semi)) {
        return;
      }
      if (k === T.LBrace || k === T.LBracket || k === T.LParen) depth++;
      if (k === T.RBrace || k === T.RBracket || k === T.RParen) {
        if (depth === 0) return;
        depth--;
      }
      this.advance();
    }
  }
  /** consume a balanced { ... } block for block-level recovery. */
  skipBlock() {
    if (!this.eat(T.LBrace)) return;
    let depth = 1;
    while (!this.atEnd() && depth > 0) {
      const k = this.advance().kind;
      if (k === T.LBrace) depth++;
      else if (k === T.RBrace) depth--;
    }
  }
  // ---- program ------------------------------------------------------------
  parseProgram() {
    const statements = [];
    this.skipSeps();
    while (!this.atEnd()) {
      const before = this.i;
      const stmt = this.parseTop();
      if (stmt) statements.push(stmt);
      if (this.i === before) this.advance();
      this.skipSeps();
    }
    return { type: "program", statements };
  }
  parseTop() {
    const t = this.cur();
    if (t.kind === T.Ident) {
      switch (t.text) {
        case "edd":
          return this.parseVersion();
        case "meta":
          return this.parseMeta();
        case "import":
          return this.parseImport();
        case "theme":
          return this.parseTheme();
        case "style":
          return this.parseStyle();
        case "defaults":
          return this.parseDefaults();
        case "scene":
          return this.parseScene();
        case "timeline":
          return this.parseTimeline();
        case "annotate":
          return this.parseAnnotate();
        case "mermaid":
          return this.parseMermaid();
        case "viz":
          return this.parseViz();
        case "overrides":
          return this.parseOverrides();
        case "plugin":
        case "define":
          this.advance();
          if (this.is(T.String)) this.advance();
          if (this.is(T.LBrace)) this.skipBlock();
          else this.recoverStmt();
          return null;
      }
    }
    this.error("E-TOP", `unexpected '${t.text || t.kind}' at top level`, t, {
      expected: "meta | theme | style | defaults | scene | timeline | annotate | mermaid",
      hint: "structure lives inside a `scene { … }` block"
    });
    this.recoverStmt();
    return null;
  }
  parseVersion() {
    const t = this.advance();
    const num = this.eat(T.Number);
    return { type: "version", value: num?.num ?? 1, span: this.spanFrom(t) };
  }
  parseImport() {
    const t = this.advance();
    const path = this.eat(T.String)?.text ?? "";
    let as;
    if (this.isKw("as")) {
      this.advance();
      as = this.eat(T.Ident)?.text;
    }
    return { type: "import", path, as, span: this.spanFrom(t) };
  }
  parseMeta() {
    const t = this.advance();
    const attrs = this.parseAttrBlock();
    return { type: "meta", attrs, span: this.spanFrom(t) };
  }
  parseMermaid() {
    const t = this.advance();
    const raw = this.eat(T.Raw);
    return { type: "mermaid", body: raw?.text ?? "", span: this.spanFrom(t) };
  }
  /** `overrides { id at (x,y) [size (w,h)]; … }` — machine-managed positions. */
  parseOverrides() {
    const t = this.advance();
    const entries = [];
    this.eat(T.LBrace);
    this.skipSeps();
    while (!this.is(T.RBrace) && !this.atEnd()) {
      const id = this.eat(T.Ident)?.text;
      if (id) {
        if (this.is(T.Colon)) this.advance();
        else if (this.isKw("at")) this.advance();
        const pos = this.parseValue();
        let x = 0;
        let y = 0;
        let w;
        let h;
        if (pos.t === "tuple" && pos.v[0]?.t === "num" && pos.v[1]?.t === "num") {
          x = pos.v[0].v;
          y = pos.v[1].v;
        }
        if (this.isKw("size")) {
          this.advance();
          const s = this.parseValue();
          if (s.t === "tuple" && s.v[0]?.t === "num" && s.v[1]?.t === "num") {
            w = s.v[0].v;
            h = s.v[1].v;
          }
        }
        entries.push({ id, x, y, w, h });
      } else {
        this.advance();
      }
      this.skipSeps();
    }
    this.eat(T.RBrace);
    return { type: "overrides", entries, span: this.spanFrom(t) };
  }
  parseTheme() {
    const t = this.advance();
    const name = this.eat(T.Ident)?.text ?? "theme";
    let ext;
    if (this.isKw("extends")) {
      this.advance();
      ext = this.eat(T.Ident)?.text;
    }
    const tokens = [];
    const props = [];
    this.eat(T.LBrace);
    this.skipSeps();
    while (!this.is(T.RBrace) && !this.atEnd()) {
      if (this.isKw("tokens")) {
        this.advance();
        this.eat(T.LBrace);
        this.skipSeps();
        while (!this.is(T.RBrace) && !this.atEnd()) {
          if (this.cur().kind === T.TokenRef) {
            const tk = this.advance();
            this.eat(T.Colon);
            tokens.push({ name: tk.name ?? tk.text.slice(1), value: this.parseValue() });
          } else {
            this.advance();
          }
          while (this.is(T.Comma) || this.is(T.Newline) || this.is(T.Semi)) this.advance();
        }
        this.eat(T.RBrace);
      } else if (this.cur().kind === T.TokenRef) {
        const tk = this.advance();
        this.eat(T.Colon);
        tokens.push({ name: tk.name ?? tk.text.slice(1), value: this.parseValue() });
      } else {
        const a = this.parseAttrEntry();
        if (a) props.push(a);
      }
      this.skipSeps();
    }
    this.eat(T.RBrace);
    return { type: "theme", name, extends: ext, tokens, props, span: this.spanFrom(t) };
  }
  parseStyle() {
    const t = this.advance();
    let name = "";
    if (this.is(T.Dot)) {
      this.advance();
      name = this.eat(T.Ident)?.text ?? "";
    } else {
      name = this.eat(T.Ident)?.text ?? "";
    }
    let ext;
    if (this.isKw("extends")) {
      this.advance();
      if (this.is(T.Dot)) this.advance();
      ext = this.eat(T.Ident)?.text;
    }
    const attrs = this.is(T.LBrace) ? this.parseAttrBlock() : [];
    return { type: "style", name, extends: ext, attrs, span: this.spanFrom(t) };
  }
  parseDefaults() {
    const t = this.advance();
    const rules = [];
    this.eat(T.LBrace);
    this.skipSeps();
    while (!this.is(T.RBrace) && !this.atEnd()) {
      const target = this.eat(T.Ident)?.text ?? "node";
      const attrs = this.is(T.LBrace) ? this.parseAttrBlock() : [];
      rules.push({ target, attrs });
      this.skipSeps();
    }
    this.eat(T.RBrace);
    return { type: "defaults", rules, span: this.spanFrom(t) };
  }
  parseAnnotate() {
    const t = this.advance();
    const name = this.is(T.String) ? this.advance().text : void 0;
    const commands = [];
    this.eat(T.LBrace);
    this.skipSeps();
    while (!this.is(T.RBrace) && !this.atEnd()) {
      const cmd = this.parseAnnotationCmd();
      if (cmd) commands.push(cmd);
      this.skipSeps();
    }
    this.eat(T.RBrace);
    return { type: "annotate", name, commands, span: this.spanFrom(t) };
  }
  // ---- scene --------------------------------------------------------------
  parseScene() {
    const t = this.advance();
    const name = this.is(T.Ident) && !this.is(T.LBrace) ? this.maybeSceneName() : void 0;
    const statements = [];
    const braceOpen = this.cur().start;
    this.eat(T.LBrace);
    this.skipSeps();
    while (!this.is(T.RBrace) && !this.atEnd()) {
      const before = this.i;
      const stmt = this.parseSceneStmt();
      if (stmt) statements.push(stmt);
      if (this.i === before) this.advance();
      this.skipSeps();
    }
    const closeTok = this.cur();
    this.eat(T.RBrace);
    return { type: "scene", name, statements, span: this.spanFrom(t), braceOpen, braceClose: closeTok.start };
  }
  maybeSceneName() {
    if (this.is(T.Ident) && this.peek().kind === T.LBrace) return this.advance().text;
    return void 0;
  }
  parseSceneStmt() {
    const t = this.cur();
    if (t.kind === T.Ident) {
      switch (t.text) {
        case "layout":
          return this.parseLayout();
        case "group":
        case "container":
          return this.parseGroup();
        case "anchor":
          return this.parseAnchorStmt();
        case "use":
          return this.parseUse();
        case "style":
          return this.parseStyle();
        case "annotate":
          return this.parseAnnotate();
        case "mermaid":
          return this.parseMermaid();
        case "viz":
          return this.parseViz();
        case "node":
          return this.parseExplicitNode();
      }
      if (SHAPE_KEYWORDS.has(t.text) && this.peek().kind === T.Ident) {
        return this.parseKeywordNode();
      }
    }
    return this.parseNodeOrEdge();
  }
  parseLayout() {
    const t = this.advance();
    const kind = this.eat(T.Ident)?.text ?? "dag";
    const attrs = this.is(T.LBrace) ? this.parseAttrBlock() : [];
    return { type: "layout", kind, attrs, span: this.spanFrom(t) };
  }
  parseUse() {
    const t = this.advance();
    if (this.isKw("theme")) {
      this.advance();
      const name2 = this.eat(T.Ident)?.text ?? "";
      return { type: "use", what: "theme", name: name2, span: this.spanFrom(t) };
    }
    if (this.is(T.Dot)) {
      this.advance();
      const name2 = this.eat(T.Ident)?.text ?? "";
      return { type: "use", what: "class", name: name2, span: this.spanFrom(t) };
    }
    const name = this.eat(T.Ident)?.text ?? "";
    let args;
    if (this.is(T.LParen)) args = this.parseArgList();
    return { type: "use", what: args ? "macro" : "class", name, args, span: this.spanFrom(t) };
  }
  parseAnchorStmt() {
    const t = this.advance();
    const name = this.eat(T.Ident)?.text ?? "";
    let on;
    if (this.isKw("on")) {
      this.advance();
      on = this.eat(T.Ident)?.text;
    }
    let spec = { kind: "cardinal", v: "c" };
    if (this.isKw("at")) {
      this.advance();
      spec = this.parseAnchorSpec();
    }
    return { type: "anchor", name, on, spec, span: this.spanFrom(t) };
  }
  parseAnchorSpec() {
    if (this.is(T.At)) {
      this.advance();
      this.eat(T.LParen);
      const u = this.eat(T.Number)?.num ?? 0;
      this.eat(T.Comma);
      const v = this.eat(T.Number)?.num ?? 0;
      this.eat(T.RParen);
      return { kind: "uv", u, v };
    }
    const word = this.eat(T.Ident)?.text ?? "c";
    if (this.is(T.Colon)) {
      this.advance();
      const num = this.eat(T.Number);
      const raw = num?.num ?? 50;
      const frac = num?.unit === "%" ? raw / 100 : raw > 1 ? raw / 100 : raw;
      return { kind: "side", side: word, frac };
    }
    return { kind: "cardinal", v: word };
  }
  // keyword node: SHAPE_KW id ["label"] {:::cls} [attrs]
  parseKeywordNode() {
    const t = this.advance();
    const shape = t.text;
    const id = this.eat(T.Ident)?.text ?? "";
    return this.finishNode(t, id, shape, void 0);
  }
  // explicit: node id ["label"] [as shape] {:::cls} [attrs]
  parseExplicitNode() {
    const t = this.advance();
    const id = this.eat(T.Ident)?.text ?? "";
    let label;
    if (this.is(T.String)) label = this.advance().text;
    let shape;
    if (this.isKw("as")) {
      this.advance();
      shape = this.eat(T.Ident)?.text;
      if (shape === "custom" && this.is(T.LParen)) {
        const args = this.parseArgList();
        const s = args[0];
        shape = s && s.t === "str" ? `custom:${s.v}` : "custom";
      }
    }
    return this.finishNode(t, id, shape, label);
  }
  finishNode(t, id, shape, label) {
    if (label === void 0 && this.is(T.String)) label = this.advance().text;
    const classes = [];
    if (shape === void 0) {
      const sug = this.tryCaptureSugar();
      if (sug) {
        shape = sug.shape;
        if (label === void 0 && sug.label) label = sug.label;
      }
    }
    while (this.is(T.TripleColon)) {
      this.advance();
      const cls = this.eat(T.Ident)?.text;
      if (cls) classes.push(cls);
    }
    if (label === void 0 && this.is(T.String)) label = this.advance().text;
    const anchors = [];
    let attrs = [];
    let attrOpen;
    let attrClose;
    if (this.is(T.LBrace)) {
      const block = this.parseNodeBlock();
      attrs = block.attrs;
      anchors.push(...block.anchors);
      attrOpen = block.attrOpen;
      attrClose = block.attrClose;
      if (block.diamondLabel !== void 0) {
        shape = shape ?? block.diamondShape ?? "diamond";
        if (label === void 0) label = block.diamondLabel;
        if (this.is(T.LBrace)) {
          const attrBlock = this.parseNodeBlock();
          attrs = attrBlock.attrs;
          anchors.push(...attrBlock.anchors);
          attrOpen = attrBlock.attrOpen;
          attrClose = attrBlock.attrClose;
        }
      }
    }
    return { type: "node", id, label, shape, classes, attrs, anchors, span: this.spanFrom(t), attrOpen, attrClose };
  }
  /** Parse `{ ... }` after a node: could be attr-block OR a diamond label (D1). */
  parseNodeBlock() {
    if (this.braceIsAttr()) {
      const anchors = [];
      const attrs = [];
      const attrOpen = this.cur().start;
      this.eat(T.LBrace);
      this.skipSeps();
      while (!this.is(T.RBrace) && !this.atEnd()) {
        if (this.isKw("anchor")) {
          const a = this.parseAnchorStmt();
          anchors.push(a);
        } else if (this.isKw("use")) {
          const u = this.parseUse();
          attrs.push({ key: "__use", value: { t: "class", v: u.name }, span: u.span });
        } else {
          const a = this.parseAttrEntry();
          if (a) attrs.push(a);
        }
        this.skipSeps();
      }
      const closeTok = this.cur();
      this.eat(T.RBrace);
      return { attrs, anchors, attrOpen, attrClose: closeTok.end };
    }
    const open = this.cur();
    const cap = this.captureSugarAt(open.start);
    if (cap) {
      this.seekOffset(cap.end);
      return { attrs: [], anchors: [], diamondLabel: cap.label, diamondShape: cap.shape };
    }
    this.skipBlock();
    return { attrs: [], anchors: [] };
  }
  /** D1: does the `{` at cursor open an attribute block (vs a diamond label)? */
  braceIsAttr() {
    let j = this.i + 1;
    while (j < this.toks.length && (this.toks[j].kind === T.Newline || this.toks[j].kind === T.Semi)) j++;
    const a = this.toks[j];
    if (!a) return true;
    if (a.kind === T.RBrace) return true;
    if (a.kind === T.Ident) {
      if (a.text === "use" || a.text === "anchor") return true;
      const b = this.toks[j + 1];
      if (b && (b.kind === T.Colon || b.kind === T.Eq)) return true;
    }
    if (a.kind === T.TokenRef) return true;
    return false;
  }
  // ---- node vs edge -------------------------------------------------------
  parseNodeOrEdge() {
    let edgeId;
    if (this.isKw("edge")) {
      this.advance();
      edgeId = this.eat(T.Ident)?.text;
      this.eat(T.Colon);
    }
    const t = this.cur();
    if (t.kind !== T.Ident) {
      this.error("E-STMT", `unexpected '${t.text || t.kind}'`, t, { hint: "expected a node id, shape keyword, or statement keyword" });
      this.recoverStmt();
      return null;
    }
    const first = this.parseEndpointGroup();
    if (this.is(T.EdgeOp)) {
      return this.parseEdgeRest(t, edgeId, first);
    }
    if (edgeId !== void 0) {
      this.error("E-EDGE-NOOP", "expected an edge operator after 'edge' declaration", this.cur(), { expected: "-> | --> | -.-> | ==> | ~> | -- | <->" });
    }
    const ep = first[0];
    const classes = [];
    while (this.is(T.TripleColon)) {
      this.advance();
      const cls = this.eat(T.Ident)?.text;
      if (cls) classes.push(cls);
    }
    const hasMore = this.is(T.String) || this.is(T.LBrace);
    if (!ep.inline && !hasMore && classes.length > 0) {
      return { type: "classapply", id: ep.id, classes, span: this.spanFrom(t) };
    }
    const nd = this.finishNode(t, ep.id, ep.inline?.shape, ep.inline?.label);
    nd.classes.unshift(...classes);
    return nd;
  }
  parseEndpointGroup() {
    const list = [this.parseEndpoint()];
    while (this.is(T.Amp)) {
      this.advance();
      list.push(this.parseEndpoint());
    }
    return list;
  }
  parseEndpoint() {
    const t = this.cur();
    const id = this.eat(T.Ident)?.text ?? "";
    let sub2;
    let uv;
    let inline;
    const sug = this.tryCaptureSugar();
    if (sug) {
      inline = { type: "node", id, label: sug.label, shape: sug.shape, classes: [], attrs: [], anchors: [], span: this.tokSpan(t) };
    } else if (this.is(T.LBrace) && !this.braceIsAttr()) {
      const cap = this.captureSugarAt(this.cur().start);
      if (cap) {
        this.seekOffset(cap.end);
        inline = { type: "node", id, label: cap.label, shape: cap.shape, classes: [], attrs: [], anchors: [], span: this.tokSpan(t) };
      }
    }
    if (this.is(T.Dot)) {
      this.advance();
      sub2 = this.eat(T.Ident)?.text;
      if (sub2 && this.is(T.Colon)) {
        this.advance();
        const n = this.eat(T.Number);
        if (n) sub2 = `${sub2}:${n.num}`;
      }
    }
    if (this.is(T.At)) {
      this.advance();
      this.eat(T.LParen);
      const u = this.eat(T.Number)?.num ?? 0;
      this.eat(T.Comma);
      const v = this.eat(T.Number)?.num ?? 0;
      this.eat(T.RParen);
      uv = [u, v];
    }
    return { id, sub: sub2, uv, inline, span: this.tokSpan(t) };
  }
  parseEdgeRest(t, edgeId, first) {
    const groups = [first];
    const ops = [];
    while (this.is(T.EdgeOp)) {
      const glyph = this.advance().text;
      let midLabel;
      if (this.is(T.Pipe)) {
        midLabel = this.readPipeLabel();
      }
      const g = this.parseEndpointGroup();
      groups.push(g);
      ops.push({ glyph, midLabel });
    }
    let label;
    if (this.is(T.String)) label = this.advance().text;
    const attrs = this.is(T.LBrace) ? this.parseAttrBlock() : [];
    return { type: "edge", id: edgeId, groups, ops, label, attrs, span: this.spanFrom(t) };
  }
  readPipeLabel() {
    const open = this.advance();
    const start = open.end;
    let end = start;
    while (this.i < this.toks.length && !this.is(T.Pipe) && !this.atEnd()) {
      end = this.cur().end;
      this.advance();
    }
    this.eat(T.Pipe);
    return this.source.slice(start, end).trim();
  }
  // ---- groups -------------------------------------------------------------
  parseGroup() {
    const t = this.advance();
    const id = this.eat(T.Ident)?.text ?? "";
    let label;
    if (this.is(T.String)) label = this.advance().text;
    const attrs = [];
    let layout;
    const items = [];
    this.eat(T.LBrace);
    this.skipSeps();
    while (!this.is(T.RBrace) && !this.atEnd()) {
      const before = this.i;
      if (this.isKw("layout")) {
        layout = this.parseLayout();
      } else if (this.cur().kind === T.Ident && this.peek().kind === T.Colon && !SHAPE_KEYWORDS.has(this.cur().text)) {
        const a = this.parseAttrEntry();
        if (a) attrs.push(a);
      } else {
        const stmt = this.parseSceneStmt();
        if (stmt) items.push(stmt);
      }
      if (this.i === before) this.advance();
      this.skipSeps();
    }
    this.eat(T.RBrace);
    return { type: "group", id, label, attrs, layout, items, span: this.spanFrom(t) };
  }
  // ---- timeline -----------------------------------------------------------
  parseTimeline() {
    const t = this.advance();
    const name = this.is(T.Ident) && this.peek().kind === T.LBrace ? this.advance().text : void 0;
    const props = [];
    const beats = [];
    this.eat(T.LBrace);
    this.skipSeps();
    while (!this.is(T.RBrace) && !this.atEnd()) {
      const before = this.i;
      if (this.isKw("beat") || this.isKw("step")) {
        beats.push(this.parseBeat());
      } else if (this.cur().kind === T.Ident && this.peek().kind === T.Colon) {
        const a = this.parseAttrEntry();
        if (a) props.push({ type: "prop", key: a.key, value: a.value, span: a.span });
      } else {
        this.recoverStmt();
      }
      if (this.i === before) this.advance();
      this.skipSeps();
    }
    this.eat(T.RBrace);
    return { type: "timeline", name, props, beats, span: this.spanFrom(t) };
  }
  parseBeat() {
    const t = this.advance();
    const id = this.eat(T.Ident)?.text ?? `beat_${t.line}`;
    const title = this.is(T.String) ? this.advance().text : void 0;
    const items = [];
    this.eat(T.LBrace);
    this.skipSeps();
    while (!this.is(T.RBrace) && !this.atEnd()) {
      const before = this.i;
      const item = this.parseBeatItem();
      if (item) items.push(item);
      if (this.i === before) this.advance();
      this.skipSeps();
    }
    this.eat(T.RBrace);
    return { type: "beat", id, title, items, span: this.spanFrom(t) };
  }
  parseBeatItem() {
    const t = this.cur();
    if (t.kind === T.Ident) {
      switch (t.text) {
        case "camera":
          return this.parseCamera();
        case "reveal":
          return this.parseReveal();
        case "annotate":
          return this.parseAnnotate();
        case "stagger":
          return this.parseStagger();
      }
      if (this.peek().kind === T.Colon) {
        const a = this.parseAttrEntry();
        if (a) return { type: "prop", key: a.key, value: a.value, span: a.span };
        return null;
      }
      if (isAnnotKind(t.text)) return this.parseAnnotationCmd();
      if (REVEAL_VERBS.has(t.text)) return this.parseRevealCmd();
    }
    this.error("E-BEAT", `unexpected '${t.text || t.kind}' in beat`, t, {
      hint: "expected camera | reveal | annotate | stagger | narrate: … | a command"
    });
    this.recoverStmt();
    return null;
  }
  parseCamera() {
    const t = this.advance();
    const cam = { type: "camera", attrs: [], span: this.spanFrom(t) };
    if (this.is(T.LBrace)) {
      cam.attrs = this.parseAttrBlock();
      this.applyCameraAttrs(cam);
      cam.span = this.spanFrom(t);
      return cam;
    }
    if (this.is(T.Ident)) {
      cam.op = this.advance().text;
      if (cam.op === "zoom" && this.is(T.Number)) {
        cam.zoom = this.advance().num;
      } else if (cam.op === "pan") {
        if (this.isKw("to") || this.isKw("by")) this.advance();
        if (this.is(T.LParen)) {
          const v = this.parseValue();
          if (v.t === "tuple" && v.v.length >= 2 && v.v[0].t === "num" && v.v[1].t === "num") {
            cam.pan = [v.v[0].v, v.v[1].v];
          }
        }
      }
    }
    if (this.canStartCameraTarget()) {
      cam.targets = [this.parseValue()];
    }
    while (this.is(T.Ident) || this.is(T.LBrace)) {
      if (this.is(T.LBrace)) {
        const block = this.parseAttrBlock();
        cam.attrs.push(...block);
        this.applyCameraAttrs(cam);
        break;
      }
      const w = this.cur().text;
      if (w === "zoom") {
        this.advance();
        cam.zoom = this.eat(T.Number)?.num;
      } else if (w === "over" || w === "duration") {
        this.advance();
        cam.over = this.readDuration();
      } else if (w === "ease") {
        this.advance();
        cam.ease = this.parseValue();
      } else if (w === "pad") {
        this.advance();
        cam.pad = this.eat(T.Number)?.num;
      } else if (w === "pan") {
        this.advance();
        this.eat(T.Ident);
        const v = this.parseValue();
        if (v.t === "tuple" && v.v.length >= 2 && v.v[0].t === "num" && v.v[1].t === "num") {
          cam.pan = [v.v[0].v, v.v[1].v];
        }
      } else {
        break;
      }
    }
    cam.span = this.spanFrom(t);
    return cam;
  }
  canStartCameraTarget() {
    if (this.is(T.LBracket)) return true;
    if (this.is(T.Dot)) return true;
    if (this.is(T.Ident)) {
      const w = this.cur().text;
      return !["zoom", "over", "ease", "pad", "pan", "duration", "tilt"].includes(w);
    }
    return false;
  }
  applyCameraAttrs(cam) {
    for (const a of cam.attrs) {
      switch (a.key) {
        case "focus":
          cam.op = "focus";
          cam.targets = [a.value];
          break;
        case "fit":
          cam.op = "fit";
          cam.targets = [a.value];
          break;
        case "center":
          cam.op = "center";
          cam.targets = [a.value];
          break;
        case "zoom":
          if (a.value.t === "num") cam.zoom = a.value.v;
          break;
        case "pad":
          if (a.value.t === "num") cam.pad = a.value.v;
          break;
        case "duration":
        case "over":
          if (a.value.t === "num") cam.over = a.value.unit === "s" ? a.value.v * 1e3 : a.value.v;
          break;
        case "ease":
          cam.ease = a.value;
          break;
        case "pan":
          if (a.value.t === "tuple" && a.value.v[0]?.t === "num" && a.value.v[1]?.t === "num") {
            cam.pan = [a.value.v[0].v, a.value.v[1].v];
          }
          break;
      }
    }
    if (!cam.op) {
      if (cam.pan) cam.op = "pan";
      else if (cam.zoom != null) cam.op = "zoom";
    }
  }
  parseReveal() {
    const t = this.advance();
    const commands = [];
    if (!this.is(T.LBrace)) {
      const explicitVerb = this.is(T.Ident) && REVEAL_VERBS.has(this.cur().text);
      const cmd = explicitVerb ? this.parseRevealCmd() : this.parseRevealCmd("show");
      if (cmd) commands.push(cmd);
      return { type: "reveal", commands, span: this.spanFrom(t) };
    }
    this.eat(T.LBrace);
    this.skipSeps();
    while (!this.is(T.RBrace) && !this.atEnd()) {
      const before = this.i;
      const cmd = this.parseRevealCmd();
      if (cmd) commands.push(cmd);
      if (this.i === before) this.advance();
      this.skipSeps();
    }
    this.eat(T.RBrace);
    return { type: "reveal", commands, span: this.spanFrom(t) };
  }
  /**
   * `[verb] [targets] [with <effect>] [{ attrs }]`.
   * `implicitVerb` supplies the verb for the bare `reveal <target>` form, where
   * the first word is a target rather than a verb.
   */
  parseRevealCmd(implicitVerb) {
    const t = this.cur();
    const verb = implicitVerb ?? (this.eat(T.Ident)?.text ?? "");
    const targets = [];
    while (this.canStartValue() && !this.isKw("with")) {
      targets.push(this.parseValue());
      if (this.is(T.Comma)) this.advance();
      else break;
    }
    let withEffect;
    if (this.isKw("with")) {
      this.advance();
      withEffect = this.eat(T.Ident)?.text;
    }
    const attrs = this.is(T.LBrace) ? this.parseAttrBlock() : [];
    return { type: "revealcmd", verb, targets, with: withEffect, attrs, span: this.spanFrom(t) };
  }
  parseStagger() {
    const t = this.advance();
    const delayMs = this.readDuration();
    const commands = [];
    this.eat(T.LBrace);
    this.skipSeps();
    while (!this.is(T.RBrace) && !this.atEnd()) {
      const before = this.i;
      const w = this.cur().text;
      if (this.cur().kind === T.Ident && isAnnotKind(w)) {
        const c = this.parseAnnotationCmd();
        if (c) commands.push(c);
      } else {
        const c = this.parseRevealCmd();
        if (c) commands.push(c);
      }
      if (this.i === before) this.advance();
      this.skipSeps();
    }
    this.eat(T.RBrace);
    return { type: "stagger", delayMs, commands, span: this.spanFrom(t) };
  }
  parseAnnotationCmd() {
    const t = this.cur();
    const kind = this.eat(T.Ident)?.text ?? "";
    let target;
    let targetList;
    if (this.is(T.LBracket)) {
      targetList = this.parseValue();
    } else if (this.is(T.Ident)) {
      target = this.parseEndpoint();
    }
    const text = this.is(T.String) ? this.advance().text : void 0;
    const attrs = this.is(T.LBrace) ? this.parseAttrBlock() : [];
    return { type: "annotcmd", kind, target, targetList, text, attrs, span: this.spanFrom(t) };
  }
  // ---- viz ------------------------------------------------------------------
  /**
   * `viz <type> [id] ["Title"] { options + data entries }`
   * Body lines are either `key: value` options or data entries:
   *   item "Label" 40 { color: red }
   *   flow source -> target 25
   *   row ["Q1", 10, 12]
   *   item "Root" { item "Child A"; item "Child B" }
   */
  parseViz() {
    const t = this.advance();
    const vizType = this.is(T.String) ? this.advance().text : this.eat(T.Ident)?.text ?? "";
    const id = this.is(T.Ident) ? this.advance().text : void 0;
    const title = this.is(T.String) ? this.advance().text : void 0;
    const attrs = [];
    const entries = [];
    this.eat(T.LBrace);
    this.parseVizBody(attrs, entries);
    this.eat(T.RBrace);
    return { type: "viz", vizType, id, title, attrs, entries, span: this.spanFrom(t) };
  }
  parseVizBody(attrs, entries) {
    this.skipSeps();
    while (!this.is(T.RBrace) && !this.atEnd()) {
      const before = this.i;
      const t = this.cur();
      if (t.kind === T.Ident && (this.peek().kind === T.Colon || this.peek().kind === T.Eq)) {
        const a = this.parseAttrEntry();
        if (a) attrs.push(a);
      } else if (t.kind === T.Ident) {
        const e = this.parseVizEntry();
        if (e) entries.push(e);
      } else {
        this.error("E-VIZ", `unexpected '${t.text || t.kind}' in viz block`, t, {
          hint: 'expected `key: value` options or a data entry like `item "Label" 40`'
        });
        this.recoverStmt();
      }
      if (this.i === before) this.advance();
      this.skipSeps();
    }
  }
  parseVizEntry() {
    const t = this.cur();
    const kind = this.eat(T.Ident)?.text ?? "";
    const entry = { kind, values: [], attrs: [], children: [], span: this.tokSpan(t) };
    if (this.is(T.Ident)) entry.id = this.advance().text;
    if (this.is(T.String)) entry.label = this.advance().text;
    if (this.is(T.EdgeOp)) {
      this.advance();
      if (this.is(T.String)) entry.to = this.advance().text;
      else if (this.is(T.Ident)) entry.to = this.advance().text;
    }
    while (!this.isSep() && !this.is(T.LBrace)) {
      const k = this.cur().kind;
      if (k === T.Number || k === T.String || k === T.LBracket || k === T.Color || k === T.Ident || k === T.LParen) {
        entry.values.push(this.parseValue());
        if (this.is(T.Comma)) this.advance();
      } else {
        break;
      }
    }
    while (this.is(T.LBrace)) {
      this.eat(T.LBrace);
      const childAttrs = [];
      this.parseVizBody(childAttrs, entry.children);
      entry.attrs.push(...childAttrs);
      this.eat(T.RBrace);
    }
    entry.span = this.spanFrom(t);
    return entry;
  }
  // ---- attributes & values ------------------------------------------------
  parseAttrBlock() {
    const attrs = [];
    if (!this.eat(T.LBrace)) return attrs;
    this.skipSeps();
    while (!this.is(T.RBrace) && !this.atEnd()) {
      const a = this.parseAttrEntry();
      if (a) attrs.push(a);
      while (this.is(T.Comma) || this.is(T.Newline) || this.is(T.Semi)) this.advance();
    }
    this.eat(T.RBrace);
    return attrs;
  }
  parseAttrEntry() {
    const t = this.cur();
    if (t.kind !== T.Ident) {
      this.error("E-ATTR", `expected attribute name, found '${t.text || t.kind}'`, t);
      this.recoverStmt();
      return null;
    }
    const key = this.advance().text;
    if (!this.eat(T.Colon)) this.eat(T.Eq);
    const value = this.parseValue();
    return { key, value, span: this.spanFrom(t) };
  }
  canStartValue() {
    switch (this.cur().kind) {
      case T.String:
      case T.Number:
      case T.Color:
      case T.Bool:
      case T.TokenRef:
      case T.Ident:
      case T.LParen:
      case T.LBracket:
      case T.Dot:
        return true;
      default:
        return false;
    }
  }
  parseValue() {
    const t = this.cur();
    switch (t.kind) {
      case T.String:
        this.advance();
        return { t: "str", v: t.text };
      case T.Number:
        this.advance();
        return { t: "num", v: t.num ?? 0, unit: t.unit ?? null };
      case T.Color:
        this.advance();
        return { t: "color", v: t.text };
      case T.Bool:
        this.advance();
        return { t: "bool", v: t.bool ?? false };
      case T.TokenRef:
        this.advance();
        return { t: "token", v: t.name ?? t.text.slice(1) };
      case T.Dot: {
        this.advance();
        const name = this.eat(T.Ident)?.text ?? "";
        return { t: "class", v: name };
      }
      case T.LParen:
        return this.parseTuple();
      case T.LBracket:
        return this.parseList();
      case T.Ident:
        return this.parseIdentValue();
      default:
        this.advance();
        return { t: "ident", v: t.text };
    }
  }
  parseIdentValue() {
    const t = this.advance();
    if (this.is(T.LParen)) {
      const args = this.parseArgList();
      return { t: "call", name: t.text, args };
    }
    if (this.is(T.Dot) || this.is(T.At)) {
      let sub2;
      let uv;
      if (this.is(T.Dot)) {
        this.advance();
        sub2 = this.eat(T.Ident)?.text;
      }
      if (this.is(T.At)) {
        this.advance();
        this.eat(T.LParen);
        const u = this.eat(T.Number)?.num ?? 0;
        this.eat(T.Comma);
        const v = this.eat(T.Number)?.num ?? 0;
        this.eat(T.RParen);
        uv = [u, v];
      }
      return { t: "ref", id: t.text, sub: sub2, uv };
    }
    if (this.is(T.LBrace)) {
      const block = this.parseAttrBlock();
      return { t: "styled", name: t.text, block };
    }
    return { t: "ident", v: t.text };
  }
  parseTuple() {
    this.eat(T.LParen);
    const vals = [];
    this.skipSeps();
    while (!this.is(T.RParen) && !this.atEnd()) {
      vals.push(this.parseValue());
      while (this.is(T.Comma) || this.is(T.Newline)) this.advance();
    }
    this.eat(T.RParen);
    return { t: "tuple", v: vals };
  }
  parseList() {
    this.eat(T.LBracket);
    const vals = [];
    this.skipSeps();
    while (!this.is(T.RBracket) && !this.atEnd()) {
      vals.push(this.parseValue());
      while (this.is(T.Comma) || this.is(T.Newline)) this.advance();
    }
    this.eat(T.RBracket);
    return { t: "list", v: vals };
  }
  parseArgList() {
    this.eat(T.LParen);
    const args = [];
    this.skipSeps();
    while (!this.is(T.RParen) && !this.atEnd()) {
      if (this.cur().kind === T.Ident && this.peek().kind === T.Colon) {
        this.advance();
        this.advance();
      }
      args.push(this.parseValue());
      while (this.is(T.Comma) || this.is(T.Newline)) this.advance();
    }
    this.eat(T.RParen);
    return args;
  }
  readDuration() {
    const n = this.eat(T.Number);
    if (!n) return 0;
    const val = n.num ?? 0;
    return n.unit === "s" ? val * 1e3 : val;
  }
  // ---- shape sugar capture ------------------------------------------------
  tryCaptureSugar() {
    const t = this.cur();
    if (t.kind !== T.LBracket && t.kind !== T.LParen) return null;
    const cap = this.captureSugarAt(t.start);
    if (!cap) return null;
    this.seekOffset(cap.end);
    return { shape: cap.shape, label: cap.label };
  }
  /** raw-capture mermaid shape sugar from source at `start`. */
  captureSugarAt(start) {
    const src = this.source;
    for (const s of SUGAR) {
      if (src.startsWith(s.open, start)) {
        const bodyStart = start + s.open.length;
        const closeIdx = src.indexOf(s.close, bodyStart);
        if (closeIdx === -1) continue;
        const label = src.slice(bodyStart, closeIdx).trim().replace(/^["']|["']$/g, "");
        return { shape: s.shape, label, end: closeIdx + s.close.length };
      }
    }
    return null;
  }
}
const ANNOT_KINDS = /* @__PURE__ */ new Set([
  "highlight",
  "underline",
  "strike",
  "point-at",
  "spotlight",
  "callout",
  "label",
  "box",
  "circle-mark",
  "note-marker",
  "emphasize",
  "badge"
]);
function isAnnotKind(word) {
  return ANNOT_KINDS.has(word) || !!getAnnotationPlugin(word);
}
const REVEAL_VERBS = /* @__PURE__ */ new Set([
  "show",
  "hide",
  "draw-on",
  "emphasize",
  "fade-in",
  "fade-out",
  "pop",
  "flow",
  "pulse",
  "move",
  "restyle",
  "add",
  "remove"
]);
const r = (n) => Math.round(n);
function firstScene(program) {
  return program.statements.find((s) => s.type === "scene");
}
function walkNodes(stmts, visit) {
  for (const st of stmts) {
    if (st.type === "node") visit(st);
    else if (st.type === "group") walkNodes(st.items, visit);
  }
}
function findNodeDecl(program, id) {
  let found;
  for (const s of program.statements) {
    if (s.type === "scene") walkNodes(s.statements, (n) => {
      if (n.id === id && !found) found = n;
    });
  }
  return found;
}
function findEdgeStmt(program, from, to) {
  for (const s of program.statements) {
    if (s.type !== "scene") continue;
    for (const st of s.statements) {
      if (st.type !== "edge") continue;
      for (let h = 0; h < st.ops.length; h++) {
        const a = st.groups[h]?.some((e) => e.id === from);
        const b = st.groups[h + 1]?.some((e) => e.id === to);
        if (a && b) return { edge: st, hop: h };
      }
    }
  }
  return void 0;
}
function splice(source, start, end, text) {
  return source.slice(0, start) + text + source.slice(end);
}
function removeLines(source, start, end) {
  let ls = start;
  while (ls > 0 && source[ls - 1] !== "\n") ls--;
  let le = end;
  while (le < source.length && source[le] !== "\n") le++;
  if (le < source.length) le++;
  return source.slice(0, ls) + source.slice(le);
}
function formatOverrides(entries) {
  if (!entries.length) return "";
  const lines = entries.slice().sort((a, b) => a.id.localeCompare(b.id)).map((e) => {
    const size = e.w != null && e.h != null ? ` size (${r(e.w)}, ${r(e.h)})` : "";
    return `  ${e.id} at (${r(e.x)}, ${r(e.y)})${size}`;
  });
  return `overrides {
${lines.join("\n")}
}`;
}
function writeOverrides(source, entries) {
  const { program } = parse(source);
  const existing = program.statements.find((s) => s.type === "overrides");
  const block = formatOverrides(entries);
  if (existing) {
    if (!block) {
      return removeLines(source, existing.span.start, existing.span.end).replace(/\n{3,}/g, "\n\n");
    }
    return splice(source, existing.span.start, existing.span.end, block);
  }
  if (!block) return source;
  return source.replace(/\s*$/, "") + "\n\n" + block + "\n";
}
function upsertAttrs(source, decl, updates) {
  if (!updates.length) return source;
  if (decl.attrOpen == null || decl.attrClose == null) {
    const body = updates.map((u) => `${u.key}: ${u.value}`).join(", ");
    return splice(source, decl.span.end, decl.span.end, ` { ${body} }`);
  }
  const edits = [];
  const inserts = [];
  const realAttrs = decl.attrs.filter((a) => a.key !== "__use");
  const byKey = new Map(realAttrs.map((a) => [a.key, a]));
  for (const u of updates) {
    const ex = byKey.get(u.key);
    if (ex) edits.push({ start: ex.span.start, end: ex.span.end, text: `${u.key}: ${u.value}` });
    else inserts.push(`${u.key}: ${u.value}`);
  }
  if (inserts.length) {
    if (realAttrs.length) {
      const lastEnd = Math.max(...realAttrs.map((a) => a.span.end));
      edits.push({ start: lastEnd, end: lastEnd, text: `, ${inserts.join(", ")}` });
    } else {
      const pos = decl.attrClose - 1;
      edits.push({ start: pos, end: pos, text: `${inserts.join(", ")} ` });
    }
  }
  edits.sort((a, b) => b.start - a.start);
  let out = source;
  for (const e of edits) out = splice(out, e.start, e.end, e.text);
  return out;
}
function renameNode(source, id, label) {
  const { program } = parse(source);
  const decl = findNodeDecl(program, id);
  const quoted = `"${label.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`;
  if (!decl) return ensureNodeDecl(source, program, id, void 0, quoted, []);
  const declText = source.slice(decl.span.start, decl.span.end);
  const m = declText.match(/(['"])(?:\\.|(?!\1).)*\1/);
  if (m && m.index != null) {
    const start = decl.span.start + m.index;
    return splice(source, start, start + m[0].length, quoted);
  }
  return upsertAttrs(source, decl, [{ key: "label", value: quoted }]);
}
function styleNode(source, id, style) {
  const { program } = parse(source);
  const decl = findNodeDecl(program, id);
  const updates = [];
  if (style.fill !== void 0) updates.push({ key: "fill", value: style.fill });
  if (style.stroke !== void 0) updates.push({ key: "stroke", value: style.stroke });
  if (style.shape !== void 0) updates.push({ key: "shape", value: style.shape });
  if (!updates.length) return source;
  if (decl) return upsertAttrs(source, decl, updates);
  return ensureNodeDecl(source, program, id, void 0, void 0, updates);
}
function addNode(source, node) {
  const { program } = parse(source);
  const decl = `${node.shape} ${node.id} "${node.label.replace(/"/g, '\\"')}"`;
  return insertIntoScene(source, program, decl);
}
function addEdge(source, edge) {
  const { program } = parse(source);
  const glyph = edge.glyph ?? "-->";
  const label = edge.label ? ` "${edge.label.replace(/"/g, '\\"')}"` : "";
  return insertIntoScene(source, program, `${edge.from} ${glyph} ${edge.to}${label}`);
}
function deleteEdge(source, from, to) {
  const { program } = parse(source);
  const hit = findEdgeStmt(program, from, to);
  if (!hit) return source;
  return removeLines(source, hit.edge.span.start, hit.edge.span.end).replace(/\n{3,}/g, "\n\n");
}
function reconnectEdge(source, from, to, which, newId) {
  const { program } = parse(source);
  const hit = findEdgeStmt(program, from, to);
  if (!hit) return source;
  const group = which === "from" ? hit.edge.groups[hit.hop] : hit.edge.groups[hit.hop + 1];
  const ep = group?.find((e) => e.id === (which === "from" ? from : to));
  if (!ep) return source;
  return splice(source, ep.span.start, ep.span.end, newId);
}
function setEdgeLabel(source, from, to, label) {
  const { program } = parse(source);
  const hit = findEdgeStmt(program, from, to);
  if (!hit || hit.edge.attrs.length) return source;
  const quoted = `"${label.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`;
  const text = source.slice(hit.edge.span.start, hit.edge.span.end);
  const matches = [...text.matchAll(/(['"])(?:\\.|(?!\1).)*\1/g)];
  const last = matches[matches.length - 1];
  if (hit.edge.label != null && last && last.index != null) {
    const start = hit.edge.span.start + last.index;
    return splice(source, start, start + last[0].length, quoted);
  }
  return splice(source, hit.edge.span.end, hit.edge.span.end, ` ${quoted}`);
}
function deleteElements(source, ids) {
  let out = source;
  for (const id of ids) {
    const { program: program2 } = parse(out);
    const removals = [];
    const decl = findNodeDecl(program2, id);
    if (decl) removals.push({ start: decl.span.start, end: decl.span.end });
    for (const s of program2.statements) {
      if (s.type !== "scene") continue;
      for (const st of s.statements) {
        if (st.type === "edge") {
          const mentions = st.groups.some((g) => g.some((ep) => ep.id === id));
          if (mentions) removals.push({ start: st.span.start, end: st.span.end });
        }
      }
    }
    removals.sort((a, b) => b.start - a.start);
    for (const rm of removals) out = removeLines(out, rm.start, rm.end);
  }
  const { program } = parse(out);
  const ov = program.statements.find((s) => s.type === "overrides");
  if (ov && ov.type === "overrides") {
    const kept = ov.entries.filter((e) => !ids.includes(e.id));
    if (kept.length !== ov.entries.length) out = writeOverrides(out, kept);
  }
  return out.replace(/\n{3,}/g, "\n\n");
}
function insertIntoScene(source, program, line) {
  const scene = firstScene(program);
  if (scene && scene.braceClose != null) {
    let pos = scene.braceClose;
    while (pos > 0 && (source[pos - 1] === " " || source[pos - 1] === "	")) pos--;
    const indent = "  ";
    return splice(source, pos, pos, `${source[pos - 1] === "\n" ? "" : "\n"}${indent}${line}
`);
  }
  return source.replace(/\s*$/, "") + `

scene {
  ${line}
}
`;
}
function ensureNodeDecl(source, program, id, shape, quotedLabel, attrs) {
  const decl = findNodeDecl(program, id);
  if (decl) {
    let out = source;
    if (quotedLabel) out = renameNode(out, id, quotedLabel.replace(/^"|"$/g, ""));
    if (attrs.length) {
      const rp = parse(out);
      const d2 = findNodeDecl(rp.program, id);
      if (d2) out = upsertAttrs(out, d2, attrs);
    }
    return out;
  }
  const head = `${"rect"} ${id}${quotedLabel ? ` ${quotedLabel}` : ""}`;
  const attrText = attrs.length ? ` { ${attrs.map((a) => `${a.key}: ${a.value}`).join(", ")} }` : "";
  return insertIntoScene(source, program, head + attrText);
}
const SVG_NS$4 = "http://www.w3.org/2000/svg";
const HANDLE = 9;
const EDGE_TOL = 9;
const MIN = 24;
const ACCENT = "#6741d9";
const SHAPE_FOR = { rect: "rect", ellipse: "ellipse", diamond: "diamond", text: "text" };
const ID_PREFIX = { rect: "box", ellipse: "oval", diamond: "dec", text: "txt" };
const RESIZE_CURSOR = {
  nw: "nwse-resize",
  se: "nwse-resize",
  ne: "nesw-resize",
  sw: "nesw-resize",
  n: "ns-resize",
  s: "ns-resize",
  e: "ew-resize",
  w: "ew-resize"
};
class EditController {
  r;
  cb;
  overlay;
  tool = "select";
  selected = [];
  selectedEdge = null;
  renamingEdge = null;
  hoverId = null;
  clipboard = [];
  pasteSeq = 0;
  drag = null;
  constructor(renderer, cb) {
    this.r = renderer;
    this.cb = cb;
    this.overlay = document.createElementNS(SVG_NS$4, "g");
    this.overlay.setAttribute("class", "edd-edit-overlay");
    this.overlay.style.pointerEvents = "none";
    renderer.screenLayer.appendChild(this.overlay);
  }
  setTool(t) {
    this.tool = t;
    if (t !== "select") {
      this.selected = [];
      this.selectedEdge = null;
    }
    this.hoverId = null;
    this.render();
    this.emit();
  }
  getTool() {
    return this.tool;
  }
  /** All selected ids (a copy). */
  getSelected() {
    return this.selected.slice();
  }
  /** The primary (last-selected) node, used for the inspector + rename. */
  getSelectedNode() {
    const id = this.selected[this.selected.length - 1];
    return id ? this.cb.getScene().nodes.find((n) => n.id === id) ?? null : null;
  }
  selectedNodes() {
    const scene = this.cb.getScene();
    return this.selected.map((id) => scene.nodes.find((n) => n.id === id)).filter((n) => !!n);
  }
  getSelectedEdge() {
    return this.selectedEdge;
  }
  selectedEdgeObj() {
    if (!this.selectedEdge) return null;
    return this.cb.getScene().edges.find((e) => e.id === this.selectedEdge) ?? null;
  }
  clearSelection() {
    if (!this.selected.length && !this.selectedEdge && !this.hoverId) return;
    this.selected = [];
    this.selectedEdge = null;
    this.hoverId = null;
    this.render();
    this.emit();
  }
  selectAll() {
    if (this.tool !== "select") return;
    this.selected = this.cb.getScene().nodes.map((n) => n.id);
    this.render();
    this.emit();
  }
  state() {
    return { tool: this.tool, selected: this.selected.slice(), selectedEdge: this.selectedEdge };
  }
  emit() {
    this.cb.onState(this.state());
  }
  cursor(c) {
    this.cb.onCursor?.(c);
  }
  // ---- selection overlay (screen space, constant size) --------------------
  render() {
    this.overlay.replaceChildren();
    const d = this.drag;
    if (d?.kind === "create") return this.drawCreatePreview();
    if (d?.kind === "connect") return this.drawConnectPreview();
    if (d?.kind === "reconnect") return this.drawReconnectPreview(d);
    if (d?.kind === "marquee") this.drawMarquee(d);
    if (!d && this.hoverId && !this.selected.includes(this.hoverId)) {
      const hn = this.cb.getScene().nodes.find((n) => n.id === this.hoverId);
      if (hn) this.overlay.appendChild(this.boxFor(hn, ACCENT, "none", void 0, 0.55));
    }
    const edge = this.selectedEdgeObj();
    if (edge) this.drawEdgeSelection(edge);
    const nodes = this.selectedNodes();
    for (const node of nodes) this.overlay.appendChild(this.boxFor(node, ACCENT, "none", "4 3"));
    if (nodes.length === 1) {
      const { x, y, w, h } = this.screenRect(nodes[0]);
      for (const [hid, p] of this.handlePoints(x, y, w, h)) {
        const hb = this.rect(p.x - HANDLE / 2, p.y - HANDLE / 2, HANDLE, HANDLE, ACCENT, "#ffffff");
        hb.setAttribute("data-handle", hid);
        this.overlay.appendChild(hb);
      }
    }
  }
  edgeScreenPoints(edge) {
    return (edge.points ?? []).map((p) => this.r.worldToScreen(p));
  }
  drawEdgeSelection(edge) {
    const pts = this.edgeScreenPoints(edge);
    if (pts.length < 2) return;
    const line = document.createElementNS(SVG_NS$4, "polyline");
    line.setAttribute("points", pts.map((p) => `${p.x},${p.y}`).join(" "));
    line.setAttribute("fill", "none");
    line.setAttribute("stroke", ACCENT);
    line.setAttribute("stroke-width", "6");
    line.setAttribute("stroke-linecap", "round");
    line.setAttribute("stroke-linejoin", "round");
    line.setAttribute("opacity", "0.28");
    this.overlay.appendChild(line);
    for (const end of ["from", "to"]) {
      const p = end === "from" ? pts[0] : pts[pts.length - 1];
      const c = document.createElementNS(SVG_NS$4, "circle");
      c.setAttribute("cx", String(p.x));
      c.setAttribute("cy", String(p.y));
      c.setAttribute("r", String(HANDLE / 2 + 1));
      c.setAttribute("stroke", ACCENT);
      c.setAttribute("stroke-width", "1.5");
      c.setAttribute("fill", "#ffffff");
      c.setAttribute("data-edge-handle", end);
      this.overlay.appendChild(c);
    }
  }
  drawReconnectPreview(d) {
    const a = this.r.worldToScreen(d.anchor);
    const b = this.r.worldToScreen(d.cur);
    const line = document.createElementNS(SVG_NS$4, "line");
    line.setAttribute("x1", String(a.x));
    line.setAttribute("y1", String(a.y));
    line.setAttribute("x2", String(b.x));
    line.setAttribute("y2", String(b.y));
    line.setAttribute("stroke", ACCENT);
    line.setAttribute("stroke-width", "2");
    line.setAttribute("stroke-dasharray", "5 4");
    this.overlay.appendChild(line);
    const target = hitTestNode(this.cb.getScene(), d.cur);
    if (target) this.overlay.appendChild(this.boxFor(target, ACCENT, "rgba(103,65,217,0.10)", "4 3"));
  }
  screenRect(node) {
    const a = this.r.worldToScreen({ x: node.x, y: node.y });
    const b = this.r.worldToScreen({ x: node.x + node.w, y: node.y + node.h });
    return { x: Math.min(a.x, b.x), y: Math.min(a.y, b.y), w: Math.abs(b.x - a.x), h: Math.abs(b.y - a.y) };
  }
  boxFor(node, stroke, fill, dash, opacity) {
    const { x, y, w, h } = this.screenRect(node);
    const r2 = this.rect(x - 2, y - 2, w + 4, h + 4, stroke, fill, dash);
    if (opacity != null) r2.setAttribute("opacity", String(opacity));
    return r2;
  }
  handlePoints(x, y, w, h) {
    return [
      ["nw", { x, y }],
      ["n", { x: x + w / 2, y }],
      ["ne", { x: x + w, y }],
      ["e", { x: x + w, y: y + h / 2 }],
      ["se", { x: x + w, y: y + h }],
      ["s", { x: x + w / 2, y: y + h }],
      ["sw", { x, y: y + h }],
      ["w", { x, y: y + h / 2 }]
    ];
  }
  rect(x, y, w, h, stroke, fill, dash) {
    const r2 = document.createElementNS(SVG_NS$4, "rect");
    r2.setAttribute("x", String(x));
    r2.setAttribute("y", String(y));
    r2.setAttribute("width", String(Math.max(0, w)));
    r2.setAttribute("height", String(Math.max(0, h)));
    r2.setAttribute("stroke", stroke);
    r2.setAttribute("stroke-width", "1.5");
    r2.setAttribute("fill", fill);
    if (dash) r2.setAttribute("stroke-dasharray", dash);
    return r2;
  }
  drawCreatePreview() {
    if (this.drag?.kind !== "create") return;
    const a = this.r.worldToScreen(this.drag.startWorld);
    const b = this.r.worldToScreen(this.drag.cur);
    this.overlay.appendChild(this.rect(Math.min(a.x, b.x), Math.min(a.y, b.y), Math.abs(b.x - a.x), Math.abs(b.y - a.y), ACCENT, "rgba(103,65,217,0.08)", "4 3"));
  }
  drawMarquee(d) {
    const a = this.r.worldToScreen(d.startWorld);
    const b = this.r.worldToScreen(d.cur);
    this.overlay.appendChild(this.rect(Math.min(a.x, b.x), Math.min(a.y, b.y), Math.abs(b.x - a.x), Math.abs(b.y - a.y), ACCENT, "rgba(103,65,217,0.10)", "4 3"));
  }
  drawConnectPreview() {
    const d = this.drag;
    if (!d || d.kind !== "connect") return;
    const scene = this.cb.getScene();
    const fromNode = scene.nodes.find((n) => n.id === d.from);
    if (!fromNode) return;
    const a = this.r.worldToScreen(rectCenter({ x: fromNode.x, y: fromNode.y, w: fromNode.w, h: fromNode.h }));
    const b = this.r.worldToScreen(d.cur);
    const line = document.createElementNS(SVG_NS$4, "line");
    line.setAttribute("x1", String(a.x));
    line.setAttribute("y1", String(a.y));
    line.setAttribute("x2", String(b.x));
    line.setAttribute("y2", String(b.y));
    line.setAttribute("stroke", ACCENT);
    line.setAttribute("stroke-width", "2");
    line.setAttribute("stroke-dasharray", "5 4");
    this.overlay.appendChild(line);
  }
  // ---- hit testing --------------------------------------------------------
  /** Which end (if any) of the selected edge is under the cursor. */
  hitEdgeHandle(screen) {
    const edge = this.selectedEdgeObj();
    const pts = edge ? this.edgeScreenPoints(edge) : [];
    if (pts.length < 2) return null;
    const near = (p) => Math.abs(screen.x - p.x) <= HANDLE && Math.abs(screen.y - p.y) <= HANDLE;
    if (near(pts[0])) return "from";
    if (near(pts[pts.length - 1])) return "to";
    return null;
  }
  worldTol(px) {
    return px / (this.r.getCamera().zoom || 1);
  }
  hitHandle(screen) {
    if (this.selected.length !== 1) return null;
    const node = this.getSelectedNode();
    if (!node) return null;
    const { x, y, w, h } = this.screenRect(node);
    for (const [hid, p] of this.handlePoints(x, y, w, h)) {
      if (Math.abs(screen.x - p.x) <= HANDLE && Math.abs(screen.y - p.y) <= HANDLE) return hid;
    }
    return null;
  }
  // ---- pointer ------------------------------------------------------------
  /** returns true if handled (facade should not pan). */
  pointerDown(world, screen, mods = {}) {
    const scene = this.cb.getScene();
    if (this.tool === "hand") return false;
    if (this.tool === "select") {
      if (!mods.shift) {
        const handle = this.hitHandle(screen);
        if (handle) {
          const n = this.getSelectedNode();
          this.drag = { kind: "resize", id: n.id, handle, startWorld: world, orig: { x: n.x, y: n.y, w: n.w, h: n.h } };
          return true;
        }
        const end = this.hitEdgeHandle(screen);
        const edge = this.selectedEdgeObj();
        if (end && edge && edge.from.node && edge.to.node) {
          const pts = edge.points ?? [];
          const anchor = end === "from" ? pts[pts.length - 1] : pts[0];
          this.drag = { kind: "reconnect", edgeId: edge.id, end, from: edge.from.node, to: edge.to.node, anchor: anchor ?? world, cur: world };
          return true;
        }
      }
      const hit = hitTestNode(scene, world);
      if (hit) {
        this.selectedEdge = null;
        if (mods.shift) {
          this.selected = this.selected.includes(hit.id) ? this.selected.filter((id) => id !== hit.id) : [...this.selected, hit.id];
          this.hoverId = null;
          this.render();
          this.emit();
          return true;
        }
        if (!this.selected.includes(hit.id)) {
          this.selected = [hit.id];
          this.emit();
        }
        const orig = /* @__PURE__ */ new Map();
        for (const n of this.selectedNodes()) orig.set(n.id, { x: n.x, y: n.y });
        this.drag = { kind: "move", ids: [...orig.keys()], hitId: hit.id, startWorld: world, orig, moved: false };
        this.hoverId = null;
        this.render();
        return true;
      }
      if (!mods.shift) {
        const edge = hitTestEdge(scene, world, this.worldTol(EDGE_TOL));
        if (edge) {
          this.selected = [];
          this.selectedEdge = edge.id;
          this.hoverId = null;
          this.render();
          this.emit();
          return true;
        }
      }
      this.selectedEdge = null;
      this.drag = { kind: "marquee", startWorld: world, cur: world, base: mods.shift ? this.selected.slice() : [], moved: false };
      return true;
    }
    if (this.tool === "arrow") {
      const hit = hitTestNode(scene, world);
      if (hit) {
        this.drag = { kind: "connect", from: hit.id, cur: world };
        return true;
      }
      return true;
    }
    this.drag = { kind: "create", startWorld: world, cur: world };
    return true;
  }
  pointerMove(world, screen) {
    const d = this.drag;
    if (!d) return this.hover(world, screen);
    const scene = this.cb.getScene();
    if (d.kind === "move") {
      const dx = world.x - d.startWorld.x;
      const dy = world.y - d.startWorld.y;
      if (Math.abs(dx) > 0.5 || Math.abs(dy) > 0.5) d.moved = true;
      for (const id of d.ids) {
        const n = scene.nodes.find((x) => x.id === id);
        const o = d.orig.get(id);
        if (n && o) {
          n.x = o.x + dx;
          n.y = o.y + dy;
        }
      }
      this.r.render(scene);
      this.render();
    } else if (d.kind === "resize") {
      const n = scene.nodes.find((x) => x.id === d.id);
      if (n) {
        this.applyResize(n, d.handle, d.orig, world);
        this.r.render(scene);
        this.render();
      }
    } else if (d.kind === "marquee") {
      d.cur = world;
      if (Math.abs(world.x - d.startWorld.x) > 3 || Math.abs(world.y - d.startWorld.y) > 3) d.moved = true;
      this.selected = this.marqueeSelection(d);
      this.render();
    } else {
      d.cur = world;
      this.render();
    }
  }
  /** Nearest routed edge to the point, or null (screen-tolerance aware). */
  edgeAt(world) {
    return hitTestEdge(this.cb.getScene(), world, this.worldTol(EDGE_TOL));
  }
  /** Idle hover: set the cursor + a faint outline so the canvas feels alive. */
  hover(world, screen) {
    if (this.tool !== "select") return;
    let cursor = "default";
    let hover = null;
    if (screen) {
      const handle = this.hitHandle(screen);
      if (handle) cursor = RESIZE_CURSOR[handle];
      else if (this.hitEdgeHandle(screen)) cursor = "move";
    }
    if (cursor === "default") {
      const hit = hitTestNode(this.cb.getScene(), world);
      if (hit) {
        cursor = "move";
        hover = this.selected.includes(hit.id) ? null : hit.id;
      } else if (this.edgeAt(world)) {
        cursor = "pointer";
      }
    }
    this.cursor(cursor);
    if (hover !== this.hoverId) {
      this.hoverId = hover;
      this.render();
    }
  }
  marqueeSelection(d) {
    const x0 = Math.min(d.startWorld.x, d.cur.x);
    const y0 = Math.min(d.startWorld.y, d.cur.y);
    const x1 = Math.max(d.startWorld.x, d.cur.x);
    const y1 = Math.max(d.startWorld.y, d.cur.y);
    const inside = this.cb.getScene().nodes.filter((n) => n.x < x1 && n.x + n.w > x0 && n.y < y1 && n.y + n.h > y0).map((n) => n.id);
    return d.base.length ? [.../* @__PURE__ */ new Set([...d.base, ...inside])] : inside;
  }
  pointerUp(world) {
    const d = this.drag;
    this.drag = null;
    if (!d) return;
    const scene = this.cb.getScene();
    if (d.kind === "move") {
      if (d.moved) this.commitPositions();
      else if (d.ids.length > 1) {
        this.selected = [d.hitId];
        this.render();
        this.emit();
      } else this.render();
    } else if (d.kind === "resize") {
      const n = scene.nodes.find((x) => x.id === d.id);
      if (n && (Math.abs(n.w - d.orig.w) > 0.5 || Math.abs(n.h - d.orig.h) > 0.5)) this.commitPositions(n.id, { w: n.w, h: n.h });
      else this.render();
    } else if (d.kind === "marquee") {
      if (!d.moved && !d.base.length) this.selected = [];
      this.render();
      this.emit();
    } else if (d.kind === "create") {
      this.finishCreate(d.startWorld, world);
    } else if (d.kind === "connect") {
      const target = hitTestNode(scene, world);
      if (target && target.id !== d.from) {
        this.cb.onSource(addEdge(this.cb.getSource(), { from: d.from, to: target.id }));
      } else {
        this.render();
      }
    } else if (d.kind === "reconnect") {
      const target = hitTestNode(scene, world);
      const otherEnd = d.end === "from" ? d.to : d.from;
      if (target && target.id !== (d.end === "from" ? d.from : d.to) && target.id !== otherEnd) {
        this.selectedEdge = null;
        this.cb.onSource(reconnectEdge(this.cb.getSource(), d.from, d.to, d.end, target.id));
        this.emit();
      } else {
        this.render();
      }
    }
  }
  applyResize(n, handle, o, world) {
    let { x, y, w, h } = o;
    const right = o.x + o.w;
    const bottom = o.y + o.h;
    if (handle.includes("e")) w = Math.max(MIN, world.x - o.x);
    if (handle.includes("s")) h = Math.max(MIN, world.y - o.y);
    if (handle.includes("w")) {
      x = Math.min(world.x, right - MIN);
      w = right - x;
    }
    if (handle.includes("n")) {
      y = Math.min(world.y, bottom - MIN);
      h = bottom - y;
    }
    n.x = x;
    n.y = y;
    n.w = w;
    n.h = h;
  }
  /**
   * Commit the current node geometry. Freezes EVERY node's position into
   * overrides (the Excalidraw-like "you've taken manual control" model), so
   * moving some nodes never reshuffles the auto-layout of the rest. Existing
   * size overrides are preserved; pass `sizeId`/`size` for a resized node.
   */
  commitPositions(sizeId, size) {
    const scene = this.cb.getScene();
    const prev = new Map((scene.overrides ?? []).map((o) => [o.id, o]));
    const map = /* @__PURE__ */ new Map();
    for (const node of scene.nodes) {
      const p = prev.get(node.id);
      map.set(node.id, { id: node.id, x: node.x, y: node.y, w: p?.w, h: p?.h });
    }
    if (sizeId && size) {
      const e = map.get(sizeId);
      if (e) {
        e.w = size.w;
        e.h = size.h;
      }
    }
    this.cb.onSource(writeOverrides(this.cb.getSource(), [...map.values()]));
  }
  finishCreate(a, b) {
    const scene = this.cb.getScene();
    const shape = SHAPE_FOR[this.tool] ?? "rect";
    const dragW = Math.abs(b.x - a.x);
    const dragH = Math.abs(b.y - a.y);
    const w = dragW < 8 ? 140 : dragW;
    const h = dragH < 8 ? 70 : dragH;
    const x = dragW < 8 ? a.x - w / 2 : Math.min(a.x, b.x);
    const y = dragH < 8 ? a.y - h / 2 : Math.min(a.y, b.y);
    const id = this.uniqueId(scene, ID_PREFIX[this.tool] ?? "box");
    let src = addNode(this.cb.getSource(), { id, shape, label: "" });
    const map = new Map((scene.overrides ?? []).map((o) => [o.id, { ...o }]));
    map.set(id, { id, x, y, w, h });
    src = writeOverrides(src, [...map.values()]);
    this.selected = [id];
    this.tool = "select";
    this.cb.onSource(src);
    this.emit();
    const center = this.r.worldToScreen({ x: x + w / 2, y: y + h / 2 });
    this.cb.onRequestRename(id, "", center);
  }
  uniqueId(scene, prefix) {
    return this.freshId(new Set(scene.nodes.map((n) => n.id)), prefix);
  }
  freshId(used, prefix) {
    let i = 1;
    while (used.has(`${prefix}${i}`)) i++;
    return `${prefix}${i}`;
  }
  // ---- discrete ops -------------------------------------------------------
  requestRenameSelected() {
    const edge = this.selectedEdgeObj();
    if (edge && edge.from.node && edge.to.node) {
      this.renamingEdge = { from: edge.from.node, to: edge.to.node };
      const pts = edge.points ?? [];
      const mid = pts.length ? pts[Math.floor(pts.length / 2)] : { x: 0, y: 0 };
      this.cb.onRequestRename(edge.id, edge.label, this.r.worldToScreen(mid));
      return;
    }
    const n = this.getSelectedNode();
    if (!n) return;
    const c = this.r.worldToScreen(rectCenter({ x: n.x, y: n.y, w: n.w, h: n.h }));
    this.cb.onRequestRename(n.id, n.label, c);
  }
  dblclick(world) {
    const hit = hitTestNode(this.cb.getScene(), world);
    if (hit) {
      this.renamingEdge = null;
      this.selected = [hit.id];
      this.selectedEdge = null;
      this.emit();
      const c = this.r.worldToScreen(rectCenter({ x: hit.x, y: hit.y, w: hit.w, h: hit.h }));
      this.cb.onRequestRename(hit.id, hit.label, c);
      return true;
    }
    const edge = this.edgeAt(world);
    if (edge && edge.from.node && edge.to.node) {
      this.selected = [];
      this.selectedEdge = edge.id;
      this.renamingEdge = { from: edge.from.node, to: edge.to.node };
      this.emit();
      const pts = edge.points ?? [];
      const mid = pts.length ? pts[Math.floor(pts.length / 2)] : world;
      this.cb.onRequestRename(edge.id, edge.label, this.r.worldToScreen(mid));
      return true;
    }
    return false;
  }
  applyRename(id, label) {
    const re = this.renamingEdge;
    this.renamingEdge = null;
    if (re) {
      this.cb.onSource(setEdgeLabel(this.cb.getSource(), re.from, re.to, label));
      return;
    }
    this.cb.onSource(renameNode(this.cb.getSource(), id, label));
  }
  /** Style one node. */
  applyStyle(id, style) {
    this.cb.onSource(styleNode(this.cb.getSource(), id, style));
  }
  /** Style several nodes in one source patch (a single undo step). */
  applyStyleMany(ids, style) {
    if (!ids.length) return;
    let src = this.cb.getSource();
    for (const id of ids) src = styleNode(src, id, style);
    this.cb.onSource(src);
  }
  deleteSelected() {
    const edge = this.selectedEdgeObj();
    if (edge && edge.from.node && edge.to.node) {
      this.selectedEdge = null;
      this.hoverId = null;
      this.cb.onSource(deleteEdge(this.cb.getSource(), edge.from.node, edge.to.node));
      this.emit();
      return;
    }
    if (!this.selected.length) return;
    const ids = this.selected.slice();
    this.selected = [];
    this.hoverId = null;
    this.cb.onSource(deleteElements(this.cb.getSource(), ids));
    this.emit();
  }
  specOf(n) {
    return { shape: n.shape, label: n.label, fill: n.style.fill ?? null, x: n.x, y: n.y, w: n.w, h: n.h };
  }
  /** Clone the selection in place with a small offset (Cmd/Ctrl-D). */
  duplicateSelected() {
    const specs = this.selectedNodes().map((n) => this.specOf(n));
    if (!specs.length) return false;
    this.cloneSpecs(specs, 16, 16);
    return true;
  }
  /** Copy the selection into the in-memory clipboard (Cmd/Ctrl-C). */
  copySelected() {
    const specs = this.selectedNodes().map((n) => this.specOf(n));
    if (!specs.length) return false;
    this.clipboard = specs;
    this.pasteSeq = 0;
    return true;
  }
  /** Paste the clipboard (Cmd/Ctrl-V), offset so copies don't stack exactly. */
  paste() {
    if (!this.clipboard.length) return false;
    this.pasteSeq += 1;
    const off = 24 * this.pasteSeq;
    this.cloneSpecs(this.clipboard, off, off);
    return true;
  }
  cloneSpecs(specs, dx, dy) {
    const scene = this.cb.getScene();
    let src = this.cb.getSource();
    const used = new Set(scene.nodes.map((n) => n.id));
    const overrides = new Map((scene.overrides ?? []).map((o) => [o.id, { ...o }]));
    const newIds = [];
    for (const s of specs) {
      const id = this.freshId(used, "copy");
      used.add(id);
      src = addNode(src, { id, shape: s.shape, label: s.label });
      if (s.fill != null) src = styleNode(src, id, { fill: s.fill });
      overrides.set(id, { id, x: s.x + dx, y: s.y + dy, w: s.w, h: s.h });
      newIds.push(id);
    }
    src = writeOverrides(src, [...overrides.values()]);
    this.selected = newIds;
    this.cb.onSource(src);
    this.emit();
  }
  handleKey(e) {
    if ((e.key === "Delete" || e.key === "Backspace") && (this.selected.length || this.selectedEdge)) {
      this.deleteSelected();
      return true;
    }
    if (e.key === "Escape") {
      this.clearSelection();
      return true;
    }
    if (this.selected.length && e.key.startsWith("Arrow")) {
      const step = e.shiftKey ? 10 : 1;
      const dx = e.key === "ArrowLeft" ? -step : e.key === "ArrowRight" ? step : 0;
      const dy = e.key === "ArrowUp" ? -step : e.key === "ArrowDown" ? step : 0;
      if (dx === 0 && dy === 0) return false;
      const scene = this.cb.getScene();
      for (const id of this.selected) {
        const n = scene.nodes.find((x) => x.id === id);
        if (n) {
          n.x += dx;
          n.y += dy;
        }
      }
      this.r.render(scene);
      this.render();
      this.commitPositions();
      return true;
    }
    return false;
  }
  dispose() {
    this.overlay.remove();
  }
}
function cameraForBBox(bbox, viewport, opts = {}) {
  const padding = opts.padding ?? 64;
  const minZoom = opts.minZoom ?? 0.05;
  const maxZoom = opts.maxZoom ?? 2.5;
  if (isEmptyBBox(bbox)) return { cx: 0, cy: 0, zoom: 1 };
  const w = Math.max(1, bbox.maxX - bbox.minX);
  const h = Math.max(1, bbox.maxY - bbox.minY);
  const c = bboxCenter(bbox);
  const availW = Math.max(1, viewport.w - padding * 2);
  const availH = Math.max(1, viewport.h - padding * 2);
  let zoom = Math.min(availW / w, availH / h);
  if (!Number.isFinite(zoom) || zoom <= 0) zoom = 1;
  zoom = Math.max(minZoom, Math.min(maxZoom, zoom));
  return { cx: c.x, cy: c.y, zoom };
}
function cameraForCenter(center, zoom) {
  return { cx: center.x, cy: center.y, zoom };
}
function mixCameras(a, b, t) {
  return {
    cx: a.cx + (b.cx - a.cx) * t,
    cy: a.cy + (b.cy - a.cy) * t,
    zoom: a.zoom * Math.pow(b.zoom / a.zoom, t)
  };
}
const c1 = 1.70158;
const c3 = c1 + 1;
const EASINGS = {
  linear: (t) => t,
  ease: (t) => cubicBezier(0.25, 0.1, 0.25, 1, t),
  "ease-in": (t) => t * t,
  "ease-out": (t) => 1 - (1 - t) * (1 - t),
  "ease-in-out": (t) => t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2,
  "back-out": (t) => 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2),
  anticipate: (t) => {
    const s = c1 * 1.2;
    return t < 0.5 ? (2 * t) ** 2 * ((s + 1) * 2 * t - s) / 2 : 1;
  },
  // A tuned spring feel for magic-move: settles with a soft overshoot.
  spring: (t) => {
    if (t >= 1) return 1;
    const freq = 9;
    return 1 - Math.exp(-6.5 * t) * Math.cos(freq * t * (1 - t) + 0);
  }
};
function easingByName(name) {
  return name && EASINGS[name] || EASINGS["ease-in-out"];
}
function cubicBezier(x1, y1, x2, y2, t) {
  const cx = 3 * x1;
  const bx = 3 * (x2 - x1) - cx;
  const ax = 1 - cx - bx;
  const cy = 3 * y1;
  const by = 3 * (y2 - y1) - cy;
  const ay = 1 - cy - by;
  const sampleX = (u2) => ((ax * u2 + bx) * u2 + cx) * u2;
  const sampleY = (u2) => ((ay * u2 + by) * u2 + cy) * u2;
  let u = t;
  for (let i = 0; i < 6; i++) {
    const x = sampleX(u) - t;
    const dx = (3 * ax * u + 2 * bx) * u + cx;
    if (Math.abs(x) < 1e-4 || Math.abs(dx) < 1e-6) break;
    u -= x / dx;
  }
  return sampleY(Math.max(0, Math.min(1, u)));
}
class CameraController {
  renderer;
  tween = null;
  raf = 0;
  /** notified every applied frame (for grid/overlay sync). */
  onFrame;
  constructor(renderer) {
    this.renderer = renderer;
  }
  get current() {
    return this.renderer.getCamera();
  }
  /** Snap immediately (used by user pan/zoom). Cancels any tween. */
  setImmediate(cam) {
    this.stop();
    this.renderer.applyCamera(cam);
    this.onFrame?.(cam);
  }
  stop() {
    if (this.raf) cancelAnimationFrame(this.raf);
    this.raf = 0;
    if (this.tween) {
      const r2 = this.tween.resolve;
      this.tween = null;
      r2();
    }
  }
  /** Animate to a target camera, retargeting smoothly if already animating. */
  animateTo(to, opts = {}) {
    const from = this.current;
    const duration = opts.durationMs ?? this.autoDuration(from, to);
    if (duration <= 0) {
      this.setImmediate(to);
      return Promise.resolve();
    }
    if (this.tween) {
      const prev = this.tween.resolve;
      this.tween = null;
      prev();
    }
    return new Promise((resolve) => {
      this.tween = { from, to, start: performance.now(), duration, easing: opts.easing ?? "spring", resolve };
      if (!this.raf) this.raf = requestAnimationFrame(this.frame);
    });
  }
  frame = (now) => {
    this.raf = 0;
    const tw = this.tween;
    if (!tw) return;
    const t = Math.min(1, (now - tw.start) / tw.duration);
    const e = easingByName(tw.easing)(t);
    const cam = {
      cx: lerp$2(tw.from.cx, tw.to.cx, e),
      cy: lerp$2(tw.from.cy, tw.to.cy, e),
      zoom: logLerp(tw.from.zoom, tw.to.zoom, e)
    };
    this.renderer.applyCamera(cam);
    this.onFrame?.(cam);
    if (t < 1) {
      this.raf = requestAnimationFrame(this.frame);
    } else {
      const done = tw.resolve;
      this.tween = null;
      done();
    }
  };
  /** Duration heuristic: further travel + bigger zoom change => longer. */
  autoDuration(from, to) {
    return autoDuration(from, to);
  }
  // ---- high-level ops -----------------------------------------------------
  fitAll(scene, opts = {}) {
    const cam = cameraForBBox(sceneBBox(scene), this.renderer.getViewportSize(), { padding: opts.padding ?? 80 });
    return this.animateTo(cam, opts);
  }
  focus(scene, ids, opts = {}) {
    let box = emptyBBox();
    for (const id of ids) {
      const b = elementBBox(scene, id);
      if (b) box = bboxUnion(box, b);
    }
    if (!Number.isFinite(box.minX)) return this.fitAll(scene, opts);
    const cam = cameraForBBox(box, this.renderer.getViewportSize(), { padding: opts.padding ?? 90, maxZoom: 4 });
    if (opts.zoom != null) cam.zoom = opts.zoom;
    return this.animateTo(cam, opts);
  }
  focusBBox(box, opts = {}) {
    const cam = cameraForBBox(box, this.renderer.getViewportSize(), { padding: opts.padding ?? 90 });
    if (opts.zoom != null) cam.zoom = opts.zoom;
    return this.animateTo(cam, opts);
  }
  /** Zoom by a factor around a screen anchor (default: viewport center). */
  zoomBy(factor, anchorScreen) {
    const cam = this.current;
    const vp = this.renderer.getViewportSize();
    const anchor = anchorScreen ?? { x: vp.w / 2, y: vp.h / 2 };
    const worldBefore = this.renderer.screenToWorld(anchor);
    const zoom = clamp$1(cam.zoom * factor, 0.05, 8);
    const cx = worldBefore.x - (anchor.x - vp.w / 2) / zoom;
    const cy = worldBefore.y - (anchor.y - vp.h / 2) / zoom;
    this.setImmediate({ cx, cy, zoom });
  }
  /** Pan by a screen-space delta. */
  panByScreen(dx, dy) {
    const cam = this.current;
    this.setImmediate({ cx: cam.cx - dx / cam.zoom, cy: cam.cy - dy / cam.zoom, zoom: cam.zoom });
  }
}
function autoDuration(from, to) {
  const dist2 = Math.hypot(to.cx - from.cx, to.cy - from.cy) * Math.min(from.zoom, to.zoom);
  const zoomRatio = Math.abs(Math.log(to.zoom / from.zoom));
  return clamp$1(420 + dist2 * 0.12 + zoomRatio * 320, 420, 1300);
}
function lerp$2(a, b, t) {
  return a + (b - a) * t;
}
function logLerp(a, b, t) {
  return a * Math.pow(b / a, t);
}
function clamp$1(v, lo, hi) {
  return v < lo ? lo : v > hi ? hi : v;
}
function layoutDag(scene, movable, opts) {
  const g = new dagre.graphlib.Graph({ compound: true });
  g.setGraph({
    rankdir: opts.rankdir,
    nodesep: opts.nodesep,
    ranksep: opts.ranksep,
    marginx: opts.margin,
    marginy: opts.margin
  });
  g.setDefaultEdgeLabel(() => ({}));
  const inGraph = /* @__PURE__ */ new Set();
  for (const n of movable) {
    g.setNode(n.id, { width: n.w, height: n.h });
    inGraph.add(n.id);
  }
  for (const grp of scene.groups) {
    if (inGraph.has(grp.id)) continue;
    const members = grp.members.filter((id) => inGraph.has(id));
    if (members.length === 0) continue;
    g.setNode(grp.id, {});
    for (const id of members) g.setParent(id, grp.id);
  }
  for (const e of scene.edges) {
    const from = e.from.node;
    const to = e.to.node;
    if (from == null || to == null) continue;
    if (!inGraph.has(from) || !inGraph.has(to)) continue;
    g.setEdge(from, to);
  }
  dagre.layout(g);
  for (const n of movable) {
    const gn = g.node(n.id);
    if (!gn || !Number.isFinite(gn.x) || !Number.isFinite(gn.y)) {
      throw new Error(`dagre produced no finite position for node "${n.id}"`);
    }
    n.x = gn.x - n.w / 2;
    n.y = gn.y - n.h / 2;
  }
  for (const e of scene.edges) {
    const from = e.from.node;
    const to = e.to.node;
    if (from == null || to == null || !inGraph.has(from) || !inGraph.has(to)) {
      e.points = void 0;
      continue;
    }
    const ge = g.edge(from, to);
    e.points = ge?.points && ge.points.length >= 2 ? ge.points.map((p) => ({ x: p.x, y: p.y })) : void 0;
  }
}
function layoutGrid(nodes, gap) {
  const n = nodes.length;
  if (n === 0) return;
  const cols = Math.max(1, Math.ceil(Math.sqrt(n)));
  let maxDim = 0;
  for (const node of nodes) {
    if (node.w > maxDim) maxDim = node.w;
    if (node.h > maxDim) maxDim = node.h;
  }
  const cell = maxDim + gap;
  for (let i = 0; i < n; i++) {
    const node = nodes[i];
    const row = Math.floor(i / cols);
    const col = i % cols;
    node.x = col * cell + (cell - node.w) / 2;
    node.y = row * cell + (cell - node.h) / 2;
  }
}
function layoutRadial(nodes, centerId, radiusFloor = 220) {
  const n = nodes.length;
  if (n === 0) return;
  let hubIdx = 0;
  if (centerId !== void 0) {
    const idx = nodes.findIndex((node) => node.id === centerId);
    if (idx >= 0) hubIdx = idx;
  }
  const hub = nodes[hubIdx];
  hub.x = -hub.w / 2;
  hub.y = -hub.h / 2;
  const ring2 = nodes.filter((_, i) => i !== hubIdx);
  const count = ring2.length;
  if (count === 0) return;
  const radius = Math.max(radiusFloor, n * 40);
  for (let k = 0; k < count; k++) {
    const angle = 2 * Math.PI * k / count;
    const cx = Math.cos(angle) * radius;
    const cy = Math.sin(angle) * radius;
    ring2[k].x = cx - ring2[k].w / 2;
    ring2[k].y = cy - ring2[k].h / 2;
  }
}
const DEFAULT_NODESEP = 60;
const DEFAULT_RANKSEP = 90;
const DAG_MARGIN = 20;
const DEFAULT_GRID_GAP = 40;
const RADIAL_RADIUS_FLOOR = 220;
const NORMALIZE_MARGIN = 40;
function applyLayout(scene) {
  if (scene.meta.layout === "manual") return;
  const movable = scene.nodes.filter((n) => n.pinned !== true);
  if (movable.length === 0) return;
  runLayout(scene, movable);
  const { dx, dy } = normalizeMargin(movable, NORMALIZE_MARGIN);
  if (dx !== 0 || dy !== 0) {
    for (const e of scene.edges) {
      if (e.points) e.points = e.points.map((p) => ({ x: p.x + dx, y: p.y + dy }));
    }
  }
}
function runLayout(scene, movable) {
  const kind = scene.meta.layout;
  try {
    const plugin = getLayoutPlugin(kind);
    if (plugin) {
      plugin(scene, movable);
      return;
    }
    switch (kind) {
      case "dag":
      case "dag-lr":
      case "dag-rl":
      case "dag-bt":
        layoutDag(scene, movable, dagOptions(scene, kind));
        return;
      case "grid":
        layoutGrid(movable, gridGap(scene));
        return;
      case "radial":
        layoutRadial(movable, readCenterId(scene), RADIAL_RADIUS_FLOOR);
        return;
      default:
        layoutGrid(movable, gridGap(scene));
        return;
    }
  } catch {
    try {
      layoutGrid(movable, gridGap(scene));
    } catch {
    }
  }
}
function dagOptions(scene, kind) {
  return {
    rankdir: resolveRankdir(scene, kind),
    nodesep: scene.meta.spacing?.node ?? DEFAULT_NODESEP,
    ranksep: scene.meta.spacing?.rank ?? DEFAULT_RANKSEP,
    margin: DAG_MARGIN
  };
}
function resolveRankdir(scene, kind) {
  const hinted = directionToRankdir(readDirection(scene));
  if (hinted) return hinted;
  switch (kind) {
    case "dag-lr":
      return "LR";
    case "dag-rl":
      return "RL";
    case "dag-bt":
      return "BT";
    default:
      return "TB";
  }
}
function directionToRankdir(dir) {
  switch (dir) {
    case "down":
    case "TB":
      return "TB";
    case "up":
    case "BT":
      return "BT";
    case "left":
    case "RL":
      return "RL";
    case "right":
    case "LR":
      return "LR";
    default:
      return void 0;
  }
}
function gridGap(scene) {
  return scene.meta.spacing?.node ?? DEFAULT_GRID_GAP;
}
function readDirection(scene) {
  const raw = scene.meta.direction;
  if (typeof raw !== "string") return void 0;
  switch (raw) {
    case "down":
    case "up":
    case "left":
    case "right":
    case "TB":
    case "BT":
    case "LR":
    case "RL":
      return raw;
    default:
      return void 0;
  }
}
function readCenterId(scene) {
  const raw = scene.meta.center;
  return typeof raw === "string" ? raw : void 0;
}
function normalizeMargin(nodes, margin) {
  let minX = Infinity;
  let minY = Infinity;
  for (const n of nodes) {
    if (n.x < minX) minX = n.x;
    if (n.y < minY) minY = n.y;
  }
  if (!Number.isFinite(minX) || !Number.isFinite(minY)) return { dx: 0, dy: 0 };
  const dx = margin - minX;
  const dy = margin - minY;
  if (dx === 0 && dy === 0) return { dx: 0, dy: 0 };
  for (const n of nodes) {
    n.x += dx;
    n.y += dy;
  }
  return { dx, dy };
}
function applyOverrides(scene) {
  if (!scene.overrides || !scene.overrides.length) return;
  const byId = new Map(scene.nodes.map((n) => [n.id, n]));
  for (const o of scene.overrides) {
    const n = byId.get(o.id);
    if (!n) continue;
    n.x = o.x;
    n.y = o.y;
    if (o.w != null && o.w > 0) n.w = o.w;
    if (o.h != null && o.h > 0) n.h = o.h;
    n.pinned = true;
  }
}
const LIGHT_THEME = {
  name: "excalidraw-light",
  background: "#ffffff",
  defaultStroke: STROKE_PALETTE.black,
  defaultText: STROKE_PALETTE.black,
  gridColor: "#d5d9e0",
  mode: "light"
};
const DARK_THEME = {
  name: "excalidraw-dark",
  background: "#121212",
  defaultStroke: "#e3e3e3",
  defaultText: "#e3e3e3",
  gridColor: "#2c313a",
  mode: "dark"
};
function defaultNodeStyle(seed, mode = "light") {
  return {
    stroke: mode === "dark" ? "#e3e3e3" : STROKE_PALETTE.black,
    fill: null,
    fillStyle: "hachure",
    strokeWidth: 1.4,
    strokeStyle: "solid",
    roughness: 1.1,
    roundness: null,
    fontFamily: "hand",
    fontSize: 20,
    textColor: mode === "dark" ? "#e3e3e3" : STROKE_PALETTE.black,
    textAlign: "center",
    verticalAlign: "middle",
    opacity: 100,
    seed
  };
}
function defaultEdgeStyle(seed, mode = "light") {
  return {
    stroke: mode === "dark" ? "#e3e3e3" : STROKE_PALETTE.black,
    strokeWidth: 1.4,
    strokeStyle: "solid",
    roughness: 1.1,
    startArrowhead: "none",
    endArrowhead: "arrow",
    animation: "none",
    animationSpeed: 1,
    opacity: 100,
    seed,
    fontFamily: "hand",
    fontSize: 16,
    textColor: mode === "dark" ? "#e3e3e3" : STROKE_PALETTE.black,
    labelBg: mode === "dark" ? "#121212" : "#ffffff"
  };
}
function defaultNodeSize(shape, label) {
  const lines = label ? label.split("\n") : [""];
  const longest = lines.reduce((m, l) => Math.max(m, l.length), 0);
  const baseW = Math.max(90, longest * 11 + 40);
  const baseH = Math.max(52, lines.length * 26 + 24);
  switch (shape) {
    case "circle":
      return { w: Math.max(baseW, baseH), h: Math.max(baseW, baseH) };
    case "diamond":
      return { w: baseW * 1.3, h: baseH * 1.3 };
    case "ellipse":
      return { w: baseW * 1.15, h: baseH * 1.15 };
    case "cylinder":
      return { w: baseW, h: baseH * 1.25 };
    case "hexagon":
    case "parallelogram":
    case "trapezoid":
      return { w: baseW * 1.2, h: baseH };
    case "text":
      return { w: baseW, h: baseH * 0.8 };
    default:
      return { w: baseW, h: baseH };
  }
}
function makeNode(input) {
  const shape = input.shape ?? "rectangle";
  const label = input.label ?? "";
  const seed = hashString(input.id) % 2e6 + 1;
  const size = input.w != null && input.h != null ? { w: input.w, h: input.h } : defaultNodeSize(shape, label);
  return {
    id: input.id,
    shape,
    label,
    x: input.x ?? 0,
    y: input.y ?? 0,
    w: input.w ?? size.w,
    h: input.h ?? size.h,
    style: { ...defaultNodeStyle(seed, input.mode), ...input.style, seed },
    group: input.group,
    z: input.z ?? 0,
    pinned: input.pinned ?? (input.x != null && input.y != null),
    data: input.data
  };
}
function makeEdge(input) {
  const seed = hashString(input.id) % 2e6 + 1;
  return {
    id: input.id,
    from: { node: input.from, anchor: input.fromAnchor },
    to: { node: input.to, anchor: input.toAnchor },
    label: input.label ?? "",
    style: { ...defaultEdgeStyle(seed, input.mode), ...input.style, seed },
    routing: input.routing ?? "straight",
    z: input.z ?? 0,
    data: input.data
  };
}
function emptyScene(mode = "light") {
  return {
    id: "scene",
    theme: mode === "dark" ? DARK_THEME : LIGHT_THEME,
    meta: { layout: "dag" },
    nodes: [],
    edges: [],
    groups: [],
    annotations: [],
    steps: []
  };
}
function parseHex(c) {
  let hex = c.trim().toLowerCase();
  if (!hex.startsWith("#")) return null;
  hex = hex.slice(1);
  if (hex.length === 3) hex = hex.replace(/./g, (ch) => ch + ch);
  if (hex.length === 8) hex = hex.slice(0, 6);
  if (hex.length !== 6 || /[^0-9a-f]/.test(hex)) return null;
  return {
    r: parseInt(hex.slice(0, 2), 16),
    g: parseInt(hex.slice(2, 4), 16),
    b: parseInt(hex.slice(4, 6), 16)
  };
}
function toHex(rgb) {
  const p = (v) => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, "0");
  return `#${p(rgb.r)}${p(rgb.g)}${p(rgb.b)}`;
}
function mix(a, b, t) {
  const ca = parseHex(a);
  const cb = parseHex(b);
  if (!ca || !cb) return a;
  return toHex({
    r: ca.r + (cb.r - ca.r) * t,
    g: ca.g + (cb.g - ca.g) * t,
    b: ca.b + (cb.b - ca.b) * t
  });
}
function lighten(c, t) {
  return mix(c, "#ffffff", t);
}
function darken(c, t) {
  return mix(c, "#000000", t);
}
function withAlpha(c, alpha) {
  const rgb = parseHex(c);
  if (!rgb) return c;
  const a = Math.round(Math.max(0, Math.min(1, alpha)) * 255).toString(16).padStart(2, "0");
  return `${toHex(rgb)}${a}`;
}
function luma(c) {
  const rgb = parseHex(c);
  if (!rgb) return 255;
  return 0.299 * rgb.r + 0.587 * rgb.g + 0.114 * rgb.b;
}
function contrastInk(bg2, dark = "#1e1e1e", light = "#ffffff") {
  if (!bg2) return dark;
  return luma(bg2) > 150 ? dark : light;
}
function paletteColor(preset, i) {
  const n = preset.palette.length;
  if (n === 0) return preset.ink;
  const base = preset.palette[(i % n + n) % n];
  const cycle = Math.floor(i / n);
  return cycle === 0 ? base : lighten(base, Math.min(0.5, cycle * 0.22));
}
function rampOpacity(i, n) {
  const total = Math.max(1, n);
  return Math.min(1, (i + 1.9) / (total + 0.9));
}
function roleStyle(preset, i, opts = {}) {
  const isRamp = preset.fillMode === "ramp";
  const color = opts.color ?? (opts.emphasis && preset.emphasis ? preset.emphasis : opts.neutral ? preset.neutral : paletteColor(preset, isRamp ? 0 : i));
  let fill;
  let effective = color;
  switch (preset.fillMode) {
    case "solid":
      fill = color;
      break;
    case "soft":
      fill = lighten(color, preset.softAmount ?? 0.8);
      effective = fill;
      break;
    case "outline":
      fill = null;
      effective = preset.background;
      break;
    case "translucent": {
      const op = preset.fillOpacity ?? 0.35;
      fill = withAlpha(color, op);
      effective = mix(preset.background, color, op);
      break;
    }
    case "gradient": {
      const g = preset.gradient ?? { to: "darker", amount: 0.2 };
      const to = g.to === "lighter" ? lighten(color, g.amount) : darken(color, g.amount);
      fill = `linear-gradient(${color},${to})`;
      effective = mix(color, to, 0.5);
      break;
    }
    case "ramp": {
      const op = opts.emphasis || opts.color ? 1 : rampOpacity(i, opts.n ?? preset.palette.length);
      fill = withAlpha(color, op);
      effective = mix(preset.background, color, op);
      break;
    }
  }
  let stroke;
  switch (preset.strokeMode) {
    case "darken":
      stroke = darken(color, 0.28);
      break;
    case "same":
      stroke = color;
      break;
    case "ink":
      stroke = preset.ink;
      break;
    case "seam":
      stroke = preset.background;
      break;
    case "none":
      stroke = "transparent";
      break;
  }
  const textColor = fill === null ? preset.ink : contrastInk(effective, inkFor(preset, "dark"), inkFor(preset, "light"));
  return {
    stroke,
    fill,
    fillStyle: fill === null ? "none" : preset.fillStyle,
    strokeWidth: preset.strokeWidth,
    roughness: preset.roughness,
    ...roughTuning(preset),
    textColor,
    fontFamily: preset.fonts.body,
    roundness: preset.cornerRadius,
    // The role's headline color must READ on the canvas — muted/pastel palettes
    // (e.g. pragmatic-shades) are pulled toward the ink until they contrast.
    color: readableOn(color, preset.background, preset.ink),
    softFill: lighten(color, 0.82)
  };
}
function readableOn(color, bg2, ink) {
  let c = color;
  for (let i = 0; i < 5 && Math.abs(luma(c) - luma(bg2)) < 80; i++) c = mix(c, ink, 0.35);
  return c;
}
function inkFor(preset, want) {
  if (want === "dark") {
    return preset.mode === "dark" ? preset.background : preset.ink;
  }
  return preset.mode === "dark" ? preset.ink : "#ffffff";
}
function roughTuning(src) {
  const out = {};
  if (src.bowing !== void 0) out.bowing = src.bowing;
  if (src.maxRandomnessOffset !== void 0) out.maxRandomnessOffset = src.maxRandomnessOffset;
  if (src.preserveVertices !== void 0) out.preserveVertices = src.preserveVertices;
  if (src.disableMultiStroke !== void 0) out.disableMultiStroke = src.disableMultiStroke;
  return out;
}
function presetDeclaresRoughTuning(preset) {
  return Object.keys(roughTuning(preset)).length > 0;
}
function tunePreset(preset, rough2) {
  if (!rough2 || rough2.roughness === void 0 && !Object.keys(roughTuning(rough2)).length) return preset;
  return {
    ...preset,
    roughness: rough2.roughness ?? preset.roughness,
    ...roughTuning(preset),
    ...roughTuning(rough2)
  };
}
function presetTheme(preset) {
  return {
    name: `preset-${preset.name}${preset.mode === "dark" ? "-dark" : ""}`,
    background: preset.background,
    defaultStroke: preset.ink,
    defaultText: preset.ink,
    // Match the engine's standard dotted-grid tints so the grid reads the same
    // whether or not a preset is active.
    gridColor: preset.mode === "dark" ? "#2c313a" : "#d5d9e0",
    mode: preset.mode
  };
}
function presetNodeDefaults(preset) {
  return {
    stroke: preset.ink,
    fillStyle: preset.fillStyle,
    strokeWidth: preset.strokeWidth,
    roughness: preset.roughness,
    ...roughTuning(preset),
    fontFamily: preset.fonts.body,
    textColor: preset.ink,
    roundness: preset.cornerRadius,
    fontWeight: preset.fonts.bodyWeight
  };
}
function presetEdgeDefaults(preset) {
  return {
    stroke: preset.edge,
    strokeWidth: Math.min(2.2, Math.max(1.2, preset.strokeWidth)),
    roughness: preset.roughness,
    ...roughTuning(preset),
    fontFamily: preset.fonts.body,
    textColor: preset.ink,
    labelBg: preset.background
  };
}
const presets = /* @__PURE__ */ new Map();
const aliasToName = /* @__PURE__ */ new Map();
function registerStylePreset(p) {
  presets.set(p.name, p);
  for (const a of p.aliases ?? []) aliasToName.set(a, p.name);
}
function getStylePreset(name) {
  if (!name) return void 0;
  return presets.get(name) ?? presets.get(aliasToName.get(name) ?? "");
}
function listStylePresets() {
  return [...presets.values()];
}
const WHEEL10 = ["#4e88e7", "#e55753", "#3cc583", "#de8431", "#ba5de5", "#1eabda", "#de58a9", "#92bd39", "#7f64ea", "#e0cb15"];
const SANS = '"Roboto", "Nunito", system-ui, -apple-system, sans-serif';
const STIX = '"STIX Two Text", Georgia, serif';
const SHANTELL = '"Shantell Sans", "Excalifont", "Segoe Print", cursive';
const CLASSIC_PRESET = {
  name: "classic",
  label: "Classic",
  description: "Classic Excalidraw-style black-and-white hand-drawn ink: confident single-pass outlines, hand lettering, no fills. The default look everywhere.",
  mode: "light",
  background: "#ffffff",
  palette: ["#1e1e1e"],
  neutral: "#8a8a8a",
  fillMode: "outline",
  // `hachure` so a shape that DECLARES a fill still renders it (sketchy, on-brand);
  // auto-coloured plain shapes and viz series stay outline-only (roleStyle → `none`).
  fillStyle: "hachure",
  strokeMode: "same",
  strokeWidth: 2.2,
  roughness: 0.45,
  bowing: 0.4,
  maxRandomnessOffset: 1,
  preserveVertices: true,
  disableMultiStroke: true,
  fonts: { body: "hand", heading: "hand", bodyWeight: 700, headingWeight: 700 },
  ink: "#1e1e1e",
  mutedInk: "#4a4a4a",
  edge: "#1e1e1e",
  autoColorNodes: false,
  cornerRadius: null
};
const CLASSIC_ROUGH_PRESET = {
  ...CLASSIC_PRESET,
  name: "classic-rough",
  label: "Classic (rough)",
  description: "Classic before 0.15: two overlapping passes, free-floating corners, the full jitter budget. Sketchier, and it does not survive a zoom.",
  roughness: 1.15,
  bowing: 1,
  maxRandomnessOffset: 2,
  preserveVertices: false,
  disableMultiStroke: false
};
const CLASSIC_DARK_PRESET = {
  ...CLASSIC_PRESET,
  name: "classic-dark",
  label: "Classic (dark)",
  mode: "dark",
  background: "#121212",
  palette: ["#e3e3e3"],
  neutral: "#8a8a8a",
  ink: "#e3e3e3",
  mutedInk: "#b0b0b0",
  edge: "#e3e3e3"
};
const CLASSIC_COLOR_PRESET = {
  name: "classic-color",
  label: "Classic Colored",
  description: "The colored Excalidraw hand-drawn look: soft pastel fills, matching outlines, Excalifont.",
  mode: "light",
  background: "#ffffff",
  palette: ["#1971c2", "#e8590c", "#2f9e44", "#9c36b5", "#f08c00", "#0c8599", "#e03131", "#66a80f"],
  neutral: "#868e96",
  fillMode: "soft",
  fillStyle: "solid",
  strokeMode: "same",
  strokeWidth: 1.6,
  roughness: 0.45,
  bowing: 0.4,
  maxRandomnessOffset: 1,
  preserveVertices: true,
  disableMultiStroke: true,
  fonts: { body: "hand", heading: "hand" },
  ink: "#1e1e1e",
  mutedInk: "#495057",
  edge: "#1e1e1e",
  autoColorNodes: false,
  cornerRadius: null,
  softAmount: 0.75
};
const HAND_CLEAN_PRESET = {
  name: "hand-clean",
  label: "Hand Clean",
  description: "Hand-drawn but crisp: pinned corners, one confident pass, pale tints on warm paper. Built for video punch-ins — stays clean at 4x zoom.",
  mode: "light",
  background: "#fbfaf7",
  palette: ["#2f5eb8", "#c8622f", "#2e7d63", "#7a4fb5", "#b8862c", "#1f7d95", "#b0405c", "#5c7a2e"],
  neutral: "#9aa0a6",
  fillMode: "soft",
  fillStyle: "solid",
  strokeMode: "same",
  strokeWidth: 1.8,
  roughness: 0.35,
  bowing: 0.35,
  maxRandomnessOffset: 1,
  preserveVertices: true,
  disableMultiStroke: true,
  fonts: { body: "hand", heading: "hand", headingWeight: 700 },
  ink: "#1f2124",
  mutedInk: "#6b6f76",
  edge: "#3f434a",
  autoColorNodes: true,
  cornerRadius: 10,
  softAmount: 0.86,
  emphasis: "#c04a26"
};
const HAND_CLEAN_DARK_PRESET = {
  ...HAND_CLEAN_PRESET,
  name: "hand-clean-dark",
  label: "Hand Clean (dark)",
  description: "Hand Clean on a charcoal stage: translucent glass fills, lifted low-chroma hues, warm chalk ink. Built for video punch-ins.",
  mode: "dark",
  background: "#16181d",
  palette: ["#7aa5f0", "#f0a06a", "#6fd0a8", "#b79bf0", "#e8cb7a", "#6fc9dd", "#f08fa6", "#b6d47a"],
  neutral: "#6b727c",
  fillMode: "translucent",
  fillOpacity: 0.16,
  ink: "#e9e7e2",
  mutedInk: "#9aa1ab",
  edge: "#868e99",
  emphasis: "#ffb26b"
};
const BUILTIN_PRESETS = [
  CLASSIC_PRESET,
  CLASSIC_DARK_PRESET,
  CLASSIC_COLOR_PRESET,
  CLASSIC_ROUGH_PRESET,
  HAND_CLEAN_PRESET,
  HAND_CLEAN_DARK_PRESET,
  {
    name: "colorful-lines",
    label: "Colorful Lines",
    description: "Clean line-art where each item's outline takes its palette color.",
    mode: "light",
    background: "#ffffff",
    palette: WHEEL10,
    neutral: "#a3a3a3",
    fillMode: "outline",
    fillStyle: "none",
    strokeMode: "same",
    strokeWidth: 2,
    roughness: 0,
    fonts: { body: SANS, heading: SANS },
    ink: "#484848",
    mutedInk: "#7a7a7a",
    edge: "#484848",
    autoColorNodes: true,
    cornerRadius: null
  },
  {
    name: "neutral-lines",
    aliases: ["vibrant-strokes"],
    label: "Neutral Lines",
    description: "Neutral gray line-art where color lives in accents and colored labels only.",
    mode: "light",
    background: "#ffffff",
    palette: WHEEL10,
    neutral: "#a3a3a3",
    fillMode: "outline",
    fillStyle: "none",
    strokeMode: "ink",
    // structural shapes in gray; palette colors live in labels/icons
    strokeWidth: 2,
    roughness: 0,
    fonts: { body: SANS, heading: SANS },
    ink: "#484848",
    mutedInk: "#7a7a7a",
    edge: "#484848",
    autoColorNodes: true,
    cornerRadius: null
  },
  {
    name: "earthy-gradient",
    aliases: ["pragmatic-shades"],
    label: "Earthy Gradient",
    description: "Muted earthy gradient shades unified by a constant dark-slate ink outline.",
    mode: "light",
    background: "#cfdfcb",
    palette: ["#b0d1a6", "#adcae2", "#e4e495", "#85bfba", "#dfcda5", "#aad5be", "#b6c9d6", "#bfd284", "#d4cab2", "#c8c8c8"],
    neutral: "#c8c8c8",
    fillMode: "gradient",
    gradient: { to: "darker", amount: 0.22 },
    fillStyle: "solid",
    strokeMode: "ink",
    strokeWidth: 2,
    roughness: 0,
    fonts: { body: SANS, heading: SANS, title: STIX },
    ink: "#2f3c3e",
    mutedInk: "#5a6a6c",
    edge: "#2f3c3e",
    autoColorNodes: true,
    cornerRadius: null
  },
  {
    name: "crayon",
    aliases: ["artistic-flair"],
    label: "Crayon",
    description: "Crayon-and-ink sketchbook — painted color dabs inside heavy wobbly brown outlines.",
    mode: "light",
    background: "#f4eee4",
    palette: ["#cd6952", "#db8c4c", "#7ec27c", "#829cbd", "#a3c464", "#7eb7ad", "#cabe51", "#8d7fba", "#ba6b72", "#a1739c"],
    neutral: "#a3a3a3",
    fillMode: "translucent",
    fillOpacity: 0.5,
    fillStyle: "hachure",
    strokeMode: "ink",
    strokeWidth: 3.4,
    roughness: 2.2,
    fonts: { body: SHANTELL, heading: SHANTELL },
    ink: "#402019",
    mutedInk: "#6d4a3c",
    edge: "#402019",
    autoColorNodes: true,
    cornerRadius: null
  },
  {
    name: "fine-line",
    aliases: ["elegant-outline"],
    label: "Fine Line",
    description: "Austere 1px black wireframe where hierarchy is carried by weight alone.",
    mode: "light",
    background: "#ffffff",
    palette: ["#000000"],
    neutral: "#a3a3a3",
    fillMode: "outline",
    fillStyle: "none",
    strokeMode: "same",
    strokeWidth: 1,
    roughness: 0,
    fonts: { body: SANS, heading: SANS, headingWeight: 700 },
    ink: "#000000",
    mutedInk: "#a3a3a3",
    edge: "#000000",
    autoColorNodes: true,
    cornerRadius: null,
    emphasis: "#4f92ff"
  },
  {
    name: "mono-accent",
    aliases: ["silver-beam"],
    label: "Mono Accent",
    description: "Gallery grayscale with one terracotta spotlight and bookish serif headings.",
    mode: "light",
    background: "#ffffff",
    palette: ["#2f2f33"],
    neutral: "#d5dcd7",
    fillMode: "ramp",
    fillStyle: "solid",
    strokeMode: "seam",
    strokeWidth: 2,
    roughness: 0,
    fonts: { body: SANS, heading: STIX, headingWeight: 700 },
    ink: "#2f2f33",
    mutedInk: "#7c7f7d",
    edge: "#2f2f33",
    autoColorNodes: true,
    cornerRadius: null,
    emphasis: "#dd7758"
  },
  {
    name: "chalkboard",
    aliases: ["sketch-notes"],
    label: "Chalkboard",
    description: "White-chalk hand-drawn sketches and handwriting on a blue chalkboard.",
    mode: "dark",
    background: "#195e98",
    palette: ["#dfe7ee"],
    neutral: "#b8c6d4",
    fillMode: "outline",
    fillStyle: "none",
    strokeMode: "same",
    strokeWidth: 2,
    roughness: 1.9,
    fonts: { body: "hand", heading: "hand", headingWeight: 700 },
    ink: "#dfe7ee",
    mutedInk: "#b8c6d4",
    edge: "#dfe7ee",
    autoColorNodes: true,
    cornerRadius: null
  }
];
for (const p of BUILTIN_PRESETS) registerStylePreset(p);
function listReferencePresets() {
  return listStylePresets().filter((p) => !p.name.startsWith("classic") && p.name !== "hand-clean-dark");
}
function listStyleChoices() {
  const order = ["classic", "classic-color", "hand-clean", "classic-rough", "colorful-lines", "neutral-lines", "earthy-gradient", "crayon", "chalkboard", "fine-line", "mono-accent"];
  const seen = new Set(order);
  const ordered = order.map((n) => getStylePreset(n)).filter((p) => !!p);
  const internalDarks = /* @__PURE__ */ new Set(["classic-dark", "hand-clean-dark"]);
  for (const p of listStylePresets()) if (!seen.has(p.name) && !internalDarks.has(p.name)) ordered.push(p);
  return ordered;
}
function effectivePreset(name, mode) {
  const found = getStylePreset(name);
  if (found) return found;
  return mode === "dark" ? CLASSIC_DARK_PRESET : CLASSIC_PRESET;
}
const POSES = /* @__PURE__ */ new Map();
const EMOTIONS = /* @__PURE__ */ new Map();
const SHIRTS = /* @__PURE__ */ new Map();
const HAIR = /* @__PURE__ */ new Map();
const ACCESSORIES = /* @__PURE__ */ new Map();
const FX = /* @__PURE__ */ new Map();
function registerCharacterPose(name, pose) {
  POSES.set(name, pose);
}
function getCharacterPose(name) {
  return POSES.get(name);
}
function listCharacterPoses() {
  return [...POSES.keys()];
}
function registerCharacterEmotion(name, draw) {
  EMOTIONS.set(name, draw);
}
function getCharacterEmotion(name) {
  return EMOTIONS.get(name);
}
function listCharacterEmotions() {
  return [...EMOTIONS.keys()];
}
const SELF_ARMED = /* @__PURE__ */ new Set(["star"]);
function shirtDrawsArms(name) {
  return !!name && SELF_ARMED.has(name);
}
function registerCharacterShirt(name, draw) {
  SHIRTS.set(name, draw);
}
function getCharacterShirt(name) {
  return SHIRTS.get(name);
}
function listCharacterShirts() {
  return [...SHIRTS.keys()];
}
function registerCharacterHair(name, draw) {
  HAIR.set(name, draw);
}
function getCharacterHair(name) {
  return HAIR.get(name);
}
function listCharacterHair() {
  return [...HAIR.keys()];
}
function registerCharacterAccessory(name, draw) {
  ACCESSORIES.set(name, draw);
}
function getCharacterAccessory(name) {
  return ACCESSORIES.get(name);
}
function listCharacterAccessories() {
  return [...ACCESSORIES.keys()];
}
function registerCharacterFx(name, draw) {
  FX.set(name, draw);
}
function getCharacterFx(name) {
  return FX.get(name);
}
function listCharacterFx() {
  return [...FX.keys()];
}
const LEG_L = [[-0.045, 0.55], [-0.066, 0.78], [-0.075, 1]];
const LEG_R = [[0.045, 0.55], [0.066, 0.78], [0.075, 1]];
const ARM_L = [[-0.1, 0.3], [-0.172, 0.46], [-0.158, 0.66]];
const ARM_R = [[0.1, 0.3], [0.172, 0.46], [0.158, 0.66]];
registerCharacterPose("standing", { about: "at rest, arms at sides", emotion: "neutral", armL: ARM_L, armR: ARM_R, legL: LEG_L, legR: LEG_R, propAnchor: [0.27, 0.1], propSize: 0.24 });
registerCharacterPose("confident", { freeArms: true, about: "hands on hips, chest out", emotion: "grin", armL: [[-0.1, 0.31], [-0.21, 0.42], [-0.08, 0.52]], armR: [[0.1, 0.31], [0.21, 0.42], [0.08, 0.52]], legL: LEG_L, legR: LEG_R, hands: false, propAnchor: [0.27, 0.1], propSize: 0.24 });
registerCharacterPose("arms-crossed", { freeArms: true, about: "arms folded across the chest", emotion: "neutral", armL: [[-0.1, 0.31], [-0.03, 0.38], [0.105, 0.345]], armR: [[0.1, 0.31], [0.03, 0.4], [-0.105, 0.365]], legL: LEG_L, legR: LEG_R, hands: false, propAnchor: [0.26, 0.12], propSize: 0.22 });
registerCharacterPose("leaning", { freeArms: true, about: "weight on one leg, ankles crossed", emotion: "smug", armL: [[-0.1, 0.31], [-0.18, 0.42], [-0.06, 0.5]], armR: [[0.1, 0.31], [0.24, 0.35]], legL: [[-0.05, 0.55], [-0.02, 1]], legR: [[0.05, 0.55], [-0.05, 0.98], [0.05, 1]], hands: false });
registerCharacterPose("strolling", { freeArms: true, about: "hands in pockets, ambling along", emotion: "content", armL: [[-0.1, 0.31], [-0.12, 0.46], [-0.06, 0.5]], armR: [[0.1, 0.31], [0.12, 0.46], [0.06, 0.5]], legL: [[-0.05, 0.55], [-0.12, 0.78], [-0.15, 1]], legR: [[0.05, 0.55], [0.12, 0.78], [0.15, 1]], hands: false });
registerCharacterPose("waving", { about: "one arm up, waving hello", emotion: "happy", armL: ARM_L, armR: [[0.1, 0.31], [0.2, 0.17], [0.27, 0.07]], legL: LEG_L, legR: LEG_R, propAnchor: [0.29, 0.04] });
registerCharacterPose("waving-both", { about: "both arms up, waving", emotion: "happy", armL: [[-0.1, 0.31], [-0.2, 0.14], [-0.26, 0.06]], armR: [[0.1, 0.31], [0.2, 0.14], [0.26, 0.06]], legL: LEG_L, legR: LEG_R });
registerCharacterPose("pointing", { about: "pointing off to the side", emotion: "neutral", armL: [[-0.1, 0.31], [-0.17, 0.46], [-0.156, 0.66]], armR: [[0.1, 0.31], [0.24, 0.29], [0.34, 0.27]], legL: LEG_L, legR: LEG_R, propAnchor: [0.4, 0.24] });
registerCharacterPose("presenting", { about: "gesturing to what's beside them", emotion: "happy", armL: [[-0.1, 0.31], [-0.176, 0.46], [-0.162, 0.66]], armR: [[0.1, 0.31], [0.24, 0.38], [0.33, 0.36]], legL: LEG_L, legR: LEG_R, propAnchor: [0.36, 0.3] });
registerCharacterPose("offering", { about: "a hand extended, offering or receiving", emotion: "happy", armL: [[-0.1, 0.31], [-0.172, 0.46], [-0.158, 0.66]], armR: [[0.1, 0.31], [0.22, 0.4], [0.33, 0.42]], legL: LEG_L, legR: LEG_R, propAnchor: [0.37, 0.4], propSize: 0.22 });
registerCharacterPose("halting", { about: 'palm out — "stop"', emotion: "neutral", armL: [[-0.1, 0.31], [-0.17, 0.46], [-0.156, 0.66]], armR: [[0.1, 0.3], [0.31, 0.29]], legL: LEG_L, legR: LEG_R, propAnchor: [0.4, 0.26], propSize: 0.2 });
registerCharacterPose("hands-up", { about: "both palms raised — stop or surrender", emotion: "surprised", armL: [[-0.1, 0.31], [-0.18, 0.28], [-0.205, 0.12]], armR: [[0.1, 0.31], [0.18, 0.28], [0.205, 0.12]], legL: LEG_L, legR: LEG_R });
registerCharacterPose("shrugging", { about: "palms up, shoulders raised", emotion: "confused", armL: [[-0.1, 0.31], [-0.22, 0.36], [-0.3, 0.28]], armR: [[0.1, 0.31], [0.22, 0.36], [0.3, 0.28]], legL: LEG_L, legR: LEG_R, propAnchor: [0, -0.12], propSize: 0.24 });
registerCharacterPose("thinking", { about: "finger to temple, an idea forming", emotion: "thinking", armL: [[-0.1, 0.31], [-0.172, 0.46], [-0.158, 0.66]], armR: [[0.1, 0.31], [0.2, 0.25], [0.118, 0.19]], legL: LEG_L, legR: LEG_R, propAnchor: [0.3, 0.02], propSize: 0.24 });
registerCharacterPose("chin-thinking", { about: "hand on chin, pondering", emotion: "thinking", armL: [[-0.1, 0.31], [-0.04, 0.44], [0.06, 0.42]], armR: [[0.1, 0.31], [0.12, 0.31], [0.045, 0.245]], legL: LEG_L, legR: LEG_R });
registerCharacterPose("listening", { about: "hand cupped to the ear", emotion: "curious", armL: ARM_L, armR: [[0.1, 0.31], [0.19, 0.22], [0.138, 0.125]], legL: LEG_L, legR: LEG_R });
registerCharacterPose("facepalm", { contact: true, about: "hand to the face, exasperated", lean: 0.02, emotion: "sad", armL: [[-0.1, 0.31], [-0.13, 0.55]], armR: [[0.1, 0.31], [0.185, 0.22], [0.085, 0.17]], legL: LEG_L, legR: LEG_R });
registerCharacterPose("peering", { about: "leaning in for a closer look", lean: 0.07, emotion: "surprised", armL: [[-0.1, 0.31], [-0.17, 0.46], [-0.156, 0.66]], armR: [[0.1, 0.31], [0.23, 0.42]], legL: LEG_L, legR: LEG_R });
registerCharacterPose("searching", { about: "hand shading the eyes, looking out", emotion: "curious", lean: 0.06, armL: [[-0.1, 0.31], [-0.175, 0.44], [-0.16, 0.56]], armR: [[0.1, 0.31], [0.22, 0.15], [0.145, 0.07]], legL: LEG_L, legR: LEG_R, propAnchor: [-0.26, 0.44], propSize: 0.24 });
registerCharacterPose("cheering", { about: "both fists up, celebrating", emotion: "excited", armL: [[-0.1, 0.31], [-0.2, 0.16], [-0.25, 0.06]], armR: [[0.1, 0.31], [0.2, 0.16], [0.25, 0.06]], legL: LEG_L, legR: LEG_R, motion: [[[-0.1, 0.02], [-0.14, -0.04]], [[0, -0.02], [0, -0.09]], [[0.1, 0.02], [0.14, -0.04]]], propAnchor: [0, -0.1], propSize: 0.26 });
registerCharacterPose("victory", { about: "one fist raised high", emotion: "excited", armL: ARM_L, armR: [[0.1, 0.31], [0.16, 0.14], [0.18, 0.02]], legL: LEG_L, legR: LEG_R });
registerCharacterPose("holding-overhead", { about: "hoisting something overhead", emotion: "happy", armL: [[-0.1, 0.31], [-0.17, 0.12], [-0.11, -0.05]], armR: [[0.1, 0.31], [0.17, 0.12], [0.11, -0.05]], legL: LEG_L, legR: LEG_R, propAnchor: [0, -0.175], propSize: 0.3, hands: false });
registerCharacterPose("reaching-up", { about: "both arms stretched up to reach", emotion: "neutral", armL: [[-0.1, 0.31], [-0.13, 0.1], [-0.14, -0.04]], armR: [[0.1, 0.31], [0.13, 0.1], [0.14, -0.04]], legL: LEG_L, legR: LEG_R, propAnchor: [0, -0.1], propSize: 0.26, hands: false });
registerCharacterPose("dancing", { about: "mid-dance, one arm up", emotion: "happy", fx: "music", armL: [[-0.1, 0.31], [-0.2, 0.16], [-0.24, 0.05]], armR: [[0.1, 0.31], [0.22, 0.4], [0.3, 0.34]], legL: [[-0.05, 0.55], [-0.16, 0.78], [-0.2, 1]], legR: [[0.05, 0.55], [0.1, 0.74], [0.06, 1]] });
registerCharacterPose("stretching", { about: "arms up and back in a big stretch", lean: -0.05, emotion: "calm", armL: [[-0.1, 0.3], [-0.16, 0.14], [-0.2, 0.06]], armR: [[0.1, 0.3], [0.16, 0.14], [0.2, 0.06]], legL: LEG_L, legR: LEG_R });
registerCharacterPose("star-pose", { about: "star jump — arms and legs spread wide", emotion: "excited", armL: [[-0.1, 0.3], [-0.22, 0.16], [-0.3, 0.06]], armR: [[0.1, 0.3], [0.22, 0.16], [0.3, 0.06]], legL: [[-0.05, 0.55], [-0.2, 1]], legR: [[0.05, 0.55], [0.2, 1]] });
registerCharacterPose("walking", { about: "mid-stride, walking", emotion: "neutral", lean: 0.03, armL: [[-0.1, 0.31], [-0.175, 0.44], [-0.165, 0.56]], armR: [[0.1, 0.31], [0.175, 0.44], [0.165, 0.56]], legL: [[-0.05, 0.55], [-0.13, 0.78], [-0.16, 1]], legR: [[0.05, 0.55], [0.14, 0.78], [0.17, 1]] });
registerCharacterPose("marching", { about: "marching, one knee raised high", emotion: "neutral", armL: [[-0.1, 0.31], [-0.16, 0.24], [-0.14, 0.16]], armR: [[0.1, 0.31], [0.16, 0.44]], legL: [[-0.05, 0.55], [-0.08, 0.74], [-0.1, 1]], legR: [[0.05, 0.55], [0.16, 0.68], [0.13, 0.82]] });
registerCharacterPose("tiptoeing", { about: "sneaking on tiptoe", lean: 0.08, emotion: "smug", armL: [[-0.1, 0.31], [-0.19, 0.28], [-0.26, 0.3]], armR: [[0.1, 0.31], [0.19, 0.28], [0.26, 0.3]], legL: [[-0.05, 0.55], [-0.13, 0.8], [-0.17, 0.98]], legR: [[0.05, 0.55], [0.13, 0.8], [0.17, 0.98]] });
registerCharacterPose("running", { about: "running at full tilt, mid-flight", lean: 0.13, emotion: "neutral", airborne: true, armL: [[-0.1, 0.3], [-0.2, 0.36], [-0.26, 0.44]], armR: [[0.1, 0.3], [0.2, 0.26], [0.26, 0.17]], legL: [[-0.05, 0.55], [-0.18, 0.7], [-0.28, 0.74]], legR: [[0.05, 0.55], [0.16, 0.72], [0.22, 0.66]], motion: [[[-0.32, 0.3], [-0.52, 0.3]], [[-0.34, 0.4], [-0.56, 0.4]], [[-0.32, 0.5], [-0.5, 0.5]]] });
registerCharacterPose("jumping", { about: "leaping upward, knees tucked", emotion: "excited", airborne: true, armL: [[-0.1, 0.31], [-0.2, 0.18], [-0.24, 0.08]], armR: [[0.1, 0.31], [0.2, 0.18], [0.24, 0.08]], legL: [[-0.05, 0.55], [-0.15, 0.68], [-0.11, 0.8]], legR: [[0.05, 0.55], [0.15, 0.68], [0.11, 0.8]], motion: [[[-0.1, 0.98], [-0.03, 0.98]], [[0.03, 1], [0.1, 1]], [[-0.04, 1.03], [0.04, 1.03]]], propAnchor: [0, -0.12], propSize: 0.26 });
registerCharacterPose("kicking", { about: "kicking a leg forward", emotion: "neutral", armL: [[-0.1, 0.31], [-0.2, 0.24]], armR: [[0.1, 0.31], [0.2, 0.4]], legL: [[-0.05, 0.55], [-0.1, 1]], legR: [[0.05, 0.55], [0.2, 0.6], [0.34, 0.52]] });
registerCharacterPose("pushing", { freeArms: true, about: "shoving something heavy forward", lean: 0.1, emotion: "neutral", armL: [[-0.1, 0.31], [0.06, 0.3], [0.3, 0.3]], armR: [[0.1, 0.31], [0.22, 0.33], [0.34, 0.35]], legL: [[-0.05, 0.55], [-0.18, 0.76], [-0.3, 1]], legR: [[0.05, 0.55], [0.14, 0.74], [0.16, 1]] });
registerCharacterPose("pulling", { freeArms: true, about: "hauling something in on a rope", lean: -0.07, emotion: "neutral", armL: [[-0.1, 0.31], [0.08, 0.38], [0.24, 0.42]], armR: [[0.1, 0.31], [0.22, 0.4], [0.34, 0.46]], legL: [[-0.05, 0.55], [-0.16, 0.76], [-0.24, 1]], legR: [[0.05, 0.55], [0.14, 0.76], [0.2, 1]] });
registerCharacterPose("carrying", { freeArms: true, about: "carrying something in both arms", emotion: "neutral", armL: [[-0.1, 0.33], [-0.155, 0.45], [-0.06, 0.475]], armR: [[0.1, 0.33], [0.155, 0.45], [0.06, 0.475]], legL: LEG_L, legR: LEG_R, hands: false, propAnchor: [0, 0.44], propSize: 0.24 });
registerCharacterPose("throwing", { about: "winding up to throw", lean: 0.08, emotion: "neutral", armL: [[-0.1, 0.31], [-0.2, 0.34]], armR: [[0.1, 0.3], [0.18, 0.16], [0.14, 0.05]], legL: [[-0.05, 0.55], [-0.16, 1]], legR: [[0.05, 0.55], [0.14, 1]], propAnchor: [0.14, 0.02], propSize: 0.16 });
registerCharacterPose("bending", { about: "bending forward to pick something up", emotion: "neutral", lean: 0.14, armL: [[-0.1, 0.32], [-0.1, 0.5], [-0.06, 0.66]], armR: [[0.1, 0.32], [0.12, 0.5], [0.08, 0.66]], legL: LEG_L, legR: LEG_R, propAnchor: [0.02, 0.66], propSize: 0.2 });
registerCharacterPose("climbing", { about: "climbing up, reaching for the next hold", emotion: "neutral", armL: [[-0.1, 0.31], [-0.16, 0.38]], armR: [[0.1, 0.31], [0.14, 0.1], [0.12, -0.02]], legL: [[-0.05, 0.55], [-0.08, 1]], legR: [[0.05, 0.55], [0.2, 0.62], [0.16, 0.78]] });
registerCharacterPose("sitting", { freeArms: true, about: "seated, hands on the knees", emotion: "neutral", lean: -0.03, armL: [[-0.1, 0.31], [-0.06, 0.44], [0.06, 0.48]], armR: [[0.1, 0.31], [0.14, 0.44], [0.1, 0.5]], legL: [[-0.05, 0.55], [0.16, 0.7], [0.14, 1]], legR: [[0.05, 0.55], [0.22, 0.72], [0.2, 1]], propAnchor: [0.16, 0.42], propSize: 0.22 });
registerCharacterPose("kneeling", { about: "down on one knee", emotion: "neutral", armL: [[-0.1, 0.31], [-0.16, 0.47]], armR: [[0.1, 0.31], [0.16, 0.52], [0.14, 0.66]], legL: [[-0.05, 0.55], [-0.14, 0.78], [-0.14, 1]], legR: [[0.05, 0.55], [0.12, 0.82], [0.24, 1]] });
registerCharacterPose("meditating", { freeArms: true, about: "cross-legged, calm and centred", emotion: "calm", armL: [[-0.1, 0.31], [-0.2, 0.48], [-0.15, 0.58]], armR: [[0.1, 0.31], [0.2, 0.48], [0.15, 0.58]], legL: [[-0.05, 0.55], [-0.24, 0.82], [0.08, 0.88]], legR: [[0.05, 0.55], [0.24, 0.82], [-0.08, 0.88]], propAnchor: [0, -0.14], propSize: 0.24 });
registerCharacterPose("bowing", { freeArms: true, about: "bowing forward, deferential", lean: 0.18, emotion: "calm", armL: [[-0.1, 0.31], [-0.06, 0.46]], armR: [[0.1, 0.31], [0.06, 0.46]], legL: LEG_L, legR: LEG_R });
registerCharacterPose("balancing", { about: "arms out, balancing on one foot", emotion: "surprised", armL: [[-0.1, 0.31], [-0.28, 0.28]], armR: [[0.1, 0.31], [0.28, 0.28]], legL: [[-0.05, 0.55], [-0.06, 1]], legR: [[0.05, 0.55], [0.16, 0.72], [0.24, 0.66]] });
registerCharacterPose("falling", { about: "off balance, arms flailing", lean: -0.14, emotion: "scared", airborne: true, armL: [[-0.1, 0.31], [-0.22, 0.22], [-0.28, 0.12]], armR: [[0.1, 0.3], [0.2, 0.16], [0.24, 0.04]], legL: [[-0.05, 0.55], [-0.1, 0.74], [-0.04, 0.86]], legR: [[0.05, 0.55], [0.2, 0.62], [0.34, 0.56]], motion: [[[-0.3, 0.32], [-0.46, 0.36]], [[-0.28, 0.44], [-0.44, 0.46]]] });
const ring$1 = (f, cx, cy, r2, rh = r2, w = f.lw * 0.7) => f.ctx.shape("circle", cx - r2, cy - rh, r2 * 2, rh * 2, { stroke: f.color, fill: null, fillStyle: "none", strokeWidth: w, roughness: 0.5 }, { z: f.z + 1, role: "character" });
const dotEyes = (f, r2 = f.face.eyeR2, dy = 0) => {
  f.dot(f.face.eyeL, f.face.eyeY + dy, r2);
  f.dot(f.face.eyeR, f.face.eyeY + dy, r2);
};
const happyEye = (f, px) => f.stroke([[px - 0.022 * f.h, f.face.eyeY - 4e-3 * f.h], [px, f.face.eyeY + 0.012 * f.h], [px + 0.022 * f.h, f.face.eyeY - 4e-3 * f.h]], f.lw * 0.7);
const calmEye = (f, px) => f.stroke([[px - 0.022 * f.h, f.face.eyeY + 6e-3 * f.h], [px, f.face.eyeY - 4e-3 * f.h], [px + 0.022 * f.h, f.face.eyeY + 6e-3 * f.h]], f.lw * 0.7);
const bigEye = (f, px) => {
  ring$1(f, px, f.face.eyeY, 0.026 * f.h);
  f.dot(px, f.face.eyeY + 6e-3 * f.h, f.face.eyeR2 * 0.9);
};
const dashEye = (f, px, dir) => f.stroke([[px - 0.022 * f.h * dir, f.face.eyeY - 0.012 * f.h], [px + 0.018 * f.h * dir, f.face.eyeY + 6e-3 * f.h]], f.lw * 0.7);
const heartEye = (f, px) => {
  const r2 = 0.026 * f.h, y = f.face.eyeY;
  f.fill([[px, y + r2 * 0.9], [px - r2, y - r2 * 0.25], [px - r2 * 0.5, y - r2 * 0.95], [px, y - r2 * 0.3], [px + r2 * 0.5, y - r2 * 0.95], [px + r2, y - r2 * 0.25]]);
};
const starEye = (f, px) => {
  const r2 = 0.03 * f.h, y = f.face.eyeY, pts = [];
  for (let i = 0; i < 10; i++) {
    const rr = i % 2 === 0 ? r2 : r2 * 0.45;
    const a = -Math.PI / 2 + i * Math.PI / 5;
    pts.push([px + Math.cos(a) * rr, y + Math.sin(a) * rr]);
  }
  f.fill(pts);
};
const xEye = (f, px) => {
  const r2 = 0.02 * f.h, y = f.face.eyeY;
  f.stroke([[px - r2, y - r2], [px + r2, y + r2]], f.lw * 0.7);
  f.stroke([[px - r2, y + r2], [px + r2, y - r2]], f.lw * 0.7);
};
const angryBrows = (f) => {
  const { eyeL, eyeR, eyeY, h } = { ...f.face, h: f.h };
  f.stroke([[eyeL - 0.02 * h, eyeY - 0.032 * h], [eyeL + 0.012 * h, eyeY - 0.018 * h]], f.lw * 0.8);
  f.stroke([[eyeR + 0.02 * h, eyeY - 0.032 * h], [eyeR - 0.012 * h, eyeY - 0.018 * h]], f.lw * 0.8);
};
const worryBrows = (f) => {
  const { eyeL, eyeR, eyeY, h } = { ...f.face, h: f.h };
  f.stroke([[eyeL - 0.02 * h, eyeY - 0.022 * h], [eyeL + 0.012 * h, eyeY - 0.036 * h]], f.lw * 0.7);
  f.stroke([[eyeR + 0.02 * h, eyeY - 0.022 * h], [eyeR - 0.012 * h, eyeY - 0.036 * h]], f.lw * 0.7);
};
const levelBrows = (f) => {
  const { eyeL, eyeR, eyeY, h } = { ...f.face, h: f.h };
  const by = eyeY - 0.027 * h;
  f.stroke([[eyeL - 0.026 * h, by], [eyeL + 0.018 * h, by]], f.lw * 0.9);
  f.stroke([[eyeR + 0.026 * h, by], [eyeR - 0.018 * h, by]], f.lw * 0.9);
};
const raisedBrows = (f) => {
  const { eyeL, eyeR, eyeY, h } = { ...f.face, h: f.h };
  for (const px of [eyeL, eyeR]) f.stroke([[px - 0.024 * h, eyeY - 0.04 * h], [px, eyeY - 0.05 * h], [px + 0.024 * h, eyeY - 0.04 * h]], f.lw * 0.7);
};
const skewBrows = (f) => {
  const { eyeL, eyeR, eyeY, h } = { ...f.face, h: f.h };
  f.stroke([[eyeL - 0.024 * h, eyeY - 0.042 * h], [eyeL, eyeY - 0.052 * h], [eyeL + 0.024 * h, eyeY - 0.042 * h]], f.lw * 0.75);
  f.stroke([[eyeR - 0.02 * h, eyeY - 0.024 * h], [eyeR + 0.024 * h, eyeY - 0.024 * h]], f.lw * 0.8);
};
const mw = (f) => 0.05 * f.h;
const smile = (f, d = 1) => f.stroke([[f.head.cx - mw(f), f.face.mouthY - 0.012 * f.h * d], [f.head.cx - mw(f) * 0.45, f.face.mouthY + 0.014 * f.h * d], [f.head.cx + mw(f) * 0.45, f.face.mouthY + 0.014 * f.h * d], [f.head.cx + mw(f), f.face.mouthY - 0.012 * f.h * d]]);
const frown = (f) => f.stroke([[f.head.cx - mw(f) * 0.85, f.face.mouthY + 0.014 * f.h], [f.head.cx, f.face.mouthY - 0.01 * f.h], [f.head.cx + mw(f) * 0.85, f.face.mouthY + 0.014 * f.h]]);
const flat = (f, w = 0.8) => f.stroke([[f.head.cx - mw(f) * w, f.face.mouthY], [f.head.cx + mw(f) * w, f.face.mouthY]]);
const firm = (f) => f.stroke([[f.head.cx - mw(f) * 0.95, f.face.mouthY], [f.head.cx + mw(f) * 0.95, f.face.mouthY]], f.lw);
const bigSmile = (f) => {
  f.stroke([[f.head.cx - mw(f) * 1.1, f.face.mouthY - 0.018 * f.h], [f.head.cx - mw(f) * 0.5, f.face.mouthY + 0.024 * f.h], [f.head.cx + mw(f) * 0.5, f.face.mouthY + 0.024 * f.h], [f.head.cx + mw(f) * 1.1, f.face.mouthY - 0.018 * f.h]]);
  f.stroke([[f.head.cx - mw(f) * 1.08, f.face.mouthY - 0.016 * f.h], [f.head.cx + mw(f) * 1.08, f.face.mouthY - 0.016 * f.h]], f.lw * 0.6);
};
const wavy = (f) => f.stroke([[f.head.cx - mw(f) * 1.05, f.face.mouthY + 7e-3 * f.h], [f.head.cx - mw(f) * 0.35, f.face.mouthY - 9e-3 * f.h], [f.head.cx + mw(f) * 0.35, f.face.mouthY + 9e-3 * f.h], [f.head.cx + mw(f) * 1.05, f.face.mouthY - 7e-3 * f.h]]);
const zigzag = (f) => f.stroke([[f.head.cx - mw(f), f.face.mouthY], [f.head.cx - mw(f) * 0.33, f.face.mouthY + 0.012 * f.h], [f.head.cx + mw(f) * 0.33, f.face.mouthY - 6e-3 * f.h], [f.head.cx + mw(f), f.face.mouthY + 8e-3 * f.h]]);
const openMouth = (f, big = false) => {
  const r2 = (big ? 0.024 : 0.018) * f.h;
  ring$1(f, f.head.cx, f.face.mouthY + (big ? 6e-3 * f.h : 0), r2, big ? r2 * 1.15 : r2);
};
registerCharacterEmotion("neutral", (f) => {
  dotEyes(f);
  smile(f, 0.45);
});
registerCharacterEmotion("blank", (f) => {
  dotEyes(f);
  flat(f);
});
registerCharacterEmotion("happy", (f) => {
  dotEyes(f);
  smile(f);
});
registerCharacterEmotion("sad", (f) => {
  dotEyes(f);
  frown(f);
});
registerCharacterEmotion("surprised", (f) => {
  dotEyes(f, f.face.eyeR2 * 1.5);
  openMouth(f);
});
registerCharacterEmotion("angry", (f) => {
  dotEyes(f);
  flat(f, 1);
  angryBrows(f);
});
registerCharacterEmotion("excited", (f) => {
  dotEyes(f, f.face.eyeR2 * 1.45);
  raisedBrows(f);
  bigSmile(f);
});
registerCharacterEmotion("confused", (f) => {
  dotEyes(f);
  skewBrows(f);
  wavy(f);
});
registerCharacterEmotion("thinking", (f) => {
  dotEyes(f, f.face.eyeR2, -0.012 * f.h);
  f.stroke([[f.head.cx - mw(f) * 0.55, f.face.mouthY + 6e-3 * f.h], [f.head.cx + mw(f) * 0.55, f.face.mouthY - 2e-3 * f.h]]);
});
registerCharacterEmotion("determined", (f) => {
  dotEyes(f, f.face.eyeR2 * 0.92);
  levelBrows(f);
  firm(f);
});
registerCharacterEmotion("wink", (f) => {
  f.dot(f.face.eyeL, f.face.eyeY, f.face.eyeR2);
  happyEye(f, f.face.eyeR);
  smile(f);
});
registerCharacterEmotion("love", (f) => {
  heartEye(f, f.face.eyeL);
  heartEye(f, f.face.eyeR);
  smile(f);
});
registerCharacterEmotion("starstruck", (f) => {
  starEye(f, f.face.eyeL);
  starEye(f, f.face.eyeR);
  openMouth(f, true);
});
registerCharacterEmotion("sleeping", (f) => {
  calmEye(f, f.face.eyeL);
  calmEye(f, f.face.eyeR);
  flat(f, 0.5);
  f.ctx.label("z", f.head.cx + f.head.r + 0.05 * f.h, f.head.cy - 0.09 * f.h, { size: Math.max(9, 0.085 * f.h), color: f.color, weight: 700, font: "heading", z: f.z + 1, role: "character" });
  f.ctx.label("Z", f.head.cx + f.head.r + 0.11 * f.h, f.head.cy - 0.16 * f.h, { size: Math.max(11, 0.11 * f.h), color: f.color, weight: 700, font: "heading", z: f.z + 1, role: "character" });
});
registerCharacterEmotion("dizzy", (f) => {
  xEye(f, f.face.eyeL);
  xEye(f, f.face.eyeR);
  zigzag(f);
});
registerCharacterEmotion("laughing", (f) => {
  happyEye(f, f.face.eyeL);
  happyEye(f, f.face.eyeR);
  openMouth(f, true);
});
registerCharacterEmotion("grin", (f) => {
  dotEyes(f);
  f.stroke([[f.head.cx - mw(f) * 1.1, f.face.mouthY - 6e-3 * f.h], [f.head.cx, f.face.mouthY + 0.016 * f.h], [f.head.cx + mw(f) * 1.1, f.face.mouthY - 6e-3 * f.h]]);
  f.stroke([[f.head.cx - mw(f) * 0.9, f.face.mouthY + 2e-3 * f.h], [f.head.cx + mw(f) * 0.9, f.face.mouthY + 2e-3 * f.h]], f.lw * 0.6);
});
registerCharacterEmotion("content", (f) => {
  happyEye(f, f.face.eyeL);
  happyEye(f, f.face.eyeR);
  smile(f);
});
registerCharacterEmotion("calm", (f) => {
  calmEye(f, f.face.eyeL);
  calmEye(f, f.face.eyeR);
  smile(f, 0.6);
});
registerCharacterEmotion("worried", (f) => {
  dotEyes(f);
  worryBrows(f);
  zigzag(f);
});
registerCharacterEmotion("scared", (f) => {
  bigEye(f, f.face.eyeL);
  bigEye(f, f.face.eyeR);
  worryBrows(f);
  openMouth(f);
});
registerCharacterEmotion("crying", (f) => {
  calmEye(f, f.face.eyeL);
  calmEye(f, f.face.eyeR);
  frown(f);
  for (const px of [f.face.eyeL, f.face.eyeR]) f.stroke([[px, f.face.eyeY + 0.02 * f.h], [px - 4e-3 * f.h, f.face.eyeY + 0.06 * f.h]], f.lw * 0.7, f.accent);
});
registerCharacterEmotion("furious", (f) => {
  dashEye(f, f.face.eyeL, 1);
  dashEye(f, f.face.eyeR, -1);
  angryBrows(f);
  f.stroke([[f.head.cx - mw(f), f.face.mouthY + 0.012 * f.h], [f.head.cx, f.face.mouthY], [f.head.cx + mw(f), f.face.mouthY + 0.012 * f.h]]);
});
registerCharacterEmotion("stressed", (f) => {
  bigEye(f, f.face.eyeL);
  bigEye(f, f.face.eyeR);
  angryBrows(f);
  zigzag(f);
});
registerCharacterEmotion("smug", (f) => {
  dashEye(f, f.face.eyeL, 1);
  dashEye(f, f.face.eyeR, -1);
  f.stroke([[f.head.cx - mw(f) * 0.4, f.face.mouthY + 6e-3 * f.h], [f.head.cx + mw(f), f.face.mouthY - 6e-3 * f.h]]);
});
registerCharacterEmotion("curious", (f) => {
  dotEyes(f);
  f.stroke([[f.face.eyeR + 0.016 * f.h, f.face.eyeY - 0.03 * f.h], [f.face.eyeR + 0.03 * f.h, f.face.eyeY - 0.024 * f.h]], f.lw * 0.7);
  openMouth(f);
});
registerCharacterEmotion("embarrassed", (f) => {
  dotEyes(f);
  smile(f, 0.6);
  for (const px of [f.head.cx - 0.06 * f.h, f.head.cx + 0.06 * f.h]) for (const dx of [-8e-3 * f.h, 8e-3 * f.h]) f.stroke([[px + dx, f.face.mouthY - 4e-3 * f.h], [px + dx - 4e-3 * f.h, f.face.mouthY + 0.01 * f.h]], f.lw * 0.55, f.accent);
});
const HIP_Y = 0.6;
const LEGACY_HIP = 0.55;
const legY = (y) => y <= LEGACY_HIP ? y / LEGACY_HIP * HIP_Y : HIP_Y + (y - LEGACY_HIP) * (1 - HIP_Y) / (1 - LEGACY_HIP);
const HEAD_Y = 0.145;
const HEAD_R = 0.145;
const BODY_TOP = 0.285;
function bodyHalfWidth(y) {
  const t = (y - BODY_TOP) / (HIP_Y - BODY_TOP);
  if (t <= 0) return 0.084;
  if (t >= 1) return 0.076;
  const WIDEST_T = 0.42;
  const k = t < WIDEST_T ? t / WIDEST_T : (1 - t) / (1 - WIDEST_T);
  const bulge = Math.sqrt(Math.max(0, 1 - (1 - k) * (1 - k)));
  const endW = t < WIDEST_T ? 0.084 : 0.076;
  return endW + (0.112 - endW) * bulge;
}
const AIRBORNE_Y = 0.93;
const bg = (f) => f.ctx.preset.background;
const rough = (f) => Math.min(1.1, f.ctx.preset.roughness);
function bean(f, fillColor) {
  f.ctx.poly(
    f.bodyOutline(),
    { stroke: f.color, fill: fillColor, fillStyle: fillColor ? "solid" : "none", strokeWidth: f.lw, roughness: rough(f) },
    { z: f.z, role: "character" }
  );
}
const sleeve = (f, side) => void f.stroke([f.B(side, 0.28), f.B(side * 1.34, 0.315), f.B(side * 1.18, 0.375)], f.lw * 0.9);
const detail = (f, draw) => {
  if (f.fidelity === "detailed") draw();
};
registerCharacterShirt("vest", (f) => bean(f, null));
registerCharacterShirt("tee", (f) => {
  bean(f, bg(f));
  sleeve(f, -1);
  sleeve(f, 1);
  detail(f, () => f.stroke([f.B(-0.5, 0.27), f.B(0, 0.315), f.B(0.5, 0.27)], f.lw * 0.75));
});
registerCharacterShirt("solid", (f) => bean(f, f.accent));
registerCharacterShirt("striped", (f) => {
  bean(f, bg(f));
  sleeve(f, -1);
  sleeve(f, 1);
  for (const sy of [0.33, 0.39, 0.45, 0.51]) f.stroke([f.B(-0.86, sy), f.B(0.86, sy)], f.lw * 0.7, f.accent);
});
registerCharacterShirt("tie", (f) => {
  bean(f, bg(f));
  f.stroke([f.B(-0.5, BODY_TOP + 5e-3), f.B(0, 0.305), f.B(0.5, BODY_TOP + 5e-3)], f.lw * 0.8);
  f.fill([f.B(0, 0.305), f.B(0.3, 0.345), f.B(0, 0.47), f.B(-0.3, 0.345)], f.accent);
});
registerCharacterShirt("crew", (f) => {
  bean(f, bg(f));
  sleeve(f, -1);
  sleeve(f, 1);
  f.stroke([f.B(-0.62, 0.265), f.B(0, 0.315), f.B(0.62, 0.265)], f.lw * 0.85);
});
registerCharacterShirt("buttoned", (f) => {
  bean(f, bg(f));
  f.stroke([f.B(-0.45, BODY_TOP + 5e-3), f.B(0, 0.31), f.B(0.45, BODY_TOP + 5e-3)], f.lw * 0.8);
  f.stroke([f.B(0, 0.31), f.B(0, 0.52)], f.lw * 0.6);
  for (const by of [0.35, 0.42, 0.49]) f.dot(...f.B(0, by), Math.max(1, f.h * 0.011));
});
registerCharacterShirt("blazer", (f) => {
  bean(f, f.accent === f.color ? bg(f) : f.accent);
  f.stroke([f.B(-0.62, BODY_TOP + 5e-3), f.B(0, 0.41), f.B(0.62, BODY_TOP + 5e-3)], f.lw * 0.9);
  f.stroke([f.B(0, 0.41), f.B(0, 0.53)], f.lw * 0.6);
  detail(f, () => f.dot(...f.B(0.6, 0.45), Math.max(1, f.h * 0.011)));
});
registerCharacterShirt("labcoat", (f) => {
  bean(f, bg(f));
  f.stroke([f.B(-0.5, BODY_TOP + 5e-3), f.B(-0.2, 0.41)], f.lw * 0.8);
  f.stroke([f.B(0.5, BODY_TOP + 5e-3), f.B(0.2, 0.41)], f.lw * 0.8);
  f.stroke([f.B(0, 0.41), f.B(0, HIP_Y)], f.lw * 0.6);
  detail(f, () => f.stroke([f.B(0.42, 0.45), f.B(0.86, 0.45), f.B(0.86, 0.51), f.B(0.42, 0.51), f.B(0.42, 0.45)], f.lw * 0.6));
});
registerCharacterShirt("overalls", (f) => {
  bean(f, bg(f));
  f.stroke([f.B(-0.62, 0.28), f.B(-0.6, 0.43)], f.lw);
  f.stroke([f.B(0.62, 0.28), f.B(0.6, 0.43)], f.lw);
  f.stroke([f.B(-0.78, 0.43), f.B(0.78, 0.43)], f.lw);
  f.dot(...f.B(-0.6, 0.45), Math.max(1.1, f.h * 0.012), f.accent);
  f.dot(...f.B(0.6, 0.45), Math.max(1.1, f.h * 0.012), f.accent);
});
registerCharacterShirt("turtleneck", (f) => {
  bean(f, f.accent === f.color ? bg(f) : f.accent);
  f.stroke([f.B(-0.62, BODY_TOP + 4e-3), f.B(0.62, BODY_TOP + 4e-3)], f.lw);
  f.stroke([f.B(-0.66, BODY_TOP + 0.022), f.B(0.66, BODY_TOP + 0.022)], f.lw * 0.8);
});
registerCharacterShirt("scarf", (f) => {
  bean(f, bg(f));
  f.fill([f.B(-0.9, BODY_TOP), f.B(0.9, BODY_TOP), f.B(0.9, 0.295), f.B(-0.9, 0.295)], f.accent);
  f.fill([f.B(0.2, 0.295), f.B(0.62, 0.295), f.B(0.5, 0.45), f.B(0.12, 0.45)], f.accent);
});
registerCharacterShirt("hoodie", (f) => {
  const hrr = f.head.r * 1.22;
  f.stroke(f.arc(f.head.cx, f.head.cy + f.head.r * 0.16, hrr, 168, 12, 14), f.lw);
  bean(f, bg(f));
  f.stroke([f.B(-0.55, 0.46), f.B(-0.55, 0.52), f.B(0.55, 0.52), f.B(0.55, 0.46)], f.lw * 0.7);
  f.dot(...f.B(-0.22, 0.29), Math.max(1, f.h * 9e-3));
  f.dot(...f.B(0.22, 0.29), Math.max(1, f.h * 9e-3));
});
const triangleBody = (f) => {
  f.ctx.poly(
    // flare stops well inside the arms: a skirt that reaches the hands reads as a bell, not a dress
    [f.B(-0.62, BODY_TOP), f.B(0.62, BODY_TOP), [f.B(1.62, HIP_Y)[0], f.B(0, HIP_Y + 0.045)[1]], [f.B(-1.62, HIP_Y)[0], f.B(0, HIP_Y + 0.045)[1]]],
    { stroke: f.color, fill: f.accent === f.color ? bg(f) : f.accent, fillStyle: "solid", strokeWidth: f.lw, roughness: rough(f) },
    { z: f.z, role: "character" }
  );
};
registerCharacterShirt("dress", triangleBody);
registerCharacterShirt("triangle", triangleBody);
registerCharacterShirt("line", (f) => {
  f.stroke([f.B(0, BODY_TOP), f.B(0, HIP_Y)], f.lw * 1.15);
});
registerCharacterShirt("star", (f) => {
  f.stroke([f.B(-1.5, 0.3), f.B(1.5, 0.3)], f.lw);
  f.stroke([f.B(-1.15, 0.3), f.B(-0.45, HIP_Y), f.B(0, 0.36), f.B(0.45, HIP_Y), f.B(1.15, 0.3)], f.lw);
});
registerCharacterShirt("none", () => {
});
const rim$1 = (f, deg, out = 1) => {
  const a = deg * Math.PI / 180;
  return [f.head.cx + Math.cos(a) * f.head.r * out, f.head.cy + Math.sin(a) * f.head.r * out];
};
registerCharacterHair("short", (f) => {
  f.stroke(f.arc(f.head.cx, f.head.cy, f.head.r * 1.02, 188, 352, 14), f.lw, f.accent);
  for (const d of [215, 250, 285, 320]) f.stroke([rim$1(f, d, 0.98), rim$1(f, d, 1.22)], f.lw * 0.7, f.accent);
});
registerCharacterHair("spiky", (f) => {
  for (const d of [205, 228, 251, 274, 297, 320, 343]) f.stroke([rim$1(f, d, 0.95), rim$1(f, d, 1.4)], f.lw * 0.8, f.accent);
});
registerCharacterHair("messy", (f) => {
  const pts = [];
  for (let d = 190; d <= 350; d += 12) pts.push(rim$1(f, d, 1 + (d % 24 === 190 % 24 ? 0.28 : 0.12) + 0.14 * Math.abs(Math.sin(d))));
  f.stroke(pts, f.lw * 0.8, f.accent);
});
registerCharacterHair("curly", (f) => {
  for (let d = 198; d <= 342; d += 24) f.stroke(f.arc(...rim$1(f, d, 1.12), f.head.r * 0.2, 0, 320, 8), f.lw * 0.7, f.accent);
});
registerCharacterHair("bob", (f) => {
  const { cx, cy, r: r2 } = f.head;
  f.fill([...f.arc(cx, cy, r2 * 1.08, 190, 350, 16), ...f.arc(cx, cy, r2 * 0.84, 350, 190, 16)], f.accent);
  for (const sgn of [-1, 1]) {
    f.stroke(
      [
        [cx + sgn * r2 * 1, cy - r2 * 0.48],
        [cx + sgn * r2 * 1.13, cy - r2 * 0.12],
        [cx + sgn * r2 * 1.06, cy + r2 * 0.42]
      ],
      f.lw * 1.1,
      f.accent
    );
  }
});
registerCharacterHair("long", (f) => {
  f.stroke(f.arc(f.head.cx, f.head.cy, f.head.r * 1.03, 190, 350, 14), f.lw, f.accent);
  for (const s of [-1, 1]) f.stroke([rim$1(f, s < 0 ? 205 : 335, 1.05), [f.head.cx + s * f.head.r * 1.1, f.head.cy + f.head.r * 1.4], [f.head.cx + s * f.head.r * 0.85, f.head.cy + f.head.r * 2.4]], f.lw * 0.9, f.accent);
});
registerCharacterHair("pigtails", (f) => {
  f.stroke(f.arc(f.head.cx, f.head.cy, f.head.r * 1.02, 200, 340, 12), f.lw * 0.85, f.accent);
  for (const s of [-1, 1]) {
    f.stroke([rim$1(f, s < 0 ? 205 : 335, 0.95), [f.head.cx + s * f.head.r * 1.35, f.head.cy]], f.lw, f.accent);
    f.fill(f.arc(f.head.cx + s * f.head.r * 1.5, f.head.cy + f.head.r * 0.15, f.head.r * 0.32, 0, 360, 12), f.accent);
  }
});
registerCharacterHair("bun", (f) => {
  f.stroke(f.arc(f.head.cx, f.head.cy, f.head.r * 1.03, 200, 340, 12), f.lw, f.accent);
  f.fill(f.arc(f.head.cx, f.head.cy - f.head.r * 1.05, f.head.r * 0.36, 0, 360, 12), f.accent);
});
registerCharacterHair("ponytail", (f) => {
  const { cx, cy, r: r2 } = f.head;
  f.fill([...f.arc(cx, cy, r2 * 1.05, 198, 342, 14), ...f.arc(cx, cy, r2 * 0.92, 342, 198, 14)], f.accent);
  f.stroke([[cx - r2 * 0.98, cy - r2 * 0.28], [cx - r2 * 1.22, cy + r2 * 0.35], [cx - r2 * 1.12, cy + r2 * 1.05]], f.lw * 1.15, f.accent);
  f.dot(cx - r2 * 0.98, cy - r2 * 0.28, Math.max(1.2, f.h * 0.012), f.accent);
});
registerCharacterHair("afro", (f) => {
  const pts = [];
  for (let d = 172; d <= 368; d += 14) pts.push(rim$1(f, d, 1.34 + 0.1 * Math.sin(d * 1.9)));
  f.stroke([...pts, rim$1(f, 368, 1), ...f.arc(f.head.cx, f.head.cy, f.head.r * 1, 368, 172, 14)], f.lw, f.accent);
});
registerCharacterHair("mohawk", (f) => {
  for (const d of [255, 268, 281, 294]) f.stroke([rim$1(f, d, 0.95), rim$1(f, d, 1.6)], f.lw, f.accent);
});
registerCharacterHair("side-part", (f) => {
  const { cx, cy, r: r2 } = f.head;
  f.fill(
    [
      [cx - r2 * 1.04, cy - r2 * 0.26],
      ...f.arc(cx, cy, r2 * 1.04, 195, 345, 14),
      [cx + r2 * 1.02, cy - r2 * 0.3],
      [cx + r2 * 0.5, cy - r2 * 0.74],
      [cx - r2 * 0.2, cy - r2 * 0.62],
      [cx - r2 * 0.76, cy - r2 * 0.3]
    ],
    f.accent
  );
});
registerCharacterHair("bald", (f) => {
  for (const s of [-1, 1]) f.stroke(f.arc(f.head.cx + s * f.head.r * 0.9, f.head.cy, f.head.r * 0.3, s < 0 ? 250 : 290, s < 0 ? 200 : 340, 6), f.lw * 0.8, f.accent);
  f.stroke(f.arc(f.head.cx, f.head.cy - f.head.r, f.head.r * 0.14, 40, 320, 6), f.lw * 0.7, f.accent);
});
const ring = (f, cx, cy, r2, c = f.accent, w = f.lw * 0.7) => f.ctx.shape("circle", cx - r2, cy - r2, r2 * 2, r2 * 2, { stroke: c, fill: null, fillStyle: "none", strokeWidth: w, roughness: 0.5 }, { z: f.z + 2, role: "character" });
const disc = (f, cx, cy, r2, c = f.accent) => f.ctx.shape("circle", cx - r2, cy - r2, r2 * 2, r2 * 2, { stroke: c, fill: c, fillStyle: "solid", strokeWidth: 1, roughness: 0.4 }, { z: f.z + 2, role: "character" });
const rim = (f, deg, out = 1) => {
  const a = deg * Math.PI / 180;
  return [f.head.cx + Math.cos(a) * f.head.r * out, f.head.cy + Math.sin(a) * f.head.r * out];
};
registerCharacterAccessory("glasses", (f) => {
  const r2 = 0.03 * f.h;
  ring(f, f.face.eyeL, f.face.eyeY, r2);
  ring(f, f.face.eyeR, f.face.eyeY, r2);
  f.stroke([[f.face.eyeL + r2, f.face.eyeY], [f.face.eyeR - r2, f.face.eyeY]], f.lw * 0.6, f.accent);
  f.stroke([[f.face.eyeL - r2, f.face.eyeY], rim(f, 200, 0.98)], f.lw * 0.6, f.accent);
  f.stroke([[f.face.eyeR + r2, f.face.eyeY], rim(f, 340, 0.98)], f.lw * 0.6, f.accent);
});
registerCharacterAccessory("sunglasses", (f) => {
  const r2 = 0.032 * f.h;
  disc(f, f.face.eyeL, f.face.eyeY, r2);
  disc(f, f.face.eyeR, f.face.eyeY, r2);
  f.stroke([[f.face.eyeL + r2, f.face.eyeY - r2 * 0.4], [f.face.eyeR - r2, f.face.eyeY - r2 * 0.4]], f.lw * 0.7, f.accent);
  f.stroke([[f.face.eyeR + r2, f.face.eyeY - r2 * 0.3], rim(f, 340, 1)], f.lw * 0.6, f.accent);
});
registerCharacterAccessory("monocle", (f) => {
  ring(f, f.face.eyeR, f.face.eyeY, 0.032 * f.h);
  f.stroke([[f.face.eyeR, f.face.eyeY + 0.032 * f.h], [f.face.eyeR + 0.01 * f.h, f.face.mouthY + 0.03 * f.h]], f.lw * 0.5, f.accent);
});
registerCharacterAccessory("hat", (f) => {
  const top = f.head.cy - f.head.r;
  f.stroke([[f.head.cx - f.head.r * 1.3, top + 0.01 * f.h], [f.head.cx + f.head.r * 1.3, top + 0.01 * f.h]], f.lw, f.accent);
  f.ctx.poly([[f.head.cx - f.head.r * 0.7, top], [f.head.cx + f.head.r * 0.7, top], [f.head.cx + f.head.r * 0.6, top - f.head.r * 0.9], [f.head.cx - f.head.r * 0.6, top - f.head.r * 0.9]], { stroke: f.accent, fill: f.ctx.preset.background, fillStyle: "solid", strokeWidth: f.lw, roughness: 0.6 }, { z: f.z + 2, role: "character" });
});
registerCharacterAccessory("cap", (f) => {
  f.ctx.poly([rim(f, 185, 1.02), ...f.arc(f.head.cx, f.head.cy, f.head.r * 1.02, 185, 355, 10), rim(f, 355, 1.02)], { stroke: f.accent, fill: f.ctx.preset.background, fillStyle: "solid", strokeWidth: f.lw, roughness: 0.6 }, { z: f.z + 2, role: "character" });
  f.fill([rim(f, 350, 1), [f.head.cx + f.head.r * 1.7, f.head.cy - f.head.r * 0.35], [f.head.cx + f.head.r * 1.7, f.head.cy - f.head.r * 0.55], rim(f, 335, 0.9)], f.accent);
});
registerCharacterAccessory("beard", (f) => {
  f.stroke(f.arc(f.head.cx, f.head.cy, f.head.r * 1.06, 28, 152, 12), f.lw, f.accent);
  for (const d of [55, 75, 90, 105, 125]) f.stroke([rim(f, d, 0.9), rim(f, d, 1.3)], f.lw * 0.6, f.accent);
});
registerCharacterAccessory("mustache", (f) => {
  const my = f.face.mouthY - 0.012 * f.h;
  f.stroke([[f.head.cx, my], [f.head.cx - 0.02 * f.h, my - 6e-3 * f.h], [f.head.cx - 0.04 * f.h, my + 6e-3 * f.h]], f.lw * 0.8, f.accent);
  f.stroke([[f.head.cx, my], [f.head.cx + 0.02 * f.h, my - 6e-3 * f.h], [f.head.cx + 0.04 * f.h, my + 6e-3 * f.h]], f.lw * 0.8, f.accent);
});
registerCharacterAccessory("bowtie", (f) => {
  const c = f.T([0, 0.235]);
  const w = 0.03 * f.h;
  f.fill([[c[0], c[1]], [c[0] - w, c[1] - w * 0.7], [c[0] - w, c[1] + w * 0.7]], f.accent);
  f.fill([[c[0], c[1]], [c[0] + w, c[1] - w * 0.7], [c[0] + w, c[1] + w * 0.7]], f.accent);
});
registerCharacterAccessory("headphones", (f) => {
  f.stroke(f.arc(f.head.cx, f.head.cy, f.head.r * 1.12, 195, 345, 12), f.lw, f.accent);
  disc(f, ...rim(f, 178, 1.02), 0.028 * f.h);
  disc(f, ...rim(f, 2, 1.02), 0.028 * f.h);
});
registerCharacterAccessory("earrings", (f) => {
  disc(f, ...rim(f, 150, 1.02), Math.max(1.2, f.h * 0.013));
  disc(f, ...rim(f, 30, 1.02), Math.max(1.2, f.h * 0.013));
});
registerCharacterAccessory("crown", (f) => {
  const base = f.head.cy - f.head.r * 0.95;
  const x0 = f.head.cx - f.head.r * 0.7;
  const x1 = f.head.cx + f.head.r * 0.7;
  f.fill([[x0, base], [x0, base - f.head.r * 0.4], [f.head.cx - f.head.r * 0.35, base - f.head.r * 0.15], [f.head.cx, base - f.head.r * 0.55], [f.head.cx + f.head.r * 0.35, base - f.head.r * 0.15], [x1, base - f.head.r * 0.4], [x1, base]], f.accent);
});
registerCharacterAccessory("mask", (f) => {
  const y = f.face.eyeY;
  f.fill([rim(f, 198, 0.98), [f.face.eyeL - 0.03 * f.h, y - 0.03 * f.h], [f.face.eyeR + 0.03 * f.h, y - 0.03 * f.h], rim(f, 342, 0.98), [f.face.eyeR + 0.02 * f.h, y + 0.03 * f.h], [f.face.eyeL - 0.02 * f.h, y + 0.03 * f.h]], f.accent);
  f.dot(f.face.eyeL, y, 0.016 * f.h, f.ctx.preset.background);
  f.dot(f.face.eyeR, y, 0.016 * f.h, f.ctx.preset.background);
});
const ICON_VIEWBOX = 24;
const ICONS = {
  check: "M4 13 L10 19 L20 5",
  x: "M5 5 L19 19 M19 5 L5 19",
  plus: "M12 4 L12 20 M4 12 L20 12",
  minus: "M4 12 L20 12",
  "arrow-up": "M12 20 L12 4 M6 10 L12 4 L18 10",
  "arrow-down": "M12 4 L12 20 M6 14 L12 20 L18 14",
  "arrow-right": "M4 12 L20 12 M14 6 L20 12 L14 18",
  "arrow-left": "M20 12 L4 12 M10 6 L4 12 L10 18",
  "trend-up": "M3 18 L9 12 L13 15 L21 6 M15 6 L21 6 L21 12",
  "trend-down": "M3 6 L9 12 L13 9 L21 18 M15 18 L21 18 L21 12",
  star: "M12 3 L14.6 9 L21 9.6 L16.2 14 L17.6 20.5 L12 17 L6.4 20.5 L7.8 14 L3 9.6 L9.4 9 Z",
  heart: "M12 20 C5 14 3.5 10 5.5 7.5 C7.5 5 10.5 5.5 12 8 C13.5 5.5 16.5 5 18.5 7.5 C20.5 10 19 14 12 20 Z",
  flag: "M6 21 L6 4 M6 4 C9 2.5 12 5.5 15 4 C16.5 3.3 18 3.5 18 3.5 L18 12 C15 13.5 12 10.5 6 13",
  target: "M12 12 m-9 0 a9 9 0 1 0 18 0 a9 9 0 1 0 -18 0 M12 12 m-4.5 0 a4.5 4.5 0 1 0 9 0 a4.5 4.5 0 1 0 -9 0 M12 12 m-1 0 a1 1 0 1 0 2 0 a1 1 0 1 0 -2 0",
  bulb: "M9 18 L15 18 M10 21 L14 21 M12 3 C8 3 6 6 6 9 C6 12 8 13 9 15 L15 15 C16 13 18 12 18 9 C18 6 16 3 12 3 Z",
  gear: "M12 8 a4 4 0 1 0 0.01 0 Z M12 2 L12 5 M12 19 L12 22 M2 12 L5 12 M19 12 L22 12 M4.9 4.9 L7 7 M17 17 L19.1 19.1 M19.1 4.9 L17 7 M7 17 L4.9 19.1",
  user: "M12 11 a4 4 0 1 0 -0.01 0 Z M4 21 C4 16.5 7.5 14 12 14 C16.5 14 20 16.5 20 21",
  users: "M9 10 a3.2 3.2 0 1 0 -0.01 0 Z M3 20 C3 16 5.5 13.8 9 13.8 C12.5 13.8 15 16 15 20 M16 10.5 a3 3 0 1 0 -0.01 0 Z M15.5 13.5 C19 13.6 21 15.8 21 19",
  clock: "M12 12 m-9 0 a9 9 0 1 0 18 0 a9 9 0 1 0 -18 0 M12 6.5 L12 12 L16 14.5",
  calendar: "M4 6 L20 6 L20 21 L4 21 Z M4 10.5 L20 10.5 M8 3.5 L8 8 M16 3.5 L16 8",
  rocket: "M12 2.5 C15 4.5 16.5 8.5 15.5 13 L8.5 13 C7.5 8.5 9 4.5 12 2.5 Z M8.5 13 L5.5 17 L8.8 16 M15.5 13 L18.5 17 L15.2 16 M10 16.5 L9.5 21 L12 18.8 L14.5 21 L14 16.5 M12 8 a1.6 1.6 0 1 0 0.01 0",
  trophy: "M7 4 L17 4 L17 10 C17 13 15 15 12 15 C9 15 7 13 7 10 Z M7 5.5 L4 5.5 C4 9 5.5 10.7 7 10.7 M17 5.5 L20 5.5 C20 9 18.5 10.7 17 10.7 M12 15 L12 18 M8.5 21 L15.5 21 M10 18 L14 18 L14.7 21 L9.3 21 Z",
  medal: "M12 15 m-5.5 0 a5.5 5.5 0 1 0 11 0 a5.5 5.5 0 1 0 -11 0 M8.5 10.5 L5.5 3 L9.5 3 L12 8 L14.5 3 L18.5 3 L15.5 10.5",
  search: "M10.5 10.5 m-6.5 0 a6.5 6.5 0 1 0 13 0 a6.5 6.5 0 1 0 -13 0 M15.5 15.5 L21 21",
  warning: "M12 3 L22 20 L2 20 Z M12 9.5 L12 14.5 M12 17 L12 17.5",
  dollar: "M12 3 L12 21 M16.5 6.5 C15.5 5.3 14 4.8 12 4.8 C9.5 4.8 8 6 8 8 C8 12.3 16 10 16 15 C16 17.3 14.3 18.7 12 18.7 C9.8 18.7 8.2 17.8 7.3 16.3",
  chart: "M4 3 L4 21 L21 21 M8 17 L8 11 M12.5 17 L12.5 7 M17 17 L17 13",
  pie: "M12 12 L12 3 A9 9 0 1 1 4.5 16.5 Z M12 12 L20.5 9 A9 9 0 0 0 12 3 Z",
  doc: "M6 2.5 L15 2.5 L19 6.5 L19 21.5 L6 21.5 Z M15 2.5 L15 6.5 L19 6.5 M9 11 L16 11 M9 14.5 L16 14.5 M9 18 L13.5 18",
  mail: "M3 6 L21 6 L21 19 L3 19 Z M3 7 L12 13.5 L21 7",
  chat: "M4 4 L20 4 L20 16 L11 16 L6.5 20 L6.5 16 L4 16 Z",
  home: "M3.5 11.5 L12 4 L20.5 11.5 M6 10 L6 20 L18 20 L18 10 M10 20 L10 14.5 L14 14.5 L14 20",
  globe: "M12 12 m-9 0 a9 9 0 1 0 18 0 a9 9 0 1 0 -18 0 M3 12 L21 12 M12 3 C15 6 15.5 17.5 12 21 M12 3 C9 6 8.5 17.5 12 21",
  lock: "M6.5 11 L17.5 11 L17.5 20.5 L6.5 20.5 Z M8.5 11 L8.5 7.5 A3.5 3.5 0 0 1 15.5 7.5 L15.5 11",
  key: "M8 14.5 a4.2 4.2 0 1 0 -0.01 0 Z M11 12 L20.5 12 M17 12 L17 15.5 M20 12 L20 14.5",
  leaf: "M5.5 18.5 C4 11 8.5 5 19.5 4.5 C20 14 14.5 19.5 8 18.2 M5.5 18.5 C8.5 14 12 10.5 16 8",
  fire: "M12 21 C7.5 21 5.5 17.8 5.5 15 C5.5 11 9 9.5 9.5 6 C11.5 7.5 12.2 9.2 12 11.5 C13.5 10.7 14.3 9.3 14.3 7.5 C17 9.5 18.5 12.5 18.5 15 C18.5 17.8 16.5 21 12 21 Z",
  drop: "M12 3 C15.8 8 18 11.2 18 14.4 A6 6 0 0 1 6 14.4 C6 11.2 8.2 8 12 3 Z",
  cloud: "M6.5 18.5 C3.8 18.5 2.5 16.7 2.5 15 C2.5 13.2 3.8 11.8 5.6 11.6 C5.9 8.5 8.3 6.5 11.2 6.5 C13.8 6.5 15.9 8 16.6 10.5 C19.3 10.6 21.5 12.2 21.5 14.7 C21.5 16.8 19.8 18.5 17.5 18.5 Z",
  database: "M12 5.5 C16 5.5 19 4.7 19 3.8 L19 20 C19 21 16 21.8 12 21.8 C8 21.8 5 21 5 20 L5 3.8 C5 4.7 8 5.5 12 5.5 Z M5 3.8 C5 2.9 8 2.2 12 2.2 C16 2.2 19 2.9 19 3.8 M5 9.5 C5 10.4 8 11.2 12 11.2 C16 11.2 19 10.4 19 9.5 M5 15 C5 15.9 8 16.7 12 16.7 C16 16.7 19 15.9 19 15",
  shield: "M12 2.5 L20 5.5 L20 12 C20 16.5 16.7 20 12 21.8 C7.3 20 4 16.5 4 12 L4 5.5 Z",
  eye: "M2.5 12 C5 7.5 8.5 5.5 12 5.5 C15.5 5.5 19 7.5 21.5 12 C19 16.5 15.5 18.5 12 18.5 C8.5 18.5 5 16.5 2.5 12 Z M12 12 m-3 0 a3 3 0 1 0 6 0 a3 3 0 1 0 -6 0",
  book: "M12 5.5 C10 3.8 7.5 3.4 4 3.5 L4 19 C7.5 18.9 10 19.3 12 21 C14 19.3 16.5 18.9 20 19 L20 3.5 C16.5 3.4 14 3.8 12 5.5 Z M12 5.5 L12 21",
  wrench: "M14.5 6.5 a4.5 4.5 0 0 1 6 -2 L17 8 L16 12 L20 11 L23.5 7.5 M16 12 L5 21 A2.1 2.1 0 0 1 3 19 L14.5 6.5",
  phone: "M5 3 L9 3 L10.5 8 L8 10 C9 12.5 11.5 15 14 16 L16 13.5 L21 15 L21 19 C21 20 20 21 19 21 C10.5 20.5 3.5 13.5 3 5 C3 4 4 3 5 3 Z",
  megaphone: "M3 10 L3 14 L6 14 L13 18.5 L13 5.5 L6 10 Z M13 9 C15.5 9 17 10.3 17 12 C17 13.7 15.5 15 13 15 M6 14 L7.5 20 L10 20 L9 14.5",
  handshake: "M2.5 7 L8 5 L13 7.5 L9.5 10.5 C8.8 11.2 9.5 12.4 10.6 12 L14.5 9 L21.5 7 M21.5 15.5 L17.5 17 L11.5 19.5 L4.5 15 M14.5 9 L18.5 13 M6.5 13.5 L9 16 M9 16 L11 17.8",
  scale: "M12 3.5 L12 20.5 M8 20.5 L16 20.5 M4 6.5 L20 6.5 M6 6.5 L3 12.5 L9 12.5 Z M18 6.5 L15 12.5 L21 12.5 Z",
  puzzle: "M9 4 L9 6 A2 2 0 1 0 13 6 L13 4 L19 4 L19 9 L17.5 9 A2 2 0 1 0 17.5 13 L19 13 L19 19 L14 19 L14 17 A2 2 0 1 0 10 17 L10 19 L4 19 L4 13 L6 13 A2 2 0 1 0 6 9 L4 9 L4 4 Z",
  diamond: "M12 3 L21 12 L12 21 L3 12 Z",
  circle: "M12 12 m-8.5 0 a8.5 8.5 0 1 0 17 0 a8.5 8.5 0 1 0 -17 0",
  // ---- 0.13: accessibility / learning / AI glyphs ---------------------------
  // side-view wheelchair user: head, backrest+seat, shin+footrest, one big wheel
  wheelchair: "M9 3.6 m-2.8 0 a2.8 2.8 0 1 0 5.6 0 a2.8 2.8 0 1 0 -5.6 0 M9 6.4 L9.5 11.5 L15 11.5 L16.8 16 L20 16 M10.5 17 m-4.2 0 a4.2 4.2 0 1 0 8.4 0 a4.2 4.2 0 1 0 -8.4 0",
  // two rails + four rungs
  ladder: "M7 2.5 L7 21.5 M17 2.5 L17 21.5 M7 6 L17 6 M7 10 L17 10 M7 14 L17 14 M7 18 L17 18",
  // two uprights, two overhanging planks, an X brace between them
  scaffold: "M6 3 L6 21 M18 3 L18 21 M3 9 L21 9 M3 16 L21 16 M6 9 L18 16 M18 9 L6 16",
  // one big four-point sparkle + a small companion (AI / magic)
  sparkle: "M11 5 C11.5 9.8 14.2 12.5 19 13 C14.2 13.5 11.5 16.2 11 21 C10.5 16.2 7.8 13.5 3 13 C7.8 12.5 10.5 9.8 11 5 Z M19 2 L19 9 M15.5 5.5 L22.5 5.5",
  // boxy head with antenna, two eyes, a mouth and side "ears"
  robot: "M5 8 L19 8 L19 19.5 L5 19.5 Z M12 8 L12 4.5 M10 3.5 L14 3.5 M9 11 L9 14 M15 11 L15 14 M8.5 17 L15.5 17 M2 11.5 L2 15.5 M2 13.5 L5 13.5 M22 11.5 L22 15.5 M19 13.5 L22 13.5",
  // two lobes, central fissure, a few gyri
  brain: "M12 4 C9.5 2.5 6 3.5 5.5 6.5 C3 7.5 2.5 11 4 12.5 C2.5 14.5 3.5 17.5 6 18 C6.5 20.5 9.5 21.5 12 19.5 M12 4 C14.5 2.5 18 3.5 18.5 6.5 C21 7.5 21.5 11 20 12.5 C21.5 14.5 20.5 17.5 18 18 C17.5 20.5 14.5 21.5 12 19.5 M12 4 L12 19.5 M8 8 C9.5 8 10 9.5 9 10.5 M16 8 C14.5 8 14 9.5 15 10.5 M7 13.5 C8.5 13.2 9.5 14.5 9 15.8 M17 13.5 C15.5 13.2 14.5 14.5 15 15.8",
  // mortarboard + cap body + tassel
  "graduation-cap": "M12 4 L22 9 L12 14 L2 9 Z M6 11.2 L6 16 C6 18.2 9 19.6 12 19.6 C15 19.6 18 18.2 18 16 L18 11.2 M22 9 L22 15.5 M22 16.5 m-1 0 a1 1 0 1 0 2 0 a1 1 0 1 0 -2 0"
};
const ALIASES = {
  tick: "check",
  cross: "x",
  close: "x",
  up: "arrow-up",
  down: "arrow-down",
  right: "arrow-right",
  left: "arrow-left",
  growth: "trend-up",
  decline: "trend-down",
  idea: "bulb",
  lightbulb: "bulb",
  settings: "gear",
  cog: "gear",
  person: "user",
  people: "users",
  team: "users",
  time: "clock",
  date: "calendar",
  launch: "rocket",
  award: "trophy",
  winner: "trophy",
  magnifier: "search",
  lens: "search",
  alert: "warning",
  money: "dollar",
  revenue: "dollar",
  bar: "chart",
  graph: "chart",
  document: "doc",
  file: "doc",
  email: "mail",
  message: "chat",
  talk: "chat",
  house: "home",
  world: "globe",
  security: "lock",
  water: "drop",
  db: "database",
  view: "eye",
  learn: "book",
  tool: "wrench",
  call: "phone",
  announce: "megaphone",
  deal: "handshake",
  balance: "scale",
  justice: "scale",
  piece: "puzzle",
  gem: "diamond",
  accessibility: "wheelchair",
  ai: "sparkle",
  magic: "sparkle",
  bot: "robot",
  graduate: "graduation-cap",
  school: "graduation-cap"
};
const REGISTERED = /* @__PURE__ */ new Map();
function registerIcon(name, d, opts = {}) {
  const entry = { d, viewBox: opts.viewBox ?? ICON_VIEWBOX };
  REGISTERED.set(name.trim().toLowerCase(), entry);
  for (const a of opts.aliases ?? []) REGISTERED.set(a.trim().toLowerCase(), entry);
}
function iconEntry(name) {
  if (!name) return void 0;
  const key = name.trim().toLowerCase();
  const reg = REGISTERED.get(key);
  if (reg) return reg;
  const d = ICONS[key] ?? ICONS[ALIASES[key] ?? ""];
  return d ? { d, viewBox: ICON_VIEWBOX } : void 0;
}
function iconPath(name) {
  return iconEntry(name)?.d;
}
function listIcons() {
  return [.../* @__PURE__ */ new Set([...Object.keys(ICONS), ...REGISTERED.keys()])];
}
const at$1 = (f, dx, dy) => [f.head.cx + dx * f.flip * f.head.r, f.head.cy + dy * f.head.r];
const mark = (f, text, dx, dy, scale = 1) => {
  const p = at$1(f, dx, dy);
  f.ctx.label(text, p[0], p[1], { size: Math.max(11, 0.16 * f.h * scale), color: f.accent, weight: 800, font: "heading", z: f.z + 3, role: "character" });
};
const star = (f, dx, dy, rr) => {
  const c = at$1(f, dx, dy), pts = [];
  for (let i = 0; i < 10; i++) {
    const r2 = i % 2 === 0 ? rr * f.h : rr * f.h * 0.45;
    const a = -Math.PI / 2 + i * Math.PI / 5;
    pts.push([c[0] + Math.cos(a) * r2, c[1] + Math.sin(a) * r2]);
  }
  f.fill(pts, f.accent);
};
const heart = (f, dx, dy, rr) => {
  const c = at$1(f, dx, dy), r2 = rr * f.h;
  f.fill([[c[0], c[1] + r2 * 0.9], [c[0] - r2, c[1] - r2 * 0.25], [c[0] - r2 * 0.5, c[1] - r2 * 0.95], [c[0], c[1] - r2 * 0.3], [c[0] + r2 * 0.5, c[1] - r2 * 0.95], [c[0] + r2, c[1] - r2 * 0.25]], f.accent);
};
registerCharacterFx("sweat", (f) => {
  for (const [dx, dy] of [[1.5, -0.9], [1.9, -0.2]]) {
    const c = at$1(f, dx, dy), s = 0.03 * f.h;
    f.fill([[c[0], c[1] - s], [c[0] + s * 0.7, c[1] + s * 0.4], [c[0], c[1] + s * 0.8], [c[0] - s * 0.7, c[1] + s * 0.4]], f.accent);
  }
});
registerCharacterFx("question", (f) => mark(f, "?", 1.4, -1.7));
registerCharacterFx("double-question", (f) => {
  mark(f, "?", 1.2, -1.6, 0.85);
  mark(f, "?", 2, -1.9, 1.05);
});
registerCharacterFx("alarm", (f) => mark(f, "!?", 1.6, -1.7));
registerCharacterFx("exclaim", (f) => mark(f, "!", 1.3, -1.8));
registerCharacterFx("idea", (f) => {
  const c = at$1(f, 0, -2.1);
  if (iconEntry("bulb")) f.ctx.icon("bulb", c[0], c[1], 0.3 * f.h, f.accent, f.z + 3);
  for (const d of [250, 270, 290]) {
    const a = d * Math.PI / 180;
    f.stroke([[c[0] + Math.cos(a) * 0.19 * f.h, c[1] + Math.sin(a) * 0.19 * f.h], [c[0] + Math.cos(a) * 0.26 * f.h, c[1] + Math.sin(a) * 0.26 * f.h]], f.lw * 0.7, f.accent);
  }
});
registerCharacterFx("anger", (f) => {
  const c = at$1(f, 1.3, -1.2), s = 0.05 * f.h;
  f.stroke([[c[0] - s, c[1] - s * 0.2], [c[0] - s * 0.2, c[1] - s], [c[0], c[1] - s * 0.2], [c[0] + s * 0.2, c[1] - s], [c[0] + s, c[1] - s * 0.2]], f.lw * 0.8, f.accent);
  f.stroke([[c[0] - s, c[1] + s * 0.4], [c[0] - s * 0.2, c[1] - s * 0.4], [c[0], c[1] + s * 0.4], [c[0] + s * 0.2, c[1] - s * 0.4], [c[0] + s, c[1] + s * 0.4]], f.lw * 0.8, f.accent);
});
registerCharacterFx("excited", (f) => {
  for (const d of [235, 260, 285, 310]) {
    const a = d * Math.PI / 180, c = at$1(f, 0, -0.2), cx = Math.cos(a) * f.flip;
    f.stroke([[c[0] + cx * 1.4 * f.head.r, c[1] + Math.sin(a) * 1.4 * f.head.r], [c[0] + cx * 1.9 * f.head.r, c[1] + Math.sin(a) * 1.9 * f.head.r]], f.lw * 0.8, f.accent);
  }
});
registerCharacterFx("stars", (f) => {
  star(f, 1.5, -1.5, 0.035);
  star(f, 2.1, -0.9, 0.024);
  star(f, 1, -2, 0.02);
});
registerCharacterFx("hearts", (f) => {
  heart(f, 1.4, -1.6, 0.03);
  heart(f, 2, -1, 0.022);
});
registerCharacterFx("music", (f) => {
  mark(f, "♪", 1.5, -1.6, 0.95);
  mark(f, "♫", 2.1, -1.1, 1.1);
});
registerCharacterFx("zzz", (f) => {
  mark(f, "z", 1.3, -1.4, 0.7);
  mark(f, "Z", 1.8, -1.9, 1);
});
registerCharacterFx("dizzy", (f) => {
  const c = at$1(f, 0, -1.7), pts = [];
  for (let i = 0; i <= 24; i++) {
    const a = i / 24 * Math.PI * 3, r2 = (0.02 + i * 16e-4) * f.h;
    pts.push([c[0] + Math.cos(a) * r2 * f.flip, c[1] + Math.sin(a) * r2 * 0.6]);
  }
  f.stroke(pts, f.lw * 0.7, f.accent);
});
registerCharacterFx("sightline", (f) => {
  const ex = f.face.eyeR - f.head.cx;
  f.ctx.line([[f.head.cx + (ex + 0.03 * f.h) * f.flip, f.face.eyeY], at$1(f, 2.6, -1.4)], { color: f.accent, width: f.lw * 0.6, z: f.z + 1, dotted: true });
});
const MIN_INK_CONTRAST = 40;
function characterInk(want, preset) {
  const wanted = want ?? preset.ink;
  const bg2 = preset.background;
  if (!parseHex(wanted) || !parseHex(bg2)) return wanted;
  const reads = (c) => Math.abs(luma(c) - luma(bg2)) >= MIN_INK_CONTRAST;
  if (reads(wanted)) return wanted;
  if (reads(preset.ink)) return preset.ink;
  return contrastInk(bg2);
}
function shadowInk(preset) {
  const bg2 = parseHex(preset.background);
  const ink = parseHex(preset.ink);
  if (!bg2 || !ink) return "rgba(0,0,0,0.07)";
  const mix2 = (a, b) => Math.round(a + (b - a) * 0.055);
  const hex = (v) => v.toString(16).padStart(2, "0");
  return `#${hex(mix2(bg2.r, ink.r))}${hex(mix2(bg2.g, ink.g))}${hex(mix2(bg2.b, ink.b))}`;
}
function shearWeight(y) {
  const t = (HIP_Y - y) / (HIP_Y - HEAD_Y);
  return t < 0 ? 0 : t > 1 ? 1 : t;
}
function drawCharacter(ctx, cx, groundY, h, opts = {}) {
  const pose = getCharacterPose(opts.pose ?? "standing") ?? getCharacterPose("standing");
  const emotion = opts.emotion ?? pose.emotion ?? "neutral";
  const color = characterInk(opts.color ?? ctx.ink, ctx.preset);
  const flip = opts.flip ? -1 : 1;
  const y0 = groundY - h;
  const z = opts.z ?? 0;
  const lw = Math.max(1.7, h * 0.017);
  const legW = lw * 1.12;
  const lean = pose.lean ?? 0;
  const fidelity = opts.fidelity ?? "plain";
  const Y = (u) => y0 + u * h;
  const Xr = (u) => cx + u * flip * h;
  const P = (p) => [Xr(p[0]), Y(p[1])];
  const L = (p) => [Xr(p[0]), Y(legY(p[1]))];
  const clearHead = (pts) => pts.map(([x, y], i) => {
    if (i === 0) return [x, y];
    const dx = x - 0;
    const dy = y - HEAD_Y;
    const d = Math.hypot(dx, dy);
    const rim2 = HEAD_R * 1.05;
    if (d >= rim2 || d === 0) return [x, y];
    return [dx / d * rim2, HEAD_Y + dy / d * rim2];
  });
  const T2 = (p) => [Xr(p[0] + lean * shearWeight(p[1])), Y(p[1])];
  const loop = (px, py, r2, c = color) => ctx.shape("circle", px - r2, py - r2, r2 * 2, r2 * 2, { stroke: c, fill: null, fillStyle: "none", strokeWidth: lw * 0.85, roughness: 0.5 }, { z: z + 1, role: "character" });
  const dot2 = (px, py, r2, c = color) => ctx.shape("circle", px - r2, py - r2, r2 * 2, r2 * 2, { stroke: c, fill: c, fillStyle: "solid", strokeWidth: 1, roughness: 0.4 }, { z: z + 1, role: "character" });
  const stroke = (pts, w = lw * 0.8, c = color) => ctx.line(pts, { color: c, width: w, z: z + 1 });
  const fill = (pts, c = color) => ctx.poly(pts, { stroke: c, fill: c, fillStyle: "solid", strokeWidth: 1, roughness: 0.4 }, { z: z + 1, role: "character" });
  const arc = (acx, acy, r2, from, to, steps = 12) => {
    const out = [];
    for (let i = 0; i <= steps; i++) {
      const a = (from + (to - from) * i / steps) * Math.PI / 180;
      out.push([acx + Math.cos(a) * r2, acy + Math.sin(a) * r2]);
    }
    return out;
  };
  const headCenter = T2([0, HEAD_Y]);
  const head = { cx: headCenter[0], cy: headCenter[1], r: HEAD_R * h };
  const torso = [
    T2([-bodyHalfWidth(BODY_TOP), BODY_TOP]),
    T2([bodyHalfWidth(BODY_TOP), BODY_TOP]),
    T2([bodyHalfWidth(HIP_Y), HIP_Y]),
    T2([-bodyHalfWidth(HIP_Y), HIP_Y])
  ];
  const B = (k, y) => T2([k * bodyHalfWidth(y), y]);
  const bodyOutline = (inset = 0) => {
    const pts = [];
    const k = 1 - inset;
    const STEPS = 22;
    for (let i = 0; i <= STEPS; i++) pts.push(B(k, BODY_TOP + (HIP_Y - BODY_TOP) * i / STEPS));
    for (let i = STEPS; i >= 0; i--) pts.push(B(-k, BODY_TOP + (HIP_Y - BODY_TOP) * i / STEPS));
    pts.push(pts[0]);
    return pts;
  };
  const ex = 0.045 * h;
  const face = {
    eyeL: head.cx - ex,
    eyeR: head.cx + ex,
    eyeY: head.cy - 0.03 * h,
    mouthY: head.cy + 0.052 * h,
    eyeR2: Math.max(1.4, h * 0.017)
  };
  const frame = {
    ctx,
    h,
    color,
    accent: color,
    lw,
    z,
    flip,
    T: T2,
    P,
    head,
    torso,
    face,
    fidelity,
    B,
    bodyOutline,
    loop,
    stroke,
    dot: dot2,
    fill,
    arc
  };
  const grounded = !pose.airborne && (opts.shadow ?? true);
  if (grounded) {
    const sw = 0.235 * h;
    const sh = 0.036 * h;
    ctx.shape(
      "ellipse",
      cx - sw / 2 + lean * 0.02 * h * flip,
      groundY - sh * 0.45,
      sw,
      sh,
      // fill only, NO stroke: the shadow is scenery, and a stroked shadow both
      // reads as an outline and trips every "does this ink contrast?" check
      { stroke: void 0, fill: shadowInk(ctx.preset), fillStyle: "solid", strokeWidth: 0, roughness: 0.6 },
      { z: z - 1, role: "character-shadow", id: ctx.uid("figure-shadow") }
    );
  }
  const limb = (pts, tf, tip, w = lw) => {
    ctx.line(pts.map(tf), { color, width: w, z });
    if (tip === "loop") {
      const n = pts.length;
      const end = tf(pts[n - 1]);
      const prev = tf(pts[Math.max(0, n - 2)]);
      const dx = end[0] - prev[0];
      const dy = end[1] - prev[1];
      const len = Math.hypot(dx, dy) || 1;
      const r2 = Math.max(1.8, h * 0.026);
      loop(end[0] + dx / len * r2 * 0.55, end[1] + dy / len * r2 * 0.55, r2);
    }
  };
  limb(pose.legL, L, "none", legW);
  limb(pose.legR, L, "none", legW);
  if (!pose.airborne) {
    for (const leg of [pose.legL, pose.legR]) {
      const end = leg[leg.length - 1];
      if (end[1] < AIRBORNE_Y) continue;
      const f = L(end);
      if (fidelity === "minimal") {
        ctx.line([[f[0], f[1]], [f[0] + 0.05 * h * flip, f[1]]], { color, width: lw, z });
      } else {
        const fw = 0.062 * h;
        const fh = 0.036 * h;
        ctx.shape(
          "ellipse",
          f[0] - fw * 0.34,
          f[1] - fh * 0.82,
          fw,
          fh,
          { stroke: color, fill: ctx.preset.background, fillStyle: "solid", strokeWidth: lw * 0.85, roughness: 0.55 },
          { z, role: "character" }
        );
      }
    }
  }
  frame.accent = opts.shirtColor ?? color;
  const shirtDraw = getCharacterShirt(opts.shirt ?? "vest") ?? getCharacterShirt("vest");
  shirtDraw(frame);
  const showHands = pose.hands !== false && fidelity !== "minimal";
  const rootOnBody = (pts) => {
    if (pose.freeArms || pts.length < 2) return pts;
    const [x, y] = pts[0];
    const edge = bodyHalfWidth(y) * Math.sign(x || 1);
    return [[edge, y], ...pts.slice(1)];
  };
  const arm = (pts) => pose.contact ? rootOnBody(pts) : clearHead(rootOnBody(pts));
  if (!shirtDrawsArms(opts.shirt)) {
    limb(arm(pose.armL), T2, showHands ? "loop" : "none");
    limb(arm(pose.armR), T2, showHands ? "loop" : "none");
  }
  ctx.shape("circle", head.cx - head.r, head.cy - head.r, head.r * 2, head.r * 2, { stroke: color, fill: ctx.preset.background, fillStyle: "solid", strokeWidth: lw, roughness: Math.min(1, ctx.preset.roughness) }, { z, role: "character" });
  if (opts.hair && opts.hair !== "none") {
    frame.accent = opts.hairColor ?? color;
    getCharacterHair(opts.hair)?.(frame);
  }
  if (fidelity !== "minimal") {
    frame.accent = color;
    (getCharacterEmotion(emotion) ?? getCharacterEmotion("neutral"))(frame);
  }
  if (opts.accessory && opts.accessory !== "none") {
    frame.accent = opts.accessoryColor ?? color;
    getCharacterAccessory(opts.accessory)?.(frame);
  }
  for (const [a, b] of pose.motion ?? []) ctx.line([P(a), P(b)], { color, width: lw * 0.8, z });
  if (opts.prop && iconEntry(opts.prop)) {
    const anchor = pose.propAnchor ?? pose.armR[pose.armR.length - 1];
    const size = (pose.propSize ?? 0.3) * h;
    const a = T2(anchor);
    ctx.icon(opts.prop, a[0], a[1] - size * 0.28, size, opts.propColor ?? color, z + 2);
  }
  const fx = opts.fx ?? pose.fx;
  if (fx && fx !== "none") {
    frame.accent = opts.fxColor ?? color;
    getCharacterFx(fx)?.(frame);
  }
  const xs = [];
  const ys = [0, 1];
  for (const l of [pose.armL, pose.armR]) for (const p of l) {
    xs.push(p[0] + lean * shearWeight(p[1]));
    ys.push(p[1]);
  }
  for (const l of [pose.legL, pose.legR]) for (const p of l) {
    xs.push(p[0]);
    ys.push(legY(p[1]));
  }
  for (const [a, b] of pose.motion ?? []) {
    xs.push(a[0], b[0]);
    ys.push(a[1], b[1]);
  }
  const minX = Math.min(-0.18, ...xs) - 0.05;
  const maxX = Math.max(0.18, ...xs) + 0.05;
  const minY = Math.min(-0.16, ...ys);
  return { x: cx + (flip > 0 ? minX : -maxX) * h, y: y0 + minY * h, w: (maxX - minX) * h, h: (1 - minY) * h };
}
function characterOptsFrom(opts) {
  const out = {};
  for (const k of ["emotion", "prop", "shirt", "shirtColor", "hair", "hairColor", "accessory", "accessoryColor", "fx", "fxColor"]) {
    if (typeof opts[k] === "string") out[k] = opts[k];
  }
  return out;
}
function charFactor(font) {
  const f = String(font);
  if (f === "code" || f.includes("mono") || f.includes("Code")) return 0.62;
  if (f === "hand" || f.includes("Shantell") || f.includes("Excalifont")) return 0.54;
  if (f === "serif" || f.includes("Baskerville") || f.includes("STIX") || f.includes("Noto Serif") || f.includes("Aboreto")) return 0.56;
  return 0.55;
}
function measureText(text, fontSize, font = "hand") {
  const factor = charFactor(font);
  let units = 0;
  for (const ch of text) {
    if (ch === " ") units += 0.5;
    else if (/[iIl1.,:;'!|]/.test(ch)) units += 0.55;
    else if (/[A-Z0-9@#%&mwMW]/.test(ch)) units += 1.18;
    else units += 1;
  }
  return units * fontSize * factor;
}
function measureBlock(text, fontSize, font = "hand") {
  const lines = text.split("\n");
  const w = lines.reduce((m, l) => Math.max(m, measureText(l, fontSize, font)), 0);
  return { w, h: lines.length * fontSize * 1.25, lines: lines.length };
}
function wrapText(text, maxWidth, fontSize, font = "hand", maxLines = 8) {
  const out = [];
  for (const para of text.split("\n")) {
    const words = para.split(/\s+/).filter(Boolean);
    let line = "";
    for (const word of words) {
      const candidate = line ? `${line} ${word}` : word;
      if (line && measureText(candidate, fontSize, font) > maxWidth) {
        out.push(line);
        line = word;
      } else {
        line = candidate;
      }
    }
    out.push(line);
  }
  const clipped = out.slice(0, maxLines);
  if (out.length > maxLines && clipped.length) {
    clipped[clipped.length - 1] = `${clipped[clipped.length - 1]}…`;
  }
  return clipped.join("\n");
}
class VizContext {
  constructor(vizId, preset, mode, diags, showValues = true) {
    this.vizId = vizId;
    this.preset = preset;
    this.mode = mode;
    this.diags = diags;
    this.showValues = showValues;
  }
  nodes = [];
  edges = [];
  annotations = [];
  /** Set by generators that place the title themselves (e.g. below the chart). */
  titleHandled = false;
  seq = 0;
  usedIds = /* @__PURE__ */ new Set();
  currentItem = null;
  // ---- data-item scoping -----------------------------------------------------
  /**
   * Run `fn` with every emitted element tagged as belonging to data item
   * `itemId`: members carry `data.vizItem = "<vizId>.<itemId>"` (plus a
   * `data.vizRole` semantic tag) and surface in the DOM as
   * `data-viz-item`/`data-viz-role` attributes, so hosts can select or
   * choreograph one item's elements as a unit. Query members with
   * vizItemMembers(); `<vizId>.<itemId>` also works as an annotation/camera/
   * reveal target.
   */
  item(itemId, fn) {
    const prev = this.currentItem;
    this.currentItem = itemId;
    try {
      return fn();
    } finally {
      this.currentItem = prev;
    }
  }
  /** The `data` payload for an element emitted under the current item scope. */
  tagged(data, role) {
    if (!this.currentItem) return data;
    return { ...data, vizItem: `${this.vizId}.${this.currentItem}`, vizRole: role };
  }
  /** Should this item's numeric value be printed? (block `showValues:` +
   *  per-item `showValue:` — values still drive geometry either way). */
  showValue(item) {
    return this.showValues && item.opts.showValue !== false;
  }
  // ---- style ---------------------------------------------------------------
  get ink() {
    return this.preset.ink;
  }
  get mutedInk() {
    return this.preset.mutedInk;
  }
  /** Role style for series/item i under the active preset. */
  role(i, opts = {}) {
    return roleStyle(this.preset, i, opts);
  }
  /** Resolve a font slot name to a FontKind/CSS stack. */
  font(slot) {
    const fonts = this.preset.fonts;
    if (!slot || slot === "body") return fonts.body;
    if (slot === "heading") return fonts.heading;
    if (slot === "title") return fonts.title ?? fonts.heading;
    return slot;
  }
  // ---- ids -----------------------------------------------------------------
  uid(hint) {
    const base = `${this.vizId}.${hint ?? `e${this.seq++}`}`;
    let id = base;
    let n = 2;
    while (this.usedIds.has(id)) id = `${base}_${n++}`;
    this.usedIds.add(id);
    return id;
  }
  // ---- shapes ----------------------------------------------------------------
  /** Emit a shape node styled by a RoleStyle (or raw style overrides). */
  shape(shape, x, y, w, h, role, opts = {}) {
    const style = {
      // The preset's rough tuning is the FLOOR under every generated shape:
      // generators hand us bare style literals (see line(), arrowhead(),
      // icon() and every template), so without this a `hand-clean` viz would
      // draw its roughness but not its pinned corners. Anything explicit
      // below still wins.
      ...roughTuning(this.preset),
      ...isRole(role) ? {
        stroke: role.stroke,
        fill: role.fill,
        fillStyle: role.fillStyle,
        strokeWidth: role.strokeWidth,
        roughness: role.roughness,
        ...roughTuning(role),
        textColor: role.textColor,
        fontFamily: role.fontFamily,
        roundness: role.roundness
      } : role
    };
    const node = makeNode({
      id: opts.id ?? this.uid(shape),
      shape,
      label: opts.label ?? "",
      x,
      y,
      w,
      h,
      style: { ...style, ...opts.style },
      z: opts.z ?? 0,
      pinned: true,
      data: this.tagged(opts.data, opts.role ?? "shape"),
      mode: this.mode
    });
    this.nodes.push(node);
    return node;
  }
  /** Polygon from absolute local points (auto-normalized into a node box). */
  poly(points, role, opts = {}) {
    const { x, y, w, h, norm: norm2 } = normalizePoints(points);
    return this.shape("polygon", x, y, w, h, role, { ...opts, data: { ...opts.data, points: norm2 } });
  }
  /** Open polyline from absolute local points (stroke only). */
  line(points, opts = {}) {
    const { x, y, w, h, norm: norm2 } = normalizePoints(points);
    const color = opts.color ?? this.preset.edge;
    const node = this.shape(
      "polyline",
      x,
      y,
      Math.max(w, 0.01),
      Math.max(h, 0.01),
      {
        stroke: color,
        fill: null,
        fillStyle: "none",
        strokeWidth: opts.width ?? Math.min(2, this.preset.strokeWidth),
        roughness: this.preset.roughness,
        strokeStyle: opts.dash ? "dashed" : opts.dotted ? "dotted" : "solid"
      },
      { id: opts.id, z: opts.z, data: { points: norm2 }, role: "line" }
    );
    if (opts.arrow && points.length >= 2) {
      const [x2, y2] = points[points.length - 1];
      const [x1, y1] = points[points.length - 2];
      this.arrowhead(x1, y1, x2, y2, color, opts.width ?? 2, opts.z);
    }
    return node;
  }
  /** Chevron arrowhead at (x2,y2) aimed from (x1,y1). */
  arrowhead(x1, y1, x2, y2, color, width = 2, z) {
    const a = Math.atan2(y2 - y1, x2 - x1);
    const s = 7 + width * 2;
    const p = (da) => [x2 - Math.cos(a + da) * s, y2 - Math.sin(a + da) * s];
    const { x, y, w, h, norm: norm2 } = normalizePoints([p(-0.45), [x2, y2], p(0.45)]);
    return this.shape(
      "polyline",
      x,
      y,
      Math.max(w, 0.01),
      Math.max(h, 0.01),
      { stroke: color, fill: null, fillStyle: "none", strokeWidth: width, roughness: this.preset.roughness },
      { z, data: { points: norm2 }, role: "line" }
    );
  }
  /** Straight arrow drawn as polyline + head (all local coords). */
  arrow(x1, y1, x2, y2, opts = {}) {
    this.line(
      [
        [x1, y1],
        [x2, y2]
      ],
      { ...opts, arrow: true }
    );
  }
  /** A path shape designed at (vw × vh), placed in box x/y/w/h. */
  path(d, vw, vh, x, y, w, h, role, opts = {}) {
    return this.shape("path", x, y, w, h, role, { ...opts, data: { ...opts.data, d, vw, vh } });
  }
  /** A known line-icon glyph, centered at (cx, cy). Unknown names no-op. */
  icon(name, cx, cy, size, color, z) {
    const entry = iconEntry(name);
    if (!entry) return null;
    const visual = Math.min(3, Math.max(1.8, size / 18));
    const strokeWidth = visual * (entry.viewBox / size);
    return this.shape(
      "path",
      cx - size / 2,
      cy - size / 2,
      size,
      size,
      { stroke: color, fill: null, fillStyle: "none", strokeWidth, roughness: Math.min(0.8, this.preset.roughness) },
      { z: z ?? 3, data: { d: entry.d, vw: entry.viewBox, vh: entry.viewBox }, role: "icon" }
    );
  }
  // ---- edges ----------------------------------------------------------------
  /** Scene edge between two emitted nodes (or free points via `at`). */
  edge(from, to, opts = {}) {
    const edge = makeEdge({
      id: opts.id ?? this.uid("edge"),
      from: typeof from === "string" ? from : "",
      to: typeof to === "string" ? to : "",
      fromAnchor: opts.fromAnchor,
      toAnchor: opts.toAnchor,
      label: opts.label,
      style: { stroke: this.preset.edge, strokeWidth: Math.min(2, this.preset.strokeWidth), roughness: this.preset.roughness, ...roughTuning(this.preset), ...opts.style },
      routing: opts.routing,
      data: this.tagged(void 0, "edge"),
      mode: this.mode
    });
    if (typeof from !== "string") edge.from = { node: null, point: from };
    if (typeof to !== "string") edge.to = { node: null, point: to };
    this.edges.push(edge);
    return edge;
  }
  // ---- text -------------------------------------------------------------------
  measure(text, size, font) {
    return measureText(text, size, this.font(font));
  }
  wrap(text, maxWidth, size, font, maxLines) {
    return wrapText(text, maxWidth, size, this.font(font), maxLines);
  }
  /**
   * Emit a text node. `x` is the anchor per `align` (center by default);
   * `y` is the vertical center of the block ("top" anchors the first line).
   */
  label(text, x, y, opts = {}) {
    const size = opts.size ?? 20;
    const font = this.font(opts.font);
    const wrapped = opts.maxW ? wrapText(text, opts.maxW, size, font, opts.maxLines) : text;
    const m = measureBlock(wrapped, size, font);
    const w = Math.max(m.w, 4);
    const h = Math.max(m.h, size * 1.25);
    const align = opts.align ?? "center";
    const nx = align === "left" ? x : align === "right" ? x - w : x - w / 2;
    const ny = (opts.vAnchor ?? "middle") === "top" ? y : y - h / 2;
    const node = makeNode({
      id: opts.id ?? this.uid("t"),
      shape: "text",
      label: wrapped,
      x: nx,
      y: ny,
      w,
      h,
      style: {
        textColor: opts.color ?? this.ink,
        fontSize: size,
        fontFamily: font,
        textAlign: align,
        fontWeight: opts.weight,
        opacity: opts.opacity ?? 100,
        stroke: "transparent",
        fill: null,
        fillStyle: "none"
      },
      z: opts.z ?? 2,
      pinned: true,
      data: this.tagged(void 0, opts.role ?? "label"),
      mode: this.mode
    });
    this.nodes.push(node);
    return node;
  }
  /** Measure the label+detail block exactly as labelBlock will lay it out. */
  measureLabelBlock(label, detail2, opts = {}) {
    const maxW = opts.maxW ?? 220;
    const size = opts.size ?? 20;
    const labelText = wrapText(label, maxW, size, this.font("heading"), 3);
    const detailText = detail2 ? wrapText(detail2, maxW, 15, this.font("body"), 4) : void 0;
    const lm = measureBlock(labelText, size, this.font("heading"));
    const dm = detailText ? measureBlock(detailText, 15, this.font("body")) : { w: 0, h: 0 };
    return { w: Math.max(lm.w, dm.w), h: lm.h + (detailText ? dm.h + 6 : 0) };
  }
  /** Item label (fs 20, colored) + optional detail (fs 15, ink) block. */
  labelBlock(label, detail2, x, y, opts = {}) {
    const align = opts.align ?? "left";
    const maxW = opts.maxW ?? 220;
    const size = opts.size ?? 20;
    const font = this.font("body");
    const labelText = wrapText(label, maxW, size, this.font("heading"), 3);
    const detailText = detail2 ? wrapText(detail2, maxW, 15, font, 4) : void 0;
    const lm = measureBlock(labelText, size, this.font("heading"));
    const dm = detailText ? measureBlock(detailText, 15, font) : { w: 0, h: 0 };
    const totalH = lm.h + (detailText ? dm.h + 6 : 0);
    const anchor = opts.vAnchor ?? "middle";
    const top = anchor === "top" ? y : anchor === "bottom" ? y - totalH : y - totalH / 2;
    this.label(labelText, x, top + lm.h / 2, { color: opts.color ?? this.ink, align, font: "heading", weight: this.preset.fonts.headingWeight, size });
    if (detailText) this.label(detailText, x, top + lm.h + 6 + dm.h / 2, { color: this.mutedInk, align, size: 15, role: "detail" });
    const w = Math.max(lm.w, dm.w);
    const bx = align === "left" ? x : align === "right" ? x - w : x - w / 2;
    return { x: bx, y: top, w, h: totalH };
  }
  /** Sketchnote character with its feet at (cx, groundY) — see characters.ts
   *  for poses, emotions, and props. Returns the drawn bounds. */
  character(pose, cx, groundY, h, opts = {}) {
    return drawCharacter(this, cx, groundY, h, { ...opts, pose });
  }
  /** Diagram title in the preset's title font. */
  title(text, cx, y, opts = {}) {
    this.titleHandled = true;
    return this.label(text, cx, y, {
      size: opts.size ?? 26,
      color: opts.color ?? this.ink,
      font: "title",
      weight: 700,
      z: 3,
      role: "title"
    });
  }
  // ---- result -----------------------------------------------------------------
  bounds() {
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const n of this.nodes) {
      minX = Math.min(minX, n.x);
      minY = Math.min(minY, n.y);
      maxX = Math.max(maxX, n.x + n.w);
      maxY = Math.max(maxY, n.y + n.h);
    }
    if (!Number.isFinite(minX)) return { x: 0, y: 0, w: 0, h: 0 };
    return { x: minX, y: minY, w: maxX - minX, h: maxY - minY };
  }
  result() {
    return { nodes: this.nodes, edges: this.edges, annotations: this.annotations, bounds: this.bounds() };
  }
}
function isRole(r2) {
  return r2.color !== void 0 && r2.softFill !== void 0;
}
function normalizePoints(points) {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const [px, py] of points) {
    minX = Math.min(minX, px);
    minY = Math.min(minY, py);
    maxX = Math.max(maxX, px);
    maxY = Math.max(maxY, py);
  }
  const w = Math.max(maxX - minX, 0.01);
  const h = Math.max(maxY - minY, 0.01);
  const norm2 = points.map(([px, py]) => [(px - minX) / w, (py - minY) / h]);
  return { x: minX, y: minY, w, h, norm: norm2 };
}
const generators = /* @__PURE__ */ new Map();
const aliasIndex = /* @__PURE__ */ new Map();
function registerViz(def) {
  generators.set(def.name, def);
  for (const alias of def.aliases ?? []) {
    generators.set(alias, def);
    aliasIndex.set(alias, def.name);
  }
}
function registerVizAlias(alias, canonical) {
  const def = generators.get(canonical);
  if (!def) return;
  const existing = generators.get(alias);
  if (existing) {
    if (existing !== def && typeof console !== "undefined") console.warn(`viz alias '${alias}' already resolves elsewhere — skipped`);
    return;
  }
  generators.set(alias, def);
  aliasIndex.set(alias, def.name);
}
function getViz(name) {
  return generators.get(name);
}
function listVizAliases() {
  return [...aliasIndex.entries()].map(([alias, canonical]) => ({ alias, canonical }));
}
function listVizTemplates() {
  return listViz().map((def) => ({
    name: def.name,
    aliases: [...aliasIndex.entries()].filter(([, canonical]) => canonical === def.name).map(([alias]) => alias),
    category: def.category,
    summary: def.summary,
    entryKinds: def.entryKinds ?? ["item"],
    options: def.options ?? [],
    sweetSpot: def.sweetSpot
  }));
}
function listViz() {
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const def of generators.values()) {
    if (seen.has(def)) continue;
    seen.add(def);
    out.push(def);
  }
  return out.sort((a, b) => a.category.localeCompare(b.category) || a.name.localeCompare(b.name));
}
function runViz(spec, preset, mode, diags) {
  const def = getViz(spec.type);
  if (!def) {
    const known = listViz().map((d) => d.name).join(", ");
    diags.error("E-VIZ-TYPE", `unknown viz type '${spec.type}'`, { line: 1, col: 1, start: 0, end: 0 }, { hint: `known types: ${known}` });
    return null;
  }
  const showValues = spec.options.showValues !== false && spec.options.showValue !== false;
  const ctx = new VizContext(spec.id, preset, mode, diags, showValues);
  def.generate(spec, ctx);
  if (spec.title && !ctx.titleHandled) {
    const b = ctx.bounds();
    ctx.title(spec.title, b.x + b.w / 2, b.y - 44);
  }
  return ctx.result();
}
function optStr(opts, key) {
  const v = opts[key];
  return typeof v === "string" ? v : void 0;
}
function optNum(opts, key) {
  const v = opts[key];
  return typeof v === "number" ? v : void 0;
}
function optBool(opts, key) {
  const v = opts[key];
  return typeof v === "boolean" ? v : void 0;
}
function itemsOf(spec, ...kinds) {
  const want = kinds.length ? new Set(kinds) : /* @__PURE__ */ new Set(["item"]);
  return spec.items.filter((i) => want.has(i.kind));
}
const lerp$1 = (a, b, t) => a + (b - a) * t;
registerViz({
  name: "funnel",
  category: "Business Frameworks",
  summary: "Narrowing stages with side labels; optional input/output captions.",
  entryKinds: ["item", "stage", "level"],
  options: [
    { name: "input", type: "string", description: "caption above the funnel mouth" },
    { name: "output", type: "string", description: "caption below the funnel tip" },
    { name: "showValues", type: "boolean", description: "print item values (default true)" }
  ],
  sweetSpot: { min: 3, max: 6 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "stage", "level");
    const n = Math.max(items.length, 1);
    const topW = 360;
    const tipW = 140;
    const cx = topW / 2;
    const input = optStr(spec.options, "input");
    const output = optStr(spec.options, "output");
    const valueText = (it) => ctx.showValue(it) && it.value !== void 0 ? `  ${fmtNum$1(it.value)}` : "";
    const labelH = Math.max(0, ...items.map((it) => ctx.measureLabelBlock(it.label + valueText(it), it.detail, { maxW: 240 }).h));
    const bandH = Math.max(82, labelH + 18);
    let y = 0;
    if (input) {
      ctx.label(input, cx, 10, { size: 20, color: ctx.ink, font: "heading", weight: ctx.preset.fonts.headingWeight });
      y = 44;
    }
    const y0 = y;
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const wT = lerp$1(topW, tipW, i / n);
        const wB = lerp$1(topW, tipW, (i + 1) / n);
        const top = y0 + i * bandH;
        ctx.poly(
          [
            [cx - wT / 2, top],
            [cx + wT / 2, top],
            [cx + wB / 2, top + bandH],
            [cx - wB / 2, top + bandH]
          ],
          role,
          { id: ctx.uid(item.id) }
        );
        const midY = top + bandH / 2 - 2;
        const edgeX = cx + (wT + wB) / 4;
        const labelX = cx + topW / 2 + 76;
        ctx.arrow(labelX - 10, midY, edgeX + 8, midY, { color: ctx.preset.edge, width: 1.6 });
        ctx.labelBlock(item.label + valueText(item), item.detail, labelX, midY, { color: role.color, align: "left", maxW: 240 });
        if (item.icon) ctx.icon(item.icon, cx, midY, 34, role.textColor);
      })
    );
    if (output) {
      ctx.label(output, cx, y0 + n * bandH + 34, { size: 20, color: ctx.ink, font: "heading", weight: ctx.preset.fonts.headingWeight });
    }
  }
});
registerViz({
  name: "pyramid",
  category: "Hierarchy",
  summary: "Triangle of stacked levels, numbered, labels staggered on the slope.",
  entryKinds: ["item", "level"],
  sweetSpot: { min: 3, max: 6 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "level");
    const n = Math.max(items.length, 1);
    const baseW = 520;
    const cx = baseW / 2;
    const labelH = Math.max(0, ...items.map((it) => ctx.measureLabelBlock(it.label, it.detail, { maxW: 250 }).h));
    const bandH = Math.max(n <= 4 ? 96 : 84, labelH + 14);
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const wT = baseW * (i / n);
        const wB = baseW * ((i + 1) / n);
        const top = i * bandH;
        const pts = i === 0 ? [
          [cx, top],
          [cx + wB / 2, top + bandH - 4],
          [cx - wB / 2, top + bandH - 4]
        ] : [
          [cx - wT / 2, top],
          [cx + wT / 2, top],
          [cx + wB / 2, top + bandH - 4],
          [cx - wB / 2, top + bandH - 4]
        ];
        ctx.poly(pts, role, { id: ctx.uid(item.id) });
        const midY = top + bandH / 2;
        if (i > 0) {
          ctx.label(String(i + 1), cx - wT / 2 + 14, midY, { size: 30, color: role.textColor, weight: 700, align: "left", font: "heading" });
        }
        const slopeX = cx + wB / 2 + 22;
        ctx.labelBlock(item.label, item.detail, slopeX, midY, { color: role.color, align: "left", maxW: 250 });
        if (item.icon) ctx.icon(item.icon, cx + 14, i === 0 ? midY + 10 : midY, 30, role.textColor);
      })
    );
  }
});
registerViz({
  name: "list",
  category: "Brainstorming",
  summary: "Styled list — numbered circles + labels (vertical ≤5, horizontal 6+).",
  entryKinds: ["item"],
  options: [{ name: "orientation", type: "horizontal|vertical", description: "override the ≤5-vertical / 6+-horizontal default" }],
  sweetSpot: { min: 2, max: 8 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item");
    const n = items.length;
    const horizontal = optStr(spec.options, "orientation") === "horizontal" || n >= 6 && optStr(spec.options, "orientation") !== "vertical";
    if (!horizontal) {
      const rowH = Math.max(0, ...items.map((it) => ctx.measureLabelBlock(it.label, it.detail, { maxW: 340 }).h));
      const pitch = Math.max(88, rowH + 26);
      items.forEach(
        (item, i) => ctx.item(item.id, () => {
          const role = ctx.role(i, { n, color: item.color });
          const cy = i * pitch + 30;
          ctx.shape("circle", 0, cy - 30, 60, 60, role, { id: ctx.uid(item.id) });
          const glyph = item.icon ?? String(i + 1);
          if (item.icon) ctx.icon(item.icon, 30, cy, 32, role.textColor);
          else ctx.label(glyph, 30, cy, { size: 24, color: role.textColor, weight: 700, font: "heading" });
          ctx.labelBlock(item.label, item.detail, 84, cy, { color: ctx.ink, align: "left", maxW: 340 });
        })
      );
    } else {
      const pitch = 160;
      items.forEach(
        (item, i) => ctx.item(item.id, () => {
          const role = ctx.role(i, { n, color: item.color });
          const cx = i * pitch + 70;
          if (item.icon) ctx.icon(item.icon, cx, 24, 40, role.color);
          else {
            ctx.shape("circle", cx - 24, 0, 48, 48, role, { id: ctx.uid(item.id) });
            ctx.label(String(i + 1), cx, 24, { size: 20, color: role.textColor, weight: 700, font: "heading" });
          }
          ctx.labelBlock(item.label, item.detail, cx, 74, { color: ctx.ink, align: "center", maxW: pitch - 24, vAnchor: "top" });
        })
      );
    }
  }
});
registerViz({
  name: "key-ideas",
  aliases: ["ideas"],
  category: "Brainstorming",
  summary: "A row of lightbulbs, one per idea, with label + description below.",
  entryKinds: ["item", "idea"],
  sweetSpot: { min: 2, max: 5 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "idea");
    const n = Math.max(items.length, 1);
    const pitch = 210;
    const D = 116;
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const cx = i * pitch + 90;
        const cy = D / 2;
        ctx.shape("circle", cx - D / 2, 0, D, D, role, { id: ctx.uid(item.id) });
        const collar = role.stroke === ctx.preset.background ? role.color : role.stroke;
        ctx.line(
          [
            [cx - 19, D + 5],
            [cx + 19, D + 5]
          ],
          { color: collar, width: role.strokeWidth }
        );
        ctx.line(
          [
            [cx - 14, D + 14],
            [cx + 14, D + 14]
          ],
          { color: collar, width: role.strokeWidth }
        );
        if (item.icon) ctx.icon(item.icon, cx, cy, 48, role.fill ? role.textColor : role.color);
        else {
          const fc = role.fill ? role.textColor : role.color;
          ctx.line(
            [
              [cx - 13, cy + 24],
              [cx - 6.5, cy + 8],
              [cx, cy + 21],
              [cx + 6.5, cy + 8],
              [cx + 13, cy + 24]
            ],
            { color: fc, width: 2 }
          );
          ctx.line(
            [
              [cx, cy - 18],
              [cx, cy + 6]
            ],
            { color: fc, width: 2 }
          );
        }
        ctx.labelBlock(item.label, item.detail, cx, D + 40, { color: role.color, align: "center", maxW: pitch - 34, vAnchor: "top" });
      })
    );
  }
});
function fmtNum$1(v) {
  if (Math.abs(v) >= 1e3) return v.toLocaleString("en-US");
  return String(v);
}
const rad = (deg) => deg * Math.PI / 180;
const lerp = (a, b, t) => a + (b - a) * t;
const polar = (cx, cy, r2, deg) => [
  cx + Math.cos(rad(deg)) * r2,
  cy + Math.sin(rad(deg)) * r2
];
function fmtNum(v) {
  if (Math.abs(v) >= 1e3) return v.toLocaleString("en-US");
  return String(Math.round(v * 100) / 100);
}
function radialAlign(deg) {
  const c = Math.cos(rad(deg));
  if (c > 0.35) return "left";
  if (c < -0.35) return "right";
  return "center";
}
function radialLabel(ctx, cx, cy, r2, deg, label, detail2, color, opts = {}) {
  const gap = opts.gap ?? 16;
  const maxW = opts.maxW ?? 200;
  const m = ctx.measureLabelBlock(label, detail2, { maxW, size: opts.size });
  const c = Math.cos(rad(deg));
  const s = Math.sin(rad(deg));
  const push = m.w / 2 * Math.abs(c) + m.h / 2 * Math.abs(s);
  const [bx, by] = polar(cx, cy, r2 + gap + push, deg);
  const align = radialAlign(deg);
  const anchorX = align === "left" ? bx - m.w / 2 : align === "right" ? bx + m.w / 2 : bx;
  return ctx.labelBlock(label, detail2, anchorX, by, { color, align, maxW, vAnchor: "middle", size: opts.size });
}
function scallopedBlob(rx, ry, bumps) {
  const pts = [];
  for (let i = 0; i < bumps; i++) {
    const a = i / bumps * Math.PI * 2 - Math.PI / 2;
    const wob = 0.93 + 0.06 * Math.sin(i * 2.7) + 0.04 * Math.cos(i * 1.3);
    pts.push([rx + rx * wob * Math.cos(a), ry + ry * wob * Math.sin(a)]);
  }
  let d = `M${pts[0][0].toFixed(1)},${pts[0][1].toFixed(1)}`;
  for (let i = 1; i <= bumps; i++) {
    const [x1, y1] = pts[i - 1];
    const [x2, y2] = pts[i % bumps];
    const r2 = Math.hypot(x2 - x1, y2 - y1) * 0.62;
    d += ` A${r2.toFixed(1)},${r2.toFixed(1)} 0 0 1 ${x2.toFixed(1)},${y2.toFixed(1)}`;
  }
  return d + " Z";
}
registerViz({
  name: "pie",
  aliases: ["donut"],
  category: "Data",
  summary: "Pie/donut chart with percentage callouts.",
  entryKinds: ["item", "slice"],
  options: [
    { name: "variant", type: "pie|donut", description: '"donut" cuts a hole in the middle' },
    { name: "showValues", type: "boolean", description: "print item values (default true)" }
  ],
  sweetSpot: { min: 2, max: 6 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "slice");
    const n = Math.max(items.length, 1);
    const D = 280;
    const cx = D / 2 + 150;
    const cy = D / 2 + 20;
    const inner = spec.type === "donut" || optStr(spec.options, "variant") === "donut" ? 0.55 : 0;
    const total = items.reduce((s, it) => s + (it.value ?? 1), 0) || 1;
    let angle = -90;
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const sweep = (item.value ?? 1) / total * 360;
        ctx.shape("sector", cx - D / 2, cy - D / 2, D, D, role, {
          id: ctx.uid(item.id),
          data: { start: angle, end: angle + sweep, inner }
        });
        const mid = angle + sweep / 2;
        const pct = Math.round((item.value ?? 1) / total * 100);
        const pctText = ctx.showValue(item) ? `${pct}% ` : "";
        radialLabel(ctx, cx, cy, D / 2, mid, `${pctText}${item.label}`, item.detail, role.color, { maxW: 190 });
        if (item.icon) {
          const [ix, iy] = polar(cx, cy, D / 2 * 0.62, mid);
          ctx.icon(item.icon, ix, iy, 28, role.textColor);
        }
        angle += sweep;
      })
    );
  }
});
registerViz({
  name: "gauge",
  category: "Data",
  summary: "A 270° dial showing one value (0–100).",
  entryKinds: ["item", "value"],
  options: [
    { name: "value", type: "number", description: "dial value 0–100 (else the first item's value)" },
    { name: "label", type: "string", description: "caption below the dial (else the first item's label)" },
    { name: "showValues", type: "boolean", description: "print item values (default true)" }
  ],
  sweetSpot: { min: 1, max: 1 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "value");
    const value = Math.max(0, Math.min(100, optNum(spec.options, "value") ?? items[0]?.value ?? 0));
    const caption = optStr(spec.options, "label") ?? items[0]?.label ?? "";
    const D = 240;
    const cx = D / 2 + 40;
    const cy = D / 2 + 40;
    const start = 135;
    const sweep = 270;
    const role = ctx.role(0, { n: 1, color: items[0]?.color });
    ctx.shape("sector", cx - D / 2, cy - D / 2, D, D, ctx.role(0, { neutral: true }), {
      data: { start, end: start + sweep, inner: 0.72 },
      style: { opacity: 45 }
    });
    ctx.shape("sector", cx - D / 2, cy - D / 2, D, D, role, {
      id: ctx.uid("value"),
      data: { start, end: start + sweep * value / 100, inner: 0.72 }
    });
    const needleAngle = start + sweep * value / 100;
    const [nx, ny] = polar(cx, cy, D / 2 - 34, needleAngle);
    ctx.line(
      [
        [cx, cy],
        [nx, ny]
      ],
      { color: ctx.ink, width: 3 }
    );
    ctx.shape("circle", cx - 7, cy - 7, 14, 14, { stroke: ctx.ink, fill: ctx.ink, fillStyle: "solid", strokeWidth: 1, roughness: ctx.preset.roughness });
    if (items[0] ? ctx.showValue(items[0]) : ctx.showValues) {
      ctx.label(`${Math.round(value)}%`, cx, cy + 58, { size: 27, color: role.color, weight: 700, font: "heading", role: "value" });
    }
    if (caption) ctx.label(caption, cx, cy + 92, { size: 18, color: ctx.ink, font: "body" });
  }
});
registerViz({
  name: "cycle",
  aliases: ["loop"],
  category: "Process",
  summary: "Phases on a ring with sweeping arrows between them.",
  entryKinds: ["item", "phase", "step"],
  sweetSpot: { min: 3, max: 8 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "phase", "step");
    const n = Math.max(items.length, 2);
    const big = n <= 4;
    const R = big ? 150 : 165;
    const nodeR = big ? 56 : 5;
    const cx = R + nodeR + 260;
    const cy = R + nodeR + 40;
    const step = 360 / n;
    items.forEach((item, i) => {
      const role = ctx.role(i, { n, color: item.color });
      const a = -90 + i * step;
      const [nx, ny] = polar(cx, cy, R, a);
      ctx.item(item.id, () => {
        if (big) {
          ctx.shape("circle", nx - nodeR, ny - nodeR, nodeR * 2, nodeR * 2, role, { id: ctx.uid(item.id) });
          if (item.icon) ctx.icon(item.icon, nx, ny, 40, role.textColor);
          else ctx.label(String(i + 1), nx, ny, { size: 28, color: role.textColor, weight: 700, font: "heading" });
        } else {
          ctx.shape("circle", nx - nodeR, ny - nodeR, nodeR * 2, nodeR * 2, { stroke: role.color, fill: role.color, fillStyle: "solid", strokeWidth: 1, roughness: ctx.preset.roughness }, { id: ctx.uid(item.id) });
        }
      });
      const gapDeg = big ? Math.asin((nodeR + 14) / R) * 180 / Math.PI : 14;
      const a1 = a + gapDeg;
      const a2 = a + step - gapDeg;
      if (big) {
        const bw = 17;
        const headDeg = Math.min(14, (a2 - a1) * 0.38);
        const bodyEnd = a2 - headDeg;
        const outer = [];
        const inner = [];
        const segs = 12;
        for (let s = 0; s <= segs; s++) {
          const ang = a1 + (bodyEnd - a1) * s / segs;
          outer.push(polar(cx, cy, R + bw / 2, ang));
          inner.unshift(polar(cx, cy, R - bw / 2, ang));
        }
        const band = [
          ...outer,
          polar(cx, cy, R + bw * 1.15, bodyEnd),
          polar(cx, cy, R, a2),
          // tip
          polar(cx, cy, R - bw * 1.15, bodyEnd),
          ...inner
        ];
        ctx.poly(band, role, { id: ctx.uid(`${item.id}_arrow`) });
      } else {
        const arcPts = [];
        const segs = 14;
        for (let s = 0; s <= segs; s++) arcPts.push(polar(cx, cy, R, a1 + (a2 - a1) * s / segs));
        ctx.line(arcPts, { color: ctx.preset.edge, width: 2, arrow: true });
      }
      ctx.item(item.id, () => radialLabel(ctx, cx, cy, R + nodeR + 10, a, item.label, item.detail, role.color, { maxW: 210 }));
    });
  }
});
registerViz({
  name: "bullseye",
  aliases: ["target"],
  category: "Hierarchy",
  summary: "Concentric target rings, labels on the left with leader lines.",
  entryKinds: ["item", "ring"],
  sweetSpot: { min: 2, max: 5 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "ring");
    const n = Math.max(items.length, 1);
    const outerR = 150;
    const cx = 420 + outerR;
    const cy = outerR + 20;
    const textX = 0;
    const labelH = Math.max(0, ...items.map((it) => ctx.measureLabelBlock(it.label, it.detail, { maxW: 240 }).h));
    const labelPitch = Math.max(72, labelH + 20);
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const r2 = outerR * (1 - i / n);
        const innerRatio = i === n - 1 ? 0 : outerR * (1 - (i + 1) / n) / r2;
        ctx.shape("sector", cx - r2, cy - r2, r2 * 2, r2 * 2, role, {
          id: ctx.uid(item.id),
          data: { start: 0, end: 359.999, inner: innerRatio }
        });
        const bandMidX = cx - (r2 + innerRatio * r2) / 2;
        const ly = cy - outerR + 16 + i * labelPitch;
        const block = ctx.labelBlock(item.label, item.detail, textX, ly, { color: role.color, align: "left", maxW: 240 });
        ctx.shape("circle", block.x + block.w + 10, ly - 3, 6, 6, { stroke: ctx.ink, fill: ctx.ink, fillStyle: "solid", strokeWidth: 1, roughness: 0.5 });
        ctx.line(
          [
            [block.x + block.w + 16, ly],
            [bandMidX, ly]
          ],
          { color: ctx.mutedInk, width: 1.4 }
        );
        if (item.icon) {
          const iconY = i === n - 1 ? cy : cy - (r2 + innerRatio * r2) / 2;
          ctx.icon(item.icon, cx, iconY, 28, role.textColor);
        }
      })
    );
  }
});
registerViz({
  name: "relationship",
  aliases: ["hub-spoke", "orbit"],
  category: "Comparison",
  summary: "A hub with satellites on a dashed orbit ring.",
  entryKinds: ["item", "node", "center", "hub"],
  sweetSpot: { min: 3, max: 8 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "node");
    const center = spec.items.find((i) => i.kind === "center" || i.kind === "hub");
    const n = Math.max(items.length, 1);
    const R = 160;
    const cx = R + 240;
    const cy = R + 60;
    for (const rot2 of [18, 78, 138]) {
      const orbit = [];
      const rx = R * 1.12;
      const ry = R * 0.48;
      for (let s = 0; s <= 56; s++) {
        const t = 2 * Math.PI * s / 56;
        const ox = Math.cos(t) * rx;
        const oy = Math.sin(t) * ry;
        const rr = rot2 * Math.PI / 180;
        orbit.push([cx + ox * Math.cos(rr) - oy * Math.sin(rr), cy + ox * Math.sin(rr) + oy * Math.cos(rr)]);
      }
      ctx.line(orbit, { color: ctx.mutedInk, width: 1.2, dash: true, z: -1 });
    }
    const hubR = 52;
    const hubRole = center?.color ? ctx.role(0, { color: center.color }) : ctx.role(0, { emphasis: true, n: n + 1 });
    const drawHub = () => {
      ctx.shape("circle", cx - hubR, cy - hubR, hubR * 2, hubR * 2, hubRole, { id: ctx.uid("hub") });
      if (center?.icon) ctx.icon(center.icon, cx, cy, 40, hubRole.textColor);
      else if (center?.label) ctx.label(ctx.wrap(center.label, hubR * 1.7, 16), cx, cy, { size: 16, color: hubRole.textColor, weight: 700, font: "heading" });
    };
    if (center) ctx.item(center.id, drawHub);
    else drawHub();
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const a = -90 + 360 / n * i;
        const [sx, sy] = polar(cx, cy, R, a);
        const r2 = 26;
        ctx.shape("circle", sx - r2, sy - r2, r2 * 2, r2 * 2, role, { id: ctx.uid(item.id) });
        if (item.icon) ctx.icon(item.icon, sx, sy, 24, role.textColor);
        radialLabel(ctx, cx, cy, R + r2 + 8, a, item.label, item.detail, role.color, { maxW: 180 });
      })
    );
  }
});
registerViz({
  name: "porters",
  aliases: ["forces"],
  category: "Business Frameworks",
  summary: "Porter's forces — circles around a center, labels radiating out.",
  entryKinds: ["item", "force"],
  sweetSpot: { min: 4, max: 6 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "force");
    const n = Math.max(items.length, 2);
    const R = 132;
    const cx = R + 300;
    const cy = R + 90;
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const a = -90 + 360 / n * i;
        const [sx, sy] = polar(cx, cy, R, a);
        const r2 = 50;
        const [ix, iy] = polar(cx, cy, R - r2 - 8, a);
        const [ex, ey] = polar(cx, cy, 26, a);
        ctx.arrow(ix, iy, ex, ey, { color: ctx.mutedInk, width: 1.6 });
        ctx.shape("circle", sx - r2, sy - r2, r2 * 2, r2 * 2, role, { id: ctx.uid(item.id) });
        if (item.icon) ctx.icon(item.icon, sx, sy, 36, role.textColor);
        else ctx.label(String(i + 1), sx, sy, { size: 26, color: role.textColor, weight: 700, font: "heading" });
        radialLabel(ctx, cx, cy, R + r2 + 10, a, item.label, item.detail, role.color, { maxW: 210 });
      })
    );
  }
});
registerViz({
  name: "impact",
  category: "Cause and Effect",
  summary: "One cause radiating to effect bubbles above it.",
  entryKinds: ["item", "effect", "cause", "center"],
  sweetSpot: { min: 2, max: 5 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "effect");
    const causeItem = spec.items.find((i) => i.kind === "cause" || i.kind === "center");
    const cause = causeItem ?? { label: spec.title ?? "Cause", color: void 0 };
    const n = Math.max(items.length, 1);
    const cx = 360;
    const cy = 360;
    const causeR = 86;
    const causeRole = ctx.role(0, { emphasis: true, color: cause.color });
    const drawCause = () => {
      ctx.shape("circle", cx - causeR, cy - causeR, causeR * 2, causeR * 2, causeRole, { id: ctx.uid("cause") });
      ctx.label(ctx.wrap(cause.label, causeR * 1.6, 18), cx, cy, { size: 18, color: causeRole.textColor, weight: 700, font: "heading" });
    };
    if (causeItem) ctx.item(causeItem.id, drawCause);
    else drawCause();
    const spreadStart = 180 + (180 - 140) / 2 + 20;
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i + 1, { n: n + 1, color: item.color });
        const a = n === 1 ? -90 : spreadStart + 140 / (n - 1) * i;
        const dist2 = 210;
        const [ex, ey] = polar(cx, cy, dist2, a);
        const r2 = 44;
        const [s1x, s1y] = polar(cx, cy, causeR + 6, a);
        const [s2x, s2y] = polar(cx, cy, dist2 - r2 - 8, a);
        ctx.line(
          [
            [s1x, s1y],
            [(s1x + s2x) / 2 + 10, (s1y + s2y) / 2],
            [s2x, s2y]
          ],
          { color: ctx.mutedInk, width: 1.8, arrow: true }
        );
        ctx.shape("circle", ex - r2, ey - r2, r2 * 2, r2 * 2, role, { id: ctx.uid(item.id) });
        if (item.icon) ctx.icon(item.icon, ex, ey, 30, role.textColor);
        else ctx.label(String(i + 1), ex, ey, { size: 24, color: role.textColor, weight: 700, font: "heading" });
        radialLabel(ctx, ex, ey, r2, a, item.label, item.detail, role.color, { maxW: 200, gap: 10 });
      })
    );
  }
});
registerViz({
  name: "performance",
  aliases: ["kpis", "metrics"],
  category: "Visual Metaphors",
  summary: "Side-by-side donut gauges, one per metric.",
  entryKinds: ["item", "metric"],
  options: [
    { name: "summary", type: "string", description: "caption under the panels" },
    { name: "showValues", type: "boolean", description: "print item values (default true)" }
  ],
  sweetSpot: { min: 2, max: 4 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "metric");
    const n = Math.max(items.length, 1);
    const panelW = 220;
    const summary = optStr(spec.options, "summary");
    const panelH = 322;
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const x0 = i * (panelW + 24);
        const cxP = x0 + panelW / 2;
        const value = Math.max(0, Math.min(100, item.value ?? 0));
        ctx.shape("rectangle", x0, 0, panelW, panelH, { stroke: role.color, fill: null, fillStyle: "none", strokeWidth: Math.max(1.4, role.strokeWidth * 0.8), roughness: ctx.preset.roughness, roundness: 14 }, { z: -1 });
        ctx.labelBlock(item.label, item.detail, cxP, 30, { color: role.color, align: "center", maxW: panelW - 28, vAnchor: "top" });
        const D = 128;
        const gy = 116;
        ctx.shape("sector", cxP - D / 2, gy, D, D, ctx.role(i, { neutral: true }), { data: { start: 0, end: 359.999, inner: 0.74 }, style: { opacity: 40 } });
        ctx.shape("sector", cxP - D / 2, gy, D, D, role, { id: ctx.uid(item.id), data: { start: -90, end: -90 + value / 100 * 359.99, inner: 0.74 } });
        if (item.icon) ctx.icon(item.icon, cxP, gy + D / 2, 40, role.color);
        if (ctx.showValue(item)) ctx.label(`${Math.round(value)}%`, cxP, gy + D + 32, { size: 24, color: role.color, weight: 700, font: "heading", role: "value" });
      })
    );
    if (summary) {
      const b = ctx.bounds();
      ctx.label(summary, b.x + b.w / 2, b.y + b.h + 40, { size: 18, color: ctx.ink, maxW: 560 });
    }
  }
});
function vennRole(ctx, role) {
  if (role.fill === null) return role;
  const alpha = ctx.preset.mode === "dark" ? 0.46 : 0.28;
  const stroke = ctx.preset.strokeMode === "ink" ? ctx.preset.ink : role.color;
  return { ...role, fill: withAlpha(role.color, alpha), stroke, fillStyle: "solid" };
}
registerViz({
  name: "venn",
  category: "Comparison",
  summary: "Overlapping sets (2–7 circles) in a symmetric rosette with region labels.",
  entryKinds: ["item", "set", "overlap", "intersection", "both", "all"],
  sweetSpot: { min: 2, max: 3 },
  generate(spec, ctx) {
    const sets = itemsOf(spec, "item", "set");
    const overlaps = spec.items.filter((i) => i.kind === "overlap" || i.kind === "intersection" || i.kind === "both" || i.kind === "all");
    const n = Math.max(2, Math.min(sets.length, 7));
    if (sets.length > 7) {
      ctx.diags.warn("W-VIZ-VENN", `venn supports up to 7 sets; got ${sets.length} — extra sets are dropped`, { line: 1, col: 1, start: 0, end: 0 }, { hint: "split into two diagrams or use a relationship viz" });
    }
    const used = sets.slice(0, n);
    const cx = 440;
    const cy = 340;
    const R = n >= 5 ? 118 : 130;
    const d = R * (0.42 + 0.09 * n);
    const startA = n === 2 ? 180 : -90;
    const centers = used.map((_, i) => {
      const a = startA + 360 / n * i;
      const [x, y] = polar(cx, cy, d, a);
      return { x, y, angle: a };
    });
    used.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = vennRole(ctx, ctx.role(i, { n, color: item.color }));
        const c = centers[i];
        ctx.shape("circle", c.x - R, c.y - R, R * 2, R * 2, role, { id: ctx.uid(item.id) });
      })
    );
    const labelSize = n >= 6 ? 17 : 20;
    const labelW = n >= 6 ? 150 : n >= 5 ? 165 : 200;
    used.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const c = centers[i];
        radialLabel(ctx, c.x, c.y, R, c.angle, item.label, item.detail, role.color, { maxW: labelW, size: labelSize });
        if (item.icon) {
          const [ix, iy] = polar(cx, cy, d + R * 0.5, c.angle);
          ctx.icon(item.icon, ix, iy, 34, role.color);
        }
      })
    );
    const idOf = (s) => used.findIndex((u) => u.id === s || u.label.toLowerCase() === s.toLowerCase());
    const figureR = d + R;
    overlaps.forEach((ov, k) => {
      const named = [...ov.strings, ...ov.to ? [ov.to] : [], ...ov.opts.sets && Array.isArray(ov.opts.sets) ? ov.opts.sets : []];
      let members = named.map(idOf).filter((i) => i >= 0);
      const isAll = ov.kind === "all" || members.length >= n || !members.length && ov.kind !== "overlap" && ov.kind !== "intersection";
      if (isAll) members = used.map((_, i) => i);
      else if (members.length < 2) members = [0, Math.min(1, n - 1)];
      const all = members.length >= n;
      const rx = all ? cx : members.reduce((s, i) => s + centers[i].x, 0) / members.length;
      const ry = all ? cy : members.reduce((s, i) => s + centers[i].y, 0) / members.length;
      let outAngle = all ? n === 2 ? -90 : 8 : Math.atan2(ry - cy, rx - cx) * 180 / Math.PI;
      if (!Number.isFinite(outAngle)) outAngle = -90;
      const role = ctx.role(n + k, { n: n + overlaps.length });
      if (ov.icon) ctx.icon(ov.icon, rx, ry, 28, role.color);
      const block = radialLabel(ctx, cx, cy, figureR + 6, outAngle, ov.label, ov.detail, role.color, { maxW: 180 });
      const bcx = block.x + block.w / 2;
      const bcy = block.y + block.h / 2;
      const ex = Math.abs(rx - bcx) > block.w / 2 + 4 ? rx < bcx ? block.x - 8 : block.x + block.w + 8 : bcx;
      const ey = ex === bcx ? ry < bcy ? block.y - 8 : block.y + block.h + 8 : bcy;
      const dl = Math.hypot(ex - rx, ey - ry) || 1;
      const gap = ov.icon ? 24 : 14;
      ctx.line(
        [
          [rx + (ex - rx) / dl * gap, ry + (ey - ry) / dl * gap],
          [ex, ey]
        ],
        { color: ctx.mutedInk, width: 1.2, dotted: true }
      );
    });
  }
});
function niceMax(v) {
  if (v <= 0) return 1;
  const mag = Math.pow(10, Math.floor(Math.log10(v)));
  for (const m of [1, 2, 2.5, 5, 10]) {
    if (v <= m * mag) return m * mag;
  }
  return 10 * mag;
}
function drawAxes(ctx, x0, y0, w, h, opts = {}) {
  const c = ctx.preset.edge;
  if (opts.arrows) {
    ctx.arrow(x0, y0, x0, y0 - h - 24, { color: c, width: 1.8 });
    ctx.arrow(x0, y0, x0 + w + 24, y0, { color: c, width: 1.8 });
  } else {
    ctx.line(
      [
        [x0, y0 - h],
        [x0, y0],
        [x0 + w, y0]
      ],
      { color: c, width: 1.8 }
    );
  }
  if (opts.yTitle) ctx.label(opts.yTitle, x0 - 6, y0 - h - 44, { size: 18, color: ctx.ink, align: "left", font: "heading", weight: ctx.preset.fonts.headingWeight });
  if (opts.xTitle) ctx.label(opts.xTitle, x0 + w + 34, y0, { size: 18, color: ctx.ink, align: "left", font: "heading", weight: ctx.preset.fonts.headingWeight });
}
function drawLegend(ctx, names, x, y) {
  let cx = x;
  names.forEach((name, i) => {
    const role = ctx.role(i, { n: names.length });
    ctx.shape("circle", cx, y - 8, 16, 16, { ...roleFillOnly(ctx, i, names.length), stroke: role.stroke === ctx.preset.background ? role.color : role.stroke });
    cx += 24;
    const w = ctx.measure(name, 15);
    ctx.label(name, cx, y, { size: 15, color: ctx.ink, align: "left" });
    cx += w + 28;
  });
  return 30;
}
function roleFillOnly(ctx, i, n) {
  const role = ctx.role(i, { n });
  return { fill: role.fill ?? role.color, fillStyle: "solid", strokeWidth: 1, roughness: ctx.preset.roughness };
}
function seriesNames(spec) {
  const entries = spec.items.filter((i) => i.kind === "series" && !i.values.length).map((i) => i.label);
  if (entries.length) return entries;
  const opt = spec.options.legend ?? spec.options.series;
  if (Array.isArray(opt)) return opt.map(String);
  return [];
}
registerViz({
  name: "bar",
  aliases: ["column"],
  category: "Data",
  summary: "Column chart with per-category colors and value labels.",
  sweetSpot: { min: 1, max: 12 },
  entryKinds: ["item", "bar"],
  options: [
    { name: "yTitle", type: "string", description: "y-axis title" },
    { name: "xTitle", type: "string", description: "x-axis title" },
    { name: "showValues", type: "boolean", description: "print item values (default true)" }
  ],
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "bar");
    const n = Math.max(items.length, 1);
    const barW = 96;
    const gap = 20;
    const chartH = 280;
    const x0 = 50;
    const y0 = chartH + 40;
    const max = niceMax(Math.max(...items.map((i) => i.value ?? 0), 1));
    drawAxes(ctx, x0, y0, n * (barW + gap) + gap, chartH, {
      arrows: true,
      yTitle: optStr(spec.options, "yTitle"),
      xTitle: optStr(spec.options, "xTitle")
    });
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const h = (item.value ?? 0) / max * chartH;
        const x = x0 + gap + i * (barW + gap);
        ctx.shape("rectangle", x, y0 - h, barW, h, role, { id: ctx.uid(item.id) });
        if (ctx.showValue(item)) ctx.label(fmtNum(item.value ?? 0), x + barW / 2, y0 - h - 16, { size: 15, color: role.color, weight: 700, role: "value" });
        ctx.label(ctx.wrap(item.label, barW + gap - 6, 15), x + barW / 2, y0 + 22, { size: 15, color: ctx.ink });
      })
    );
  }
});
registerViz({
  name: "bar-horizontal",
  aliases: ["hbar"],
  category: "Data",
  summary: "Horizontal bars with circular category badges.",
  sweetSpot: { min: 1, max: 8 },
  entryKinds: ["item", "bar"],
  options: [{ name: "showValues", type: "boolean", description: "print item values (default true)" }],
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "bar");
    const n = Math.max(items.length, 1);
    const rowH = 76;
    const badgeR = 27;
    const trackW = 420;
    const x0 = 110;
    const max = niceMax(Math.max(...items.map((i) => i.value ?? 0), 1));
    const valueText = (it) => ctx.showValue(it) ? `  ${fmtNum(it.value ?? 0)}` : "";
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const cy = i * rowH + badgeR + 6;
        ctx.shape("circle", 30 - badgeR, cy - badgeR, badgeR * 2, badgeR * 2, role, { id: ctx.uid(`${item.id}_badge`) });
        if (item.icon) ctx.icon(item.icon, 30, cy, 28, role.textColor);
        else ctx.label(String(i + 1), 30, cy, { size: 20, color: role.textColor, weight: 700 });
        const w = (item.value ?? 0) / max * trackW;
        ctx.shape("rectangle", x0, cy - 17, Math.max(w, 3), 34, role, { id: ctx.uid(item.id), style: { roundness: 8 } });
        ctx.label(`${item.label}${valueText(item)}`, x0 + w + 14, cy, { size: 16, color: ctx.ink, align: "left" });
      })
    );
  }
});
function stackedBars(spec, ctx, horizontal) {
  const rows = itemsOf(spec, "item", "row").filter((r2) => r2.values.length);
  const names = seriesNames(spec);
  const k = Math.max(names.length, ...rows.map((r2) => r2.values.length), 1);
  const max = niceMax(Math.max(...rows.map((r2) => r2.values.reduce((s, v) => s + v, 0)), 1));
  let y = 0;
  if (names.length) y += drawLegend(ctx, names, horizontal ? 90 : 60, 8) + 8;
  if (horizontal) {
    const rowH = 60;
    const pitch = 88;
    const trackW = 520;
    const x0 = 90;
    rows.forEach(
      (row, r2) => ctx.item(row.id, () => {
        const cy = y + r2 * pitch + rowH / 2 + 26;
        ctx.label(row.label, x0 - 12, cy, { size: 15, color: ctx.ink, align: "right", maxW: 84 });
        let x = x0;
        row.values.forEach((v, s) => {
          const role = ctx.role(s, { n: k });
          const w = v / max * trackW;
          ctx.shape("rectangle", x, cy - rowH / 2, Math.max(w, 2), rowH, role, { id: ctx.uid(`${row.id}_${s}`) });
          if (w > 44 && ctx.showValue(row)) ctx.label(fmtNum(v), x + w / 2, cy, { size: 14, color: role.textColor, role: "value" });
          x += w;
        });
      })
    );
    const axisY = y + rows.length * pitch + 20;
    ctx.line(
      [
        [x0, y + 16],
        [x0, axisY],
        [x0 + trackW + 20, axisY]
      ],
      { color: ctx.preset.edge, width: 1.6 }
    );
    for (let t = 0; t <= 4; t++) {
      const tx = x0 + trackW * t / 4;
      ctx.label(fmtNum(max * t / 4), tx, axisY + 18, { size: 13, color: ctx.mutedInk });
    }
  } else {
    const barW = 84;
    const gap = 26;
    const chartH = 300;
    const x0 = 60;
    const y0 = y + chartH + 30;
    drawAxes(ctx, x0, y0, rows.length * (barW + gap) + gap, chartH, { yTitle: optStr(spec.options, "yTitle"), xTitle: optStr(spec.options, "xTitle") });
    rows.forEach(
      (row, r2) => ctx.item(row.id, () => {
        const x = x0 + gap + r2 * (barW + gap);
        let top = y0;
        row.values.forEach((v, s) => {
          const role = ctx.role(s, { n: k });
          const h = v / max * chartH;
          top -= h;
          ctx.shape("rectangle", x, top, barW, h, role, { id: ctx.uid(`${row.id}_${s}`) });
          if (h > 26 && ctx.showValue(row)) ctx.label(fmtNum(v), x + barW / 2, top + h / 2, { size: 14, color: role.textColor, role: "value" });
        });
        ctx.label(ctx.wrap(row.label, barW + gap - 6, 15), x + barW / 2, y0 + 22, { size: 15, color: ctx.ink });
      })
    );
  }
}
registerViz({
  name: "stacked-bar",
  category: "Data",
  summary: 'Stacked columns; rows are `item "Q1" [a, b, c]`, legend via `series`.',
  sweetSpot: { min: 2, max: 6 },
  entryKinds: ["item", "row", "series"],
  options: [
    { name: "yTitle", type: "string", description: "y-axis title" },
    { name: "xTitle", type: "string", description: "x-axis title" },
    { name: "legend", type: "string", description: "list of series names for the legend" },
    { name: "series", type: "string", description: "alias for legend" },
    { name: "showValues", type: "boolean", description: "print item values (default true)" }
  ],
  generate: (spec, ctx) => stackedBars(spec, ctx, false)
});
registerViz({
  name: "stacked-bar-horizontal",
  aliases: ["stacked-hbar"],
  category: "Data",
  summary: "Horizontal stacked bars with a value axis and legend.",
  sweetSpot: { min: 2, max: 6 },
  entryKinds: ["item", "row", "series"],
  options: [
    { name: "legend", type: "string", description: "list of series names for the legend" },
    { name: "series", type: "string", description: "alias for legend" },
    { name: "showValues", type: "boolean", description: "print item values (default true)" }
  ],
  generate: (spec, ctx) => stackedBars(spec, ctx, true)
});
function lineChart(spec, ctx, area) {
  const points = itemsOf(spec, "item", "point");
  const n = Math.max(points.length, 2);
  const pitch = Math.max(64, Math.min(110, 720 / n));
  const chartW = (n - 1) * pitch;
  const chartH = 260;
  const x0 = 50;
  const y0 = chartH + 44;
  const max = niceMax(Math.max(...points.map((p) => p.value ?? 0), 1));
  drawAxes(ctx, x0, y0, chartW + 40, chartH, { arrows: true, yTitle: optStr(spec.options, "yTitle"), xTitle: optStr(spec.options, "xTitle") });
  const role = ctx.role(0, { n: 1, color: optStr(spec.options, "color") });
  const pts = points.map((p, i) => [x0 + 30 + i * pitch, y0 - (p.value ?? 0) / max * chartH]);
  if (area && pts.length >= 2) {
    const poly = [...pts, [pts[pts.length - 1][0], y0], [pts[0][0], y0]];
    ctx.poly(poly, { ...ctx.role(0, { n: 1, color: role.color }), stroke: "transparent", fill: withSoft(ctx, role.color), fillStyle: "solid" }, { z: -1 });
  }
  ctx.line(pts, { color: ctx.preset.fillMode === "outline" ? ctx.preset.edge : role.color, width: 2.2 });
  points.forEach(
    (p, i) => ctx.item(p.id, () => {
      const [px, py] = pts[i];
      ctx.shape("circle", px - 5, py - 5, 10, 10, { stroke: role.color, fill: ctx.preset.background, fillStyle: "solid", strokeWidth: 2, roughness: Math.min(0.6, ctx.preset.roughness) });
      if (ctx.showValue(p)) ctx.label(fmtNum(p.value ?? 0), px, py - 20, { size: 14, color: role.color, weight: 700, role: "value" });
      ctx.label(p.label, px, y0 + 20, { size: 14, color: ctx.ink });
    })
  );
}
function withSoft(ctx, color) {
  return ctx.role(0, { color }).softFill;
}
registerViz({
  name: "line",
  category: "Data",
  summary: "Line chart with point markers and value labels.",
  sweetSpot: { min: 2, max: 14 },
  entryKinds: ["item", "point"],
  options: [
    { name: "yTitle", type: "string", description: "y-axis title" },
    { name: "xTitle", type: "string", description: "x-axis title" },
    { name: "color", type: "string", description: "line color override" },
    { name: "showValues", type: "boolean", description: "print item values (default true)" }
  ],
  generate: (spec, ctx) => lineChart(spec, ctx, false)
});
registerViz({
  name: "area",
  category: "Data",
  summary: "Line chart with a soft filled area underneath.",
  sweetSpot: { min: 2, max: 14 },
  entryKinds: ["item", "point"],
  options: [
    { name: "yTitle", type: "string", description: "y-axis title" },
    { name: "xTitle", type: "string", description: "x-axis title" },
    { name: "color", type: "string", description: "line color override" },
    { name: "showValues", type: "boolean", description: "print item values (default true)" }
  ],
  generate: (spec, ctx) => lineChart(spec, ctx, true)
});
registerViz({
  name: "waterfall",
  category: "Data",
  summary: "Start bar, floating signed deltas, computed net bar, connector line.",
  sweetSpot: { min: 2, max: 8 },
  entryKinds: ["item", "delta", "total", "net", "end"],
  options: [
    { name: "yTitle", type: "string", description: "y-axis title" },
    { name: "xTitle", type: "string", description: "x-axis title" },
    { name: "showValues", type: "boolean", description: "print item values (default true)" }
  ],
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "delta");
    const totals = spec.items.filter((i) => i.kind === "total" || i.kind === "net" || i.kind === "end");
    const barW = 84;
    const gap = 30;
    const chartH = 320;
    const x0 = 60;
    const y0 = chartH + 40;
    const bars = [];
    let level = 0;
    items.forEach((item, i) => {
      const v = item.value ?? 0;
      if (i === 0) {
        bars.push({ item, from: 0, to: v, kind: "start" });
        level = v;
      } else {
        bars.push({ item, from: level, to: level + v, kind: "delta" });
        level += v;
      }
    });
    for (const t of totals) bars.push({ item: t, from: 0, to: level, kind: "total" });
    const max = niceMax(Math.max(...bars.map((b) => Math.max(b.from, b.to)), 1));
    const yOf = (v) => y0 - v / max * chartH;
    drawAxes(ctx, x0, y0, bars.length * (barW + gap) + gap, chartH, { yTitle: optStr(spec.options, "yTitle"), xTitle: optStr(spec.options, "xTitle") });
    for (let t = 1; t <= 4; t++) {
      const gy = y0 - chartH * t / 4;
      ctx.line(
        [
          [x0, gy],
          [x0 + bars.length * (barW + gap) + gap, gy]
        ],
        { color: ctx.mutedInk, width: 0.8, dash: true, z: -2 }
      );
      ctx.label(fmtNum(max * t / 4), x0 - 10, gy, { size: 13, color: ctx.mutedInk, align: "right" });
    }
    const joints = [];
    bars.forEach(
      (b, i) => ctx.item(b.item.id, () => {
        const roleIdx = b.kind === "start" ? 0 : b.kind === "total" ? 2 : 1;
        const role = ctx.role(roleIdx, { n: 3, color: b.item.color });
        const x = x0 + gap + i * (barW + gap);
        const top = Math.min(yOf(b.from), yOf(b.to));
        const h = Math.max(Math.abs(yOf(b.from) - yOf(b.to)), 3);
        ctx.shape("rectangle", x, top, barW, h, role, { id: ctx.uid(b.item.id), style: { roundness: 6 } });
        const delta = b.to - b.from;
        const sign = b.kind === "delta" ? delta >= 0 ? "+" : "−" : "";
        if (ctx.showValue(b.item)) ctx.label(`${sign}${fmtNum(Math.abs(b.kind === "total" ? b.to : b.kind === "start" ? b.to : delta))}`, x + barW / 2, top - 16, { size: 15, color: role.color, weight: 700, role: "value" });
        ctx.label(ctx.wrap(b.item.label, barW + gap - 4, 14), x + barW / 2, y0 + 22, { size: 14, color: ctx.ink });
        joints.push([x + barW / 2, yOf(b.to)]);
      })
    );
    ctx.line(joints, { color: ctx.preset.edge, width: 1.4, z: 1 });
    for (const [jx, jy] of joints) {
      ctx.shape("circle", jx - 4, jy - 4, 8, 8, { stroke: ctx.preset.edge, fill: ctx.preset.background, fillStyle: "solid", strokeWidth: 1.6, roughness: 0.4 }, { z: 2 });
    }
  }
});
registerViz({
  name: "dumbbell-horizontal",
  aliases: ["progress-bars", "tracks"],
  category: "Data",
  summary: "Rows of tracks with value bars and a hanging tag bubble.",
  sweetSpot: { min: 2, max: 8 },
  entryKinds: ["item", "row"],
  options: [{ name: "showValues", type: "boolean", description: "print item values (default true)" }],
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "row");
    const n = Math.max(items.length, 1);
    const trackW = 520;
    const pitch = 118;
    const max = niceMax(Math.max(...items.map((i) => i.value ?? 0), 1));
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const y = i * pitch;
        ctx.label(item.label, 0, y, { size: 19, color: ctx.ink, align: "left", font: "heading", weight: ctx.preset.fonts.headingWeight });
        const barY = y + 22;
        ctx.shape("rectangle", 0, barY, trackW, 34, ctx.role(i, { neutral: true }), { style: { roundness: 17, opacity: 35 } });
        const w = Math.max((item.value ?? 0) / max * trackW, 34);
        ctx.shape("rectangle", 0, barY, w, 34, role, { id: ctx.uid(item.id), style: { roundness: 17 } });
        const tag = item.strings[0] ?? item.opts.tag ?? (ctx.showValue(item) ? fmtNum(item.value ?? 0) : void 0);
        if (tag !== void 0) {
          const tw = ctx.measure(String(tag), 13) + 20;
          const bx = Math.max(w - tw / 2 - 10, 20);
          ctx.poly(
            [
              [bx + tw / 2 - 7, barY + 42],
              [bx + tw / 2, barY + 34],
              [bx + tw / 2 + 7, barY + 42]
            ],
            { stroke: role.color, fill: role.color, fillStyle: "solid", strokeWidth: 1, roughness: ctx.preset.roughness }
          );
          ctx.shape("rectangle", bx - tw / 2, barY + 42, tw, 26, { stroke: role.color, fill: null, fillStyle: "none", strokeWidth: 1.4, roughness: ctx.preset.roughness }, { style: { roundness: 8 } });
          ctx.label(String(tag), bx, barY + 55, { size: 13, color: role.color, weight: 700, role: "value" });
        }
      })
    );
  }
});
registerViz({
  name: "dumbbell-vertical",
  aliases: ["deltas"],
  category: "Data",
  summary: "Alternating capsules with a delta badge, connected to text blocks.",
  sweetSpot: { min: 2, max: 6 },
  entryKinds: ["item", "row"],
  options: [{ name: "showValues", type: "boolean", description: "print item values (default true)" }],
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "row");
    const n = Math.max(items.length, 1);
    const pitch = 128;
    const capW = 300;
    const capH = 104;
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const right = i % 2 === 0;
        const y = i * pitch;
        const capX = right ? 330 : 0;
        const r2 = capH / 2;
        const gy = y + capH / 2;
        const cA = capX + r2;
        const cB = capX + capW - r2;
        ctx.shape("circle", cA - r2, gy - r2, r2 * 2, r2 * 2, role, { id: ctx.uid(item.id) });
        ctx.shape("circle", cB - r2, gy - r2, r2 * 2, r2 * 2, role, { id: ctx.uid(`${item.id}_b`) });
        const waistColor = role.stroke === ctx.preset.background ? role.color : role.stroke;
        const waist = (sign) => {
          const pts = [];
          const xa = cA + r2 * 0.82;
          const xb = cB - r2 * 0.82;
          const ya = gy + sign * r2 * 0.58;
          const mid = gy + sign * r2 * 0.3;
          for (let s = 0; s <= 10; s++) {
            const t = s / 10;
            const u = 1 - t;
            pts.push([u * u * xa + 2 * u * t * ((xa + xb) / 2) + t * t * xb, u * u * ya + 2 * u * t * mid + t * t * ya]);
          }
          return pts;
        };
        ctx.line(waist(-1), { color: waistColor, width: role.strokeWidth || 2 });
        ctx.line(waist(1), { color: waistColor, width: role.strokeWidth || 2 });
        const delta = item.opts.delta ?? item.strings[0] ?? (item.value !== void 0 && ctx.showValue(item) ? `+${fmtNum(item.value)}` : "");
        const inBell = role.fill ? role.textColor : role.color;
        ctx.label(String(delta), right ? cB : cA, gy, { size: 21, color: inBell, weight: 700, font: "heading", z: 2, role: "value" });
        const iconC = right ? cA : cB;
        if (item.icon) {
          ctx.shape("circle", iconC - r2 * 0.62, gy - r2 * 0.62, r2 * 1.24, r2 * 1.24, { stroke: inBell, fill: null, fillStyle: "none", strokeWidth: 1.6, roughness: Math.min(1, ctx.preset.roughness) }, { z: 2 });
          ctx.icon(item.icon, iconC, gy, r2 * 0.7, inBell, 3);
        }
        const textX = right ? 0 : 660;
        const conStart = right ? [capX - 8, gy] : [capX + capW + 8, gy];
        const conEnd = right ? [260, gy] : [640, gy];
        ctx.arrow(conStart[0], conStart[1], conEnd[0], conEnd[1], { color: ctx.preset.edge, width: 1.6 });
        ctx.labelBlock(item.label, item.detail, textX, gy, { color: role.color, align: "left", maxW: 240 });
      })
    );
  }
});
registerViz({
  name: "gantt",
  category: "Process",
  summary: 'Cascading task bars over a time grid; `task "Name" start end`.',
  sweetSpot: { min: 1, max: 10 },
  entryKinds: ["task", "item"],
  options: [
    { name: "scale", type: "string", description: "list of tick labels for the time axis" },
    { name: "deadline", type: "number", description: "time position of the deadline marker" },
    { name: "deadlineLabel", type: "string", description: "caption for the deadline marker" }
  ],
  generate(spec, ctx) {
    const tasks = spec.items.filter((i) => i.kind === "task" || i.kind === "item");
    const scale = Array.isArray(spec.options.scale) ? spec.options.scale.map(String) : void 0;
    const maxT = niceMax(Math.max(...tasks.map((t) => t.values[1] ?? (t.values[0] ?? 0) + 1), scale ? scale.length - 1 : 1));
    const chartW = 620;
    const x0 = 150;
    const rowPitch = 52;
    const chartH = tasks.length * rowPitch + 20;
    const ticks = scale ? scale.length : 6;
    for (let t = 0; t < ticks; t++) {
      const tx = x0 + chartW * t / (ticks - 1);
      ctx.line(
        [
          [tx, 34],
          [tx, 34 + chartH]
        ],
        { color: ctx.mutedInk, width: t === 0 || t === ticks - 1 ? 1.4 : 0.8, dash: !(t === 0 || t === ticks - 1), z: -1 }
      );
      const lbl = scale ? scale[t] : fmtNum(maxT * t / (ticks - 1));
      ctx.label(lbl, tx, 18, { size: 14, color: ctx.mutedInk });
    }
    tasks.forEach(
      (task, i) => ctx.item(task.id, () => {
        const role = ctx.role(i, { n: tasks.length, color: task.color });
        const start = task.values[0] ?? 0;
        const end = task.values[1] ?? start + 1;
        const y = 48 + i * rowPitch;
        ctx.label(task.label, x0 - 16, y + 17, { size: 16, color: role.color, align: "right", maxW: 130, font: "heading", weight: ctx.preset.fonts.headingWeight });
        const bx = x0 + start / maxT * chartW;
        const bw = Math.max((end - start) / maxT * chartW, 10);
        ctx.shape("rectangle", bx, y, bw, 34, role, { id: ctx.uid(task.id), style: { roundness: 8 } });
      })
    );
    const deadline = optNum(spec.options, "deadline");
    if (deadline !== void 0) {
      const dx = x0 + deadline / maxT * chartW;
      ctx.line(
        [
          [dx, 30],
          [dx, 34 + chartH + 6]
        ],
        { color: ctx.ink, width: 2.2 }
      );
      ctx.label(optStr(spec.options, "deadlineLabel") ?? "Deadline", dx, 34 + chartH + 24, { size: 14, color: ctx.ink, weight: 700 });
    }
  }
});
registerViz({
  name: "sankey",
  category: "Data",
  summary: "Sources → targets with value-thick ribbons (`flow a -> b 25`).",
  sweetSpot: { min: 2, max: 5 },
  entryKinds: ["flow", "item", "node", "source", "target"],
  options: [{ name: "showValues", type: "boolean", description: "print item values (default true)" }],
  generate(spec, ctx) {
    const flows = spec.items.filter((i) => i.kind === "flow" || i.kind === "item" && i.to);
    const declared = spec.items.filter((i) => i.kind === "node" || i.kind === "source" || i.kind === "target");
    const srcNames = [];
    const dstNames = [];
    for (const d of declared) (d.kind === "target" ? dstNames : srcNames).push(d.label || d.id);
    for (const f of flows) {
      const from = f.label || f.id;
      if (!srcNames.includes(from)) srcNames.push(from);
      if (f.to && !dstNames.includes(f.to)) dstNames.push(f.to);
    }
    const srcTotals = new Map(srcNames.map((s) => [s, 0]));
    const dstTotals = new Map(dstNames.map((s) => [s, 0]));
    for (const f of flows) {
      const from = f.label || f.id;
      srcTotals.set(from, (srcTotals.get(from) ?? 0) + (f.value ?? 1));
      if (f.to) dstTotals.set(f.to, (dstTotals.get(f.to) ?? 0) + (f.value ?? 1));
    }
    const totalAll = [...srcTotals.values()].reduce((a, b) => a + b, 0) || 1;
    const H = 420;
    const gapY = 26;
    const colX = { src: 120, dst: 560 };
    const barW = 18;
    const scaleH = (v) => v / totalAll * (H - gapY * Math.max(srcNames.length, dstNames.length));
    const srcPos = /* @__PURE__ */ new Map();
    const dstPos = /* @__PURE__ */ new Map();
    let y = 0;
    srcNames.forEach((s, i) => {
      const h = Math.max(scaleH(srcTotals.get(s) ?? 0), 12);
      srcPos.set(s, { y, used: 0, i });
      const role = ctx.role(i, { n: srcNames.length });
      ctx.shape("rectangle", colX.src - barW, y, barW, h, { ...roleFillOnly(ctx, i, srcNames.length), stroke: role.color });
      ctx.labelBlock(s, ctx.showValues ? fmtNum(srcTotals.get(s) ?? 0) : void 0, colX.src - barW - 12, y + h / 2, { color: role.color, align: "right", maxW: 110, size: 16 });
      y += h + gapY;
    });
    y = 0;
    dstNames.forEach((s, i) => {
      const h = Math.max(scaleH(dstTotals.get(s) ?? 0), 12);
      dstPos.set(s, { y, used: 0, i });
      const role = ctx.role(srcNames.length + i, { n: srcNames.length + dstNames.length });
      ctx.shape("rectangle", colX.dst, y, barW, h, { ...roleFillOnly(ctx, srcNames.length + i, srcNames.length + dstNames.length), stroke: role.color });
      ctx.labelBlock(s, ctx.showValues ? fmtNum(dstTotals.get(s) ?? 0) : void 0, colX.dst + barW + 12, y + h / 2, { color: role.color, align: "left", maxW: 130, size: 16 });
      y += h + gapY;
    });
    for (const f of flows) {
      const from = f.label || f.id;
      const to = f.to ?? "";
      const sp = srcPos.get(from);
      const dp = dstPos.get(to);
      if (!sp || !dp) continue;
      const h = Math.max(scaleH(f.value ?? 1), 6);
      const y1 = sp.y + sp.used;
      const y2 = dp.y + dp.used;
      sp.used += h;
      dp.used += h;
      ctx.item(f.id, () => {
        const role = ctx.role(sp.i, { n: srcNames.length });
        const top = [];
        const bot = [];
        const segs = 18;
        for (let s = 0; s <= segs; s++) {
          const t = s / segs;
          const ease = t * t * (3 - 2 * t);
          const px = lerp(colX.src, colX.dst, t);
          top.push([px, lerp(y1, y2, ease)]);
          bot.unshift([px, lerp(y1 + h, y2 + h, ease)]);
        }
        ctx.poly([...top, ...bot], { stroke: "transparent", fill: role.softFill, fillStyle: "solid", strokeWidth: 0, roughness: 0.3 }, { z: -1, id: ctx.uid(`${f.id}_${to}`) });
        if (ctx.showValue(f)) ctx.label(fmtNum(f.value ?? 1), colX.dst - 44, y2 + h / 2, { size: 13, color: role.color, weight: 700, role: "value" });
      });
    }
  }
});
registerViz({
  name: "drop-off",
  aliases: ["dropoff"],
  category: "Data",
  summary: "Nested rounded cards stepping down-right, labels called out around them.",
  entryKinds: ["item", "stage"],
  options: [{ name: "showValues", type: "boolean", description: "print item values (default true)" }],
  sweetSpot: { min: 2, max: 5 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "stage");
    const n = Math.max(items.length, 1);
    const s0 = 200;
    const shrink = 0.74;
    const cx0 = 190;
    const cy0 = 60;
    let brX = cx0 + s0;
    let brY = cy0 + s0;
    const sizes = items.map((_, i) => s0 * Math.pow(shrink, i));
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const s = sizes[i];
        if (i > 0) {
          brX += s * 0.28;
          brY += s * 0.3;
        }
        const x = brX - s;
        const y = brY - s;
        ctx.shape("rectangle", x, y, s, s, role, { id: ctx.uid(item.id), style: { roundness: s * 0.2 } });
        const value = ctx.showValue(item) && item.value !== void 0 ? ` ${fmtNum(item.value)}` : "";
        const pos = i % 5;
        let lx;
        let ly;
        let align = "center";
        if (pos === 0) {
          lx = x - 16;
          ly = y - 14;
          align = "right";
        } else if (pos === 1) {
          lx = x + s + 16;
          ly = y - 14;
          align = "left";
        } else if (pos === 2) {
          lx = cx0 - 30;
          ly = y + s / 2;
          align = "right";
        } else if (pos === 3) {
          lx = brX + 26;
          ly = y + s / 2;
          align = "left";
        } else {
          lx = brX - s / 2;
          ly = brY + 26;
        }
        ctx.labelBlock(item.label + value, item.detail, lx, ly, { color: role.color, align, maxW: 180 });
        if (item.icon) ctx.icon(item.icon, x + s * 0.32, y + s * 0.32, Math.max(24, s * 0.2), role.fill ? role.textColor : role.color);
      })
    );
  }
});
function seamSafe(ctx, role) {
  return role.stroke === ctx.preset.background ? role.color : role.stroke;
}
function stepLabel(ctx, item, cx, cy, maxTextW, role) {
  const textW = Math.min(ctx.measure(item.label, 17, "heading"), maxTextW);
  const opts = { size: 17, color: role.textColor, font: "heading", weight: ctx.preset.fonts.headingWeight };
  if (item.icon) {
    const start = cx - (34 + textW) / 2;
    ctx.icon(item.icon, start + 12, cy, 24, role.textColor);
    ctx.label(ctx.wrap(item.label, maxTextW, 17, "heading", 2), start + 34, cy, { ...opts, align: "left" });
  } else {
    ctx.label(ctx.wrap(item.label, maxTextW, 17, "heading", 2), cx, cy, opts);
  }
}
registerViz({
  name: "flowchart",
  aliases: ["flow", "process"],
  category: "Process",
  summary: "Chain of rounded steps with straight arrows; `direction: right` for horizontal.",
  entryKinds: ["item", "step"],
  options: [
    { name: "direction", type: "right|down", description: "right (or horizontal) lays the chain horizontally" },
    { name: "orientation", type: "horizontal|vertical", description: "alias for direction" }
  ],
  sweetSpot: { min: 2, max: 7 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "step");
    const n = Math.max(items.length, 1);
    const dir = optStr(spec.options, "direction") ?? optStr(spec.options, "orientation");
    const horizontal = dir === "right" || dir === "horizontal";
    const stepH = 56;
    const gap = 64;
    if (horizontal) {
      let x = 0;
      items.forEach((item, i) => {
        const iconW = item.icon ? 34 : 0;
        const textW = Math.min(ctx.measure(item.label, 17, "heading"), 240);
        const w = Math.max(150, textW + iconW + 48);
        ctx.item(item.id, () => {
          const role = ctx.role(i, { n, color: item.color });
          ctx.shape("rectangle", x, 0, w, stepH, role, { id: ctx.uid(item.id), style: { roundness: 14 } });
          stepLabel(ctx, item, x + w / 2, stepH / 2, w - iconW - 48, role);
          if (item.detail) {
            ctx.label(ctx.wrap(item.detail, w + 26, 14), x + w / 2, stepH + 18, { size: 14, color: ctx.mutedInk, vAnchor: "top" });
          }
        });
        if (i < items.length - 1) ctx.arrow(x + w + 6, stepH / 2, x + w + gap - 6, stepH / 2, { color: ctx.preset.edge, width: 2 });
        x += w + gap;
      });
    } else {
      const widths = items.map((it) => Math.min(ctx.measure(it.label, 17, "heading"), 260) + (it.icon ? 34 : 0) + 48);
      const stepW = Math.min(360, Math.max(170, ...widths));
      const cx = stepW / 2;
      items.forEach((item, i) => {
        const y = i * (stepH + gap);
        ctx.item(item.id, () => {
          const role = ctx.role(i, { n, color: item.color });
          ctx.shape("rectangle", 0, y, stepW, stepH, role, { id: ctx.uid(item.id), style: { roundness: 14 } });
          stepLabel(ctx, item, cx, y + stepH / 2, stepW - (item.icon ? 34 : 0) - 48, role);
          if (item.detail) {
            ctx.label(ctx.wrap(item.detail, 220, 14), stepW + 22, y + stepH / 2, { size: 14, color: ctx.mutedInk, align: "left" });
          }
        });
        if (i < items.length - 1) ctx.arrow(cx, y + stepH + 5, cx, y + stepH + gap - 5, { color: ctx.preset.edge, width: 2 });
      });
    }
  }
});
registerViz({
  name: "sequence",
  category: "Process",
  summary: "Boustrophedon grid of titled description panels joined by flow arrows.",
  entryKinds: ["item", "step"],
  options: [{ name: "columns", type: "number", description: "grid columns, clamped 2-4 (default 3)" }],
  sweetSpot: { min: 4, max: 9 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "step");
    const n = Math.max(items.length, 1);
    const cols = Math.max(2, Math.min(4, optNum(spec.options, "columns") ?? 3));
    const cellW = 280;
    const cellH = 234;
    const panelW = 240;
    const panelH = 130;
    const panelTop = 40;
    const pos = items.map((_, i) => {
      const row = Math.floor(i / cols);
      const rc = i % cols;
      const col = row % 2 === 0 ? rc : cols - 1 - rc;
      return { row, col, x: col * cellW, y: row * cellH };
    });
    items.forEach((item, i) => {
      const { x, y } = pos[i];
      ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const stroke = seamSafe(ctx, role);
        ctx.label(ctx.wrap(item.label, panelW - 4, 20, "heading", 1), x + panelW / 2, y + panelTop - 16, {
          size: 20,
          color: role.color,
          font: "heading",
          weight: ctx.preset.fonts.headingWeight
        });
        ctx.line(
          [
            [x + 14, y + panelTop - 1],
            [x + panelW - 14, y + panelTop - 1]
          ],
          { color: role.color, width: 2.4 }
        );
        ctx.shape(
          "rectangle",
          x,
          y + panelTop,
          panelW,
          panelH,
          { stroke, fill: role.softFill, fillStyle: "solid", strokeWidth: role.strokeWidth, roughness: role.roughness },
          { id: ctx.uid(item.id), style: { roundness: 10 } }
        );
        const midY = y + panelTop + panelH / 2;
        if (item.icon && item.detail) {
          ctx.icon(item.icon, x + panelW / 2, y + panelTop + 28, 30, role.color);
          ctx.label(ctx.wrap(item.detail, panelW - 30, 15, void 0, 4), x + panelW / 2, y + panelTop + 52, { size: 15, color: ctx.ink, vAnchor: "top" });
        } else if (item.icon) {
          ctx.icon(item.icon, x + panelW / 2, midY, 40, role.color);
        } else if (item.detail) {
          ctx.label(ctx.wrap(item.detail, panelW - 30, 15, void 0, 5), x + panelW / 2, midY, { size: 15, color: ctx.ink });
        }
      });
      if (i < items.length - 1) {
        const a = pos[i];
        const b = pos[i + 1];
        if (a.row === b.row) {
          const ay = a.y + panelTop + panelH / 2;
          const right = b.col > a.col;
          const x1 = a.x + (right ? panelW + 8 : -8);
          const x2 = b.x + (right ? -8 : panelW + 8);
          ctx.arrow(x1, ay, x2, ay, { color: ctx.preset.edge, width: 2 });
        } else {
          const axc = a.x + panelW / 2;
          ctx.arrow(axc, a.y + panelTop + panelH + 8, axc, b.y - 6, { color: ctx.preset.edge, width: 2 });
        }
      }
    });
  }
});
const PIN_DOWN = "M50 140 C40 110 8 94 8 52 A42 42 0 1 1 92 52 C92 94 60 110 50 140 Z";
const PIN_UP = "M50 0 C40 30 8 46 8 88 A42 42 0 1 0 92 88 C92 46 60 30 50 0 Z";
registerViz({
  name: "timeline",
  category: "Timelines",
  summary: "A baseline with alternating teardrop pins: icon inside, date + description beside.",
  entryKinds: ["item", "event", "milestone"],
  sweetSpot: { min: 3, max: 7 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "event", "milestone");
    const n = Math.max(items.length, 1);
    const pitch = 190;
    const baseY = 210;
    const pinW = 86;
    const pinH = 116;
    ctx.line(
      [
        [0, baseY],
        [(n - 1) * pitch + 150, baseY]
      ],
      { color: ctx.preset.edge, width: 2, z: -1 }
    );
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const cx = i * pitch + 76;
        const up = i % 2 === 0;
        const pinY = up ? baseY - pinH : baseY;
        ctx.path(up ? PIN_DOWN : PIN_UP, 100, 140, cx - pinW / 2, pinY, pinW, pinH, role, { id: ctx.uid(item.id) });
        ctx.shape("circle", cx - 8, baseY - 8, 16, 16, { stroke: role.color, fill: ctx.preset.background, fillStyle: "solid", strokeWidth: 2, roughness: Math.min(0.8, ctx.preset.roughness) }, { z: 2 });
        ctx.shape("circle", cx - 3.5, baseY - 3.5, 7, 7, { stroke: role.color, fill: null, fillStyle: "none", strokeWidth: 1.6, roughness: 0.4 }, { z: 2 });
        const bulbY = up ? pinY + pinH * 0.37 : pinY + pinH * 0.63;
        if (item.icon) ctx.icon(item.icon, cx, bulbY, 38, role.fill ? role.textColor : role.color);
        ctx.labelBlock(item.label, item.detail, cx, up ? pinY - 14 : pinY + pinH + 14, {
          color: role.color,
          align: "center",
          maxW: 165,
          vAnchor: up ? "bottom" : "top"
        });
      })
    );
  }
});
registerViz({
  name: "journey",
  aliases: ["roadmap"],
  category: "Process",
  summary: "A winding two-walled ribbon road, one color segment per stage (reference design).",
  entryKinds: ["item", "stage", "stop"],
  sweetSpot: { min: 3, max: 6 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "stage", "stop");
    const n = Math.max(items.length, 1);
    const runH = 200;
    const pitch = 150;
    const yTop = 60;
    const yBot = yTop + runH;
    const half = 17;
    const center = [];
    for (let i = 0; i < n; i++) {
      const x = 60 + i * pitch;
      const down = i % 2 === 0;
      for (let s = 0; s <= 20; s++) {
        const y = down ? yTop + runH * s / 20 : yBot - runH * s / 20;
        center.push([x, y]);
      }
      if (i < n - 1) {
        const cxT = x + pitch / 2;
        const r2 = pitch / 2;
        for (let s = 1; s < 12; s++) {
          const a = down ? 180 - 180 * s / 12 : 180 + 180 * s / 12;
          center.push([cxT + Math.cos(rad(a)) * r2, (down ? yBot : yTop) + Math.sin(rad(a)) * r2]);
        }
      }
    }
    const left = [];
    const right = [];
    for (let i = 0; i < center.length; i++) {
      const [x, y] = center[i];
      const [px, py] = center[Math.max(0, i - 1)];
      const [nx, ny] = center[Math.min(center.length - 1, i + 1)];
      let dx = nx - px;
      let dy = ny - py;
      const len = Math.hypot(dx, dy) || 1;
      dx /= len;
      dy /= len;
      left.push([x - dy * half, y + dx * half]);
      right.push([x + dy * half, y - dx * half]);
    }
    const chunk = Math.floor(center.length / n);
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const from = i * chunk;
        const to = i === n - 1 ? center.length : (i + 1) * chunk + 1;
        const wallColor = role.stroke === ctx.preset.background ? role.color : role.stroke;
        ctx.line(left.slice(from, to), { id: ctx.uid(item.id), color: wallColor, width: 2.6 });
        ctx.line(right.slice(from, to), { color: wallColor, width: 2.6 });
        const runX = 60 + i * pitch;
        const above = i % 2 === 0;
        const labelY = above ? yTop - (n > 1 ? pitch / 2 : half) - 18 : yBot + (n > 1 ? pitch / 2 : half) + 18;
        ctx.labelBlock(item.label, item.detail, runX, labelY, {
          color: role.color,
          align: "center",
          maxW: 150,
          vAnchor: above ? "bottom" : "top"
        });
        if (item.icon) ctx.icon(item.icon, runX, yTop + runH / 2 + (above ? 30 : -30), 30, role.color);
      })
    );
    const lastDown = (n - 1) % 2 === 0;
    const endX = 60 + (n - 1) * pitch;
    const endY = lastDown ? yBot + 4 : yTop - 4;
    const lastRole = ctx.role(n - 1, { n, color: items[n - 1]?.color });
    const tipColor = lastRole.stroke === ctx.preset.background ? lastRole.color : lastRole.stroke;
    ctx.poly(
      lastDown ? [
        [endX - half * 1.7, endY],
        [endX, endY + 30],
        [endX + half * 1.7, endY]
      ] : [
        [endX - half * 1.7, endY],
        [endX, endY - 30],
        [endX + half * 1.7, endY]
      ],
      { stroke: tipColor, fill: lastRole.fill, fillStyle: lastRole.fill ? "solid" : "none", strokeWidth: 2.6, roughness: ctx.preset.roughness }
    );
  }
});
registerViz({
  name: "stairs",
  aliases: ["staircase"],
  category: "Process",
  summary: "Ascending abutting step blocks with icon above and label inside each.",
  entryKinds: ["item", "step"],
  sweetSpot: { min: 3, max: 6 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "step");
    const n = Math.max(items.length, 1);
    const stepW = 156;
    const rise = 52;
    const firstH = 64;
    const top = 64;
    const y0 = top + firstH + (n - 1) * rise;
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const x = i * stepW;
        const h = firstH + i * rise;
        ctx.shape("rectangle", x, y0 - h, stepW, h, role, { id: ctx.uid(item.id) });
        if (item.icon) ctx.icon(item.icon, x + stepW / 2, y0 - h - 34, 46, role.color);
        const inside = role.fill ? role.textColor : role.color;
        ctx.label(item.label, x + stepW / 2, y0 - h + 24, { size: 18, color: inside, font: "heading", weight: ctx.preset.fonts.headingWeight, maxW: stepW - 16 });
        if (item.detail) {
          ctx.label(ctx.wrap(item.detail, stepW - 20, 13, void 0, 3), x + stepW / 2, y0 - h + 52, { size: 13, color: role.fill ? role.textColor : ctx.ink });
        }
      })
    );
  }
});
const onPanel = (role) => role.fill ? role.textColor : role.color;
const inPanel = (ctx, role) => role.fill ? role.textColor : ctx.ink;
function optList(opts, key) {
  const v = opts[key];
  return Array.isArray(v) ? v.map(String) : void 0;
}
function bulletList(ctx, entries, x, y, opts) {
  const dotD = opts.dotD ?? 12;
  const size = opts.size ?? 15;
  const pitch = opts.pitch ?? 42;
  entries.forEach((entry, i) => {
    const draw = () => {
      const cy = y + i * pitch + pitch / 2;
      ctx.shape("circle", x, cy - dotD / 2, dotD, dotD, {
        stroke: opts.dotColor,
        fill: opts.dotColor,
        fillStyle: "solid",
        strokeWidth: 1,
        roughness: ctx.preset.roughness
      });
      ctx.label(ctx.wrap(entry.label, opts.maxW, size, void 0, 2), x + dotD + 12, cy, { size, color: opts.textColor, align: "left" });
    };
    if (opts.scopeItems) ctx.item(entry.id, draw);
    else draw();
  });
  return entries.length * pitch;
}
function inItem(ctx, item, fn) {
  if (item) ctx.item(item.id, fn);
  else fn();
}
const lineCount = (wrapped) => wrapped.split("\n").length;
registerViz({
  name: "swot",
  category: "Business Frameworks",
  summary: "Stacked S/W/O/T panels with a big display letter, title and bullets.",
  entryKinds: ["item", "section"],
  sweetSpot: { min: 4, max: 4 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "section");
    const n = Math.max(items.length, 1);
    const W = 560;
    const pad = 22;
    const contentX = 190;
    const contentW = W - contentX - pad;
    const pitch = 46;
    let panelH = 160;
    for (const item of items) {
      let need = 76;
      if (item.detail) need += lineCount(ctx.wrap(item.detail, contentW, 15)) * 19 + 10;
      need += item.children.length * pitch + 18;
      panelH = Math.max(panelH, need);
    }
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const y = i * (panelH + 18);
        ctx.shape("rectangle", 0, y, W, panelH, role, { id: ctx.uid(item.id), style: { roundness: role.roundness ?? 8 } });
        const accent = onPanel(role);
        const body = inPanel(ctx, role);
        const letter = (item.label.trim()[0] ?? "?").toUpperCase();
        ctx.label(letter, 95, y + panelH / 2, { size: 110, color: accent, weight: 700, font: "heading" });
        if (item.icon) ctx.icon(item.icon, 95, y + panelH - 34, 30, accent);
        let cy = y + pad + 12;
        ctx.label(ctx.wrap(item.label, contentW, 20, "heading", 2), contentX, cy, {
          size: 20,
          color: accent,
          align: "left",
          vAnchor: "top",
          font: "heading",
          weight: ctx.preset.fonts.headingWeight
        });
        cy += 36;
        if (item.detail) {
          const text = ctx.wrap(item.detail, contentW, 15);
          ctx.label(text, contentX, cy, { size: 15, color: body, align: "left", vAnchor: "top" });
          cy += lineCount(text) * 19 + 10;
        }
        bulletList(ctx, item.children, contentX, cy, { dotColor: accent, textColor: body, maxW: contentW - 24, pitch });
      })
    );
  }
});
registerViz({
  name: "pestel",
  category: "Business Frameworks",
  summary: "Vertical category cards — big letter, title, summary, bullets.",
  entryKinds: ["item", "card", "category", "factor"],
  sweetSpot: { min: 4, max: 6 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "card", "category", "factor");
    const n = Math.max(items.length, 1);
    const W = 182;
    const gap = 14;
    const pad = 15;
    const contentW = W - pad * 2;
    let cardH = 340;
    for (const item of items) {
      let need = 96 + lineCount(ctx.wrap(item.label, contentW, 20, "heading", 3)) * 25 + 14;
      if (item.detail) need += lineCount(ctx.wrap(item.detail, contentW, 15)) * 19 + 14;
      need += item.children.length * 54 + pad;
      cardH = Math.max(cardH, need);
    }
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const x = i * (W + gap);
        ctx.shape("rectangle", x, 0, W, cardH, role, { id: ctx.uid(item.id), style: { roundness: role.roundness ?? 8 } });
        const accent = onPanel(role);
        const body = inPanel(ctx, role);
        const cx = x + W / 2;
        const letter = (item.label.trim()[0] ?? "?").toUpperCase();
        ctx.label(letter, cx, 52, { size: 64, color: accent, weight: 700, font: "heading" });
        if (item.icon) ctx.icon(item.icon, cx, 52, 30, accent);
        let cy = 96;
        const title = ctx.wrap(item.label, contentW, 20, "heading", 3);
        ctx.label(title, cx, cy, { size: 20, color: accent, vAnchor: "top", font: "heading", weight: ctx.preset.fonts.headingWeight });
        cy += lineCount(title) * 25 + 14;
        if (item.detail) {
          const text = ctx.wrap(item.detail, contentW, 15);
          ctx.label(text, x + pad, cy, { size: 15, color: body, align: "left", vAnchor: "top" });
          cy += lineCount(text) * 19 + 14;
        }
        bulletList(ctx, item.children, x + pad, cy, { dotD: 7, dotColor: accent, textColor: body, maxW: contentW - 22, pitch: 54 });
      })
    );
  }
});
registerViz({
  name: "quadrant",
  aliases: ["2x2", "matrix"],
  category: "Comparison",
  summary: "2×2 matrix on double-headed axes; items in TL/TR/BL/BR order.",
  entryKinds: ["item", "quadrant"],
  options: [
    { name: "xLabels", type: "string[]", description: "x-axis end captions as [negative, positive]" },
    { name: "yLabels", type: "string[]", description: "y-axis end captions as [negative, positive]" }
  ],
  sweetSpot: { min: 4, max: 4 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "quadrant").slice(0, 4);
    const W = 720;
    const H = 600;
    const cx = W / 2;
    const cy = H / 2;
    const edge = ctx.preset.edge;
    ctx.line(
      [
        [0, cy],
        [W, cy]
      ],
      { color: edge, width: 1.8 }
    );
    ctx.arrowhead(cx, cy, W, cy, edge, 1.8);
    ctx.arrowhead(cx, cy, 0, cy, edge, 1.8);
    ctx.line(
      [
        [cx, 0],
        [cx, H]
      ],
      { color: edge, width: 1.8 }
    );
    ctx.arrowhead(cx, cy, cx, 0, edge, 1.8);
    ctx.arrowhead(cx, cy, cx, H, edge, 1.8);
    const xl = optList(spec.options, "xLabels");
    if (xl) {
      ctx.label(xl[0] ?? "", 8, cy + 16, { size: 12, color: ctx.mutedInk, align: "left" });
      ctx.label(xl[1] ?? "", W - 8, cy + 16, { size: 12, color: ctx.mutedInk, align: "right" });
    }
    const yl = optList(spec.options, "yLabels");
    if (yl) {
      ctx.label(yl[1] ?? "", cx + 12, 10, { size: 12, color: ctx.mutedInk, align: "left" });
      ctx.label(yl[0] ?? "", cx + 12, H - 10, { size: 12, color: ctx.mutedInk, align: "left" });
    }
    const centers = [
      [W * 0.25, H * 0.25],
      [W * 0.75, H * 0.25],
      [W * 0.25, H * 0.75],
      [W * 0.75, H * 0.75]
    ];
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n: 4, color: item.color });
        const [qx, qy] = centers[i];
        const maxW = W / 2 - 80;
        const bullets = item.children.slice(0, 3);
        const detailText = !bullets.length && item.detail ? ctx.wrap(item.detail, maxW, 15) : void 0;
        const blockH = (item.icon ? 58 : 0) + 30 + (bullets.length ? bullets.length * 38 : detailText ? lineCount(detailText) * 19 + 8 : 0);
        let y = qy - blockH / 2;
        if (item.icon) {
          ctx.icon(item.icon, qx, y + 23, 44, role.color);
          y += 58;
        }
        ctx.label(ctx.wrap(item.label, maxW, 20, "heading", 2), qx, y + 12, {
          size: 20,
          color: role.color,
          font: "heading",
          weight: ctx.preset.fonts.headingWeight,
          id: ctx.uid(item.id)
        });
        y += 34;
        if (bullets.length) {
          bulletList(ctx, bullets, qx - maxW / 2, y, { dotD: 8, dotColor: role.color, textColor: ctx.ink, maxW: maxW - 24, pitch: 38 });
        } else if (detailText) {
          ctx.label(detailText, qx, y, { size: 15, color: ctx.mutedInk, vAnchor: "top" });
        }
      })
    );
  }
});
registerViz({
  name: "table",
  category: "Comparison",
  summary: "Grid of individually drawn cells; each column stroked its own color.",
  sweetSpot: { min: 1, max: 8 },
  entryKinds: ["row", "item", "header"],
  generate(spec, ctx) {
    const rows = spec.items.filter((i) => i.kind === "row" || i.kind === "item" || i.kind === "header");
    let header;
    const body = [];
    for (const r2 of rows) {
      if (!header && (r2.kind === "header" || r2.opts.header === true)) header = r2;
      else body.push(r2);
    }
    const cellsOf = (r2) => [r2.label, ...r2.strings];
    const all = header ? [header, ...body] : body;
    const cols = Math.max(...all.map((r2) => cellsOf(r2).length), 1);
    const colW = [];
    for (let j = 0; j < cols; j++) {
      let w = 90;
      for (const r2 of all) {
        const text = cellsOf(r2)[j] ?? "";
        w = Math.max(w, ctx.measure(text, r2 === header ? 20 : 15) + 32);
      }
      colW.push(Math.min(w, 230));
    }
    const colX = [0];
    for (let j = 0; j < cols; j++) colX.push(colX[j] + colW[j] + 5);
    const headerH = 64;
    const bodyH = 52;
    const colColor = (j) => j === 0 ? ctx.ink : ctx.role(j - 1, { n: Math.max(cols - 1, 1) }).color;
    const cellStyle = (j) => ({
      stroke: colColor(j),
      fill: null,
      fillStyle: "none",
      strokeWidth: Math.min(2, ctx.preset.strokeWidth),
      roughness: ctx.preset.roughness
    });
    let y = 0;
    if (header) {
      cellsOf(header).forEach((text, j) => {
        ctx.shape("rectangle", colX[j], y, colW[j], headerH, cellStyle(j), { id: j === 0 ? ctx.uid(header.id) : void 0, style: { roundness: 6 } });
        ctx.label(ctx.wrap(text, colW[j] - 14, 20, "heading", 2), colX[j] + colW[j] / 2, y + headerH / 2, {
          size: 20,
          color: colColor(j),
          font: "heading",
          weight: ctx.preset.fonts.headingWeight
        });
      });
      y += headerH + 5;
    }
    body.forEach((row) => {
      ctx.item(row.id, () => {
        for (let j = 0; j < cols; j++) {
          const text = cellsOf(row)[j] ?? "";
          ctx.shape("rectangle", colX[j], y, colW[j], bodyH, cellStyle(j), { id: j === 0 ? ctx.uid(row.id) : void 0, style: { roundness: 6 } });
          if (text) ctx.label(ctx.wrap(text, colW[j] - 14, 15, void 0, 2), colX[j] + colW[j] / 2, y + bodyH / 2, { size: 15, color: ctx.ink });
        }
      });
      y += bodyH + 5;
    });
  }
});
registerViz({
  name: "pros-and-cons",
  aliases: ["pros-cons"],
  category: "Comparison",
  summary: "Two panels — pros with a check, cons with a cross — as bullet lists.",
  sweetSpot: { min: 1, max: 6 },
  entryKinds: ["pro", "con", "item"],
  options: [
    { name: "proColor", type: "string", description: "override the pros panel color" },
    { name: "conColor", type: "string", description: "override the cons panel color" }
  ],
  generate(spec, ctx) {
    let pros = spec.items.filter((i) => i.kind === "pro");
    let cons = spec.items.filter((i) => i.kind === "con");
    let proTitle = "Pros";
    let conTitle = "Cons";
    for (const g of spec.items) {
      if (!g.children.length) continue;
      const key = `${g.kind} ${g.id} ${g.label}`.toLowerCase();
      if (!pros.length && /\bpros?\b/.test(key)) {
        pros = g.children;
        proTitle = g.label || proTitle;
      } else if (!cons.length && /\bcons?\b/.test(key)) {
        cons = g.children;
        conTitle = g.label || conTitle;
      }
    }
    const proRole = ctx.role(2, { color: optStr(spec.options, "proColor") });
    const conRole = ctx.role(1, { color: optStr(spec.options, "conColor") });
    const panelW = 300;
    const gap = 26;
    const pad = 20;
    const rows = Math.max(pros.length, cons.length, 1);
    const panelH = 96 + rows * 42 + 10;
    const panel = (x, name, role, entries, iconName, idHint) => {
      ctx.shape("rectangle", x, 0, panelW, panelH, role, { id: ctx.uid(idHint), style: { roundness: role.roundness ?? 8 } });
      const accent = onPanel(role);
      const body = inPanel(ctx, role);
      ctx.label(name, x + pad, 34, { size: 20, color: accent, align: "left", font: "heading", weight: ctx.preset.fonts.headingWeight });
      ctx.icon(iconName, x + panelW - pad - 20, 32, 38, accent);
      ctx.line(
        [
          [x + pad, 58],
          [x + panelW - pad, 58]
        ],
        { color: accent, width: 1.6 }
      );
      bulletList(ctx, entries, x + pad, 82, { dotColor: accent, textColor: body, maxW: panelW - pad * 2 - 24, scopeItems: true });
    };
    panel(0, proTitle, proRole, pros, "check", "pros");
    panel(panelW + gap, conTitle, conRole, cons, "x", "cons");
  }
});
registerViz({
  name: "versus",
  aliases: ["vs"],
  category: "Comparison",
  summary: "Two contenders compared criterion by criterion around a center gutter.",
  sweetSpot: { min: 1, max: 6 },
  entryKinds: ["left", "right", "item", "contender", "criterion", "row"],
  generate(spec, ctx) {
    let left = spec.items.find((i) => i.kind === "left");
    let right = spec.items.find((i) => i.kind === "right");
    for (const g of itemsOf(spec, "item", "contender")) {
      if (!left && g !== right) left = g;
      else if (!right && g !== left) right = g;
    }
    const criteria = spec.items.filter((i) => i.kind === "criterion" || i.kind === "row");
    const lRole = ctx.role(0, { color: left?.color });
    const rRole = ctx.role(1, { color: right?.color });
    const W = 920;
    const headerH = 72;
    const sideW = 380;
    const gutterCx = W / 2;
    const pitch = 150;
    const startY = 104;
    const rowsH = Math.max(criteria.length, 1) * pitch;
    inItem(ctx, left, () => {
      ctx.shape("rectangle", 0, 0, sideW, headerH, lRole, { id: ctx.uid(left?.id ?? "left"), style: { roundness: lRole.roundness ?? 8 } });
      ctx.label(left?.label ?? "A", sideW / 2, headerH / 2, { size: 26, color: onPanel(lRole), font: "heading", weight: 700, maxW: sideW - 30 });
    });
    inItem(ctx, right, () => {
      ctx.shape("rectangle", W - sideW, 0, sideW, headerH, rRole, { id: ctx.uid(right?.id ?? "right"), style: { roundness: rRole.roundness ?? 8 } });
      ctx.label(right?.label ?? "B", W - sideW / 2, headerH / 2, { size: 26, color: onPanel(rRole), font: "heading", weight: 700, maxW: sideW - 30 });
    });
    inItem(ctx, left, () => {
      ctx.shape("rectangle", gutterCx - 130, startY, 54, rowsH, lRole, { style: { roundness: lRole.roundness ?? 8 } });
    });
    inItem(ctx, right, () => {
      ctx.shape("rectangle", gutterCx + 76, startY, 54, rowsH, rRole, { style: { roundness: rRole.roundness ?? 8 } });
    });
    criteria.forEach(
      (c, k) => ctx.item(c.id, () => {
        const cy = startY + k * pitch + pitch / 2;
        let nameY = cy;
        if (c.icon && ctx.icon(c.icon, gutterCx, cy - 26, 42, ctx.ink)) nameY = cy + 12;
        ctx.label(ctx.wrap(c.label, 130, 18, "heading", 2), gutterCx, nameY, { size: 18, color: ctx.ink, font: "heading", weight: ctx.preset.fonts.headingWeight });
        const lChild = c.children[0];
        const rChild = c.children[1];
        const lClaim = optStr(c.opts, "left") ?? lChild?.label;
        const rClaim = optStr(c.opts, "right") ?? rChild?.label;
        if (lClaim) ctx.labelBlock(lClaim, lChild?.detail, gutterCx - 160, cy, { color: lRole.color, align: "right", maxW: 290, size: 18 });
        if (rClaim) ctx.labelBlock(rClaim, rChild?.detail, gutterCx + 160, cy, { color: rRole.color, align: "left", maxW: 290, size: 18 });
      })
    );
  }
});
registerViz({
  name: "problem-solution",
  category: "Problems and Solutions",
  summary: "Problem → central solution circle → outcome, with support captions.",
  sweetSpot: { min: 3, max: 6 },
  entryKinds: ["item", "problem", "solution", "outcome", "support"],
  generate(spec, ctx) {
    const generic = itemsOf(spec, "item");
    const problem = spec.items.find((i) => i.kind === "problem") ?? generic[0];
    const solution = spec.items.find((i) => i.kind === "solution") ?? generic[1];
    const outcome = spec.items.find((i) => i.kind === "outcome") ?? generic[2];
    const supports = spec.items.filter((i) => i.kind === "support");
    const pRole = ctx.role(1, { color: problem?.color });
    const oRole = ctx.role(2, { color: outcome?.color });
    const cx = 400;
    const ccy = 140;
    const D = 180;
    inItem(ctx, solution, () => {
      ctx.shape(
        "circle",
        cx - D / 2,
        ccy - D / 2,
        D,
        D,
        { stroke: ctx.ink, fill: null, fillStyle: "none", strokeWidth: ctx.preset.strokeWidth, roughness: ctx.preset.roughness },
        { id: ctx.uid(solution?.id ?? "solution") }
      );
      if (solution) {
        const text = ctx.wrap(solution.label, D - 44, 18, "heading", 3);
        const detail2 = solution.detail ? ctx.wrap(solution.detail, D - 44, 13, void 0, 3) : void 0;
        const th = lineCount(text) * 23;
        const dh = detail2 ? lineCount(detail2) * 16 + 8 : 0;
        ctx.label(text, cx, ccy - dh / 2, { size: 18, color: ctx.ink, font: "heading", weight: ctx.preset.fonts.headingWeight });
        if (detail2) ctx.label(detail2, cx, ccy + th / 2 + 8, { size: 13, color: ctx.mutedInk });
      }
    });
    const tile = (item, role, tx, fallbackIcon, hint) => {
      if (!item) return;
      ctx.item(item.id, () => {
        ctx.shape("rectangle", tx, ccy - 98, 84, 84, role, { id: ctx.uid(item.id ?? hint), style: { roundness: role.roundness ?? 10 } });
        ctx.icon(item.icon ?? fallbackIcon, tx + 42, ccy - 56, 44, onPanel(role));
        ctx.labelBlock(item.label, item.detail, tx + 42, ccy + 2, { color: role.color, align: "center", maxW: 220, vAnchor: "top" });
      });
    };
    tile(problem, pRole, 60, "trend-down", "problem");
    tile(outcome, oRole, 656, "trend-up", "outcome");
    ctx.arrow(170, ccy - 56, cx - D / 2 - 12, ccy - 30, { color: ctx.preset.edge, width: 1.6 });
    ctx.arrow(cx + D / 2 + 12, ccy - 30, 630, ccy - 56, { color: ctx.preset.edge, width: 1.6 });
    if (supports.length) {
      const topY = ccy + D / 2 + 6;
      const busY = topY + 44;
      const spread = Math.min(220, 560 / supports.length);
      const first = cx - (supports.length - 1) * spread / 2;
      ctx.line(
        [
          [cx, topY],
          [cx, busY]
        ],
        { color: ctx.preset.edge, width: 1.4 }
      );
      if (supports.length > 1) {
        ctx.line(
          [
            [first, busY],
            [first + (supports.length - 1) * spread, busY]
          ],
          { color: ctx.preset.edge, width: 1.4 }
        );
      }
      supports.forEach(
        (s, i) => ctx.item(s.id, () => {
          const sx = first + i * spread;
          ctx.line(
            [
              [sx, busY],
              [sx, busY + 16]
            ],
            { color: ctx.preset.edge, width: 1.4 }
          );
          ctx.label(ctx.wrap(s.label, spread - 24, 15), sx, busY + 30, { size: 15, color: ctx.mutedInk, vAnchor: "top" });
        })
      );
    }
  }
});
registerViz({
  name: "transformation",
  aliases: ["before-after"],
  category: "Problems and Solutions",
  summary: "A suspension bridge carrying you from before to after (reference design).",
  entryKinds: ["item", "before", "after"],
  sweetSpot: { min: 2, max: 2 },
  generate(spec, ctx) {
    const generic = itemsOf(spec, "item");
    const before = spec.items.find((i) => i.kind === "before") ?? generic[0];
    const after = spec.items.find((i) => i.kind === "after") ?? generic[1];
    const bRole = ctx.role(1, { color: before?.color });
    const aRole = ctx.role(2, { color: after?.color });
    const x0 = 150;
    const bandW = 640;
    const edge = ctx.preset.edge;
    const cx = x0 + bandW / 2;
    const deckY = 190;
    const topY = 30;
    const t1 = x0 + bandW * 0.28;
    const t2 = x0 + bandW * 0.72;
    const cableY = (x) => {
      if (x <= t1) {
        const u2 = (x - x0) / (t1 - x0);
        return deckY - (deckY - topY) * u2 * u2;
      }
      if (x >= t2) {
        const u2 = (x0 + bandW - x) / (x0 + bandW - t2);
        return deckY - (deckY - topY) * u2 * u2;
      }
      const u = (x - t1) / (t2 - t1);
      const sag = deckY - 55;
      return topY + (sag - topY) * (1 - (2 * u - 1) * (2 * u - 1));
    };
    ctx.line(
      [
        [x0, deckY],
        [x0 + bandW, deckY]
      ],
      { color: edge, width: 2.4 }
    );
    for (const tx of [t1, t2]) {
      ctx.line(
        [
          [tx, topY - 6],
          [tx, deckY + 62]
        ],
        { color: edge, width: 3 }
      );
      ctx.line(
        [
          [tx - 12, deckY + 62],
          [tx + 12, deckY + 62]
        ],
        { color: edge, width: 2 }
      );
    }
    const cablePts = [];
    const SEG = 64;
    for (let s = 0; s <= SEG; s++) {
      const x = x0 + bandW * s / SEG;
      cablePts.push([x, cableY(x)]);
    }
    ctx.line(cablePts, { color: edge, width: 2 });
    const N = 30;
    for (let i = 1; i < N; i++) {
      const hx = x0 + bandW * i / N;
      const hy = cableY(hx);
      if (deckY - hy < 8) continue;
      ctx.line(
        [
          [hx, hy],
          [hx, deckY]
        ],
        { color: edge, width: 1.3 }
      );
    }
    if (before) ctx.item(before.id, () => ctx.labelBlock(before.label, void 0, x0 - 26, deckY - 10, { color: bRole.color, align: "right", maxW: 150 }));
    if (after) ctx.item(after.id, () => ctx.labelBlock(after.label, void 0, x0 + bandW + 26, deckY - 10, { color: aRole.color, align: "left", maxW: 150 }));
    const top = 30;
    const boxW = 240;
    const boxH = 86;
    const boxY = top + 226;
    const box = (item, role, bx, hint) => {
      if (!item) return;
      ctx.item(item.id, () => {
        ctx.shape("rectangle", bx, boxY, boxW, boxH, role, { id: ctx.uid(item.id ?? hint), style: { roundness: role.roundness ?? 8 } });
        const accent = onPanel(role);
        if (item.detail) {
          ctx.label(item.label, bx + boxW / 2, boxY + 24, { size: 17, color: accent, weight: 700, font: "heading", maxW: boxW - 28, maxLines: 1 });
          ctx.label(ctx.wrap(item.detail, boxW - 28, 13, void 0, 2), bx + boxW / 2, boxY + 54, { size: 13, color: inPanel(ctx, role) });
        } else {
          ctx.label(item.label, bx + boxW / 2, boxY + boxH / 2, { size: 17, color: accent, weight: 700, font: "heading", maxW: boxW - 28, maxLines: 2 });
        }
      });
    };
    box(before, bRole, t1 - boxW / 2, "before");
    box(after, aRole, t2 - boxW / 2, "after");
    ctx.arrow(cx - 22, boxY + boxH / 2, cx + 22, boxY + boxH / 2, { color: edge, width: 2 });
  }
});
function cubicPts(p0, p1, p2, p3, segs = 16) {
  const pts = [];
  for (let s = 0; s <= segs; s++) {
    const t = s / segs;
    const u = 1 - t;
    pts.push([
      u * u * u * p0[0] + 3 * u * u * t * p1[0] + 3 * u * t * t * p2[0] + t * t * t * p3[0],
      u * u * u * p0[1] + 3 * u * u * t * p1[1] + 3 * u * t * t * p2[1] + t * t * t * p3[1]
    ]);
  }
  return pts;
}
function sCurveH(x1, y1, x2, y2, segs = 16) {
  const mx = (x1 + x2) / 2;
  return cubicPts([x1, y1], [mx, y1], [mx, y2], [x2, y2], segs);
}
function qCorner(p0, c, p1, segs = 6) {
  const pts = [];
  for (let s = 0; s <= segs; s++) {
    const t = s / segs;
    const u = 1 - t;
    pts.push([u * u * p0[0] + 2 * u * t * c[0] + t * t * p1[0], u * u * p0[1] + 2 * u * t * c[1] + t * t * p1[1]]);
  }
  return pts;
}
function outline$1(ctx, color, strokeWidth) {
  return { stroke: color, fill: null, fillStyle: "none", strokeWidth: strokeWidth ?? ctx.preset.strokeWidth, roughness: ctx.preset.roughness };
}
function dot$1(ctx, cx, cy, d) {
  ctx.shape("circle", cx - d / 2, cy - d / 2, d, d, { stroke: ctx.ink, fill: ctx.ink, fillStyle: "solid", strokeWidth: 1, roughness: 0.5 });
}
function scoped$1(ctx, itemId, fn) {
  if (itemId) ctx.item(itemId, fn);
  else fn();
}
function taperRoot(base, angDeg, len, halfW, bow) {
  const a = rad(angDeg);
  const dx = Math.cos(a);
  const dy = Math.sin(a);
  const px = -dy;
  const py = dx;
  const tip = [base[0] + dx * len, base[1] + dy * len];
  const ctrl = [base[0] + dx * len * 0.55 + px * bow * len * 0.17, base[1] + dy * len * 0.55 + py * bow * len * 0.17];
  const segs = 14;
  const spine = [];
  for (let i = 0; i <= segs; i++) {
    const t = i / segs;
    const u = 1 - t;
    spine.push([u * u * base[0] + 2 * u * t * ctrl[0] + t * t * tip[0], u * u * base[1] + 2 * u * t * ctrl[1] + t * t * tip[1]]);
  }
  const left = [];
  const right = [];
  for (let i = 0; i <= segs; i++) {
    const t = i / segs;
    const p = spine[i];
    const prev = spine[Math.max(0, i - 1)];
    const next = spine[Math.min(segs, i + 1)];
    let tx = next[0] - prev[0];
    let ty = next[1] - prev[1];
    const l = Math.hypot(tx, ty) || 1;
    tx /= l;
    ty /= l;
    const w = halfW * (1 - t) * (1 - t * 0.15);
    left.push([p[0] - ty * w, p[1] + tx * w]);
    right.push([p[0] + ty * w, p[1] - tx * w]);
  }
  return { outline: [...left, ...right.reverse()], tip };
}
function nodeBox(ctx, label, fs, maxW, padX) {
  const text = ctx.wrap(label, maxW, fs, "heading", 2);
  const lines = text.split("\n");
  const w = Math.max(...lines.map((l) => ctx.measure(l, fs, "heading")), fs) + padX * 2;
  const h = lines.length * fs * 1.35 + fs * 0.8;
  return { text, w, h };
}
function resolveMindmap(spec) {
  const explicit = spec.items.find((i) => i.kind === "root" || i.kind === "center");
  if (explicit) {
    return { root: explicit, branches: [...explicit.children, ...spec.items.filter((i) => i !== explicit)], fromTitle: false };
  }
  const top = spec.items;
  if (top.length === 1 && top[0].children.length) return { root: top[0], branches: top[0].children, fromTitle: false };
  if (spec.title) return { root: { label: spec.title }, branches: top, fromTitle: true };
  if (top.length > 1) return { root: top[0], branches: [...top[0].children, ...top.slice(1)], fromTitle: false };
  return { root: { id: top[0]?.id, label: top[0]?.label ?? "Topic" }, branches: top[0]?.children ?? [], fromTitle: false };
}
function stackCenters(heights, gap) {
  const total = heights.reduce((s, h) => s + h, 0) + Math.max(0, heights.length - 1) * gap;
  let cursor = -total / 2;
  return heights.map((h) => {
    const c = cursor + h / 2;
    cursor += h + gap;
    return c;
  });
}
const CHILD_PITCH = 38;
function drawBranchCluster(ctx, branch, roleIdx, n, rootEdge, branchX, cy, dir) {
  const role = ctx.role(roleIdx, { n, color: branch.color });
  const bb = nodeBox(ctx, branch.label, 15, 170, 12);
  const bx = dir > 0 ? branchX : branchX - bb.w;
  ctx.item(branch.id, () => {
    ctx.shape("round-rectangle", bx, cy - bb.h / 2, bb.w, bb.h, role, {
      id: ctx.uid(branch.id),
      label: bb.text,
      style: { fontSize: 15 }
    });
    ctx.line(sCurveH(rootEdge[0], rootEdge[1], dir > 0 ? bx - 2 : bx + bb.w + 2, cy), { color: ctx.preset.edge, width: 1.8 });
  });
  const kids = branch.children;
  if (!kids.length) return;
  const childGap = 56;
  const startY = cy - (kids.length - 1) * CHILD_PITCH / 2;
  const branchEdgeX = dir > 0 ? bx + bb.w : bx;
  kids.forEach(
    (child, k) => ctx.item(child.id, () => {
      const kRole = ctx.role(roleIdx, { n, color: child.color ?? role.color });
      const kb = nodeBox(ctx, child.label, 12, 150, 10);
      const ky = startY + k * CHILD_PITCH;
      const kx = dir > 0 ? branchEdgeX + childGap : branchEdgeX - childGap - kb.w;
      ctx.shape("round-rectangle", kx, ky - kb.h / 2, kb.w, kb.h, kRole, {
        id: ctx.uid(child.id),
        label: kb.text,
        style: { fontSize: 12 }
      });
      ctx.line(sCurveH(branchEdgeX + dir * 2, cy, dir > 0 ? kx - 2 : kx + kb.w + 2, ky, 14), { color: role.color, width: 1.5 });
    })
  );
}
function clusterHeight(branch, minH) {
  return Math.max(minH, branch.children.length * CHILD_PITCH + 10);
}
function genMindmapSides(spec, ctx, side) {
  const { root, branches, fromTitle } = resolveMindmap(spec);
  if (fromTitle) ctx.titleHandled = true;
  const n = Math.max(branches.length, 1);
  const rb = nodeBox(ctx, root.label, 16, 200, 16);
  const rootW = Math.max(rb.w, 120);
  const rootH = Math.max(rb.h, 46);
  const rootRole = ctx.role(0, { neutral: true, color: root.color });
  scoped$1(ctx, root.id, () => {
    ctx.shape("round-rectangle", -rootW / 2, -rootH / 2, rootW, rootH, rootRole, { id: ctx.uid("root"), label: rb.text, style: { fontSize: 16 } });
  });
  const right = [];
  const left = [];
  branches.forEach((item, idx) => {
    if (side === "left") left.push({ item, idx });
    else if (side === "right") right.push({ item, idx });
    else (idx < Math.ceil(branches.length / 2) ? right : left).push({ item, idx });
  });
  const gap = 36;
  const branchGapX = 130;
  for (const [list, dir] of [
    [right, 1],
    [left, -1]
  ]) {
    if (!list.length) continue;
    const centers = stackCenters(
      list.map(({ item }) => clusterHeight(item, 52)),
      gap
    );
    list.forEach(({ item, idx }, j) => {
      const branchX = dir > 0 ? rootW / 2 + branchGapX : -(rootW / 2 + branchGapX);
      drawBranchCluster(ctx, item, idx, n, [dir > 0 ? rootW / 2 : -rootW / 2, 0], branchX, centers[j], dir);
    });
  }
}
function genMindmapHorizontal(spec, ctx) {
  const { root, branches, fromTitle } = resolveMindmap(spec);
  if (fromTitle) ctx.titleHandled = true;
  const n = Math.max(branches.length, 1);
  const rb = nodeBox(ctx, root.label, 16, 180, 16);
  const rootW = Math.max(rb.w, 120);
  const rootH = Math.max(rb.h, 46);
  const rootRole = ctx.role(0, { neutral: true, color: root.color });
  scoped$1(ctx, root.id, () => {
    ctx.shape("round-rectangle", 0, -rootH / 2, rootW, rootH, rootRole, { id: ctx.uid("root"), label: rb.text, style: { fontSize: 16 } });
  });
  const centers = stackCenters(
    branches.map((b) => clusterHeight(b, 52)),
    30
  );
  const branchX = rootW + 110;
  branches.forEach((item, idx) => {
    drawBranchCluster(ctx, item, idx, n, [rootW, 0], branchX, centers[idx], 1);
  });
}
function genMindmapVertical(spec, ctx) {
  const { root, branches, fromTitle } = resolveMindmap(spec);
  if (fromTitle) ctx.titleHandled = true;
  const n = Math.max(branches.length, 1);
  const rootRole = ctx.role(0, { neutral: true, color: root.color });
  const rt = ctx.wrap(root.label, 240, 22, "heading", 2);
  const rootW = Math.max(200, Math.max(...rt.split("\n").map((l) => ctx.measure(l, 22, "heading"))) + 56);
  const rootH = 70;
  scoped$1(ctx, root.id, () => {
    ctx.shape("round-rectangle", -rootW / 2, -rootH / 2, rootW, rootH, rootRole, { id: ctx.uid("root"), label: rt, style: { fontSize: 22 } });
  });
  const cardW = 260;
  const cardGap = 28;
  const headingWeight = ctx.preset.fonts.headingWeight;
  const measureCard = (branch, idx) => {
    const titleText = ctx.wrap(branch.label, cardW - 24, 20, "heading", 2);
    const tLines = titleText.split("\n");
    const titleW = Math.max(...tLines.map((l) => ctx.measure(l, 20, "heading")));
    const titleH = tLines.length * 26;
    const descLines = [];
    if (branch.detail) descLines.push(...ctx.wrap(branch.detail, cardW - 24, 15, "body", 4).split("\n"));
    for (const c of branch.children) descLines.push(...ctx.wrap(c.label, cardW - 24, 15, "body", 2).split("\n"));
    const h = titleH + (descLines.length ? descLines.length * 20 + 8 : 0);
    return { idx, titleText, titleW, titleH, descLines, h };
  };
  const drawCard = (card, branch, x, top) => {
    const role = ctx.role(card.idx, { n, color: branch.color });
    const cx = x + cardW / 2;
    const titleCy = top + card.titleH / 2;
    ctx.label(card.titleText, cx, titleCy, { size: 20, color: role.color, font: "heading", weight: headingWeight });
    const seg = (cardW - card.titleW) / 2 - 12;
    if (seg > 10) {
      ctx.line(
        [
          [x, titleCy],
          [x + seg, titleCy]
        ],
        { color: role.color, width: 2 }
      );
      ctx.line(
        [
          [x + cardW - seg, titleCy],
          [x + cardW, titleCy]
        ],
        { color: role.color, width: 2 }
      );
    }
    if (card.descLines.length) {
      ctx.label(card.descLines.join("\n"), cx, top + card.titleH + 8, { size: 15, color: ctx.mutedInk, vAnchor: "top", maxW: cardW - 24 });
    }
  };
  const aboveCount = Math.ceil(branches.length / 2);
  const rows = [
    { list: branches.slice(0, aboveCount), base: -110, dir: -1 },
    { list: branches.slice(aboveCount), base: 110, dir: 1 }
  ];
  rows.forEach(({ list, base, dir }, r2) => {
    if (!list.length) return;
    const rowW = list.length * cardW + (list.length - 1) * cardGap;
    const busY = base + dir * -40;
    const cxs = [];
    list.forEach((branch, j) => {
      const idx = r2 === 0 ? j : aboveCount + j;
      const card = measureCard(branch, idx);
      const x = -rowW / 2 + j * (cardW + cardGap);
      const top = dir < 0 ? base - card.h : base;
      const cx = x + cardW / 2;
      cxs.push(cx);
      ctx.item(branch.id, () => {
        drawCard(card, branch, x, top);
        ctx.line(
          [
            [cx, busY],
            [cx, base]
          ],
          { color: ctx.preset.edge, width: 1.8 }
        );
      });
    });
    ctx.line(
      [
        [0, dir < 0 ? -rootH / 2 : rootH / 2],
        [0, busY]
      ],
      { color: ctx.preset.edge, width: 1.8 }
    );
    if (cxs.length > 1 || Math.abs(cxs[0]) > 2) {
      ctx.line(
        [
          [Math.min(...cxs, 0), busY],
          [Math.max(...cxs, 0), busY]
        ],
        { color: ctx.preset.edge, width: 1.8 }
      );
    }
  });
}
function mindmapDef(name, summary, variant, sweetSpot) {
  registerViz({
    name,
    category: "Mindmap",
    summary,
    entryKinds: ["item", "root", "center"],
    sweetSpot,
    generate(spec, ctx) {
      if (variant === "vertical") genMindmapVertical(spec, ctx);
      else if (variant === "horizontal") genMindmapHorizontal(spec, ctx);
      else genMindmapSides(spec, ctx, variant);
    }
  });
}
mindmapDef("mindmap", "Root with branches fanning left and right; children beyond each branch.", "both", { min: 3, max: 8 });
mindmapDef("mindmap-left", "Mindmap with every branch on the left of the root.", "left", { min: 2, max: 5 });
mindmapDef("mindmap-right", "Mindmap with every branch on the right of the root.", "right", { min: 2, max: 5 });
mindmapDef("mindmap-horizontal", "Root at the left; branches one column right, children beyond.", "horizontal", { min: 2, max: 6 });
mindmapDef("mindmap-vertical", "Org-chart mindmap: root center, branch cards above/below with elbow trunks.", "vertical", { min: 2, max: 6 });
registerViz({
  name: "decision",
  category: "Comparison",
  summary: "A person weighing a question, elbow branches fanning to the options.",
  entryKinds: ["item", "option", "question"],
  options: [{ name: "question", type: "string", description: "the question posed (falls back to a question entry, then the title)" }],
  sweetSpot: { min: 2, max: 5 },
  generate(spec, ctx) {
    const options = itemsOf(spec, "item", "option");
    const n = Math.max(options.length, 1);
    const questionEntry = spec.items.find((i) => i.kind === "question");
    const question = questionEntry?.label ?? optStr(spec.options, "question") ?? spec.title;
    if (question && question === spec.title) ctx.titleHandled = true;
    const rowH = Math.max(0, ...options.map((o) => ctx.measureLabelBlock(o.label, o.detail, { maxW: 280 }).h));
    const pitch = Math.max(78, rowH + 26);
    const rowTop = 84;
    const rows = options.map((_, i) => rowTop + i * pitch);
    const midY = rowTop + (n - 1) * pitch / 2;
    if (question) {
      scoped$1(ctx, questionEntry?.id, () => {
        ctx.label(ctx.wrap(question, 360, 20, "heading", 3), 140, 24, { size: 20, color: ctx.ink, weight: 700, font: "heading", align: "left" });
      });
    }
    ctx.icon("user", 36, midY, 70, ctx.ink);
    const splitX = 290;
    const optX = 380;
    const endX = optX - 14;
    const r2 = 16;
    const edgeStyle = { color: ctx.preset.edge, width: 1.8 };
    ctx.line(
      [
        [78, midY],
        [splitX - r2, midY]
      ],
      edgeStyle
    );
    options.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const y = rows[i];
        if (Math.abs(y - midY) < 2) {
          ctx.line(
            [
              [splitX - r2, midY],
              [endX, y]
            ],
            edgeStyle
          );
        } else {
          const s = y > midY ? 1 : -1;
          const pts = [
            ...qCorner([splitX - r2, midY], [splitX, midY], [splitX, midY + s * r2]),
            ...qCorner([splitX, y - s * r2], [splitX, y], [splitX + r2, y]),
            [endX, y]
          ];
          ctx.line(pts, edgeStyle);
        }
        if (item.icon) ctx.icon(item.icon, optX + 17, y, 34, role.color);
        else {
          ctx.shape("circle", optX + 4, y - 13, 26, 26, role, { id: ctx.uid(item.id) });
          ctx.label(String(i + 1), optX + 17, y, { size: 15, color: role.textColor, weight: 700, font: "heading" });
        }
        ctx.labelBlock(item.label, item.detail, optX + 48, y, { color: ctx.ink, align: "left", maxW: 280 });
      })
    );
  }
});
registerViz({
  name: "root-causes",
  aliases: ["root-cause"],
  category: "Cause and Effect",
  summary: "A leafy tree — the problem is the crown, the causes are its roots.",
  entryKinds: ["item", "cause", "problem", "center"],
  sweetSpot: { min: 2, max: 7 },
  generate(spec, ctx) {
    const causes = itemsOf(spec, "item", "cause");
    const n = Math.max(causes.length, 1);
    const problemEntry = spec.items.find((i) => i.kind === "problem" || i.kind === "center");
    const problem = problemEntry?.label ?? spec.title;
    if (problem && problem === spec.title) ctx.titleHandled = true;
    const rx = 178;
    const ry = 110;
    const canopyCy = -96;
    ctx.path(scallopedBlob(rx, ry, 11), rx * 2, ry * 2, -rx, canopyCy - ry, rx * 2, ry * 2, { ...outline$1(ctx, ctx.ink, 2.2), fill: ctx.preset.background, fillStyle: "solid" }, { id: ctx.uid("canopy"), z: 1 });
    if (problem) {
      scoped$1(ctx, problemEntry?.id, () => {
        ctx.label(ctx.wrap(problem, 240, 20, "heading", 3), 0, canopyCy, { size: 20, color: ctx.ink, weight: 700, font: "heading", z: 3, maxW: 240 });
      });
    }
    const groundY = 214;
    const trunk = [
      [-15, -8],
      [-21, 70],
      [-28, 142],
      [-42, groundY - 6],
      [-56, groundY],
      [-20, groundY + 5],
      [0, groundY + 12],
      [20, groundY + 5],
      [56, groundY],
      [42, groundY - 6],
      [28, 142],
      [21, 70],
      [15, -8]
    ];
    ctx.poly(trunk, outline$1(ctx, ctx.ink, 2), { id: ctx.uid("trunk") });
    const gy = groundY + 9;
    ctx.line([[-262, gy], [-70, gy]], { color: ctx.mutedInk, width: 1.6, dash: true });
    ctx.line([[70, gy], [262, gy]], { color: ctx.mutedInk, width: 1.6, dash: true });
    const rootSpecs = [
      { ang: 146, len: 168, hw: 12, bow: 1 },
      { ang: 124, len: 140, hw: 10, bow: 1 },
      { ang: 106, len: 116, hw: 9, bow: -1 },
      { ang: 90, len: 152, hw: 10, bow: 0 },
      { ang: 74, len: 116, hw: 9, bow: 1 },
      { ang: 56, len: 140, hw: 10, bow: -1 },
      { ang: 34, len: 168, hw: 12, bow: -1 }
    ];
    const roots = rootSpecs.map((r2) => taperRoot([(90 - r2.ang) * 0.72, groundY + 5], r2.ang, r2.len, r2.hw, r2.bow));
    const leftTipIdx = [0, 1, 2];
    const rightTipIdx = [6, 5, 4];
    const causeRoot = [];
    let leftJ = 0;
    let rightJ = 0;
    causes.forEach((item, i) => {
      const bottom = i === causes.length - 1 && causes.length % 2 === 1 && causes.length >= 3;
      if (bottom) {
        causeRoot[i] = 3;
        return;
      }
      const side = i % 2 === 0 ? -1 : 1;
      const j = side < 0 ? leftJ++ : rightJ++;
      causeRoot[i] = side < 0 ? leftTipIdx[Math.min(j, 2)] : rightTipIdx[Math.min(j, 2)];
    });
    roots.forEach((r2, idx) => {
      if (!causeRoot.includes(idx)) ctx.poly(r2.outline, outline$1(ctx, ctx.ink, 1.6));
    });
    const labelY = causes.map((item, i) => causeRoot[i] === 3 ? 0 : roots[causeRoot[i]].tip[1]);
    const blockH = causes.map((item) => ctx.measureLabelBlock(item.label, item.detail, { maxW: 220 }).h);
    for (const side of [-1, 1]) {
      const col = causes.map((_, i) => i).filter((i) => causeRoot[i] !== 3 && (i % 2 === 0 ? -1 : 1) === side).sort((a, b) => labelY[a] - labelY[b]);
      for (let k = 1; k < col.length; k++) {
        const above = col[k - 1];
        const need = labelY[above] + blockH[above] / 2 + blockH[col[k]] / 2 + 16;
        if (labelY[col[k]] < need) labelY[col[k]] = need;
      }
    }
    causes.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const root = roots[causeRoot[i]];
        const tip = root.tip;
        ctx.poly(root.outline, outline$1(ctx, role.color, 1.8));
        const leader = { color: role.color, width: 1.5 };
        if (causeRoot[i] === 3) {
          ctx.line([tip, [tip[0], tip[1] + 22]], leader);
          ctx.labelBlock(item.label, item.detail, tip[0], tip[1] + 30, { color: role.color, align: "center", maxW: 280, vAnchor: "top" });
          return;
        }
        const side = i % 2 === 0 ? -1 : 1;
        const y = labelY[i];
        const bx = side * 226;
        ctx.labelBlock(item.label, item.detail, bx, y, { color: role.color, align: side < 0 ? "right" : "left", maxW: 220 });
        const sx = bx + side * -8;
        if (Math.abs(y - tip[1]) < 2) {
          ctx.line([[sx, y], tip], leader);
        } else {
          const mx = (sx + tip[0]) / 2;
          ctx.line([[sx, y], [mx, y], [mx, tip[1]], tip], leader);
        }
      })
    );
  }
});
function genConverge(spec, ctx) {
  const inputs = [...itemsOf(spec, "item", "input")];
  let output = spec.items.find((i) => i.kind === "output" || i.kind === "out");
  let outputLabel = optStr(spec.options, "output");
  let outputDetail;
  if (!output && !outputLabel && inputs.length > 1) output = inputs.pop();
  if (output) {
    outputLabel = output.label;
    outputDetail = output.detail;
  }
  const n = Math.max(inputs.length, 1);
  const pitch = 114;
  const ys = inputs.map((_, i) => i * pitch);
  const midY = (n - 1) * pitch / 2;
  const lensH = Math.max(280, (n - 1) * pitch + 100);
  const lensW = 72;
  const lensCx = 410;
  ctx.shape("ellipse", lensCx - lensW / 2, midY - lensH / 2, lensW, lensH, outline$1(ctx, ctx.mutedInk), { id: ctx.uid("lens") });
  inputs.forEach(
    (item, i) => ctx.item(item.id, () => {
      const role = ctx.role(i, { n: n + 1, color: item.color });
      const y = ys[i];
      if (item.icon) ctx.icon(item.icon, 23, y, 46, role.color);
      else {
        ctx.shape("circle", 5, y - 18, 36, 36, role, { id: ctx.uid(item.id) });
        ctx.label(String(i + 1), 23, y, { size: 18, color: role.textColor, weight: 700, font: "heading" });
      }
      const block = ctx.labelBlock(item.label, item.detail, 56, y, { color: role.color, align: "left", maxW: 230 });
      const startX = block.x + block.w + 8;
      const t = n === 1 ? 0 : (i / (n - 1) - 0.5) * 44;
      ctx.line(sCurveH(startX, y, lensCx + lensW / 2 - 12, midY + t), { color: ctx.preset.edge, width: 1.8 });
    })
  );
  const outRole = ctx.role(inputs.length, { n: n + 1, color: output?.color });
  const outX = lensCx + lensW / 2 + 14;
  scoped$1(ctx, output?.id, () => {
    ctx.arrow(outX, midY, outX + 66, midY, { color: ctx.preset.edge, width: 1.8 });
    const blockX = outX + 84;
    if (output?.icon) ctx.icon(output.icon, blockX + 23, midY, 46, outRole.color);
    const textX = output?.icon ? blockX + 56 : blockX;
    ctx.labelBlock(outputLabel ?? "Outcome", outputDetail, textX, midY, { color: outRole.color, align: "left", maxW: 220 });
  });
}
registerViz({
  name: "converge",
  category: "Brainstorming",
  summary: "Inputs funnel through a lens into one outcome.",
  entryKinds: ["item", "input", "output", "out"],
  options: [{ name: "output", type: "string", description: "outcome label when no output entry (else the last item is the output)" }],
  sweetSpot: { min: 2, max: 5 },
  generate: genConverge
});
registerViz({
  name: "lens",
  category: "Visual Metaphors",
  summary: "A focusing lens — several inputs concentrated into one output.",
  entryKinds: ["item", "input", "output", "out"],
  options: [{ name: "output", type: "string", description: "outcome label when no output entry (else the last item is the output)" }],
  sweetSpot: { min: 2, max: 5 },
  generate: genConverge
});
const DIVERGE_CURVE_VW = 120;
const DIVERGE_CURVE_VH = 160;
const DIVERGE_CURVE_L = "M70 0 L106 0 C106 88 46 92 46 128 L56 128 L28 160 L0 128 L10 128 C10 84 70 80 70 0 Z";
const DIVERGE_CURVE_R = "M50 0 L14 0 C14 88 74 92 74 128 L64 128 L92 160 L120 128 L110 128 C110 84 50 80 50 0 Z";
registerViz({
  name: "diverge",
  category: "Brainstorming",
  summary: "A question radiating thick arrows to option blocks at the corners.",
  entryKinds: ["item", "option", "question", "center"],
  sweetSpot: { min: 2, max: 4 },
  generate(spec, ctx) {
    const options = itemsOf(spec, "item", "option");
    const n = Math.max(options.length, 1);
    const questionEntry = spec.items.find((i) => i.kind === "question" || i.kind === "center");
    const question = questionEntry?.label ?? spec.title;
    if (question && question === spec.title) ctx.titleHandled = true;
    if (question) {
      scoped$1(ctx, questionEntry?.id, () => {
        ctx.label(ctx.wrap(question, 420, 25, "heading", 2), 0, -14, { size: 25, color: ctx.ink, weight: 700, font: "heading" });
      });
    }
    const top = 60;
    const AW = 170;
    const AH = 76;
    const gapX = 80;
    const rowCy = top + AH / 2;
    const CW = DIVERGE_CURVE_VW * 1.1;
    const CH = DIVERGE_CURVE_VH * 1.1;
    const sx = (v) => v * (CW / DIVERGE_CURVE_VW);
    let slots;
    if (n === 1) slots = [{ kind: "right" }];
    else if (n === 2) slots = [{ kind: "left" }, { kind: "right" }];
    else if (n === 3) slots = [{ kind: "left" }, { kind: "down-center" }, { kind: "right" }];
    else {
      slots = [{ kind: "left" }, { kind: "down-left" }, { kind: "down-right" }, { kind: "right" }];
      const extraAngles = [142, 38, 162, 18, 115, 65];
      for (let k = 4; k < n; k++) slots.push({ kind: "ray", angle: extraAngles[k - 4] ?? 90 });
    }
    const C = [0, rowCy];
    if (slots.some((s) => s.kind === "ray")) dot$1(ctx, C[0], C[1], 10);
    options.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const slot = slots[i];
        switch (slot.kind) {
          case "left":
          case "right": {
            const dir = slot.kind === "right" ? 1 : -1;
            const bx = dir > 0 ? gapX : -gapX - AW;
            ctx.shape("block-arrow", bx, rowCy - AH / 2, AW, AH, role, {
              id: ctx.uid(item.id),
              data: { dir: dir > 0 ? "right" : "left" }
            });
            if (item.icon) ctx.icon(item.icon, bx + AW * (dir > 0 ? 0.62 : 0.38), rowCy, 30, role.textColor);
            const tipX = dir > 0 ? bx + AW : bx;
            ctx.labelBlock(item.label, item.detail, tipX + dir * 16, rowCy, { color: role.color, align: dir > 0 ? "left" : "right", maxW: 200 });
            break;
          }
          case "down-left":
          case "down-right":
          case "down-center": {
            const mirrored = slot.kind !== "down-left";
            const bx = slot.kind === "down-left" ? -10 - sx(106) : slot.kind === "down-right" ? 10 - sx(14) : -CW / 2;
            ctx.path(mirrored ? DIVERGE_CURVE_R : DIVERGE_CURVE_L, DIVERGE_CURVE_VW, DIVERGE_CURVE_VH, bx, top, CW, CH, role, { id: ctx.uid(item.id) });
            const headX = bx + sx(mirrored ? 92 : 28);
            if (item.icon) ctx.icon(item.icon, headX, top + CH * 105 / DIVERGE_CURVE_VH, 28, role.textColor);
            const tipY = top + CH;
            const shift = slot.kind === "down-left" ? -30 : slot.kind === "down-right" ? 30 : 0;
            ctx.labelBlock(item.label, item.detail, headX + shift, tipY + 16, { color: role.color, align: "center", maxW: 210, vAnchor: "top" });
            break;
          }
          case "ray": {
            const a = slot.angle ?? 90;
            const from = polar(C[0], C[1], 50, a);
            const to = polar(C[0], C[1], 190, a);
            ctx.line([from, to], { color: role.color, width: 5, arrow: true, id: ctx.uid(item.id) });
            const tip = polar(C[0], C[1], 214, a);
            const align = radialAlign(a);
            const shift = align === "left" ? 14 : align === "right" ? -14 : 0;
            if (item.icon) ctx.icon(item.icon, tip[0], tip[1] + 18, 34, role.color);
            ctx.labelBlock(item.label, item.detail, tip[0] + shift, tip[1] + (item.icon ? 44 : 14), { color: role.color, align, maxW: 190, vAnchor: "top" });
            break;
          }
        }
      })
    );
  }
});
registerViz({
  name: "prism",
  category: "Visual Metaphors",
  summary: "One input beam split by a prism into several outputs.",
  entryKinds: ["item", "output", "out", "input", "in"],
  options: [{ name: "input", type: "string", description: "input label when no input entry" }],
  sweetSpot: { min: 2, max: 5 },
  generate(spec, ctx) {
    const outputs = itemsOf(spec, "item", "output", "out");
    const n = Math.max(outputs.length, 1);
    const inputEntry = spec.items.find((i) => i.kind === "input" || i.kind === "in");
    const inputLabel = inputEntry?.label ?? optStr(spec.options, "input") ?? "Input";
    const triX = 230;
    const triY = 20;
    const triW = 200;
    const triH = 190;
    const cy = triY + triH * 0.62;
    ctx.shape("triangle", triX, triY, triW, triH, outline$1(ctx, ctx.mutedInk), { id: ctx.uid("prism") });
    ctx.poly(
      [
        [triX + triW / 2, triY],
        [triX + triW / 2 + 64, triY - 22],
        [triX + triW + 64, triY + triH - 22],
        [triX + triW, triY + triH]
      ],
      outline$1(ctx, ctx.mutedInk)
    );
    const inRole = inputEntry?.color ? ctx.role(0, { color: inputEntry.color }) : void 0;
    const inColor = inRole?.color ?? ctx.ink;
    scoped$1(ctx, inputEntry?.id, () => {
      ctx.shape("round-rectangle", 0, cy - 36, 72, 72, outline$1(ctx, inColor), { id: ctx.uid("input") });
      ctx.icon(inputEntry?.icon ?? "bulb", 36, cy, 40, inColor);
      ctx.label(ctx.wrap(inputLabel, 150, 20, "heading", 2), 36, cy + 62, { size: 20, color: inColor, weight: ctx.preset.fonts.headingWeight, font: "heading" });
      ctx.line(
        [
          [74, cy],
          [triX + 66, cy]
        ],
        { color: ctx.preset.edge, width: 2 }
      );
    });
    const pitch = 84;
    const nodeX = 560;
    const startY = cy - (n - 1) * pitch / 2;
    outputs.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const y = startY + i * pitch;
        const t = n === 1 ? 0 : (i / (n - 1) - 0.5) * 44;
        ctx.line(
          [
            [triX + triW - 30, cy + t * 0.4],
            [nodeX - 6, y]
          ],
          { color: role.color, width: 2.2, arrow: true }
        );
        ctx.shape("round-rectangle", nodeX, y - 35, 70, 70, role, { id: ctx.uid(item.id) });
        if (item.icon) ctx.icon(item.icon, nodeX + 35, y, 36, role.textColor);
        else ctx.label(String(i + 1), nodeX + 35, y, { size: 24, color: role.textColor, weight: 700, font: "heading" });
        ctx.labelBlock(item.label, item.detail, nodeX + 88, y, { color: role.color, align: "left", maxW: 210 });
      })
    );
  }
});
function roleStroke(ctx, role) {
  return role.stroke === ctx.preset.background ? role.color : role.stroke;
}
function scoped(ctx, item, fn) {
  if (item) ctx.item(item.id, fn);
  else fn();
}
const jit$1 = (i, amp) => Math.sin(i * 7.3) * amp;
function dot(ctx, x, y, d, color, z) {
  ctx.shape("circle", x - d / 2, y - d / 2, d, d, { stroke: color, fill: color, fillStyle: "solid", strokeWidth: 1, roughness: 0.5 }, { z });
}
function quad(p0, c, p1, segs = 12) {
  const pts = [];
  for (let s = 0; s <= segs; s++) {
    const t = s / segs;
    const u = 1 - t;
    pts.push([u * u * p0[0] + 2 * u * t * c[0] + t * t * p1[0], u * u * p0[1] + 2 * u * t * c[1] + t * t * p1[1]]);
  }
  return pts;
}
registerViz({
  name: "balance",
  aliases: ["scales"],
  category: "Comparison",
  summary: "A two-pan balance weighing two sides of item rows.",
  entryKinds: ["item", "side"],
  options: [{ name: "tilt", type: "left|right|level", description: "which side hangs lower (default level)" }],
  sweetSpot: { min: 2, max: 2 },
  generate(spec, ctx) {
    const sides = itemsOf(spec, "item", "side").slice(0, 2);
    while (sides.length < 2) {
      sides.push({ kind: "side", id: `side${sides.length + 1}`, label: "", values: [], strings: [], opts: {}, children: [] });
    }
    const tilt = optStr(spec.options, "tilt") ?? "level";
    const cx = 260;
    const beamY = 190;
    const armSpan = 180;
    const plinthY = beamY + 86;
    ctx.shape("rectangle", cx - 64, plinthY, 128, 16, { stroke: ctx.ink, fill: ctx.mutedInk, fillStyle: "hachure", strokeWidth: 2, roughness: ctx.preset.roughness });
    ctx.poly(
      [
        [cx - 42, plinthY],
        [cx + 42, plinthY],
        [cx, beamY + 6]
      ],
      ctx.role(0, { neutral: true })
    );
    dot(ctx, cx, beamY, 24, ctx.ink, 2);
    sides.forEach(
      (side, s) => ctx.item(side.id, () => {
        const dir = s === 0 ? -1 : 1;
        const dy = tilt === "level" ? 0 : tilt === "left" === (s === 0) ? 16 : -16;
        const role = ctx.role(s, { n: 2, color: side.color });
        const px = cx + dir * armSpan;
        const panY = beamY + 42 + dy;
        ctx.line(quad([cx, beamY - 8], [cx + dir * armSpan * 0.55, beamY - 46 + dy * 0.5], [px, panY - 14]), { color: ctx.ink, width: 2.4 });
        const dish = [];
        for (let t = 0; t <= 12; t++) {
          const u = t / 12;
          dish.push([px - 44 + 88 * u, panY + Math.sin(Math.PI * u) * 16]);
        }
        ctx.line(dish, { color: roleStroke(ctx, role), width: 2.6, id: ctx.uid(side.id) });
        ctx.line(
          [
            [px, panY - 14],
            [px - 44, panY]
          ],
          { color: ctx.mutedInk, width: 1.4 }
        );
        ctx.line(
          [
            [px, panY - 14],
            [px + 44, panY]
          ],
          { color: ctx.mutedInk, width: 1.4 }
        );
        side.children.forEach((row, j) => {
          const ry = panY - 34 - (side.children.length - 1 - j) * 40;
          const tw = ctx.measure(row.label, 18);
          const hasIcon = !!row.icon;
          const total = (hasIcon ? 36 : 18) + tw;
          const left = px - total / 2;
          if (hasIcon) ctx.icon(row.icon, left + 14, ry, 28, role.color);
          else dot(ctx, left + 5, ry, 10, role.color);
          ctx.label(row.label, left + (hasIcon ? 36 : 18), ry, { size: 18, color: ctx.ink, align: "left" });
        });
        if (side.label) ctx.labelBlock(side.label, side.detail, px, panY + 34, { color: role.color, align: "center", maxW: 190, vAnchor: "top" });
      })
    );
  }
});
registerViz({
  name: "podium",
  category: "Comparison",
  summary: "Winners' podium — ranks 1-2-3 in the classic 2-1-3 arrangement.",
  entryKinds: ["item", "rank"],
  sweetSpot: { min: 3, max: 3 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "rank").slice(0, 3);
    const blockW = 150;
    const gap = 14;
    const base = 270;
    const heights = [176, 122, 74];
    const cols = [1, 0, 2];
    cols.forEach((rank2, c) => {
      const item = items[rank2];
      if (!item) return;
      ctx.item(item.id, () => {
        const role = ctx.role(rank2, { n: 3, color: item.color });
        const stroke = roleStroke(ctx, role);
        const w = Math.min(2.6, role.strokeWidth);
        const x = c * (blockW + gap);
        const top = base - heights[rank2];
        const bx = x + blockW / 2;
        ctx.line(
          [
            [x - 12, top + 9],
            [x - 12, top],
            [x + blockW + 12, top],
            [x + blockW + 12, top + 9]
          ],
          { color: stroke, width: w, id: ctx.uid(item.id) }
        );
        ctx.line(
          [
            [x, top],
            [x, base]
          ],
          { color: stroke, width: w }
        );
        ctx.line(
          [
            [x + blockW, top],
            [x + blockW, base]
          ],
          { color: stroke, width: w }
        );
        ctx.icon(item.icon ?? (rank2 === 0 ? "trophy" : "medal"), bx, top - 38, 46, role.color);
        ctx.label(String(rank2 + 1), bx, top + 26, { size: 30, color: role.color, weight: 700, font: "heading" });
        ctx.label(ctx.wrap(item.label, blockW - 18, 17, "body", 2), bx, top + 58, { size: 17, color: ctx.ink });
      });
    });
  }
});
registerViz({
  name: "spectrum",
  category: "Comparison",
  summary: "Pole-to-pole horizontal spectrum of zones with arrow ends.",
  entryKinds: ["item", "zone"],
  sweetSpot: { min: 2, max: 5 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "zone");
    const n = Math.max(items.length, 1);
    const zoneW = 152;
    const zoneH = 94;
    const gap = 10;
    const aw = 40;
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const x = i * (zoneW + gap);
        const first = i === 0;
        const last = i === items.length - 1;
        let iconCx = x + zoneW / 2;
        if (first && last) {
          ctx.poly(
            [
              [x + aw, 0],
              [x + zoneW - aw, 0],
              [x + zoneW, zoneH / 2],
              [x + zoneW - aw, zoneH],
              [x + aw, zoneH],
              [x, zoneH / 2]
            ],
            role,
            { id: ctx.uid(item.id) }
          );
        } else if (first) {
          ctx.poly(
            [
              [x + aw, 0],
              [x + zoneW, 0],
              [x + zoneW, zoneH],
              [x + aw, zoneH],
              [x, zoneH / 2]
            ],
            role,
            { id: ctx.uid(item.id) }
          );
          iconCx += aw / 2;
        } else if (last) {
          ctx.poly(
            [
              [x, 0],
              [x + zoneW - aw, 0],
              [x + zoneW, zoneH / 2],
              [x + zoneW - aw, zoneH],
              [x, zoneH]
            ],
            role,
            { id: ctx.uid(item.id) }
          );
          iconCx -= aw / 2;
        } else {
          ctx.shape("round-rectangle", x, 0, zoneW, zoneH, role, { id: ctx.uid(item.id) });
        }
        ctx.icon(item.icon, iconCx, zoneH / 2, 40, role.textColor);
        const pole = first || last;
        ctx.labelBlock(item.label, item.detail, x + zoneW / 2, pole ? zoneH + 22 : -22, {
          color: role.color,
          align: "center",
          maxW: zoneW + 24,
          vAnchor: pole ? "top" : "bottom"
        });
      })
    );
  }
});
function gapSpanGenerator(variant) {
  return (spec, ctx) => {
    const items = itemsOf(spec, "item", "step", "challenge", "plank");
    const n = Math.max(items.length, 1);
    const from = spec.items.find((i) => i.kind === "from");
    const to = spec.items.find((i) => i.kind === "to");
    const action = optStr(spec.options, "action");
    const cliffW = 190;
    const gapW = Math.max(370, n * 132);
    const W = cliffW * 2 + gapW;
    const topY = 240;
    const botY = 404;
    const bow = variant === "planks" ? 84 : 64;
    const cliff = (edgeX, dir) => {
      ctx.line([[dir === 1 ? -36 : edgeX, topY], [dir === 1 ? edgeX : W + 36, topY]], { color: ctx.ink, width: 2.6 });
      const pts = [[edgeX, topY]];
      for (let k = 1; k <= 6; k++) pts.push([edgeX - dir * Math.abs(jit$1(k * (dir + 3), 10)), topY + (botY - topY) * (k / 6)]);
      ctx.line(pts, { color: ctx.ink, width: 2.2 });
      for (let k = 0; k < 5; k++) {
        const hy = topY + 24 + k * 28;
        ctx.line([[edgeX - dir * (8 + k % 2 * 5), hy], [edgeX - dir * (26 + k % 3 * 7), hy + 11]], { color: ctx.mutedInk, width: 1.4 });
      }
    };
    cliff(cliffW, 1);
    cliff(W - cliffW, -1);
    for (const fx of [0.28, 0.5, 0.72]) {
      const gx = cliffW + gapW * fx;
      ctx.line([[gx, botY - 40], [gx, botY - 4]], { color: ctx.mutedInk, width: 1.3, dash: true });
    }
    const placeSide = (it, cx) => {
      if (it.icon) ctx.icon(it.icon, cx, topY - 118, 34, ctx.ink);
      ctx.labelBlock(it.label, it.detail, cx, topY - 18, { color: ctx.ink, align: "center", maxW: cliffW - 26, vAnchor: "bottom", size: 19 });
    };
    if (from) ctx.item(from.id, () => placeSide(from, cliffW / 2));
    if (to) ctx.item(to.id, () => placeSide(to, W - cliffW / 2));
    const x0 = cliffW - 8;
    const x1 = W - cliffW + 8;
    const deck = (t) => {
      const x = lerp(x0, x1, t);
      const y = topY + 2 - Math.sin(Math.PI * t) * bow;
      return [x, y];
    };
    const topLine = [];
    const botLine = [];
    for (let s = 0; s <= 30; s++) {
      const [px, py] = deck(s / 30);
      topLine.push([px, py]);
      botLine.push([px, py + 10]);
    }
    ctx.line(topLine, { color: ctx.ink, width: 2.4, id: ctx.uid("deck") });
    ctx.line(botLine, { color: ctx.ink, width: 2 });
    for (let s = 1; s < 30; s += 2) {
      const [px, py] = deck(s / 30);
      ctx.line([[px, py], [px, py + 10]], { color: ctx.mutedInk, width: 1.3 });
    }
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const [px, py] = deck((i + 1) / (n + 1));
        const D = 44;
        ctx.shape("circle", px - D / 2, py - 6 - D, D, D, role, { id: ctx.uid(item.id) });
        if (item.icon) ctx.icon(item.icon, px, py - 6 - D / 2, 24, role.textColor);
        else ctx.label(String(i + 1), px, py - 6 - D / 2, { size: 20, color: role.textColor, weight: 700, font: "heading" });
        const row = i % 2;
        const anchorY = py - D - 18 - row * 64;
        if (row) ctx.line([[px, py - D - 12], [px, anchorY + 8]], { color: ctx.preset.edge, width: 1.3 });
        ctx.labelBlock(item.label, item.detail, px, anchorY, { color: role.color, align: "center", maxW: 168, vAnchor: "bottom" });
      })
    );
    if (action) ctx.label(ctx.wrap(action, W - 60, 22, "heading", 2), W / 2, botY + 40, { size: 22, color: ctx.ink, weight: 700, font: "heading" });
  };
}
registerViz({
  name: "challenges",
  aliases: ["hurdles"],
  category: "Problems and Solutions",
  summary: "Hurdles spanning the gap between two cliffs (from → to).",
  entryKinds: ["item", "step", "challenge", "plank", "from", "to"],
  options: [{ name: "action", type: "string", description: "call-to-action caption below the from/to boxes" }],
  sweetSpot: { min: 2, max: 5 },
  generate: gapSpanGenerator("hurdles")
});
registerViz({
  name: "bridge",
  category: "Problems and Solutions",
  summary: "Bridge planks spanning the gap between two cliffs (from → to).",
  entryKinds: ["item", "step", "challenge", "plank", "from", "to"],
  options: [{ name: "action", type: "string", description: "call-to-action caption below the from/to boxes" }],
  sweetSpot: { min: 2, max: 5 },
  generate: gapSpanGenerator("planks")
});
registerViz({
  name: "vision",
  category: "Visual Metaphors",
  summary: "A staircase rising from today toward an open door (the vision).",
  entryKinds: ["item", "current", "vision"],
  sweetSpot: { min: 2, max: 2 },
  generate(spec, ctx) {
    const generic = itemsOf(spec, "item");
    const current = spec.items.find((i) => i.kind === "current") ?? generic[0];
    const vision = spec.items.find((i) => i.kind === "vision") ?? generic.find((i) => i !== current);
    const cRole = ctx.role(0, { n: 2, color: current?.color });
    const vRole = ctx.role(1, { n: 2, color: vision?.color });
    const steps = 5;
    const rise = 46;
    const run = 56;
    const groundY = 340;
    const x0 = 40;
    const topX = x0 + steps * run;
    const topY = groundY - steps * rise;
    const landingW = 170;
    const xR = topX + landingW;
    const silhouette = [[x0, groundY]];
    for (let k = 0; k < steps; k++) {
      const xL = x0 + k * run;
      const yT = groundY - (k + 1) * rise;
      silhouette.push([xL, yT], [xL + run, yT]);
    }
    silhouette.push([xR, topY], [xR, groundY]);
    ctx.poly(silhouette, { stroke: ctx.ink, fill: cRole.softFill, fillStyle: "solid", strokeWidth: 2.2, roughness: ctx.preset.roughness }, { id: ctx.uid("stairs") });
    ctx.line(
      [
        [x0 - 104, groundY],
        [xR + 44, groundY]
      ],
      { color: ctx.ink, width: 2.4 }
    );
    ctx.line(
      [
        [x0 + run * 0.75, groundY - rise * 2.55],
        [topX - 14, topY - 40]
      ],
      { color: vRole.color, width: 2.2, dash: true, arrow: true }
    );
    const fx = x0 - 52;
    scoped(ctx, current, () => {
      ctx.character("pointing", fx, groundY, 86, { color: cRole.color });
      if (current?.icon) ctx.icon(current.icon, fx, groundY - 112, 30, cRole.color);
      if (current) ctx.labelBlock(current.label, current.detail, fx - 52, groundY + 28, { color: cRole.color, align: "left", maxW: 210, vAnchor: "top" });
    });
    const doorW = 92;
    const doorH = 166;
    const doorX = topX + (landingW - doorW) / 2 - 14;
    const doorB = topY;
    scoped(ctx, vision, () => {
      ctx.line(
        [
          [doorX - 7, doorB],
          [doorX - 7, doorB - doorH - 7],
          [doorX + doorW + 7, doorB - doorH - 7],
          [doorX + doorW + 7, doorB]
        ],
        { color: ctx.ink, width: 2.2 }
      );
      ctx.shape("rectangle", doorX, doorB - doorH, doorW, doorH, vRole, { id: vision ? ctx.uid(vision.id) : void 0 });
      ctx.poly(
        [
          [doorX + doorW, doorB - doorH],
          [doorX + doorW + 54, doorB - doorH - 26],
          [doorX + doorW + 54, doorB - 32],
          [doorX + doorW, doorB]
        ],
        vRole
      );
      dot(ctx, doorX + doorW + 42, doorB - doorH / 2 - 12, 8, vRole.textColor, 3);
      const rcx = doorX + doorW / 2;
      const rcy = doorB - doorH - 14;
      for (const [dx, dy] of [
        [-40, -26],
        [0, -34],
        [40, -26]
      ]) {
        ctx.line(
          [
            [rcx + dx * 0.4, rcy + dy * 0.4],
            [rcx + dx, rcy + dy]
          ],
          { color: vRole.color, width: 2 }
        );
      }
      if (vision?.icon) ctx.icon(vision.icon, doorX + doorW / 2, doorB - doorH - 78, 34, vRole.color);
      if (vision) ctx.labelBlock(vision.label, vision.detail, xR + 28, doorB - doorH + 14, { color: vRole.color, align: "left", maxW: 200, vAnchor: "top" });
    });
  }
});
registerViz({
  name: "hole",
  aliases: ["pit"],
  category: "Visual Metaphors",
  summary: "A pit in the ground with a ladder out — the title carries the message.",
  entryKinds: [],
  options: [{ name: "caption", type: "string", description: "message line below the pit" }],
  generate(spec, ctx) {
    const W = 620;
    const mouthW = 240;
    const pitL = (W - mouthW) / 2;
    const pitR = pitL + mouthW;
    const pitCx = (pitL + pitR) / 2;
    const depth = mouthW * 1.5;
    const wallPt = (t) => {
      const a = Math.PI * t;
      return [pitCx - mouthW / 2 * Math.cos(a), depth * Math.sin(a) ** 0.8];
    };
    const segs = 34;
    const wall = [];
    for (let s = 0; s <= segs; s++) {
      const [px, py] = wallPt(s / segs);
      const ragged = s === 0 || s === segs ? 0 : 1;
      wall.push([px + jit$1(s, 5) * ragged, py + jit$1(s + 11, 4) * ragged]);
    }
    ctx.line(wall, { color: ctx.ink, width: 2.4, id: ctx.uid("pit") });
    for (let k = 0; k < 9; k++) {
      const t = 0.1 + 0.8 * k / 8;
      const [px, py] = wallPt(t);
      const inw = px < pitCx ? 1 : -1;
      ctx.line(
        [
          [px + inw * 6, py - 4],
          [px + inw * 21, py - 15]
        ],
        { color: ctx.mutedInk, width: 1.4 }
      );
    }
    ctx.character("peering", pitL - 52, 0, 86, { color: ctx.ink });
    const grass = ctx.role(0, { n: 2 }).color;
    ctx.line(
      [
        [-30, 0],
        [pitL + 2, 0]
      ],
      { color: grass, width: 2 }
    );
    ctx.line(
      [
        [pitR - 2, 0],
        [W + 30, 0]
      ],
      { color: grass, width: 2 }
    );
    for (const gx of [pitL - 16, pitR + 22, W - 70]) {
      ctx.line(
        [
          [gx - 5, 0],
          [gx, -11],
          [gx + 5, 0]
        ],
        { color: grass, width: 1.6 }
      );
    }
    for (let k = 0; k < 14; k++) {
      const gx = -16 + k * 97.3 % (W + 32);
      if (gx > pitL - 16 && gx < pitR + 16) continue;
      dot(ctx, gx, 12 + k * 17 % 26, 3, ctx.mutedInk);
    }
    for (let k = 0; k < 20; k++) {
      const t = 0.06 + 0.88 * (k * 0.383 % 1);
      const [px, py] = wallPt(t);
      const out = px < pitCx ? -1 : 1;
      dot(ctx, px + out * (18 + k * 13 % 24), py - 4 + k * 7 % 16, 3, ctx.mutedInk);
    }
    const lc = ctx.role(1, { n: 2 }).color;
    const foot = [pitCx + 22, depth - 8];
    const head = [pitR + 26, -44];
    const len = Math.hypot(head[0] - foot[0], head[1] - foot[1]);
    const nx = 396 / len;
    const ny = (head[0] - foot[0]) / len;
    const rail = (side) => [
      [foot[0] + nx * side, foot[1] + ny * side],
      [head[0] + nx * side, head[1] + ny * side]
    ];
    const [r1b, r1t] = rail(-13);
    const [r2b, r2t] = rail(13);
    ctx.line([r1b, r1t], { color: lc, width: 2.6, id: ctx.uid("ladder") });
    ctx.line([r2b, r2t], { color: lc, width: 2.6 });
    for (let k = 0; k < 7; k++) {
      const t = 0.08 + k * 0.135;
      ctx.line(
        [
          [lerp(r1b[0], r1t[0], t), lerp(r1b[1], r1t[1], t)],
          [lerp(r2b[0], r2t[0], t), lerp(r2b[1], r2t[1], t)]
        ],
        { color: lc, width: 2.2 }
      );
    }
    const caption = optStr(spec.options, "caption");
    if (caption) ctx.label(caption, W / 2, depth + 44, { size: 18, color: ctx.ink, maxW: W - 80 });
  }
});
registerViz({
  name: "trend",
  category: "Visual Metaphors",
  summary: "A rising staircase of progress with labeled levels on leader lines.",
  entryKinds: ["item", "step", "level"],
  sweetSpot: { min: 2, max: 5 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "step", "level");
    const n = Math.max(items.length, 1);
    const teeth = 3;
    const toothRise = 52;
    const toothRun = 56;
    const flightRise = teeth * toothRise;
    const flightRun = teeth * toothRun;
    const H = n * flightRise;
    const pts = [[0, H]];
    let px = 0;
    let py = H;
    for (let k = 0; k < n * teeth; k++) {
      py -= toothRise;
      pts.push([px, py]);
      px += toothRun;
      pts.push([px, py]);
    }
    ctx.line(pts, { color: ctx.ink, width: 2.6 });
    const ux = Math.SQRT1_2;
    const uy = -Math.SQRT1_2;
    const ax = px - 58;
    const ay = py + 8;
    const shaft = 112;
    const headL = 66;
    const halfShaft = 26;
    const halfHead = 58;
    const P = (along, side) => [ax + ux * along - uy * side, ay + uy * along + ux * side];
    ctx.poly(
      [P(0, -halfShaft), P(shaft, -halfShaft), P(shaft, -halfHead), P(shaft + headL, 0), P(shaft, halfHead), P(shaft, halfShaft), P(0, halfShaft)],
      { stroke: ctx.ink, fill: null, fillStyle: "none", strokeWidth: 2.4, roughness: ctx.preset.roughness }
    );
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const yA = H - (i + 1) * flightRise + 8;
        const rightSide = i % 2 === 0;
        const bx = rightSide ? n * flightRun + 30 : -30;
        const sx = rightSide ? (i + 1) * flightRun - 6 : i * flightRun + 6;
        ctx.line(
          [
            [sx, yA],
            [bx + (rightSide ? -16 : 16), yA]
          ],
          { color: ctx.mutedInk, width: 1.4 }
        );
        dot(ctx, sx, yA, 8, role.color, 3);
        if (item.icon) ctx.icon(item.icon, bx + (rightSide ? 22 : -22), yA - 44, 36, role.color);
        ctx.labelBlock(item.label, item.detail, bx, yA, { color: role.color, align: rightSide ? "left" : "right", maxW: 210 });
      })
    );
  }
});
const KART_D = "M8 38 L8 27 Q8 20 16 20 L36 20 Q41 8 52 8 Q63 8 68 20 L86 20 Q94 20 94 29 L94 36 Q94 41 87 41 L15 41 Q8 41 8 38 Z M28 41 a8.5 8.5 0 1 0 0.01 0 Z M72 41 a8.5 8.5 0 1 0 0.01 0 Z";
registerViz({
  name: "race",
  category: "Visual Metaphors",
  summary: "Karts racing toward the finish line, staggered by rank.",
  entryKinds: ["item", "racer", "kart"],
  options: [{ name: "finish", type: "string", description: "banner text over the finish gate (default FINISH)" }],
  sweetSpot: { min: 2, max: 5 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "racer", "kart");
    const n = Math.max(items.length, 1);
    const laneH = 96;
    const kw = 112;
    const kh = 58;
    const labelW = 52 + Math.max(120, ...items.map((it) => ctx.measureLabelBlock(it.label, it.detail, { maxW: 170, size: 18 }).w));
    const finishX = labelW + 470;
    const H = n * laneH;
    for (let i = 0; i <= n; i++) {
      const y = i * laneH;
      if (i === 0 || i === n) ctx.line([[labelW - 16, y], [finishX + 54, y]], { color: ctx.ink, width: 2.2 });
      else ctx.line([[labelW - 16, y], [finishX + 54, y]], { color: ctx.mutedInk, width: 1.3, dash: true });
    }
    const sq = 12;
    for (let r2 = 0; r2 < Math.ceil(H / sq); r2++) {
      for (let c = 0; c < 2; c++) {
        if ((r2 + c) % 2 === 0) {
          ctx.shape("rectangle", finishX + c * sq, r2 * sq, sq, Math.min(sq, H - r2 * sq), { stroke: ctx.ink, fill: ctx.ink, fillStyle: "solid", strokeWidth: 0.8, roughness: 0.5 });
        }
      }
    }
    ctx.shape("rectangle", finishX, 0, sq * 2, H, { stroke: ctx.ink, fill: null, fillStyle: "none", strokeWidth: 1.6, roughness: ctx.preset.roughness });
    ctx.label(optStr(spec.options, "finish") ?? "FINISH", finishX + sq, -22, { size: 16, color: ctx.ink, weight: 700, font: "heading" });
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const cy = i * laneH + laneH / 2;
        const front = finishX - 22 - i * 82 - Math.abs(jit$1(i, 12));
        ctx.path(KART_D, 102, 60, front - kw, cy - kh / 2 + 4, kw, kh, role, { id: ctx.uid(item.id) });
        ctx.line([[front - kw - 30, cy - 8], [front - kw - 10, cy - 8]], { color: ctx.mutedInk, width: 1.6 });
        ctx.line([[front - kw - 22, cy + 7], [front - kw - 5, cy + 7]], { color: ctx.mutedInk, width: 1.6 });
        ctx.labelBlock(item.label, item.detail, 0, cy, { color: role.color, align: "left", maxW: labelW - 40, size: 18 });
      })
    );
  }
});
const BUST_D = "M30 6 a11 11 0 1 0 0.01 0 Z M6 56 C6 40 16 33 30 33 C44 33 54 40 54 56";
registerViz({
  name: "dialogue",
  aliases: ["conversation"],
  category: "Visual Metaphors",
  summary: "A chat transcript between two speakers, bubbles alternating sides.",
  entryKinds: ["item", "msg", "turn", "message", "speaker"],
  options: [
    { name: "a", type: "string", description: "left speaker name (default A)" },
    { name: "b", type: "string", description: "right speaker name (default B)" }
  ],
  sweetSpot: { min: 2, max: 6 },
  generate(spec, ctx) {
    const msgs = itemsOf(spec, "item", "msg", "turn", "message");
    const speakers = spec.items.filter((i) => i.kind === "speaker");
    const nameA = optStr(spec.options, "a") ?? speakers[0]?.label ?? "A";
    const nameB = optStr(spec.options, "b") ?? speakers[1]?.label ?? "B";
    const roleA = ctx.role(0, { n: 2, color: speakers[0]?.color });
    const roleB = ctx.role(1, { n: 2, color: speakers[1]?.color });
    const bubbleW = 300;
    const indent = 140;
    let y = 0;
    msgs.forEach(
      (m, i) => ctx.item(m.id, () => {
        const sp = (optStr(m.opts, "speaker") ?? (i % 2 === 0 ? "a" : "b")).toLowerCase();
        const isA = sp !== "b";
        const role = isA ? roleA : roleB;
        const text = ctx.wrap(m.label + (m.detail ? ` ${m.detail}` : ""), bubbleW - 32, 15, "body", 6);
        const h = measureBlock(text, 15, ctx.font("body")).h + 26;
        const x = isA ? 0 : indent;
        ctx.shape("round-rectangle", x, y, bubbleW, h, role, { id: ctx.uid(m.id) });
        ctx.label(text, x + 16, y + h / 2, { size: 15, color: role.textColor, align: "left", z: 3 });
        y += h + 16;
      })
    );
    const by = y + 20;
    scoped(ctx, speakers[0], () => {
      ctx.path(BUST_D, 60, 58, -12, by, 64, 62, roleA, { id: ctx.uid("speaker_a") });
      ctx.label(nameA, 20, by + 84, { size: 17, color: roleA.color, weight: 700, font: "heading" });
    });
    scoped(ctx, speakers[1], () => {
      ctx.path(BUST_D, 60, 58, indent + bubbleW - 52, by, 64, 62, roleB, { id: ctx.uid("speaker_b") });
      ctx.label(nameB, indent + bubbleW - 20, by + 84, { size: 17, color: roleB.color, weight: 700, font: "heading" });
    });
  }
});
registerViz({
  name: "pillar",
  aliases: ["pillars"],
  category: "Visual Metaphors",
  summary: "Classical columns, one per pillar, icon + label in the shaft.",
  entryKinds: ["item", "pillar"],
  sweetSpot: { min: 2, max: 5 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "pillar");
    const n = Math.max(items.length, 1);
    const pitch = 190;
    const colW = 150;
    const shaftW = 106;
    const shaftH = 250;
    const shaftY = 38;
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const x = i * pitch;
        const cxC = x + colW / 2;
        ctx.shape("rectangle", x, 0, colW, 20, role);
        ctx.shape("rectangle", x + 12, 22, colW - 24, 12, role);
        const shaftX = x + (colW - shaftW) / 2;
        ctx.shape("rectangle", shaftX, shaftY, shaftW, shaftH, role, { id: ctx.uid(item.id) });
        ctx.shape("rectangle", x + 12, shaftY + shaftH + 4, colW - 24, 12, role);
        ctx.shape("rectangle", x, shaftY + shaftH + 18, colW, 20, role);
        for (const fx of [0.3, 0.5, 0.7]) {
          ctx.line(
            [
              [shaftX + shaftW * fx, shaftY + 150],
              [shaftX + shaftW * fx, shaftY + shaftH - 14]
            ],
            { color: role.textColor, width: 1.1 }
          );
        }
        ctx.icon(item.icon, cxC, shaftY + 42, 40, role.textColor);
        ctx.label(ctx.wrap(item.label, shaftW - 16, 18, "heading", 3), cxC, shaftY + 104, {
          size: 18,
          color: role.textColor,
          weight: ctx.preset.fonts.headingWeight,
          font: "heading"
        });
        if (item.detail) {
          ctx.label(ctx.wrap(item.detail, colW + 24, 14, "body", 4), cxC, shaftY + shaftH + 52, { size: 14, color: ctx.mutedInk, vAnchor: "top" });
        }
      })
    );
  }
});
registerViz({
  name: "bottleneck",
  category: "Visual Metaphors",
  summary: "Flow crowding through a bottle's neck — many in, few out.",
  entryKinds: ["item"],
  options: [
    { name: "count", type: "number", description: "upstream circle count, 6-28 (default 16)" },
    { name: "in", type: "string", description: "caption over the wide inlet" },
    { name: "out", type: "string", description: "caption over the outlet" },
    { name: "neck", type: "string", description: "caption naming the constraint, arrowed at the neck" }
  ],
  generate(spec, ctx) {
    const items = itemsOf(spec, "item");
    const role = ctx.role(0, { n: 1, color: items[0]?.color });
    const W = 720;
    const halfIn = 66;
    const halfNeck = 16;
    const halfOut = 54;
    const aEnd = 218;
    const neckL = 296;
    const neckR = 424;
    const bStart = 502;
    const ease = (t) => (1 - Math.cos(Math.PI * t)) / 2;
    const half = (x) => {
      if (x <= aEnd) return halfIn;
      if (x < neckL) return lerp(halfIn, halfNeck, ease((x - aEnd) / (neckL - aEnd)));
      if (x <= neckR) return halfNeck;
      if (x < bStart) return lerp(halfNeck, halfOut, ease((x - neckR) / (bStart - neckR)));
      return halfOut;
    };
    const topC = [];
    const botC = [];
    for (let x = 0; x <= W; x += 8) {
      topC.push([x, -half(x)]);
      botC.push([x, half(x)]);
    }
    ctx.line(topC, { color: ctx.ink, width: 2.4, id: ctx.uid("pipe") });
    ctx.line(botC, { color: ctx.ink, width: 2.4 });
    const count = Math.max(6, Math.min(28, optNum(spec.options, "count") ?? 16));
    for (let k = 0; k < count; k++) {
      const bx = 20 + k * 53.7 % (aEnd + 20 - 34);
      const clear = half(bx + 6) - 13;
      const by = -clear + k * 37.3 % (clear * 2);
      ctx.shape("circle", bx - 6, by - 6, 12, 12, role);
    }
    for (let k = 0; k < 8; k++) {
      const bx = aEnd - 26 + k * 29.3 % (neckL - aEnd + 4);
      const clear = half(bx) - 12;
      if (clear < 9) continue;
      const by = -clear + k * 23.7 % (clear * 2);
      ctx.shape("circle", bx - 6, by - 6, 12, 12, role);
    }
    for (const [ex, ey] of [
      [258, -4],
      [314, 2],
      [360, -2],
      [406, 1]
    ]) {
      ctx.shape("circle", ex - 6, ey - 6, 12, 12, role);
    }
    for (const [ex, ey] of [
      [548, -16],
      [612, 12],
      [676, -6]
    ]) {
      ctx.shape("circle", ex - 6, ey - 6, 12, 12, role);
    }
    for (const ay of [-40, 0, 40]) ctx.arrow(-78, ay, -16, ay, { color: ctx.preset.edge, width: 2 });
    ctx.arrow(W + 16, 0, W + 78, 0, { color: ctx.preset.edge, width: 2 });
    const inLabel = optStr(spec.options, "in");
    const outLabel = optStr(spec.options, "out");
    if (inLabel) ctx.label(inLabel, -47, -halfIn - 24, { size: 16, color: ctx.ink, maxW: 150 });
    if (outLabel) ctx.label(outLabel, W + 47, -halfOut - 24, { size: 16, color: ctx.ink, maxW: 150 });
    const neckCap = optStr(spec.options, "neck");
    if (neckCap) {
      const ncx = (neckL + neckR) / 2;
      ctx.arrow(ncx, halfNeck + 92, ncx, halfNeck + 18, { color: ctx.ink, width: 2 });
      ctx.label(ctx.wrap(neckCap, 220, 17, "heading", 2), ncx, halfNeck + 112, { size: 17, color: ctx.ink, weight: 700, font: "heading", vAnchor: "top" });
    }
  }
});
registerViz({
  name: "iceberg",
  category: "Parts of Whole",
  summary: "The visible tip vs the hidden mass below the waterline.",
  entryKinds: ["above", "below", "item"],
  sweetSpot: { min: 2, max: 5 },
  generate(spec, ctx) {
    let aboveItems = spec.items.filter((i) => i.kind === "above");
    let belowItems = spec.items.filter((i) => i.kind === "below");
    if (!aboveItems.length && !belowItems.length) {
      const items = itemsOf(spec, "item");
      aboveItems = items.slice(0, 1);
      belowItems = items.slice(1);
    }
    const total = Math.max(aboveItems.length + belowItems.length, 2);
    const roleOf = (it, idx) => ctx.role(idx, { n: total, color: it?.color });
    const W = 660;
    const wl = [];
    for (let x = -20; x <= W; x += 16) wl.push([x, Math.sin(x / 30) * 5]);
    ctx.line(wl, { color: ctx.mutedInk, width: 1.8 });
    const aboveRole = roleOf(aboveItems[0], 0);
    scoped(
      ctx,
      aboveItems[0],
      () => ctx.poly(
        [
          [330, -2],
          [372, -58],
          [404, -34],
          [446, -120],
          [482, -52],
          [516, -80],
          [552, -2]
        ],
        aboveRole,
        { id: aboveItems[0] ? ctx.uid(aboveItems[0].id) : ctx.uid("peak") }
      )
    );
    const belowRole = roleOf(belowItems[0], aboveItems.length || 1);
    scoped(
      ctx,
      belowItems[0],
      () => ctx.poly(
        [
          [318, 8],
          [566, 8],
          [602, 96],
          [548, 162],
          [578, 232],
          [500, 296],
          [448, 350],
          [396, 292],
          [330, 220],
          [352, 140],
          [300, 78]
        ],
        belowRole,
        { id: belowItems[0] ? ctx.uid(belowItems[0].id) : ctx.uid("mass") }
      )
    );
    const entry = (item, role, y, endX) => {
      const b = ctx.labelBlock(item.label, item.detail, 0, y, { color: role.color, align: "left", maxW: 210 });
      let lx = b.x + b.w + 12;
      if (item.icon) {
        ctx.icon(item.icon, lx + 16, y, 30, role.color);
        lx += 38;
      }
      ctx.line(
        [
          [lx, y],
          [endX - 8, y]
        ],
        { color: ctx.mutedInk, width: 1.4 }
      );
      dot(ctx, endX, y, 7, role.color, 3);
    };
    aboveItems.forEach((item, j) => ctx.item(item.id, () => entry(item, roleOf(item, j), -46 - j * 52, 355 + j * 18)));
    belowItems.forEach(
      (item, j) => ctx.item(item.id, () => {
        const y = belowItems.length === 1 ? 160 : 60 + 260 * j / (belowItems.length - 1);
        entry(item, roleOf(item, aboveItems.length + j), y, lerp(322, 428, y / 350));
      })
    );
  }
});
function outline(ctx, color, strokeWidth) {
  return { stroke: color, fill: null, fillStyle: "none", strokeWidth: strokeWidth ?? ctx.preset.strokeWidth, roughness: ctx.preset.roughness };
}
registerViz({
  name: "flywheel",
  category: "Business Frameworks",
  summary: "Thick ring segments spinning clockwise — a self-reinforcing momentum loop.",
  entryKinds: ["item", "stage", "center"],
  options: [{ name: "center", type: "string", description: "label inside the wheel (or use a `center` entry)" }],
  sweetSpot: { min: 3, max: 6 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "stage");
    const n = Math.max(items.length, 1);
    const centerEntry = spec.items.find((i) => i.kind === "center");
    const centerLabel = centerEntry?.label ?? optStr(spec.options, "center");
    const R = 158;
    const inner = 0.6;
    const gapDeg = 18;
    const seg = 360 / n;
    const rMid = R * (1 + inner) / 2;
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const start = -90 + i * seg + gapDeg / 2;
        const end = -90 + (i + 1) * seg - gapDeg / 2;
        ctx.shape(
          "sector",
          -R,
          -R,
          R * 2,
          R * 2,
          role,
          { id: ctx.uid(item.id), data: { start, end, inner } }
        );
        const tip = polar(0, 0, rMid, end + 11);
        const baseO = polar(0, 0, R * 0.965, end + 0.5);
        const baseI = polar(0, 0, R * (inner + 0.035), end + 0.5);
        ctx.poly([baseO, tip, baseI], { stroke: role.stroke, fill: role.fill ?? role.color, fillStyle: "solid", strokeWidth: role.strokeWidth, roughness: ctx.preset.roughness });
        const mid = (start + end) / 2;
        if (item.icon) {
          const [ix, iy] = polar(0, 0, rMid, mid);
          ctx.icon(item.icon, ix, iy, 30, role.textColor);
        }
        radialLabel(ctx, 0, 0, R, mid, item.label, item.detail, role.color, { maxW: 190 });
      })
    );
    if (centerLabel) {
      const draw = () => {
        ctx.label(ctx.wrap(centerLabel, R * inner * 1.5, 22, "heading", 3), 0, 0, { size: 22, color: ctx.ink, weight: 700, font: "heading", z: 3 });
        if (centerEntry?.detail) ctx.label(ctx.wrap(centerEntry.detail, R * inner * 1.5, 14, "body", 2), 0, 34, { size: 14, color: ctx.mutedInk, z: 3, role: "detail" });
      };
      if (centerEntry) ctx.item(centerEntry.id, draw);
      else draw();
    }
  }
});
registerViz({
  name: "radar",
  category: "Data",
  summary: "Spider chart — 1-3 series polygons over 4-8 labeled axes.",
  entryKinds: ["axis", "series", "item"],
  options: [{ name: "max", type: "number", description: "scale maximum (default: largest value)" }],
  sweetSpot: { min: 4, max: 8 },
  generate(spec, ctx) {
    let axes = itemsOf(spec, "axis");
    let series = itemsOf(spec, "series");
    if (!axes.length) {
      const items = itemsOf(spec, "item");
      axes = items;
      if (!series.length && items.some((i) => i.value !== void 0)) {
        series = [{ kind: "series", id: "s1", label: "", detail: void 0, value: void 0, values: items.map((i) => i.value ?? 0), strings: [], opts: {}, children: [] }];
      }
    }
    const K = Math.max(axes.length, 3);
    const R = 150;
    const max = optNum(spec.options, "max") ?? Math.max(1, ...series.flatMap((s) => s.values));
    const angle = (i) => -90 + i * 360 / K;
    const ringPts = (f) => axes.map((_, i) => polar(0, 0, R * f, angle(i)));
    for (let i = 0; i < K; i++) ctx.line([[0, 0], polar(0, 0, R, angle(i))], { color: ctx.mutedInk, width: 1.1 });
    for (const f of [1 / 3, 2 / 3]) ctx.poly(ringPts(f), { ...outline(ctx, ctx.mutedInk, 1.1), strokeStyle: "dashed" });
    ctx.poly(ringPts(1), outline(ctx, ctx.mutedInk, 1.6));
    axes.forEach(
      (ax, i) => ctx.item(ax.id, () => {
        radialLabel(ctx, 0, 0, R, angle(i), ax.label, ax.detail, ctx.ink, { maxW: 150, gap: 12 });
      })
    );
    const legendY = R + 74;
    let legendX = series.length > 1 ? (-(series.length * 130) + 26) / 2 : 0;
    series.forEach(
      (s, si) => ctx.item(s.id, () => {
        const role = ctx.role(si, { n: Math.max(series.length, 2), color: s.color });
        const pts = axes.map((_, i) => polar(0, 0, R * Math.max(0, Math.min(max, s.values[i] ?? 0)) / max, angle(i)));
        ctx.poly(pts, { stroke: role.color, fill: role.softFill, fillStyle: "solid", strokeWidth: 2.6, roughness: ctx.preset.roughness, opacity: 60 });
        for (const [px, py] of pts) ctx.shape("circle", px - 5, py - 5, 10, 10, { stroke: role.color, fill: role.color, fillStyle: "solid", strokeWidth: 1, roughness: 0.6 });
        if (s.label && series.length > 1) {
          ctx.shape("rectangle", legendX, legendY - 7, 15, 15, { stroke: role.color, fill: role.softFill, fillStyle: "solid", strokeWidth: 1.6, roughness: ctx.preset.roughness });
          ctx.label(s.label, legendX + 23, legendY + 1, { size: 15, color: ctx.ink, align: "left" });
          legendX += 130;
        }
      })
    );
  }
});
registerViz({
  name: "roadmap-lanes",
  category: "Timelines",
  summary: "Workstream swimlanes × time columns — the product-roadmap slide.",
  entryKinds: ["lane", "task", "milestone", "item"],
  options: [{ name: "scale", type: "string[]", description: 'column headers, e.g. ["Q1","Q2","Q3","Q4"]' }],
  sweetSpot: { min: 2, max: 5 },
  generate(spec, ctx) {
    const lanes = itemsOf(spec, "lane", "item").filter((l) => l.children.length);
    const scale = spec.options.scale?.map(String) ?? ["Q1", "Q2", "Q3", "Q4"];
    const cols = scale.length;
    const colW = 158;
    const rowH = 44;
    const lanePad = 14;
    const labelW = 24 + Math.max(90, ...lanes.map((l) => ctx.measure(l.label, 18, "heading")));
    const gridW = cols * colW;
    const headerH = 40;
    scale.forEach((tick, c) => {
      ctx.label(tick, labelW + c * colW + colW / 2, headerH / 2 - 8, { size: 16, color: ctx.mutedInk, weight: ctx.preset.fonts.headingWeight, font: "heading" });
    });
    let y = headerH;
    const laneTop = [];
    lanes.forEach((lane, li) => {
      laneTop[li] = y;
      y += lanePad * 2 + lane.children.length * rowH;
    });
    const totalH = y;
    for (let c = 0; c <= cols; c++) {
      ctx.line([[labelW + c * colW, headerH - 6], [labelW + c * colW, totalH]], { color: ctx.mutedInk, width: 1.1, dash: true });
    }
    lanes.forEach((lane, li) => {
      const role = ctx.role(li, { n: Math.max(lanes.length, 2), color: lane.color });
      const top = laneTop[li];
      const h = lanePad * 2 + lane.children.length * rowH;
      ctx.item(lane.id, () => {
        ctx.line([[0, top], [labelW + gridW, top]], { color: ctx.mutedInk, width: 1.4 });
        if (lane.icon) ctx.icon(lane.icon, 15, top + h / 2, 24, role.color);
        ctx.label(ctx.wrap(lane.label, labelW - 44, 18, "heading", 2), lane.icon ? 34 : 4, top + h / 2, { size: 18, color: role.color, weight: ctx.preset.fonts.headingWeight, font: "heading", align: "left" });
      });
      lane.children.forEach((task, ti) => {
        ctx.item(task.id, () => {
          const cy = top + lanePad + ti * rowH + rowH / 2;
          const start = task.values[0] ?? 0;
          const end = task.values[1] ?? start + 1;
          if (task.kind === "milestone") {
            const mx = labelW + start * colW;
            ctx.shape("diamond", mx - 11, cy - 11, 22, 22, { stroke: role.color, fill: role.fill ?? role.color, fillStyle: "solid", strokeWidth: role.strokeWidth, roughness: ctx.preset.roughness });
            ctx.label(task.label, mx + 18, cy, { size: 15, color: ctx.ink, align: "left" });
            return;
          }
          const bx = labelW + start * colW;
          const bw = Math.max(colW * 0.35, (end - start) * colW);
          ctx.shape("pill", bx, cy - 15, bw, 30, { stroke: role.stroke, fill: role.fill ?? role.softFill, fillStyle: role.fillStyle, strokeWidth: role.strokeWidth, roughness: ctx.preset.roughness }, { id: ctx.uid(task.id) });
          const fits = ctx.measure(task.label, 15) < bw - 20;
          if (fits) ctx.label(task.label, bx + bw / 2, cy, { size: 15, color: role.textColor });
          else ctx.label(task.label, bx + bw + 10, cy, { size: 15, color: ctx.ink, align: "left" });
        });
      });
    });
    ctx.line([[0, totalH], [labelW + gridW, totalH]], { color: ctx.mutedInk, width: 1.4 });
  }
});
registerViz({
  name: "milestone-path",
  category: "Timelines",
  summary: "A winding trail to a summit flag, milestones marked along the way.",
  entryKinds: ["item", "milestone", "goal"],
  options: [{ name: "goal", type: "string", description: "summit flag label (or use a `goal` entry)" }],
  sweetSpot: { min: 3, max: 6 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "milestone");
    const n = Math.max(items.length, 1);
    const goalEntry = spec.items.find((i) => i.kind === "goal");
    const goalLabel = goalEntry?.label ?? optStr(spec.options, "goal");
    const way = [
      [10, 400],
      [210, 372],
      [330, 316],
      [176, 256],
      [66, 206],
      [210, 146],
      [352, 96],
      [452, 38]
    ];
    const pts = catmull(way, 14);
    ctx.line(pts, { color: ctx.ink, width: 2.6, dash: true });
    ctx.line([[-16, 406], [58, 406]], { color: ctx.ink, width: 2.2 });
    const [sx, sy] = pts[pts.length - 1];
    const gRole = ctx.role(n, { n: n + 1, color: goalEntry?.color });
    const drawFlag = () => {
      ctx.line([[sx, sy], [sx, sy - 58]], { color: gRole.color, width: 2.6 });
      ctx.poly(
        [
          [sx, sy - 58],
          [sx + 48, sy - 47],
          [sx, sy - 36]
        ],
        { stroke: gRole.stroke, fill: gRole.fill ?? gRole.color, fillStyle: "solid", strokeWidth: gRole.strokeWidth, roughness: ctx.preset.roughness }
      );
      if (goalLabel) ctx.labelBlock(goalLabel, goalEntry?.detail, sx + 60, sy - 64, { color: gRole.color, align: "left", maxW: 180, vAnchor: "top" });
    };
    if (goalEntry) ctx.item(goalEntry.id, drawFlag);
    else drawFlag();
    const cum = [0];
    for (let i = 1; i < pts.length; i++) cum[i] = cum[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]);
    const total = cum[cum.length - 1];
    const at2 = (s) => {
      const target = s * total;
      let i = cum.findIndex((c) => c >= target);
      if (i < 0) i = pts.length - 1;
      return { p: pts[i], i };
    };
    const marks = items.map((item, i) => {
      const { p } = at2((i + 1) / (n + 0.6));
      const m = ctx.measureLabelBlock(item.label, item.detail, { maxW: 170 });
      const side = i % 2 === 0 ? 1 : -1;
      const lx = p[0] + side * 26;
      return { item, i, p, side, lx, w: m.w, h: m.h, labelY: p[1] + (item.icon ? 8 : 0) };
    });
    const boxOf = (m) => ({
      x0: m.side > 0 ? m.lx : m.lx - m.w,
      x1: m.side > 0 ? m.lx + m.w : m.lx,
      y0: m.labelY - m.h / 2,
      y1: m.labelY + m.h / 2
    });
    for (let pass = 0; pass < 4; pass++) {
      for (let a = 0; a < marks.length; a++) {
        for (let b = a + 1; b < marks.length; b++) {
          const A = boxOf(marks[a]);
          const B = boxOf(marks[b]);
          if (A.x0 < B.x1 - 8 && B.x0 < A.x1 - 8 && A.y0 < B.y1 - 6 && B.y0 < A.y1 - 6) {
            marks[b].labelY = A.y0 - marks[b].h / 2 - 12;
          }
        }
      }
    }
    marks.forEach(
      ({ item, i, p, side, lx, labelY }) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n: n + 1, color: item.color });
        ctx.shape("circle", p[0] - 8, p[1] - 8, 16, 16, { stroke: role.stroke, fill: role.fill ?? role.color, fillStyle: "solid", strokeWidth: role.strokeWidth, roughness: 0.8 }, { id: ctx.uid(item.id) });
        if (item.icon) ctx.icon(item.icon, p[0], p[1] - 30, 26, role.color);
        if (Math.abs(labelY - p[1]) > 24) ctx.line([[p[0] + side * 12, p[1]], [lx + side * 6, labelY]], { color: ctx.preset.edge, width: 1.2, dotted: true });
        ctx.labelBlock(item.label, item.detail, lx, labelY, { color: role.color, align: side > 0 ? "left" : "right", maxW: 170 });
      })
    );
  }
});
function catmull(way, per) {
  const out = [];
  for (let i = 0; i < way.length - 1; i++) {
    const p0 = way[i - 1] ?? way[i];
    const p1 = way[i];
    const p2 = way[i + 1];
    const p3 = way[i + 2] ?? p2;
    for (let j = 0; j < per; j++) {
      const t = j / per;
      const t2 = t * t;
      const t3 = t2 * t;
      out.push([
        0.5 * (2 * p1[0] + (-p0[0] + p2[0]) * t + (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2 + (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3),
        0.5 * (2 * p1[1] + (-p0[1] + p2[1]) * t + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2 + (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3)
      ]);
    }
  }
  out.push(way[way.length - 1]);
  return out;
}
registerViz({
  name: "value-chain",
  category: "Business Frameworks",
  summary: "Porter-style chevron band; optional support-activity bars above.",
  entryKinds: ["item", "stage", "support"],
  sweetSpot: { min: 3, max: 6 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "stage");
    const supports = spec.items.filter((i) => i.kind === "support");
    const n = Math.max(items.length, 1);
    const W = 168;
    const H = 104;
    const overlap = 26;
    const pitch = W - overlap;
    const bandW = (n - 1) * pitch + W;
    supports.forEach(
      (s, si) => ctx.item(s.id, () => {
        const sy = -34 * (supports.length - si) - 18;
        ctx.shape("rectangle", 0, sy, bandW, 28, { stroke: ctx.mutedInk, fill: null, fillStyle: "none", strokeWidth: 1.6, roughness: ctx.preset.roughness }, { id: ctx.uid(s.id) });
        ctx.label(s.label, 14, sy + 14, { size: 15, color: ctx.mutedInk, align: "left" });
      })
    );
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const x = i * pitch;
        ctx.shape("chevron", x, 0, W, H, role, { id: ctx.uid(item.id), data: { dir: "right", notch: 0.16 } });
        const cx = x + W / 2 + (i === 0 ? -4 : 6);
        if (item.icon) {
          ctx.icon(item.icon, cx, H / 2 - 18, 26, role.textColor);
          ctx.label(ctx.wrap(item.label, W - 62, 17, "heading", 2), cx, H / 2 + 16, { size: 17, color: role.textColor, weight: ctx.preset.fonts.headingWeight, font: "heading" });
        } else {
          ctx.label(ctx.wrap(item.label, W - 62, 17, "heading", 3), cx, H / 2, { size: 17, color: role.textColor, weight: ctx.preset.fonts.headingWeight, font: "heading" });
        }
        if (item.detail) {
          ctx.label(ctx.wrap(item.detail, W - 28, 14, "body", 3), cx, H + 30, { size: 14, color: ctx.mutedInk, role: "detail", vAnchor: "top" });
        }
      })
    );
  }
});
registerViz({
  name: "pricing-tiers",
  category: "Comparison",
  summary: "Plan cards with price + feature lists; one tier can be highlighted.",
  entryKinds: ["tier", "plan", "item"],
  options: [
    { name: "period", type: "string", description: 'price suffix, e.g. "/mo"' },
    { name: "currency", type: "string", description: 'price prefix (default "$")' },
    { name: "showValues", type: "boolean", description: "print prices (default true)" }
  ],
  sweetSpot: { min: 2, max: 4 },
  generate(spec, ctx) {
    const tiers = itemsOf(spec, "tier", "plan", "item");
    const n = Math.max(tiers.length, 1);
    const period = optStr(spec.options, "period") ?? "/mo";
    const currency = optStr(spec.options, "currency") ?? "$";
    const W = 212;
    const gap = 30;
    const maxFeatures = Math.max(0, ...tiers.map((t) => t.children.length));
    const headH = 118;
    const H = headH + maxFeatures * 30 + 26;
    const lift = 20;
    tiers.forEach(
      (tier, i) => ctx.item(tier.id, () => {
        const role = ctx.role(i, { n, color: tier.color });
        const hot = tier.opts.highlight === true || tier.opts.recommended === true;
        const x = i * (W + gap);
        const y = hot ? -lift : 0;
        const h = H + (hot ? lift * 2 : 0);
        ctx.shape(
          "round-rectangle",
          x,
          y,
          W,
          h,
          hot ? { stroke: role.color, fill: role.softFill, fillStyle: "solid", strokeWidth: 3, roughness: ctx.preset.roughness, roundness: 14 } : { stroke: ctx.ink, fill: null, fillStyle: "none", strokeWidth: 1.8, roughness: ctx.preset.roughness, roundness: 14 },
          { id: ctx.uid(tier.id) }
        );
        if (hot) {
          const bw = 118;
          ctx.shape("pill", x + W / 2 - bw / 2, y - 15, bw, 30, { stroke: role.color, fill: role.fill ?? role.color, fillStyle: "solid", strokeWidth: role.strokeWidth, roughness: ctx.preset.roughness });
          ctx.label(String(tier.opts.badge ?? "Popular"), x + W / 2, y, { size: 14, color: role.textColor, weight: 700 });
        }
        const cx = x + W / 2;
        ctx.label(tier.label, cx, y + 40, { size: 20, color: hot ? role.color : ctx.ink, weight: 700, font: "heading" });
        if (tier.value !== void 0 && ctx.showValue(tier)) {
          ctx.label(`${currency}${fmtNum(tier.value)}`, cx - 4, y + 78, { size: 34, color: ctx.ink, weight: 700, font: "heading", role: "value" });
          const pw = ctx.measure(`${currency}${fmtNum(tier.value)}`, 34, "heading");
          ctx.label(period, cx + pw / 2 + 4, y + 86, { size: 14, color: ctx.mutedInk, align: "left", role: "value" });
        } else if (tier.detail) {
          ctx.label(ctx.wrap(tier.detail, W - 30, 15, "body", 2), cx, y + 78, { size: 15, color: ctx.mutedInk, role: "detail" });
        }
        ctx.line([[x + 18, y + headH - 12], [x + W - 18, y + headH - 12]], { color: ctx.mutedInk, width: 1.2 });
        tier.children.forEach((f, fi) => {
          const fy = y + headH + 8 + fi * 30;
          ctx.icon(f.icon ?? "check", x + 28, fy, 17, role.color);
          ctx.label(ctx.wrap(f.label, W - 66, 15, "body", 1), x + 44, fy, { size: 15, color: ctx.ink, align: "left" });
        });
      })
    );
  }
});
const clamp = (v, lo, hi) => v < lo ? lo : v > hi ? hi : v;
registerViz({
  name: "okr",
  category: "Business Frameworks",
  summary: "One objective branching into key-result cards with progress bars.",
  entryKinds: ["item", "kr", "objective"],
  options: [
    { name: "objective", type: "string", description: "objective text (or use an `objective` entry / the title)" },
    { name: "showValues", type: "boolean", description: "print progress percentages (default true)" }
  ],
  sweetSpot: { min: 2, max: 4 },
  generate(spec, ctx) {
    const krs = itemsOf(spec, "item", "kr");
    const n = Math.max(krs.length, 1);
    const objEntry = spec.items.find((i) => i.kind === "objective");
    const objective = objEntry?.label ?? optStr(spec.options, "objective") ?? spec.title;
    if (objective && objective === spec.title) ctx.titleHandled = true;
    const cardW = 224;
    const gap = 30;
    const totalW = n * cardW + (n - 1) * gap;
    const objText = ctx.wrap(objective ?? "Objective", 300, 20, "heading", 3);
    const objW = Math.max(220, ...objText.split("\n").map((l) => ctx.measure(l, 20, "heading"))) + 48;
    const objH = objText.split("\n").length * 26 + 30;
    const objX = totalW / 2 - objW / 2;
    const drawObj = () => {
      ctx.shape("round-rectangle", objX, 0, objW, objH, { stroke: ctx.ink, fill: null, fillStyle: "none", strokeWidth: 2.6, roughness: ctx.preset.roughness, roundness: 12 }, { id: ctx.uid("objective") });
      ctx.label(objText, totalW / 2, objH / 2, { size: 20, color: ctx.ink, weight: 700, font: "heading" });
    };
    if (objEntry) ctx.item(objEntry.id, drawObj);
    else drawObj();
    const cardTop = objH + 58;
    const labelHs = krs.map((kr) => ctx.measureLabelBlock(kr.label, kr.detail, { maxW: cardW - 40, size: 16 }).h);
    const cardH = Math.max(96, ...labelHs.map((h) => h + 58));
    krs.forEach(
      (kr, i) => ctx.item(kr.id, () => {
        const role = ctx.role(i, { n, color: kr.color });
        const x = i * (cardW + gap);
        const cx = x + cardW / 2;
        const midY = objH + 28;
        ctx.line(
          [
            [totalW / 2, objH],
            [totalW / 2, midY],
            [cx, midY],
            [cx, cardTop]
          ],
          { color: ctx.preset.edge, width: 1.6 }
        );
        ctx.shape("round-rectangle", x, cardTop, cardW, cardH, { stroke: role.color, fill: null, fillStyle: "none", strokeWidth: 2, roughness: ctx.preset.roughness, roundness: 10 }, { id: ctx.uid(kr.id) });
        ctx.labelBlock(kr.label, kr.detail, x + 16, cardTop + 16, { color: ctx.ink, align: "left", maxW: cardW - 40, vAnchor: "top", size: 16 });
        const raw = kr.value ?? 0;
        const pct = clamp(raw <= 1 ? raw * 100 : raw, 0, 100);
        const barY = cardTop + cardH - 30;
        const barW = cardW - 32 - (ctx.showValue(kr) ? 46 : 0);
        ctx.shape("round-rectangle", x + 16, barY, barW, 13, { stroke: ctx.mutedInk, fill: null, fillStyle: "none", strokeWidth: 1.2, roughness: ctx.preset.roughness, roundness: 6 });
        if (pct > 3) {
          ctx.shape("round-rectangle", x + 16, barY, Math.max(10, barW * pct / 100), 13, { stroke: role.color, fill: role.fill ?? role.color, fillStyle: "solid", strokeWidth: 1, roughness: ctx.preset.roughness, roundness: 6 });
        }
        if (ctx.showValue(kr)) ctx.label(`${Math.round(pct)}%`, x + cardW - 16, barY + 7, { size: 16, color: role.color, weight: 700, align: "right", font: "heading", role: "value" });
      })
    );
  }
});
registerViz({
  name: "kanban",
  category: "Process",
  summary: "Named columns of hand-drawn cards — the task board.",
  entryKinds: ["column", "lane", "item"],
  sweetSpot: { min: 2, max: 4 },
  generate(spec, ctx) {
    const columns = itemsOf(spec, "column", "lane", "item").filter((c) => c.children.length || c.kind !== "item");
    const n = Math.max(columns.length, 1);
    const colW = 216;
    const gap = 24;
    const headerH = 52;
    const cardGap = 12;
    const stacks = columns.map(
      (col) => col.children.map((card) => {
        const text = ctx.wrap(card.label, colW - 56, 15, "body", 3);
        return { card, text, h: text.split("\n").length * 19 + 24 };
      })
    );
    const panelH = Math.max(170, ...stacks.map((s) => headerH + s.reduce((a, c) => a + c.h + cardGap, 0) + 16));
    columns.forEach((col, i) => {
      const role = ctx.role(i, { n, color: col.color });
      const x = i * (colW + gap);
      ctx.item(col.id, () => {
        ctx.shape("round-rectangle", x, 0, colW, panelH, { stroke: ctx.mutedInk, fill: null, fillStyle: "none", strokeWidth: 1.6, roughness: ctx.preset.roughness, roundness: 12 }, { id: ctx.uid(col.id) });
        ctx.label(col.label, x + 18, headerH / 2 + 2, { size: 18, color: role.color, weight: ctx.preset.fonts.headingWeight, font: "heading", align: "left" });
        const chipX = x + colW - 34;
        ctx.shape("circle", chipX, headerH / 2 - 13, 28, 28, { stroke: role.color, fill: role.softFill, fillStyle: "solid", strokeWidth: 1.6, roughness: ctx.preset.roughness });
        ctx.label(String(col.children.length), chipX + 14, headerH / 2 + 1, { size: 15, color: role.color, weight: 700, font: "heading" });
        ctx.line([[x + 12, headerH], [x + colW - 12, headerH]], { color: ctx.mutedInk, width: 1.2 });
      });
      let y = headerH + 14;
      stacks[i].forEach(({ card, text, h }) => {
        ctx.item(card.id, () => {
          ctx.shape("round-rectangle", x + 12, y, colW - 24, h, { stroke: role.stroke, fill: role.softFill, fillStyle: "solid", strokeWidth: 1.6, roughness: ctx.preset.roughness, roundness: 8 }, { id: ctx.uid(card.id) });
          if (card.icon) ctx.icon(card.icon, x + 30, y + h / 2, 18, role.color);
          ctx.label(text, x + (card.icon ? 44 : 26), y + h / 2, { size: 15, color: ctx.ink, align: "left" });
        });
        y += h + cardGap;
      });
    });
  }
});
registerViz({
  name: "decision-tree",
  category: "Comparison",
  summary: "Questions branching left-to-right through labeled yes/no edges to outcomes.",
  entryKinds: ["item", "question", "option"],
  sweetSpot: { min: 2, max: 3 },
  generate(spec, ctx) {
    const top = itemsOf(spec, "item", "question", "option");
    if (!top.length) return;
    let rootItem;
    if (top.length === 1) rootItem = top[0];
    else {
      rootItem = { kind: "question", id: "root", label: spec.title ?? "Decide", detail: void 0, value: void 0, values: [], strings: [], opts: {}, children: top };
      if (spec.title) ctx.titleHandled = true;
    }
    let leafSeq = 0;
    const build = (item) => {
      const children = item.children.map(build);
      const rows = children.length ? children.reduce((a, c) => a + c.rows, 0) : 1;
      return { item, children, rows, y: 0, role: children.length ? -1 : leafSeq++ };
    };
    const root = build(rootItem);
    const nLeaves = Math.max(leafSeq, 1);
    const rowH = 66;
    const assign = (node, topRow) => {
      node.y = (topRow + node.rows / 2) * rowH;
      let r2 = topRow;
      for (const c of node.children) {
        assign(c, r2);
        r2 += c.rows;
      }
    };
    assign(root, 0);
    const colW = [];
    const measure = (node, depth) => {
      const w = Math.max(96, ...ctx.wrap(node.item.label, 168, 16, "heading", 3).split("\n").map((l) => ctx.measure(l, 16, "heading"))) + (node.item.icon ? 72 : 40);
      colW[depth] = Math.max(colW[depth] ?? 0, w);
      node.children.forEach((c) => measure(c, depth + 1));
    };
    measure(root, 0);
    const hGap = 86;
    const colX = [];
    colW.forEach((w, d) => colX[d] = d === 0 ? 0 : colX[d - 1] + colW[d - 1] + hGap);
    const draw = (node, depth) => {
      const isLeaf = !node.children.length;
      const w = colW[depth];
      const text = ctx.wrap(node.item.label, 168, 16, "heading", 3);
      const h = Math.max(46, text.split("\n").length * 21 + 18);
      const x = colX[depth];
      ctx.item(node.item.id, () => {
        const role = isLeaf ? ctx.role(node.role, { n: nLeaves, color: node.item.color }) : void 0;
        if (isLeaf && role) {
          ctx.shape("pill", x, node.y - h / 2, w, h, role, { id: ctx.uid(node.item.id) });
          if (node.item.icon) {
            ctx.icon(node.item.icon, x + 26, node.y, 20, role.textColor);
            ctx.label(text, x + 44, node.y, { size: 16, color: role.textColor, weight: ctx.preset.fonts.headingWeight, font: "heading", align: "left" });
          } else {
            ctx.label(text, x + w / 2, node.y, { size: 16, color: role.textColor, weight: ctx.preset.fonts.headingWeight, font: "heading" });
          }
        } else {
          ctx.shape("round-rectangle", x, node.y - h / 2, w, h, { stroke: ctx.ink, fill: null, fillStyle: "none", strokeWidth: 2.2, roughness: ctx.preset.roughness, roundness: 10 }, { id: ctx.uid(node.item.id) });
          ctx.label(text, x + w / 2, node.y, { size: 16, color: ctx.ink, weight: ctx.preset.fonts.headingWeight, font: "heading" });
        }
        if (node.item.detail && isLeaf) {
          ctx.label(ctx.wrap(node.item.detail, 180, 13, "body", 2), x + w + 12, node.y, { size: 13, color: ctx.mutedInk, align: "left", role: "detail" });
        }
      });
      node.children.forEach((c) => {
        const x1 = x + w;
        const x2 = colX[depth + 1];
        const mx = x1 + (x2 - x1) / 2;
        ctx.item(c.item.id, () => {
          ctx.line(
            [
              [x1, node.y],
              [mx, node.y],
              [mx, c.y],
              [x2 - 8, c.y]
            ],
            { color: ctx.preset.edge, width: 1.7, arrow: true }
          );
          const when = typeof c.item.opts.when === "string" ? c.item.opts.when : typeof c.item.opts.label === "string" ? c.item.opts.label : void 0;
          if (when) ctx.label(when, (mx + x2 - 8) / 2, c.y - 13, { size: 13, color: ctx.mutedInk, weight: 700 });
        });
        draw(c, depth + 1);
      });
    };
    draw(root, 0);
  }
});
registerViz({
  name: "heatmap",
  category: "Data",
  summary: "A matrix of intensity-shaded cells — risk matrices, skills grids.",
  entryKinds: ["row", "item"],
  options: [
    { name: "cols", type: "string[]", description: 'column headers, e.g. ["Q1","Q2","Q3"]' },
    { name: "max", type: "number", description: "intensity ceiling (default: largest value)" },
    { name: "showValues", type: "boolean", description: "print cell values (default true)" }
  ],
  sweetSpot: { min: 2, max: 7 },
  generate(spec, ctx) {
    const rows = itemsOf(spec, "row", "item");
    const colNames = spec.options.cols?.map(String) ?? (spec.options.columns?.map(String) ?? []);
    const nCols = Math.max(colNames.length, ...rows.map((r2) => r2.values.length), 1);
    const max = optNum(spec.options, "max") ?? Math.max(1, ...rows.flatMap((r2) => r2.values));
    const cellW = 72;
    const cellH = 48;
    const gap = 7;
    const labelW = 20 + Math.max(60, ...rows.map((r2) => ctx.measure(r2.label, 16)));
    const accent = ctx.role(0, { n: 1 }).color;
    for (let c = 0; c < nCols; c++) {
      ctx.label(colNames[c] ?? String(c + 1), labelW + c * (cellW + gap) + cellW / 2, 0, { size: 15, color: ctx.mutedInk, weight: ctx.preset.fonts.headingWeight, font: "heading" });
    }
    rows.forEach(
      (row, r2) => ctx.item(row.id, () => {
        const cy = 26 + r2 * (cellH + gap) + cellH / 2;
        ctx.label(row.label, labelW - 14, cy, { size: 16, color: ctx.ink, align: "right" });
        for (let c = 0; c < nCols; c++) {
          const v = row.values[c];
          const x = labelW + c * (cellW + gap);
          if (v === void 0) {
            ctx.shape("round-rectangle", x, cy - cellH / 2, cellW, cellH, { stroke: ctx.mutedInk, fill: null, fillStyle: "none", strokeWidth: 1, roughness: ctx.preset.roughness, roundness: 8, strokeStyle: "dashed" });
            continue;
          }
          const t = clamp(v / max, 0, 1);
          ctx.shape("round-rectangle", x, cy - cellH / 2, cellW, cellH, { stroke: accent, fill: accent, fillStyle: "solid", strokeWidth: 1.2, roughness: ctx.preset.roughness, roundness: 8, opacity: Math.round(16 + t * 82) });
          if (ctx.showValue(row)) {
            ctx.label(fmtNum(v), x + cellW / 2, cy, { size: 15, color: t > 0.55 ? ctx.preset.background : ctx.ink, weight: 700, font: "heading", role: "value", z: 3 });
          }
        }
      })
    );
  }
});
registerViz({
  name: "slope-chart",
  category: "Data",
  summary: "Before → after lines, one per series — rank and magnitude change at a glance.",
  entryKinds: ["item", "series"],
  options: [
    { name: "left", type: "string", description: 'left column header (default "Before")' },
    { name: "right", type: "string", description: 'right column header (default "After")' },
    { name: "showValues", type: "boolean", description: "print endpoint values (default true)" }
  ],
  sweetSpot: { min: 2, max: 6 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "series").filter((i) => i.values.length >= 2);
    const n = Math.max(items.length, 1);
    const leftHdr = optStr(spec.options, "left") ?? "Before";
    const rightHdr = optStr(spec.options, "right") ?? "After";
    const H = Math.max(240, n * 62);
    const xL = 0;
    const xR = 300;
    const all = items.flatMap((i) => [i.values[0], i.values[1]]);
    const lo = Math.min(...all);
    const hi = Math.max(...all);
    const span = hi - lo || 1;
    const yOf = (v) => 26 + (H - 52) * (1 - (v - lo) / span);
    ctx.label(leftHdr, xL, -26, { size: 17, color: ctx.mutedInk, weight: ctx.preset.fonts.headingWeight, font: "heading" });
    ctx.label(rightHdr, xR, -26, { size: 17, color: ctx.mutedInk, weight: ctx.preset.fonts.headingWeight, font: "heading" });
    ctx.line([[xL, 0], [xL, H]], { color: ctx.mutedInk, width: 1.4 });
    ctx.line([[xR, 0], [xR, H]], { color: ctx.mutedInk, width: 1.4 });
    const relax = (ys) => {
      const order = ys.map((y, i) => [y, i]).sort((a, b) => a[0] - b[0]);
      const out = [...ys];
      for (let k = 1; k < order.length; k++) {
        const [prevY] = [out[order[k - 1][1]]];
        if (out[order[k][1]] - prevY < 26) out[order[k][1]] = prevY + 26;
      }
      return out;
    };
    const yLs = relax(items.map((i) => yOf(i.values[0])));
    const yRs = relax(items.map((i) => yOf(i.values[1])));
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const [v0, v1] = item.values;
        const y0 = yOf(v0);
        const y1 = yOf(v1);
        ctx.line([[xL, y0], [xR, y1]], { color: role.color, width: 2.6 });
        for (const [px, py] of [[xL, y0], [xR, y1]]) {
          ctx.shape("circle", px - 6, py - 6, 12, 12, { stroke: role.color, fill: role.fill ?? role.color, fillStyle: "solid", strokeWidth: 1, roughness: 0.7 });
        }
        const lv = ctx.showValue(item) ? `  ${fmtNum(v0)}` : "";
        const rv = ctx.showValue(item) ? `${fmtNum(v1)}` : "";
        ctx.label(`${item.label}${lv}`, xL - 14, yLs[i], { size: 16, color: role.color, weight: ctx.preset.fonts.headingWeight, font: "heading", align: "right" });
        if (rv) ctx.label(rv, xR + 14, yRs[i], { size: 16, color: role.color, weight: 700, font: "heading", align: "left", role: "value" });
      })
    );
  }
});
registerViz({
  name: "tug-of-war",
  category: "Visual Metaphors",
  summary: "Two teams pulling a rope — the marker drifts toward the stronger side.",
  entryKinds: ["side", "team"],
  options: [{ name: "tilt", type: "left|right|balanced", description: "override the computed balance" }],
  sweetSpot: { min: 2, max: 2 },
  generate(spec, ctx) {
    const sides = itemsOf(spec, "side", "team").slice(0, 2);
    if (!sides.length) return;
    const weigh = (s) => s?.value ?? (s?.children.reduce((a, c) => a + (c.value ?? 1), 0) || 1);
    const [L, R] = [sides[0], sides[1]];
    const wL = weigh(L);
    const wR = weigh(R);
    const tilt = optStr(spec.options, "tilt");
    const bias = tilt === "left" ? -0.5 : tilt === "right" ? 0.5 : tilt === "balanced" ? 0 : clamp((wR - wL) / (wL + wR), -0.5, 0.5);
    const ropeY = 150;
    const midX = 280;
    const knotX = midX + bias * 88;
    ctx.line([[midX, ropeY - 40], [midX, ropeY + 52]], { color: ctx.mutedInk, width: 1.3, dash: true });
    ctx.line([[92, ropeY - 2], [knotX, ropeY + 3]], { color: ctx.ink, width: 2.6 });
    ctx.line([[knotX, ropeY + 3], [468, ropeY - 2]], { color: ctx.ink, width: 2.6 });
    ctx.line([[knotX, ropeY + 3], [knotX, ropeY + 36]], { color: ctx.ink, width: 1.8 });
    ctx.poly(
      [
        [knotX, ropeY + 14],
        [knotX + 20, ropeY + 20.5],
        [knotX, ropeY + 27]
      ],
      { stroke: ctx.ink, fill: ctx.ink, fillStyle: "solid", strokeWidth: 1.2, roughness: 0.7 }
    );
    const figure = (x, away, color) => {
      ctx.character("pulling", x, ropeY + 46, 104, { color, flip: away === 1, emotion: "determined" });
      ctx.line([[x - away * 22, ropeY + 48], [x + away * 26, ropeY + 48]], { color: ctx.mutedInk, width: 1.5 });
    };
    sides.forEach(
      (side, si) => ctx.item(side.id, () => {
        const role = ctx.role(si, { n: 2, color: side.color });
        const away = si === 0 ? -1 : 1;
        figure(si === 0 ? 202 : 358, away, role.color);
        figure(si === 0 ? 128 : 432, away, role.color);
        const lx = si === 0 ? 40 : 520;
        const align = si === 0 ? "left" : "right";
        ctx.label(side.label, lx, ropeY + 84, { size: 19, color: role.color, weight: 700, font: "heading", align });
        side.children.forEach((f, fi) => {
          ctx.label(ctx.wrap(f.label, 210, 14, "body", 2), lx, ropeY + 112 + fi * 26, { size: 14, color: ctx.mutedInk, align, role: "detail" });
        });
        if (side.icon) ctx.icon(side.icon, si === 0 ? lx + 12 : lx - 12, ropeY - 78, 28, role.color);
      })
    );
  }
});
function rot(pts, cx, cy, deg) {
  const a = rad(deg);
  const c = Math.cos(a);
  const s = Math.sin(a);
  return pts.map(([x, y]) => [cx + (x - cx) * c - (y - cy) * s, cy + (x - cx) * s + (y - cy) * c]);
}
const BMC_CELLS = [
  { keys: ["partners", "key-partners"], title: "Key Partners", icon: "handshake" },
  { keys: ["activities", "key-activities"], title: "Key Activities", icon: "gear" },
  { keys: ["resources", "key-resources"], title: "Key Resources", icon: "key" },
  { keys: ["value", "value-proposition", "value-prop"], title: "Value Proposition", icon: "diamond" },
  { keys: ["relationships", "customer-relationships"], title: "Customer Relationships", icon: "heart" },
  { keys: ["channels"], title: "Channels", icon: "megaphone" },
  { keys: ["segments", "customers", "customer-segments"], title: "Customer Segments", icon: "users" },
  { keys: ["costs", "cost", "cost-structure"], title: "Cost Structure", icon: "chart" },
  { keys: ["revenue", "revenue-streams", "income"], title: "Revenue Streams", icon: "dollar" }
];
registerViz({
  name: "business-model-canvas",
  category: "Business Frameworks",
  summary: "The classic 9-box BMC grid, sections filled with bullet lists.",
  entryKinds: ["partners", "activities", "resources", "value", "relationships", "channels", "segments", "costs", "revenue", "item"],
  sweetSpot: { min: 5, max: 9 },
  generate(spec, ctx) {
    const generics = itemsOf(spec, "item", "section");
    let g = 0;
    const sections = BMC_CELLS.map((cell) => {
      const byKind = spec.items.find((i) => cell.keys.includes(i.kind));
      return byKind ?? generics[g++];
    });
    const colW = 176;
    const topH = 300;
    const botH = 104;
    const W = colW * 5;
    const frames = [
      [0, 0, colW, topH],
      [colW, 0, colW, topH / 2],
      [colW, topH / 2, colW, topH / 2],
      [colW * 2, 0, colW, topH],
      [colW * 3, 0, colW, topH / 2],
      [colW * 3, topH / 2, colW, topH / 2],
      [colW * 4, 0, colW, topH],
      [0, topH, W / 2, botH],
      [W / 2, topH, W / 2, botH]
    ];
    frames.forEach(([x, y, w, h], ci) => {
      const cell = BMC_CELLS[ci];
      const section = sections[ci];
      const role = ctx.role(ci, { n: 9, color: section?.color });
      const draw = () => {
        ctx.shape("rectangle", x, y, w, h, { stroke: ctx.ink, fill: null, fillStyle: "none", strokeWidth: 1.8, roughness: ctx.preset.roughness }, { id: ctx.uid(section?.id ?? cell.keys[0]) });
        const title = section?.label || cell.title;
        ctx.label(ctx.wrap(title, w - 52, 15, "heading", 2), x + 12, y + 20, { size: 15, color: role.color, weight: 700, font: "heading", align: "left", vAnchor: "top" });
        ctx.icon(section?.icon ?? cell.icon, x + w - 20, y + 20, 18, role.color);
        const bullets = section?.children ?? [];
        let by = y + 52 + (ctx.wrap(title, w - 52, 15, "heading", 2).includes("\n") ? 16 : 0);
        for (const b of bullets) {
          if (by > y + h - 16) break;
          const text = ctx.wrap(b.label, w - 40, 13, "body", 2);
          const lines = text.split("\n").length;
          ctx.shape("circle", x + 14, by - 3, 6, 6, { stroke: role.color, fill: role.color, fillStyle: "solid", strokeWidth: 1, roughness: 0.5 });
          ctx.label(text, x + 27, by + (lines - 1) * 8, { size: 13, color: ctx.ink, align: "left" });
          by += lines * 17 + 8;
        }
      };
      if (section) ctx.item(section.id, draw);
      else draw();
    });
  }
});
registerViz({
  name: "ecosystem",
  category: "Business Frameworks",
  summary: "Concentric stakeholder orbits around one center.",
  entryKinds: ["center", "ring", "orbit", "item"],
  sweetSpot: { min: 2, max: 3 },
  generate(spec, ctx) {
    const center = spec.items.find((i) => i.kind === "center");
    const rings = itemsOf(spec, "ring", "orbit", "item").filter((r2) => r2.children.length);
    const nR = Math.max(rings.length, 1);
    const cRole = ctx.role(0, { neutral: true });
    const drawCenter = () => {
      ctx.shape("circle", -46, -46, 92, 92, cRole, { id: ctx.uid(center?.id ?? "center") });
      if (center?.icon) {
        ctx.icon(center.icon, 0, -18, 28, cRole.textColor);
        ctx.label(ctx.wrap(center.label, 80, 15, "heading", 2), 0, 16, { size: 15, color: cRole.textColor, weight: 700, font: "heading" });
      } else {
        ctx.label(ctx.wrap(center?.label ?? spec.title ?? "Core", 80, 16, "heading", 3), 0, 0, { size: 16, color: cRole.textColor, weight: 700, font: "heading" });
      }
    };
    if (center) ctx.item(center.id, drawCenter);
    else drawCenter();
    if (!center && spec.title) ctx.titleHandled = true;
    rings.forEach(
      (ring2, ri) => ctx.item(ring2.id, () => {
        const role = ctx.role(ri, { n: nR, color: ring2.color });
        const R = 128 + ri * 92;
        const orbit = [];
        for (let a = 0; a <= 72; a++) orbit.push(polar(0, 0, R, a * 360 / 72));
        ctx.poly(orbit, { stroke: ctx.mutedInk, fill: null, fillStyle: "none", strokeWidth: 1.2, strokeStyle: "dashed", roughness: ctx.preset.roughness });
        const k = ring2.children.length;
        radialLabel(ctx, 0, 0, R + 2, -90 + ri * 45 - 180 / k, ring2.label, void 0, role.color, { gap: 4, size: 14 });
        ring2.children.forEach((m, mi) => {
          const deg = -90 + ri * 45 + mi * 360 / k;
          const [px, py] = polar(0, 0, R, deg);
          ctx.shape("circle", px - 27, py - 27, 54, 54, { stroke: role.color, fill: role.softFill, fillStyle: "solid", strokeWidth: 1.8, roughness: ctx.preset.roughness }, { id: ctx.uid(m.id) });
          if (m.icon) ctx.icon(m.icon, px, py, 24, role.color);
          else ctx.label(m.label.slice(0, 2), px, py, { size: 16, color: role.color, weight: 700, font: "heading" });
          if (ri === nR - 1) radialLabel(ctx, px, py, 29, deg, m.label, void 0, ctx.ink, { maxW: 110, gap: 6, size: 13 });
          else ctx.label(ctx.wrap(m.label, 100, 13, "body", 2), px, py + 40, { size: 13, color: ctx.ink, vAnchor: "top" });
        });
      })
    );
  }
});
registerViz({
  name: "swimlane-flow",
  category: "Process",
  summary: "A flowchart over responsibility lanes — who does what, in order.",
  entryKinds: ["lane", "step", "item"],
  sweetSpot: { min: 2, max: 4 },
  generate(spec, ctx) {
    const lanes = itemsOf(spec, "lane", "item").filter((l) => l.children.length);
    if (!lanes.length) return;
    let seq = 0;
    const steps = lanes.flatMap((lane, li) => lane.children.map((s) => ({ s, li, order: s.value ?? seq++ }))).sort((a, b) => a.order - b.order);
    const nSteps = steps.length;
    const laneH = 104;
    const boxW = 148;
    const boxH = 58;
    const pitch = boxW + 46;
    const labelW = 28 + Math.max(84, ...lanes.map((l) => ctx.measure(ctx.wrap(l.label, 110, 16, "heading", 2).split("\n")[0], 16, "heading")));
    const W = labelW + nSteps * pitch + 20;
    lanes.forEach((lane, li) => {
      const y = li * laneH;
      ctx.item(lane.id, () => {
        ctx.line([[0, y], [W, y]], { color: ctx.mutedInk, width: li === 0 ? 2 : 1.4 });
        const role = ctx.role(li, { n: lanes.length, color: lane.color });
        if (lane.icon) ctx.icon(lane.icon, 16, y + laneH / 2 - 16, 22, role.color);
        ctx.label(ctx.wrap(lane.label, labelW - 34, 16, "heading", 2), 4, y + laneH / 2 + (lane.icon ? 14 : 0), { size: 16, color: role.color, weight: ctx.preset.fonts.headingWeight, font: "heading", align: "left" });
      });
    });
    ctx.line([[0, lanes.length * laneH], [W, lanes.length * laneH]], { color: ctx.mutedInk, width: 2 });
    ctx.line([[labelW - 10, 0], [labelW - 10, lanes.length * laneH]], { color: ctx.mutedInk, width: 1.2, dash: true });
    const posOf = (k) => [labelW + steps[k].order * pitch + 10, steps[k].li * laneH + laneH / 2];
    steps.forEach(({ s, li }, k) => {
      const [x, cy] = posOf(k);
      const role = ctx.role(li, { n: lanes.length, color: s.color ?? lanes[li].color });
      ctx.item(s.id, () => {
        ctx.shape("round-rectangle", x, cy - boxH / 2, boxW, boxH, role, { id: ctx.uid(s.id) });
        ctx.label(ctx.wrap(s.label, boxW - 24 - (s.icon ? 20 : 0), 14, "heading", 2), x + boxW / 2 + (s.icon ? 11 : 0), cy, { size: 14, color: role.textColor, weight: ctx.preset.fonts.headingWeight, font: "heading" });
        if (s.icon) ctx.icon(s.icon, x + 18, cy, 18, role.textColor);
        if (k < nSteps - 1) {
          const [nx, ny] = posOf(k + 1);
          if (ny === cy) {
            ctx.arrow(x + boxW, cy, nx - 6, cy, { color: ctx.preset.edge, width: 1.8 });
          } else {
            const mx = (x + boxW + nx) / 2;
            ctx.line(
              [
                [x + boxW, cy],
                [mx, cy],
                [mx, ny],
                [nx - 6, ny]
              ],
              { color: ctx.preset.edge, width: 1.8, arrow: true }
            );
          }
        }
      });
    });
  }
});
registerViz({
  name: "bullet-chart",
  category: "Data",
  summary: "KPI rows — actual bar vs a target tick over a qualitative band.",
  entryKinds: ["item", "kpi"],
  options: [
    { name: "max", type: "number", description: "scale ceiling (default: largest value/target)" },
    { name: "showValues", type: "boolean", description: "print actual values (default true)" }
  ],
  sweetSpot: { min: 2, max: 6 },
  generate(spec, ctx) {
    const rows = itemsOf(spec, "item", "kpi");
    const n = Math.max(rows.length, 1);
    const trackW = 330;
    const rowH = 62;
    const labelW = 22 + Math.max(80, ...rows.map((r2) => ctx.measure(r2.label, 16)));
    const max = optNum(spec.options, "max") ?? Math.max(1, ...rows.flatMap((r2) => [r2.values[0] ?? 0, r2.values[1] ?? (typeof r2.opts.target === "number" ? r2.opts.target : 0)])) * 1.08;
    rows.forEach(
      (row, i) => ctx.item(row.id, () => {
        const role = ctx.role(i, { n, color: row.color });
        const cy = i * rowH + rowH / 2;
        const actual = row.values[0] ?? 0;
        const target = row.values[1] ?? (typeof row.opts.target === "number" ? row.opts.target : void 0);
        ctx.label(row.label, labelW - 14, cy, { size: 16, color: ctx.ink, align: "right" });
        ctx.shape("rectangle", labelW, cy - 13, trackW, 26, { stroke: ctx.mutedInk, fill: role.softFill, fillStyle: "solid", strokeWidth: 1.2, roughness: ctx.preset.roughness, opacity: 60 });
        ctx.shape("rectangle", labelW, cy - 6, Math.max(6, trackW * Math.min(actual, max) / max), 12, { stroke: role.color, fill: role.fill ?? role.color, fillStyle: "solid", strokeWidth: 1, roughness: ctx.preset.roughness }, { id: ctx.uid(row.id) });
        if (target !== void 0) {
          const tx = labelW + trackW * Math.min(target, max) / max;
          ctx.line([[tx, cy - 19], [tx, cy + 19]], { color: ctx.ink, width: 2.6 });
        }
        if (ctx.showValue(row)) {
          const txt = fmtNum(actual) + (target !== void 0 ? ` / ${fmtNum(target)}` : "");
          ctx.label(txt, labelW + trackW + 14, cy, { size: 15, color: role.color, weight: 700, font: "heading", align: "left", role: "value" });
        }
      })
    );
  }
});
registerViz({
  name: "domino",
  category: "Cause and Effect",
  summary: "A chain reaction — tiles toppling left to right into the outcome.",
  entryKinds: ["item", "cause", "step"],
  sweetSpot: { min: 3, max: 6 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "cause", "step");
    const n = Math.max(items.length, 1);
    const tileW = 30;
    const tileH = 118;
    const pitch = 96;
    const groundY = 0;
    ctx.line([[-58, groundY], [(n - 1) * pitch + tileW + 58, groundY]], { color: ctx.ink, width: 2.4 });
    ctx.arrow(-52, -tileH - 26, -6, -tileH + 4, { color: ctx.ink, width: 2.2 });
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const x = i * pitch;
        const tip = Math.max(0, 62 - i * (62 / Math.max(n - 1.4, 1)));
        const corners = [
          [x, groundY - tileH],
          [x + tileW, groundY - tileH],
          [x + tileW, groundY],
          [x, groundY]
        ];
        const pts = tip > 0 ? rot(corners, x + tileW, groundY, tip) : corners;
        ctx.poly(pts, role, { id: ctx.uid(item.id) });
        const [px, py] = tip > 0 ? rot([[x + tileW / 2, groundY - tileH + 22]], x + tileW, groundY, tip)[0] : [x + tileW / 2, groundY - tileH + 22];
        ctx.shape("circle", px - 4, py - 4, 8, 8, { stroke: role.textColor, fill: role.textColor, fillStyle: "solid", strokeWidth: 1, roughness: 0.5 });
        const row = i % 2;
        ctx.labelBlock(item.label, item.detail, x + tileW / 2 + 8, groundY + 26 + row * 62, { color: role.color, align: "center", maxW: 150, vAnchor: "top" });
        if (row) ctx.line([[x + tileW / 2 + 8, groundY + 6], [x + tileW / 2 + 8, groundY + 22 + 62]], { color: ctx.preset.edge, width: 1.2, dotted: true });
        if (item.icon) {
          const [ix, iy] = tip > 0 ? rot([[x + tileW / 2, groundY - tileH - 24]], x + tileW, groundY, tip)[0] : [x + tileW / 2, groundY - tileH - 24];
          ctx.icon(item.icon, ix, iy, 24, role.color);
        }
      })
    );
  }
});
registerViz({
  name: "lighthouse",
  category: "Visual Metaphors",
  summary: "A lighthouse beam sweeping over labeled rocks — guidance past the risks.",
  entryKinds: ["item", "rock", "risk"],
  options: [{ name: "ship", type: "string", description: "label under the ship sailing past" }],
  sweetSpot: { min: 2, max: 4 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "rock", "risk");
    const n = Math.max(items.length, 1);
    const waterY = 226;
    const W = 700;
    ctx.poly(
      [
        [10, waterY],
        [36, waterY - 34],
        [86, waterY - 44],
        [142, waterY - 30],
        [168, waterY]
      ],
      { stroke: ctx.ink, fill: null, fillStyle: "none", strokeWidth: 2.2, roughness: ctx.preset.roughness }
    );
    const beamRole = ctx.role(0, { n: 1 });
    ctx.poly(
      [
        [66, waterY - 40],
        [78, 84],
        [104, 84],
        [116, waterY - 40]
      ],
      { stroke: ctx.ink, fill: null, fillStyle: "none", strokeWidth: 2.2, roughness: ctx.preset.roughness },
      { id: ctx.uid("tower") }
    );
    for (const ty of [waterY - 78, waterY - 116]) ctx.line([[70 + (waterY - 40 - ty) * -0.085, ty], [112 + (waterY - 40 - ty) * 0.085, ty]], { color: ctx.mutedInk, width: 1.6 });
    ctx.shape("rectangle", 74, 56, 34, 28, { stroke: ctx.ink, fill: null, fillStyle: "none", strokeWidth: 2, roughness: ctx.preset.roughness });
    ctx.poly(
      [
        [70, 56],
        [91, 36],
        [112, 56]
      ],
      { stroke: ctx.ink, fill: null, fillStyle: "none", strokeWidth: 2, roughness: ctx.preset.roughness }
    );
    ctx.poly(
      [
        [110, 62],
        [W - 40, 128],
        [W - 40, waterY - 14],
        [112, 82]
      ],
      { stroke: ctx.mutedInk, fill: beamRole.softFill, fillStyle: "solid", strokeWidth: 1.1, roughness: ctx.preset.roughness, opacity: 62 }
    );
    for (const [dx, dy] of [
      [-20, -14],
      [0, -22],
      [20, -14]
    ]) {
      ctx.line([[91 + dx * 0.5, 40 + dy * 0.5], [91 + dx, 40 + dy]], { color: ctx.ink, width: 1.8 });
    }
    const wl = [];
    for (let x = 150; x <= W; x += 14) wl.push([x, waterY + Math.sin(x / 26) * 4]);
    ctx.line(wl, { color: ctx.mutedInk, width: 1.8 });
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i + 1, { n: n + 1, color: item.color });
        const rx = 232 + i * (W - 320) / Math.max(n - 0.4, 1);
        const rw = 46 + i % 2 * 12;
        ctx.poly(
          [
            [rx, waterY + 4],
            [rx + rw * 0.22, waterY - 20 - i % 2 * 8],
            [rx + rw * 0.55, waterY - 9],
            [rx + rw * 0.8, waterY - 24],
            [rx + rw, waterY + 4]
          ],
          { stroke: role.color, fill: null, fillStyle: "none", strokeWidth: 2.2, roughness: ctx.preset.roughness },
          { id: ctx.uid(item.id) }
        );
        const row = i % 2;
        const ly = waterY + 40 + row * 60;
        ctx.line([[rx + rw / 2, waterY + 8], [rx + rw / 2, ly - 6]], { color: ctx.preset.edge, width: 1.2, dotted: true });
        ctx.labelBlock(item.label, item.detail, rx + rw / 2, ly, { color: role.color, align: "center", maxW: 150, vAnchor: "top" });
      })
    );
    const shipLabel = optStr(spec.options, "ship");
    const sx = W - 66;
    ctx.poly(
      [
        [sx - 40, waterY - 6],
        [sx + 40, waterY - 6],
        [sx + 26, waterY + 16],
        [sx - 26, waterY + 16]
      ],
      { stroke: ctx.ink, fill: null, fillStyle: "none", strokeWidth: 2.2, roughness: ctx.preset.roughness }
    );
    ctx.line([[sx, waterY - 6], [sx, waterY - 58]], { color: ctx.ink, width: 2 });
    ctx.poly(
      [
        [sx, waterY - 58],
        [sx + 34, waterY - 22],
        [sx, waterY - 22]
      ],
      { stroke: ctx.ink, fill: null, fillStyle: "none", strokeWidth: 2, roughness: ctx.preset.roughness }
    );
    if (shipLabel) ctx.label(shipLabel, sx, waterY - 76, { size: 15, color: ctx.ink, weight: 700, font: "heading" });
  }
});
registerViz({
  name: "magnet",
  category: "Visual Metaphors",
  summary: "A horseshoe magnet pulling item chips in — attraction and retention.",
  entryKinds: ["item"],
  options: [{ name: "label", type: "string", description: "caption under the magnet" }],
  sweetSpot: { min: 2, max: 5 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item");
    const n = Math.max(items.length, 1);
    const cx = 120;
    const cy = 150;
    const RO = 86;
    const RI = 40;
    const legX = cx + 96;
    const body = [[legX, cy - RO]];
    for (let a = -90; a <= 90; a += 6) body.push(polar(cx, cy, RO, 180 - a));
    body.push([legX, cy + RO], [legX, cy + RI]);
    for (let a = 90; a >= -90; a -= 6) body.push(polar(cx, cy, RI, 180 - a));
    body.push([legX, cy - RI]);
    ctx.poly(body, { stroke: ctx.ink, fill: null, fillStyle: "none", strokeWidth: 2.6, roughness: ctx.preset.roughness }, { id: ctx.uid("magnet") });
    const pole = (py, ri) => {
      const role = ctx.role(ri, { n: 2 });
      ctx.shape("rectangle", legX, py, 26, RO - RI, { stroke: role.stroke, fill: role.fill ?? role.color, fillStyle: "solid", strokeWidth: 1.6, roughness: ctx.preset.roughness });
    };
    pole(cy - RO, 0);
    pole(cy + RI, 1);
    for (const k of [0, 1, 2]) {
      const bow = 66 + k * 44;
      ctx.line(quadPts([legX + 28, cy - (RO + RI) / 2], [legX + bow + 40, cy], [legX + 28, cy + (RO + RI) / 2]), { color: ctx.mutedInk, width: 1.2, dash: true });
    }
    const caption = optStr(spec.options, "label");
    if (caption) ctx.label(ctx.wrap(caption, 190, 16, "heading", 2), cx + 30, cy + RO + 36, { size: 16, color: ctx.ink, weight: 700, font: "heading" });
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const spread = (i - (n - 1) / 2) / Math.max((n - 1) / 2, 1);
        const px = legX + 176 + Math.abs(spread) * 66 + i % 2 * 30;
        const py = cy + spread * 96;
        const text = ctx.wrap(item.label, 150, 15, "heading", 2);
        const tw = Math.max(...text.split("\n").map((l) => ctx.measure(l, 15, "heading")));
        const w = tw + 34 + (item.icon ? 22 : 0);
        const h = text.includes("\n") ? 54 : 38;
        ctx.shape("pill", px, py - h / 2, w, h, role, { id: ctx.uid(item.id) });
        if (item.icon) ctx.icon(item.icon, px + 20, py, 18, role.textColor);
        ctx.label(text, px + w / 2 + (item.icon ? 9 : 0), py, { size: 15, color: role.textColor, weight: ctx.preset.fonts.headingWeight, font: "heading" });
        ctx.line([[px - 30, py - 6], [px - 8, py - 6]], { color: ctx.mutedInk, width: 1.6 });
        ctx.line([[px - 24, py + 7], [px - 5, py + 7]], { color: ctx.mutedInk, width: 1.6 });
        if (item.detail) ctx.label(ctx.wrap(item.detail, 170, 13, "body", 2), px + w / 2, py + h / 2 + 16, { size: 13, color: ctx.mutedInk, role: "detail", vAnchor: "top" });
      })
    );
  }
});
function quadPts(p0, c, p1, segs = 16) {
  const pts = [];
  for (let s = 0; s <= segs; s++) {
    const t = s / segs;
    const u = 1 - t;
    pts.push([u * u * p0[0] + 2 * u * t * c[0] + t * t * p1[0], u * u * p0[1] + 2 * u * t * c[1] + t * t * p1[1]]);
  }
  return pts;
}
const jit = (i, amp) => Math.sin(i * 7.3) * amp;
const PERSONA_POSES = ["waving", "confident", "thinking", "cheering", "presenting", "pointing"];
registerViz({
  name: "personas",
  category: "Brainstorming",
  summary: "A cast of sketchnote characters — one per role/persona, posed and labeled.",
  entryKinds: ["item", "persona", "role"],
  options: [
    { name: "pose", type: "string", description: "per item: action pose (see the character library; poses cycle when unset)" },
    { name: "emotion", type: "string", description: "per item: facial expression" },
    { name: "shirt", type: "string", description: "per item: clothing style (+ shirtColor)" },
    { name: "hair", type: "string", description: "per item: hair style (+ hairColor)" },
    { name: "accessory", type: "string", description: "per item: glasses / hat / beard … (+ accessoryColor)" },
    { name: "fx", type: "string", description: "per item: floating mark — sweat / question / idea / stars … (+ fxColor)" },
    { name: "prop", type: "string", description: "per item: any icon name, held in hand" }
  ],
  sweetSpot: { min: 2, max: 6 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "persona", "role");
    const n = Math.max(items.length, 1);
    const figH = 128;
    const blockW = Math.max(150, ...items.map((it) => ctx.measureLabelBlock(it.label, it.detail, { maxW: 180, size: 18 }).w));
    const pitch = Math.max(206, blockW + 44);
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const cx = i * pitch + pitch / 2;
        const pose = typeof item.opts.pose === "string" ? item.opts.pose : PERSONA_POSES[i % PERSONA_POSES.length];
        const chOpts = characterOptsFrom(item.opts);
        ctx.character(pose, cx, figH + 26, figH, { color: role.color, propColor: role.color, ...chOpts, prop: chOpts.prop ?? item.icon });
        ctx.line([[cx - 40, figH + 28], [cx + 40, figH + 28]], { color: ctx.mutedInk, width: 1.6 });
        ctx.labelBlock(item.label, item.detail, cx, figH + 52, { color: role.color, align: "center", maxW: 180, vAnchor: "top", size: 18 });
      })
    );
  }
});
registerViz({
  name: "quote",
  category: "Brainstorming",
  summary: "A big hand-lettered quote with attribution and a presenting character.",
  entryKinds: ["quote", "by", "item"],
  options: [
    { name: "by", type: "string", description: "attribution line (or use a `by` entry)" },
    { name: "pose", type: "string", description: 'character pose (default "presenting"; "none" hides the figure)' },
    { name: "emotion", type: "string", description: "character emotion" },
    { name: "prop", type: "string", description: "icon the character holds" },
    { name: "shirt", type: "string", description: "character shirt style (+ shirtColor)" },
    { name: "hair", type: "string", description: "character hair style (+ hairColor)" },
    { name: "accessory", type: "string", description: "worn accessory — glasses / hat / beard … (+ accessoryColor)" },
    { name: "fx", type: "string", description: "floating state mark — sweat / question / idea / stars …" }
  ],
  sweetSpot: { min: 1, max: 1 },
  generate(spec, ctx) {
    const quoteEntry = spec.items.find((i) => i.kind === "quote" || i.kind === "item");
    const text = quoteEntry?.label ?? spec.title ?? "…";
    if (!quoteEntry && spec.title) ctx.titleHandled = true;
    const by = spec.items.find((i) => i.kind === "by")?.label ?? optStr(spec.options, "by");
    const accent = ctx.role(0, { n: 1 }).color;
    const wrapped = ctx.wrap(text, 430, 27, "heading", 5);
    const lines = wrapped.split("\n").length;
    const qh = lines * 27 * 1.3;
    const qx = 250;
    ctx.label("“", qx - 240, 6, { size: 86, color: accent, weight: 700, font: "title" });
    const drawQuote = () => {
      ctx.label(wrapped, qx, qh / 2 + 14, { size: 27, color: ctx.ink, weight: 700, font: "heading" });
      ctx.line(
        [
          [qx - 160, qh + 34],
          [qx + 160, qh + 30]
        ],
        { color: accent, width: 2.6 }
      );
      if (by) ctx.label(`— ${by}`, qx + 200, qh + 58, { size: 17, color: ctx.mutedInk, align: "right" });
    };
    if (quoteEntry) ctx.item(quoteEntry.id, drawQuote);
    else drawQuote();
    const pose = optStr(spec.options, "pose") ?? "presenting";
    if (pose !== "none" && listCharacterPoses().includes(pose)) {
      ctx.character(pose, qx - 306, qh + 112, 126, { color: ctx.ink, propColor: accent, shirtColor: accent, ...characterOptsFrom(spec.options) });
      ctx.line([[qx - 344, qh + 114], [qx - 266, qh + 114]], { color: ctx.mutedInk, width: 1.6 });
    }
  }
});
registerViz({
  name: "clouds",
  category: "Brainstorming",
  summary: "Scattered thought-cloud islands — a loose collection of ideas.",
  entryKinds: ["item", "idea", "cloud"],
  sweetSpot: { min: 3, max: 7 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "idea", "cloud");
    const n = Math.max(items.length, 1);
    const sized = items.map((it) => {
      const m = ctx.measureLabelBlock(it.label, it.detail, { maxW: 170, size: 18 });
      return { it, rx: Math.max(96, m.w / 2 + 40), ry: Math.max(62, m.h / 2 + (it.icon ? 24 : 0) + 36) };
    });
    const maxRx = Math.max(...sized.map((s) => s.rx));
    const maxRy = Math.max(...sized.map((s) => s.ry));
    const perRow = n <= 4 ? 2 : 3;
    const pitchX = maxRx * 2 + 44;
    const pitchY = maxRy * 2 + 26;
    sized.forEach(({ it, rx, ry }, i) => {
      const row = Math.floor(i / perRow);
      const col = i % perRow;
      const cx = col * pitchX + (row % 2 ? pitchX / 2 : 0) + maxRx + jit(i, 14);
      const cy = row * pitchY + maxRy + jit(i + 3, 10);
      ctx.item(it.id, () => {
        const role = ctx.role(i, { n, color: it.color });
        ctx.path(scallopedBlob(rx, ry, 9 + i % 3), rx * 2, ry * 2, cx - rx, cy - ry, rx * 2, ry * 2, { stroke: role.color, fill: role.softFill, fillStyle: "solid", strokeWidth: 2.2, roughness: ctx.preset.roughness }, { id: ctx.uid(it.id) });
        const iconLift = it.icon ? 14 : 0;
        if (it.icon) ctx.icon(it.icon, cx, cy - ry * 0.44, 26, role.color);
        ctx.labelBlock(it.label, it.detail, cx, cy + iconLift * 0.6, { color: ctx.ink, align: "center", maxW: 170, size: 18 });
      });
    });
  }
});
registerViz({
  name: "fishbone",
  category: "Cause and Effect",
  summary: "Ishikawa diagram — cause categories on angled bones along a spine to the effect.",
  entryKinds: ["bone", "category", "item", "effect", "problem"],
  sweetSpot: { min: 2, max: 6 },
  generate(spec, ctx) {
    const bones = itemsOf(spec, "bone", "category", "item").filter((b) => b.children.length || b.kind !== "item");
    const nB = Math.max(bones.length, 1);
    const effectEntry = spec.items.find((i) => i.kind === "effect" || i.kind === "problem");
    const effect = effectEntry?.label ?? spec.title ?? "Effect";
    if (!effectEntry && spec.title) ctx.titleHandled = true;
    const pairW = 224;
    const nPairs = Math.ceil(nB / 2);
    const spineEnd = 150 + nPairs * pairW;
    const boneDX = 104;
    const boneDY = 156;
    ctx.line([[24, -26], [0, 0], [24, 26]], { color: ctx.ink, width: 2.6 });
    ctx.arrow(6, 0, spineEnd + 4, 0, { color: ctx.ink, width: 3 });
    const headText = ctx.wrap(effect, 150, 17, "heading", 4);
    const headW = Math.max(120, ...headText.split("\n").map((l) => ctx.measure(l, 17, "heading"))) + 30;
    const headH = headText.split("\n").length * 23 + 24;
    const drawHead = () => {
      ctx.shape("round-rectangle", spineEnd + 12, -headH / 2, headW, headH, { stroke: ctx.ink, fill: null, fillStyle: "none", strokeWidth: 2.4, roughness: ctx.preset.roughness, roundness: 12 }, { id: ctx.uid("effect") });
      ctx.label(headText, spineEnd + 12 + headW / 2, 0, { size: 17, color: ctx.ink, weight: 700, font: "heading" });
    };
    if (effectEntry) ctx.item(effectEntry.id, drawHead);
    else drawHead();
    bones.forEach(
      (bone, i) => ctx.item(bone.id, () => {
        const role = ctx.role(i, { n: nB, color: bone.color });
        const up = i % 2 === 0;
        const pair = Math.floor(i / 2);
        const ax = 170 + pair * pairW + (up ? 0 : pairW / 2);
        const sign = up ? -1 : 1;
        const end = [ax - boneDX, sign * boneDY];
        ctx.line([[ax, 0], end], { color: role.color, width: 2.4 });
        ctx.labelBlock(bone.label, void 0, end[0], end[1] + sign * 12, { color: role.color, align: "center", maxW: 160, vAnchor: up ? "bottom" : "top" });
        bone.children.slice(0, 4).forEach((cause, j) => {
          const t = 0.78 - j * 0.2;
          const px = lerp(ax, end[0], t);
          const py = lerp(0, end[1], t);
          ctx.line([[px, py], [px - 40, py]], { color: ctx.mutedInk, width: 1.4 });
          ctx.label(ctx.wrap(cause.label, 128, 13, "body", 2), px - 46, py, { size: 13, color: ctx.ink, align: "right" });
        });
      })
    );
  }
});
registerViz({
  name: "head-thoughts",
  category: "Brainstorming",
  summary: "A profile-head container — what's going on in someone's mind.",
  entryKinds: ["item", "thought"],
  options: [{ name: "who", type: "string", description: "caption under the head" }],
  sweetSpot: { min: 2, max: 5 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "thought").slice(0, 6);
    const n = Math.max(items.length, 1);
    const HEAD_D = "M130 10 C 200 8 252 40 258 96 C 260 118 256 132 250 142 C 246 148 243 152 245 157 C 262 168 269 180 263 190 C 256 197 249 196 246 200 C 253 206 253 214 246 220 C 251 226 249 234 242 238 C 252 248 250 262 236 270 C 220 288 192 300 168 304 L 163 340 L 84 340 C 90 310 92 298 88 284 C 58 258 42 220 44 168 C 46 88 76 12 130 10 Z";
    const W = 330;
    const H = 396;
    ctx.path(HEAD_D, 300, 360, 0, 0, W, H, { stroke: ctx.ink, fill: null, fillStyle: "none", strokeWidth: 2.6, roughness: ctx.preset.roughness }, { id: ctx.uid("head") });
    const slots = [
      [142, 84],
      [148, 150],
      [144, 214],
      [142, 268],
      [150, 116],
      [148, 184]
    ];
    const order = n <= 4 ? [0, 1, 2, 3] : [4, 5, 2, 3, 0, 1];
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const [sx, sy] = slots[n <= 4 ? order[i] : order[i % order.length]];
        const px = sx / 300 * W;
        const py = sy / 360 * H;
        if (item.icon) {
          ctx.icon(item.icon, px - 62, py, 24, role.color);
          ctx.label(ctx.wrap(item.label, 118, 14, "heading", 2), px - 44, py, { size: 14, color: role.color, weight: ctx.preset.fonts.headingWeight, font: "heading", align: "left" });
        } else {
          ctx.shape("circle", px - 66, py - 4, 8, 8, { stroke: role.color, fill: role.color, fillStyle: "solid", strokeWidth: 1, roughness: 0.5 });
          ctx.label(ctx.wrap(item.label, 128, 14, "heading", 2), px - 50, py, { size: 14, color: role.color, weight: ctx.preset.fonts.headingWeight, font: "heading", align: "left" });
        }
      })
    );
    const who = optStr(spec.options, "who");
    if (who) ctx.label(who, W * 0.42, H + 26, { size: 17, color: ctx.mutedInk, weight: 700, font: "heading" });
  }
});
registerViz({
  name: "hex-cluster",
  category: "Business Frameworks",
  summary: "A honeycomb — one core hexagon ringed by up to six themed cells.",
  entryKinds: ["item", "cell", "center"],
  options: [{ name: "center", type: "string", description: "core cell label (or use a `center` entry)" }],
  sweetSpot: { min: 3, max: 6 },
  generate(spec, ctx) {
    const items = itemsOf(spec, "item", "cell").slice(0, 6);
    const n = Math.max(items.length, 1);
    const centerEntry = spec.items.find((i) => i.kind === "center");
    const centerLabel = centerEntry?.label ?? optStr(spec.options, "center") ?? spec.title;
    if (!centerEntry && centerLabel === spec.title && spec.title) ctx.titleHandled = true;
    const w = 172;
    const h = 150;
    const ringR = h * 1.06;
    const cell = (cx, cy, role, id) => ctx.shape("hexagon", cx - w / 2, cy - h / 2, w, h, role, { id });
    const coreRole = ctx.role(0, { neutral: true });
    const drawCore = () => {
      cell(0, 0, coreRole, ctx.uid(centerEntry?.id ?? "core"));
      if (centerEntry?.icon) ctx.icon(centerEntry.icon, 0, -22, 30, coreRole.textColor);
      ctx.label(ctx.wrap(centerLabel ?? "Core", w - 60, 17, "heading", 3), 0, centerEntry?.icon ? 14 : 0, { size: 17, color: coreRole.textColor, weight: 700, font: "heading" });
    };
    if (centerEntry) ctx.item(centerEntry.id, drawCore);
    else drawCore();
    items.forEach(
      (item, i) => ctx.item(item.id, () => {
        const role = ctx.role(i, { n, color: item.color });
        const ang = -90 + i * 360 / Math.max(n, 3);
        const cx = Math.cos(ang * Math.PI / 180) * ringR * 1.35;
        const cy = Math.sin(ang * Math.PI / 180) * ringR;
        cell(cx, cy, role, ctx.uid(item.id));
        if (item.icon) ctx.icon(item.icon, cx, cy - 26, 26, role.textColor);
        ctx.label(ctx.wrap(item.label, w - 56, 15, "heading", 3), cx, cy + (item.icon ? 12 : 0), { size: 15, color: role.textColor, weight: ctx.preset.fonts.headingWeight, font: "heading" });
        if (item.detail) ctx.label(ctx.wrap(item.detail, w + 10, 13, "body", 2), cx, cy + h / 2 + 20, { size: 13, color: ctx.mutedInk, role: "detail" });
      })
    );
  }
});
const VIZ_ALIASES = {
  // ---- Process --------------------------------------------------------------
  flowchart: ["workflow", "flow-chart", "steps-flow"],
  kanban: ["board", "task-board", "kanban-board"],
  "swimlane-flow": ["swimlanes", "cross-functional-flow", "raci-flow"],
  sequence: ["sequential", "step-by-step", "procedure"],
  stairs: ["steps", "step-up", "climb"],
  journey: ["journey-map", "user-journey", "path"],
  cycle: ["cyclic", "circular", "feedback-loop"],
  gantt: ["schedule", "project-plan", "gantt-chart"],
  // ---- Data -----------------------------------------------------------------
  bar: ["bar-chart", "bars", "vertical-bar"],
  "bar-horizontal": ["horizontal-bar", "bar-chart-horizontal"],
  "stacked-bar": ["stacked-column", "stacked-bars"],
  "stacked-bar-horizontal": ["stacked-hbar", "horizontal-stacked-bar"],
  line: ["line-chart", "line-graph"],
  area: ["area-chart", "filled-line"],
  waterfall: ["waterfall-chart", "cascade", "bridge-chart"],
  gauge: ["dial", "meter", "speedometer"],
  pie: ["pie-chart", "doughnut", "share"],
  "drop-off": ["attrition", "funnel-drop", "leakage"],
  "dumbbell-vertical": ["change-comparison", "yoy", "before-after-values"],
  "dumbbell-horizontal": ["goal-progress", "kpi-bars"],
  sankey: ["flow-diagram", "sankey-diagram", "flows"],
  radar: ["spider", "spider-chart", "radar-chart", "capability-map", "skills-chart"],
  heatmap: ["heat-map", "intensity-grid", "risk-matrix", "skills-grid"],
  "slope-chart": ["slope", "slopegraph", "before-after-lines", "rank-change"],
  "bullet-chart": ["bullet", "kpi-vs-target", "target-bars"],
  // ---- Timelines ------------------------------------------------------------
  timeline: ["milestones", "chronology", "history"],
  "roadmap-lanes": ["product-roadmap", "swimlane-roadmap", "quarterly-roadmap", "release-plan"],
  "milestone-path": ["path-to-goal", "summit", "trail", "journey-to-goal"],
  // ---- Comparison -----------------------------------------------------------
  "pros-and-cons": ["pro-con", "plus-minus", "for-against"],
  table: ["comparison-table", "grid", "feature-table"],
  versus: ["head-to-head", "comparison", "showdown"],
  balance: ["tradeoff", "trade-off", "weigh"],
  relationship: ["network", "hub"],
  podium: ["ranking", "leaderboard", "winners", "top-three"],
  decision: ["choose", "options"],
  spectrum: ["range", "continuum", "scale-range"],
  quadrant: ["four-quadrant", "grid-2x2"],
  venn: ["venn-diagram", "overlap", "sets", "intersection"],
  "pricing-tiers": ["pricing", "plans", "pricing-table", "packages"],
  "decision-tree": ["decision-flow", "yes-no", "branching", "choice-tree"],
  // ---- Business Frameworks --------------------------------------------------
  swot: ["swot-analysis", "strengths-weaknesses"],
  pestel: ["pest", "pestle", "pestel-analysis", "macro-environment"],
  porters: ["five-forces", "porters-five-forces", "competitive-forces"],
  pyramid: ["hierarchy", "layers", "tiers", "triangle"],
  bullseye: ["concentric", "priorities", "rings"],
  funnel: ["sales-funnel", "conversion-funnel", "pipeline"],
  flywheel: ["momentum", "growth-loop", "virtuous-cycle", "growth-engine"],
  okr: ["okrs", "objectives", "goal-tree", "key-results"],
  "business-model-canvas": ["bmc", "business-canvas", "model-canvas"],
  ecosystem: ["orbits", "stakeholder-map", "ecosystem-map"],
  "value-chain": ["porter-value-chain", "chevron-process", "delivery-chain"],
  "hex-cluster": ["honeycomb", "hexagon-cluster", "hex-grid"],
  "tug-of-war": ["force-field", "push-pull", "tension"],
  // ---- Brainstorming / Parts of a whole -------------------------------------
  mindmap: ["mind-map", "brainstorm", "topics"],
  personas: ["team", "cast", "roles", "characters", "people"],
  quote: ["quotation", "big-quote", "saying", "callout-quote"],
  clouds: ["idea-clouds", "thought-clouds", "sticky-ideas", "scattered-ideas"],
  "head-thoughts": ["in-their-head", "mind-of", "empathy-map-mind", "whats-on-their-mind"],
  "key-ideas": ["highlights", "takeaways", "key-points"],
  list: ["bullets", "checklist", "items", "bullet-list"],
  diverge: ["diverging", "branch-out", "fan-out"],
  converge: ["converging", "funnel-in", "merge", "inputs"],
  iceberg: ["visible-hidden", "surface-depth", "above-below"],
  // ---- Problems & Solutions / Cause & Effect --------------------------------
  "problem-solution": ["issue-fix", "challenge-response"],
  transformation: ["transition", "change", "makeover"],
  challenges: ["obstacles", "barriers"],
  bridge: ["gap", "migration", "span", "bridge-gap"],
  "root-causes": ["why", "causes", "cause-tree", "cause-effect"],
  domino: ["chain-reaction", "dominoes", "cascade-effect", "knock-on"],
  fishbone: ["ishikawa", "fishbone-diagram", "cause-categories"],
  impact: ["ripple", "consequences", "effects"],
  // ---- Visual Metaphors -----------------------------------------------------
  vision: ["goal", "aspiration", "destination", "north-star"],
  performance: ["scorecard", "dashboard", "kpi-donuts"],
  bottleneck: ["constraint", "chokepoint", "throughput"],
  hole: ["trap", "pitfall", "risk"],
  trend: ["growth", "upward", "trajectory", "maturity", "rising"],
  race: ["competition", "finish-line", "contest"],
  dialogue: ["chat", "qa", "discussion"],
  lens: ["focus", "magnify", "filter"],
  prism: ["refraction", "one-to-many", "split"],
  pillar: ["columns", "foundations", "supports"],
  lighthouse: ["guidance", "beacon", "watch-out"],
  magnet: ["attraction", "retention", "pull"]
};
function applyVizAliases() {
  for (const [canonical, aliases] of Object.entries(VIZ_ALIASES)) {
    for (const alias of aliases) registerVizAlias(alias, canonical);
  }
}
applyVizAliases();
const CHARACTER_NODE_DEFAULT_HEIGHT = 200;
const CHARACTER_NODE_MIN_HEIGHT = 24;
const CHARACTER_LABEL_GAP = 10;
function characterNodeSpec(node) {
  if (node.shape !== "character") return null;
  const raw = node.data?.character;
  const height = Math.max(CHARACTER_NODE_MIN_HEIGHT, Number(raw?.height) || CHARACTER_NODE_DEFAULT_HEIGHT);
  return { ...raw, pose: raw?.pose || "standing", height };
}
function characterDrawOptions(spec, style) {
  const fill = flatFill(style.fill && style.fillStyle !== "none" ? style.fill : void 0);
  const opts = {
    pose: spec.pose,
    color: style.stroke,
    emotion: spec.emotion,
    shirt: spec.shirt,
    hair: spec.hair,
    accessory: spec.accessory,
    fx: spec.fx,
    prop: spec.prop,
    flip: spec.flip,
    fidelity: spec.fidelity,
    shadow: spec.shadow,
    shirtColor: spec.shirtColor ?? fill,
    hairColor: spec.hairColor,
    accessoryColor: spec.accessoryColor,
    fxColor: spec.fxColor,
    propColor: spec.propColor
  };
  for (const k of Object.keys(opts)) if (opts[k] === void 0) delete opts[k];
  return opts;
}
function flatFill(c) {
  if (!c) return void 0;
  if (!c.startsWith("linear-gradient(")) return c;
  const first = c.slice("linear-gradient(".length, -1).split(",")[0]?.trim();
  return first || void 0;
}
function scratchContext(id, preset, mode) {
  return new VizContext(id, preset, mode, new DiagnosticBag());
}
function measureCharacterNode(spec, style, preset, mode) {
  const ctx = scratchContext("measure", preset, mode);
  const drawn = drawCharacter(ctx, 0, 0, spec.height, characterDrawOptions(spec, style));
  const b = ctx.bounds();
  const minX = Math.min(drawn.x, b.x);
  const minY = Math.min(drawn.y, b.y);
  const maxX = Math.max(drawn.x + drawn.w, b.x + b.w);
  const maxY = Math.max(drawn.y + drawn.h, b.y + b.h, 0);
  return { x: minX, y: minY, w: maxX - minX, h: maxY - minY };
}
function characterNodeBox(spec, label, style, preset, mode) {
  const figure = measureCharacterNode(spec, style, preset, mode);
  let labelW = 0;
  let labelH = 0;
  if (label) {
    const m = measureBlock(label, style.fontSize, style.fontFamily);
    labelW = m.w + 8;
    labelH = m.h;
  }
  const w = Math.max(figure.w, labelW);
  const h = figure.h + (label ? CHARACTER_LABEL_GAP + labelH : 0);
  return { w, h, figure, labelH };
}
function emitCharacterNode(node, preset, mode) {
  const spec = characterNodeSpec(node) ?? { pose: "standing", height: CHARACTER_NODE_DEFAULT_HEIGHT };
  const style = node.style;
  const base = measureCharacterNode(spec, style, preset, mode);
  const labelH = node.label ? measureBlock(node.label, style.fontSize, style.fontFamily).h : 0;
  const availH = Math.max(1, node.h - (node.label ? CHARACTER_LABEL_GAP + labelH : 0));
  const scale = Math.min(node.w / Math.max(1, base.w), availH / Math.max(1, base.h));
  const s = Math.abs(scale - 1) < 1e-6 ? 1 : Math.max(0.01, scale);
  const h = spec.height * s;
  const fig = { x: base.x * s, y: base.y * s, w: base.w * s, h: base.h * s };
  const groundY = node.y + availH;
  const cx = node.x + node.w / 2 - (fig.x + fig.w / 2);
  const ctx = scratchContext(node.id, preset, mode);
  drawCharacter(ctx, cx, groundY, h, { ...characterDrawOptions(spec, style), z: node.z });
  return {
    nodes: ctx.nodes,
    figure: { x: cx + fig.x, y: groundY + fig.y, w: fig.w, h: fig.h },
    groundY,
    labelH
  };
}
const ICON_NODE_DEFAULT_SIZE = 64;
const ICON_NODE_MIN_SIZE = 12;
const ICON_LABEL_GAP = 8;
function iconNodeSpec(node) {
  if (node.shape !== "icon") return null;
  const raw = node.data?.icon;
  const size = Math.max(ICON_NODE_MIN_SIZE, Number(raw?.size) || ICON_NODE_DEFAULT_SIZE);
  return { name: raw?.name ?? node.id, size };
}
function iconNodeBox(spec, label, style) {
  let labelW = 0;
  let labelH = 0;
  if (label) {
    const m = measureBlock(label, style.fontSize, style.fontFamily);
    labelW = m.w + 8;
    labelH = m.h;
  }
  return { w: Math.max(spec.size, labelW), h: spec.size + (label ? ICON_LABEL_GAP + labelH : 0), labelH };
}
function iconNodeGlyph(node) {
  const spec = iconNodeSpec(node) ?? { name: node.id, size: ICON_NODE_DEFAULT_SIZE };
  const labelH = node.label ? measureBlock(node.label, node.style.fontSize, node.style.fontFamily).h : 0;
  const availH = Math.max(1, node.h - (node.label ? ICON_LABEL_GAP + labelH : 0));
  const size = Math.max(1, Math.min(spec.size, node.w, availH));
  const entry = iconEntry(spec.name);
  return {
    x: node.x + (node.w - size) / 2,
    y: node.y + (availH - size) / 2,
    size,
    d: entry?.d ?? null,
    viewBox: entry?.viewBox ?? 24,
    labelH
  };
}
const SHAPE_MAP = {
  rect: "rectangle",
  rectangle: "rectangle",
  "round-rect": "round-rectangle",
  "round-rectangle": "round-rectangle",
  roundrect: "round-rectangle",
  ellipse: "ellipse",
  circle: "circle",
  diamond: "diamond",
  decision: "diamond",
  cylinder: "cylinder",
  db: "cylinder",
  database: "cylinder",
  hexagon: "hexagon",
  parallelogram: "parallelogram",
  trapezoid: "trapezoid",
  cloud: "cloud",
  actor: "actor",
  note: "note",
  document: "document",
  stadium: "pill",
  pill: "pill",
  subroutine: "rectangle",
  triangle: "triangle",
  star: "star",
  text: "text",
  image: "rectangle",
  frame: "rectangle",
  character: "character",
  icon: "icon"
};
function mapShape(name) {
  if (!name) return "rectangle";
  if (name.startsWith("custom:")) return name;
  return SHAPE_MAP[name] ?? name;
}
function lowerGlyph(glyph) {
  switch (glyph) {
    case "--":
    case "---":
      return { strokeStyle: "solid", startArrowhead: "none", endArrowhead: "none" };
    case "->":
    case "-->":
    case "--->":
      return { strokeStyle: "solid", startArrowhead: "none", endArrowhead: "arrow" };
    case "<-":
    case "<--":
      return { strokeStyle: "solid", startArrowhead: "arrow", endArrowhead: "none" };
    case "<->":
    case "<-->":
      return { strokeStyle: "solid", startArrowhead: "arrow", endArrowhead: "arrow" };
    case "-.->":
      return { strokeStyle: "dashed", startArrowhead: "none", endArrowhead: "arrow" };
    case "..>":
      return { strokeStyle: "dotted", startArrowhead: "none", endArrowhead: "arrow" };
    case "==>":
      return { strokeStyle: "solid", startArrowhead: "none", endArrowhead: "arrow", strokeWidthMul: 2.1 };
    case "===":
      return { strokeStyle: "solid", startArrowhead: "none", endArrowhead: "none", strokeWidthMul: 2.1 };
    case "~>":
      return { strokeStyle: "solid", startArrowhead: "none", endArrowhead: "arrow", animation: "flow", routing: "curved" };
    case "--o":
    case "-o":
      return { strokeStyle: "solid", startArrowhead: "none", endArrowhead: "circle" };
    case "--x":
    case "-x":
      return { strokeStyle: "solid", startArrowhead: "none", endArrowhead: "bar" };
    default:
      return { strokeStyle: "solid", startArrowhead: "none", endArrowhead: "arrow" };
  }
}
function mapStrokeWidth(v) {
  if (v.t === "num") return v.v;
  if (v.t === "ident") {
    return { thin: 1, medium: 1.4, bold: 2.8, thick: 3.4 }[v.v];
  }
  return void 0;
}
function mapRoughness(v) {
  if (v.t === "num") return v.v;
  if (v.t === "ident") {
    return { architect: 0, clean: 0.35, artist: 1, cartoonist: 2 }[v.v];
  }
  return void 0;
}
function mapBowing(v) {
  if (v.t === "num") return v.v;
  if (v.t === "ident") {
    return { none: 0, slight: 0.35, normal: 1, loose: 2, wild: 3 }[v.v];
  }
  return void 0;
}
function mapBool(v) {
  if (v.t === "bool") return v.v;
  if (v.t === "num") return v.v !== 0;
  if (v.t === "ident") {
    return { true: true, yes: true, on: true, false: false, no: false, off: false }[v.v];
  }
  return void 0;
}
function mapFillStyle(v) {
  if (v.t !== "ident") return void 0;
  const ok = /* @__PURE__ */ new Set(["hachure", "cross-hatch", "solid", "zigzag", "dots", "none"]);
  return ok.has(v.v) ? v.v : void 0;
}
function mapStrokeStyle(v) {
  if (v.t !== "ident") return void 0;
  return ["solid", "dashed", "dotted"].includes(v.v) ? v.v : void 0;
}
function mapRouting(v) {
  if (v.t !== "ident") return void 0;
  const map = {
    straight: "straight",
    bezier: "curved",
    curved: "curved",
    orthogonal: "orthogonal",
    elbow: "elbow",
    step: "orthogonal",
    arc: "curved"
  };
  return map[v.v];
}
function mapArrowhead(v) {
  if (v.t !== "ident") return void 0;
  return v.v;
}
function mapAnimation(v) {
  let name;
  let speed;
  if (v.t === "ident") name = v.v;
  else if (v.t === "styled") {
    name = v.name;
    const sp = v.block.find((a) => a.key === "speed");
    if (sp && sp.value.t === "num") speed = sp.value.v;
  }
  if (!name) return void 0;
  if (getArrowAnimation(name)) return { kind: name, speed };
  const known = /* @__PURE__ */ new Set(["none", "flow", "dash-march", "draw-on", "pulse", "comet", "gradient-flow", "electric", "glow", "caravan", "wiggle"]);
  const remap = { glow: "comet", caravan: "dash-march", wiggle: "flow" };
  const kind = remap[name] ?? (known.has(name) ? name : "flow");
  return { kind, speed };
}
function mapEasing(v) {
  if (!v) return "ease-in-out";
  if (v.t === "ident") {
    const known = ["linear", "ease", "ease-in", "ease-out", "ease-in-out", "back-out", "anticipate", "spring"];
    if (known.includes(v.v)) return v.v;
    if (v.v === "magic" || v.v === "bounce") return "spring";
    return "ease-in-out";
  }
  if (v.t === "call") {
    if (v.name === "spring") return "spring";
    return "ease-in-out";
  }
  return "ease-in-out";
}
function resolveColor(v, tokens, kind, depth = 0) {
  if (depth > 8) return null;
  switch (v.t) {
    case "color":
      return v.v;
    case "str":
      return kind === "fill" ? resolveFill(v.v) : resolveStroke(v.v, "#1e1e1e");
    case "ident":
      return kind === "fill" ? resolveFill(v.v) : resolveStroke(v.v, "#1e1e1e");
    case "token": {
      const t = tokens.get(v.v);
      if (!t) return null;
      return resolveColor(t, tokens, kind, depth + 1);
    }
    default:
      return null;
  }
}
function numberOf(v) {
  return v && v.t === "num" ? v.v : void 0;
}
const COLOR_KEYS = /* @__PURE__ */ new Set(["color", "fill", "stroke"]);
const DETAIL_KEYS = ["detail", "note", "desc", "description"];
function lowerViz(decl, index, tokens) {
  const options = {};
  for (const a of decl.attrs) {
    options[a.key] = COLOR_KEYS.has(a.key) ? resolveColor(a.value, tokens, "stroke") ?? plain(a.value, tokens) : plain(a.value, tokens);
  }
  const id = decl.id ?? `viz${index + 1}`;
  return {
    type: decl.vizType,
    id,
    title: decl.title,
    options,
    items: decl.entries.map((e, i) => lowerEntry(e, i, tokens))
  };
}
function lowerEntry(e, i, tokens) {
  const values = [];
  const strings = [];
  for (const v of e.values) collect(v, values, strings, tokens);
  const opts = {};
  let color;
  let icon;
  let detail2;
  for (const a of e.attrs) {
    if (COLOR_KEYS.has(a.key)) {
      color = resolveColor(a.value, tokens, "stroke") ?? color;
      continue;
    }
    if (a.key === "icon") {
      const p = plain(a.value, tokens);
      if (typeof p === "string") icon = p;
      continue;
    }
    if (DETAIL_KEYS.includes(a.key)) {
      const p = plain(a.value, tokens);
      if (typeof p === "string") detail2 = p;
      continue;
    }
    if (a.key === "value") {
      const p = plain(a.value, tokens);
      if (typeof p === "number") values.unshift(p);
      continue;
    }
    opts[a.key] = plain(a.value, tokens);
  }
  if (detail2 === void 0 && e.label !== void 0 && strings.length) detail2 = strings[0];
  const label = e.label ?? prettify(e.id) ?? "";
  return {
    kind: e.kind,
    id: e.id ?? slug$1(e.label) ?? `${e.kind}_${i}`,
    label,
    detail: detail2,
    value: values.length ? values[0] : void 0,
    values,
    strings,
    to: e.to,
    color,
    icon,
    opts,
    children: e.children.map((c, j) => lowerEntry(c, j, tokens))
  };
}
function collect(v, nums, strs, tokens) {
  switch (v.t) {
    case "num":
      nums.push(v.v);
      break;
    case "str":
    case "ident":
    case "color":
      strs.push(v.v);
      break;
    case "list":
    case "tuple":
      for (const x of v.v) collect(x, nums, strs, tokens);
      break;
    case "token": {
      const t = tokens.get(v.v);
      if (t) collect(t, nums, strs, tokens);
      break;
    }
  }
}
function plain(v, tokens) {
  switch (v.t) {
    case "num":
      return v.v;
    case "str":
    case "ident":
    case "color":
    case "class":
      return v.v;
    case "bool":
      return v.v;
    case "token": {
      const t = tokens.get(v.v);
      return t ? plain(t, tokens) : void 0;
    }
    case "tuple":
    case "list":
      return v.v.map((x) => plain(x, tokens));
    default:
      return void 0;
  }
}
function slug$1(label) {
  if (!label) return void 0;
  const s = label.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 24);
  return s || void 0;
}
function prettify(id) {
  return id;
}
function nameOf(v) {
  if (v.t === "ident" || v.t === "str") return v.v.trim();
  return void 0;
}
function at(span) {
  return { line: span.line, col: span.col, start: span.start, end: span.end };
}
function lowerCharacterNode(attrs, tokens, diags, fallbackSpan) {
  const spec = { pose: "standing", height: CHARACTER_NODE_DEFAULT_HEIGHT };
  const axis = (a, key, valid, fallback) => {
    const name = nameOf(a.value);
    if (!name) return;
    if (name === "none" && key !== "pose" && key !== "emotion") {
      spec[key] = "none";
      return;
    }
    if (valid.includes(name)) {
      spec[key] = name;
      return;
    }
    const guess = nearest(name, valid);
    diags.warn(
      "W-CHARACTER-" + key.toUpperCase(),
      `unknown character ${key} '${name}'${fallback ? ` — using '${fallback}'` : " — ignored"}`,
      at(a.span ?? fallbackSpan),
      { expected: valid.join(" | "), found: name, hint: guess ? `did you mean '${guess}'?` : `valid ${key}s: ${valid.join(", ")}` }
    );
    if (fallback) spec[key] = fallback;
  };
  for (const a of attrs) {
    const v = a.value;
    switch (a.key) {
      case "pose":
        axis(a, "pose", listCharacterPoses(), "standing");
        break;
      case "emotion":
        axis(a, "emotion", listCharacterEmotions(), "neutral");
        break;
      case "shirt":
        axis(a, "shirt", listCharacterShirts(), void 0);
        break;
      case "hair":
        axis(a, "hair", listCharacterHair(), void 0);
        break;
      case "accessory":
        axis(a, "accessory", listCharacterAccessories(), void 0);
        break;
      case "fx":
        axis(a, "fx", listCharacterFx(), void 0);
        break;
      case "prop": {
        const name = nameOf(v);
        if (!name || name === "none") break;
        if (iconEntry(name)) spec.prop = name;
        else {
          const icons = listIcons();
          const guess = nearest(name, icons);
          diags.warn("W-CHARACTER-PROP", `unknown prop icon '${name}' — ignored`, at(a.span ?? fallbackSpan), {
            found: name,
            hint: guess ? `did you mean '${guess}'?` : `valid icons: ${icons.join(", ")}`
          });
        }
        break;
      }
      case "height":
        if (v.t === "num") spec.height = Math.max(CHARACTER_NODE_MIN_HEIGHT, v.v);
        break;
      case "flip":
        if (v.t === "bool") spec.flip = v.v;
        else if (v.t === "ident") spec.flip = v.v === "true" || v.v === "yes";
        break;
      case "shadow":
        if (v.t === "bool") spec.shadow = v.v;
        else if (v.t === "ident") spec.shadow = v.v === "true" || v.v === "yes";
        break;
      case "fidelity": {
        const f = nameOf(v);
        if (f === "minimal" || f === "plain" || f === "detailed") spec.fidelity = f;
        else if (f)
          diags.warn("W-CHARACTER-FIDELITY", `unknown fidelity '${f}' — use minimal | plain | detailed`, at(a.span ?? fallbackSpan), {
            hint: "minimal = bystanders (no face) · plain = default · detailed = the protagonist"
          });
        break;
      }
      case "shirtColor":
      case "hairColor":
      case "accessoryColor":
      case "fxColor":
      case "propColor": {
        const c = resolveColor(v, tokens, "stroke");
        if (c) spec[a.key] = c;
        break;
      }
    }
  }
  return spec;
}
function lowerIconNode(id, attrs, diags, fallbackSpan) {
  const spec = { name: id, size: ICON_NODE_DEFAULT_SIZE };
  let nameAttr;
  for (const a of attrs) {
    const v = a.value;
    switch (a.key) {
      case "icon":
      case "glyph": {
        const name = nameOf(v);
        if (name) {
          spec.name = name;
          nameAttr = a;
        }
        break;
      }
      case "size":
      case "iconSize":
        if (v.t === "num") spec.size = Math.max(ICON_NODE_MIN_SIZE, v.v);
        break;
    }
  }
  if (!iconEntry(spec.name)) {
    const icons = listIcons();
    const guess = nearest(spec.name, icons);
    diags.warn("W-ICON", `unknown icon '${spec.name}' — the caption renders without a glyph`, at(nameAttr?.span ?? fallbackSpan), {
      found: spec.name,
      hint: guess ? `did you mean '${guess}'?` : `valid icons: ${icons.join(", ")}`
    });
  }
  return spec;
}
function attr(block, key) {
  const found = block.find((a) => a.key === key);
  return found?.value;
}
const FONT_MAP = {
  hand: "hand",
  normal: "normal",
  sans: "normal",
  mono: "code",
  code: "code",
  serif: "serif"
};
function compileProgram(program, opts = {}) {
  const diags = opts.diagnostics ?? new DiagnosticBag();
  const themes = /* @__PURE__ */ new Map();
  const styles = /* @__PURE__ */ new Map();
  const defaults = /* @__PURE__ */ new Map();
  const sceneStmts = [];
  const annotateTop = [];
  let timeline = [];
  let timelineProps = {};
  const metaAttrs = [];
  const overrideEntries = [];
  const vizDecls = [];
  let activeTheme;
  let hasMermaid = false;
  for (const s of program.statements) {
    switch (s.type) {
      case "viz":
        vizDecls.push(s);
        break;
      case "overrides":
        overrideEntries.push(...s.entries);
        break;
      case "meta":
        metaAttrs.push(...s.attrs);
        break;
      case "theme":
        themes.set(s.name, { tokens: s.tokens, props: s.props, extends: s.extends });
        break;
      case "style":
        styles.set(s.name, { attrs: s.attrs, extends: s.extends });
        break;
      case "defaults":
        for (const r2 of s.rules) defaults.set(r2.target, [...defaults.get(r2.target) ?? [], ...r2.attrs]);
        break;
      case "scene":
        sceneStmts.push(...s.statements);
        break;
      case "annotate":
        annotateTop.push(...s.commands);
        break;
      case "timeline":
        timeline = s.beats;
        timelineProps = Object.fromEntries(s.props.map((p) => [p.key, p.value]));
        break;
      case "mermaid":
        hasMermaid = true;
        break;
    }
  }
  if (hasMermaid) {
    diags.warn("W-MERMAID-SYNC", "the pure compiler skips `mermaid` blocks; import Mermaid via the EdodoDraw facade or convertMermaid()", { line: 1, col: 1, start: 0, end: 0 }, { hint: "see docs/IMPORT_AND_EXPORT_GUIDE" });
  }
  const nodeDecls = /* @__PURE__ */ new Map();
  const nodeOrder = [];
  const edgeDecls = [];
  const groupInfos = [];
  const nodeGroup = /* @__PURE__ */ new Map();
  const sceneAnnotates = [];
  let layoutKind;
  let layoutAttrs = [];
  const mergeNodeDecl = (nd, group) => {
    const existing = nodeDecls.get(nd.id);
    if (existing) {
      existing.classes.push(...nd.classes);
      existing.attrs.push(...nd.attrs);
      existing.anchors.push(...nd.anchors);
      if (nd.shape) existing.shape = nd.shape;
      if (nd.label !== void 0) existing.label = nd.label;
    } else {
      nodeDecls.set(nd.id, { ...nd, classes: [...nd.classes], attrs: [...nd.attrs], anchors: [...nd.anchors] });
      nodeOrder.push(nd.id);
    }
    if (group) nodeGroup.set(nd.id, group);
  };
  const walk = (stmts, group) => {
    for (const st of stmts) {
      switch (st.type) {
        case "node":
          mergeNodeDecl(st, group);
          break;
        case "edge":
          edgeDecls.push(st);
          break;
        case "group": {
          const members = [];
          for (const it of st.items) if (it.type === "node") members.push(it.id);
          groupInfos.push({ decl: st, members });
          walk(st.items, st.id);
          break;
        }
        case "layout":
          layoutKind = st.kind;
          layoutAttrs = st.attrs;
          break;
        case "use":
          if (st.what === "theme") activeTheme = st.name;
          break;
        case "style":
          styles.set(st.name, { attrs: st.attrs, extends: st.extends });
          break;
        case "annotate":
          sceneAnnotates.push(...st.commands);
          break;
        case "classapply": {
          const nd = { type: "node", id: st.id, classes: st.classes, attrs: [], anchors: [], span: st.span };
          mergeNodeDecl(nd, group);
          break;
        }
        case "anchor":
          break;
        case "viz":
          vizDecls.push(st);
          break;
        case "mermaid":
          hasMermaid = true;
          break;
      }
    }
  };
  walk(sceneStmts);
  const tokenMap = /* @__PURE__ */ new Map();
  const themeName = activeTheme ?? [...themes.keys()][0];
  if (themeName) {
    const chain = [];
    let cur = themeName;
    const seen = /* @__PURE__ */ new Set();
    while (cur && themes.has(cur) && !seen.has(cur)) {
      chain.unshift(cur);
      seen.add(cur);
      cur = themes.get(cur).extends;
    }
    for (const name of chain) {
      for (const t of themes.get(name).tokens) tokenMap.set(t.name, t.value);
    }
  }
  const metaStyleAttr = attr(metaAttrs, "style");
  const metaStyleName = metaStyleAttr && (metaStyleAttr.t === "str" || metaStyleAttr.t === "ident") ? metaStyleAttr.v : void 0;
  const presetName = opts.stylePreset ?? metaStyleName;
  const explicitPreset = getStylePreset(presetName);
  if (presetName && !explicitPreset) {
    diags.warn("W-STYLE-PRESET", `unknown style preset '${presetName}'`, { line: 1, col: 1, start: 0, end: 0 }, { hint: "see docs/STYLES_GUIDE for the built-in preset names" });
  }
  const derivedMode = themeName?.toLowerCase().includes("dark") ? "dark" : "light";
  const mode = opts.mode ?? explicitPreset?.mode ?? derivedMode;
  const preset = explicitPreset ?? (themeName ? void 0 : effectivePreset(void 0, mode));
  const classAttrs = (name, seen = /* @__PURE__ */ new Set()) => {
    if (seen.has(name) || !styles.has(name)) return { attrs: [] };
    seen.add(name);
    const s = styles.get(name);
    const base = s.extends ? classAttrs(s.extends, seen).attrs : [];
    return { attrs: [...base, ...s.attrs] };
  };
  const scene = emptyScene(mode);
  if (preset) {
    scene.theme = presetTheme(preset);
    scene.theme.mode = mode;
    scene.meta.style = preset.name;
  }
  applyMeta(scene, metaAttrs, tokenMap);
  {
    const declared = buildNodeStyle(defaults.get("node") ?? [], tokenMap).style;
    const rough2 = {};
    if (preset && presetDeclaresRoughTuning(preset)) {
      rough2.roughness = preset.roughness;
      Object.assign(rough2, roughTuning(preset));
    }
    if (declared.roughness !== void 0) rough2.roughness = declared.roughness;
    Object.assign(rough2, roughTuning(declared));
    if (Object.keys(rough2).length) scene.meta.rough = rough2;
  }
  const styleFor = (kind, classes, inline) => {
    const layered = [];
    for (const a of defaults.get(kind) ?? []) layered.push(a);
    for (const c of classes) layered.push(...classAttrs(c).attrs);
    layered.push(...inline);
    return layered;
  };
  const COLORISH = /* @__PURE__ */ new Set(["fill", "bg", "bgColor", "background", "stroke", "color"]);
  const hasOwnColor = (layered) => layered.some((a) => COLORISH.has(a.key));
  const ensureNode = (id, label) => {
    if (scene.nodes.some((n) => n.id === id)) return;
    const style = preset ? { ...presetNodeDefaults(preset) } : void 0;
    scene.nodes.push(makeNode({ id, label: id, mode, style }));
  };
  const autoColorIdx = /* @__PURE__ */ new Map();
  if (preset?.autoColorNodes) {
    let idx = 0;
    for (const id of nodeOrder) {
      const nd = nodeDecls.get(id);
      if (!hasOwnColor(styleFor("node", collectClasses(nd), nd.attrs))) autoColorIdx.set(id, idx++);
    }
  }
  for (const id of nodeOrder) {
    const nd = nodeDecls.get(id);
    const classes = collectClasses(nd);
    const layered = styleFor("node", classes, nd.attrs);
    const built = buildNodeStyle(layered, tokenMap);
    if (!preset) applyDarkInk(built.style, mode);
    let style = built.style;
    if (preset) {
      const base = presetNodeDefaults(preset);
      const autoIdx = autoColorIdx.get(id);
      if (autoIdx !== void 0) {
        const role = roleStyle(preset, autoIdx, { n: autoColorIdx.size });
        base.stroke = role.stroke;
        base.fill = role.fill;
        base.fillStyle = role.fillStyle;
        base.textColor = role.textColor;
      }
      style = { ...base, ...style };
      if (built.style.fill != null) {
        const fillStyle = style.fillStyle ?? "solid";
        const coveringFill = fillStyle !== "none" && fillStyle !== "hachure";
        if (coveringFill && isLightColor(style.fill ?? null)) {
          if (built.style.textColor === void 0 && isLightColor(style.textColor ?? null)) style = { ...style, textColor: "#1e1e1e" };
          if (built.style.stroke === void 0 && isLightColor(style.stroke ?? null)) style = { ...style, stroke: "#1e1e1e" };
        }
      }
    }
    const shape = mapShape(built.shape ?? nd.shape);
    const label = built.label ?? nd.label ?? prettyId(id);
    const node = makeNode({
      id,
      shape,
      label,
      style,
      x: built.x,
      y: built.y,
      w: built.w,
      h: built.h,
      pinned: built.pinned,
      group: nodeGroup.get(id),
      mode,
      data: { tags: collectTags(nd), classes }
    });
    if (shape === "character") {
      const spec = lowerCharacterNode(layered, tokenMap, diags, nd.span);
      const box = characterNodeBox(spec, node.label, node.style, preset ?? effectivePreset(void 0, mode), mode);
      spec.figure = box.figure;
      node.w = box.w;
      node.h = box.h;
      node.data = { ...node.data, character: spec };
    } else if (shape === "icon") {
      const spec = lowerIconNode(id, layered, diags, nd.span);
      const box = iconNodeBox(spec, node.label, node.style);
      node.w = box.w;
      node.h = box.h;
      node.data = { ...node.data, icon: spec };
    }
    scene.nodes.push(node);
  }
  for (const gi of groupInfos) {
    const g = {
      id: gi.decl.id,
      label: gi.decl.label ?? "",
      members: gi.members,
      style: buildGroupStyle(gi.decl.attrs, tokenMap),
      frame: true
    };
    scene.groups.push(g);
  }
  let edgeSeq = 0;
  for (const ed of edgeDecls) {
    for (let h = 0; h < ed.ops.length; h++) {
      const gl = lowerGlyph(ed.ops[h].glyph);
      const fromSet = ed.groups[h];
      const toSet = ed.groups[h + 1];
      const singleHop = ed.ops.length === 1;
      for (const from of fromSet) {
        for (const to of toSet) {
          if (from.inline) ensureInline(scene, from.inline, tokenMap, mode, styleFor);
          if (to.inline) ensureInline(scene, to.inline, tokenMap, mode, styleFor);
          ensureNode(from.id);
          ensureNode(to.id);
          const label = ed.ops[h].midLabel ?? (singleHop ? ed.label : void 0) ?? "";
          const id = ed.id && singleHop && fromSet.length === 1 && toSet.length === 1 ? ed.id : `e${edgeSeq++}_${from.id}_${to.id}`;
          const built = buildEdgeStyle(gl, styleFor("edge", [], ed.attrs), tokenMap);
          const edge = makeEdge({
            id,
            from: from.id,
            to: to.id,
            fromAnchor: endpointAnchor(from),
            toAnchor: endpointAnchor(to),
            label,
            style: preset ? { ...presetEdgeDefaults(preset), ...built.style } : built.style,
            routing: built.routing ?? gl.routing ?? "straight",
            mode
          });
          scene.edges.push(edge);
        }
      }
    }
  }
  const pairCount = /* @__PURE__ */ new Map();
  const pairKey = (e) => [e.from.node, e.to.node].filter(Boolean).sort().join("|");
  for (const e of scene.edges) pairCount.set(pairKey(e), (pairCount.get(pairKey(e)) ?? 0) + 1);
  const pairIdx = /* @__PURE__ */ new Map();
  for (const e of scene.edges) {
    const key = pairKey(e);
    const count = pairCount.get(key);
    if (count > 1) {
      const idx = pairIdx.get(key) ?? 0;
      pairIdx.set(key, idx + 1);
      e.data = { ...e.data, parallel: { index: idx, count } };
      e.routing = "curved";
    }
  }
  for (const cmd of [...annotateTop, ...sceneAnnotates]) {
    const a = annotationFromCmd(cmd, tokenMap, "script");
    if (a) scene.annotations.push(a);
  }
  scene.meta.layout = resolveLayoutKind(layoutKind, scene);
  const dir = layoutAttrs.length ? attr(layoutAttrs, "direction") : void 0;
  if (dir && dir.t === "ident") scene.meta.direction = dir.v;
  const gap = numberOf(attr(layoutAttrs, "gap"));
  const rankGap = numberOf(attr(layoutAttrs, "rankGap")) ?? numberOf(attr(layoutAttrs, "rankgap"));
  if (gap || rankGap) scene.meta.spacing = { node: gap, rank: rankGap };
  const centerId = attr(layoutAttrs, "center");
  if (centerId && centerId.t === "ref") scene.meta.center = centerId.id;
  else if (centerId && centerId.t === "ident") scene.meta.center = centerId.v;
  if (overrideEntries && overrideEntries.length) {
    scene.overrides = overrideEntries;
    applyOverrides(scene);
  }
  applyLayout(scene);
  const animatedSpecs = [];
  if (vizDecls.length) {
    const vizPreset = tunePreset(preset ?? effectivePreset(void 0, mode), scene.meta.rough);
    let cursorY = contentMaxY(scene) + (scene.nodes.length ? 100 : 40);
    for (let i = 0; i < vizDecls.length; i++) {
      const spec = lowerViz(vizDecls[i], i, tokenMap);
      if (spec.options.animate) animatedSpecs.push(spec);
      const result = runViz(spec, vizPreset, mode, diags);
      if (!result) continue;
      const dx = 40 - result.bounds.x;
      const dy = cursorY - result.bounds.y;
      for (const n of result.nodes) {
        n.x += dx;
        n.y += dy;
        scene.nodes.push(n);
      }
      for (const e of result.edges) {
        if (e.from.point) e.from = { ...e.from, point: { x: e.from.point.x + dx, y: e.from.point.y + dy } };
        if (e.to.point) e.to = { ...e.to, point: { x: e.to.point.x + dx, y: e.to.point.y + dy } };
        if (e.points) e.points = e.points.map((p) => ({ x: p.x + dx, y: p.y + dy }));
        scene.edges.push(e);
      }
      for (const a of result.annotations) scene.annotations.push(a);
      cursorY += result.bounds.h + 100;
    }
  }
  if (timeline.length) scene.steps = timeline.map((b, idx) => beatToStep(b, idx, scene, tokenMap, timelineProps, diags));
  else if (animatedSpecs.length) scene.steps = buildAutoVizSteps(scene, animatedSpecs);
  else scene.steps = [];
  resolveAnnotationTargets(scene, diags);
  return { scene, diagnostics: diags };
}
function targetExists(scene, id) {
  return !!getNode(scene, id) || !!getEdge(scene, id) || !!getGroup(scene, id) || vizItemMembers(scene, id).length > 0;
}
function resolveAnnotationTargets(scene, diags) {
  const all = [...scene.annotations, ...scene.steps.flatMap((s) => s.annotations)];
  for (const a of all) {
    const start = Number(/^an_(\d+)_/.exec(a.id)?.[1] ?? 0);
    const pos = { line: 1, col: 1, start, end: start };
    const warn = (what) => diags.warn("W-ANNOT-TARGET", `annotation target '${what}' matches no element`, pos, { hint: "check the id — viz items are addressed as <blockId>.<itemId>" });
    for (const t of [a.target, a.target2]) {
      if (!t?.ref) continue;
      if (targetExists(scene, t.ref)) continue;
      const joined = t.part ? `${t.ref}.${t.part}` : void 0;
      if (joined && targetExists(scene, joined)) {
        t.ref = joined;
        t.part = void 0;
        continue;
      }
      warn(joined ?? t.ref);
    }
    const members = a.options.members;
    if (members) {
      for (const m of members) if (m && !targetExists(scene, m)) warn(m);
    }
  }
}
function contentMaxY(scene) {
  let maxY = 0;
  for (const n of scene.nodes) maxY = Math.max(maxY, n.y + n.h);
  return maxY;
}
function buildAutoVizSteps(scene, specs) {
  const beats = [];
  const withDescendants = (item) => [item.id, ...item.children.flatMap(withDescendants)];
  for (const spec of specs) {
    const effect = revealEffect(spec.options.animate === true ? "fade" : String(spec.options.animate)) ?? "fade";
    const holdRaw = spec.options.hold;
    const hold = typeof holdRaw === "number" ? holdRaw <= 60 ? holdRaw * 1e3 : holdRaw : void 0;
    const camera = spec.options.animateCamera === true || spec.options.animateCamera === "focus";
    for (const item of spec.items) {
      const members = withDescendants(item).flatMap((id) => vizItemMembers(scene, `${spec.id}.${id}`));
      if (!members.length) continue;
      beats.push({ key: `${spec.id}.${item.id}`, label: item.label, members: [...new Set(members)], effect, hold, camera });
    }
  }
  if (!beats.length) return [];
  const steps = [
    { id: "auto_overview", name: "Overview", annotations: [], reveal: [], hide: beats.flatMap((b) => b.members), camera: { op: "fit-all" } }
  ];
  beats.forEach((b, i) => {
    steps.push({
      id: `auto_${b.key.replace(/[^a-zA-Z0-9_]/g, "_")}_${i}`,
      name: b.label,
      caption: b.label,
      annotations: [],
      reveal: b.members,
      hide: [],
      revealFx: Object.fromEntries(b.members.map((m) => [m, b.effect])),
      autoAdvanceMs: b.hold,
      camera: b.camera ? { op: "focus", targets: [b.key], padding: 150 } : void 0
    });
  });
  steps.push({ id: "auto_fit", name: "All together", annotations: [], reveal: [], hide: [], camera: { op: "fit-all" } });
  return steps;
}
function prettyId(id) {
  return id;
}
function collectClasses(nd) {
  const out = [...nd.classes];
  for (const a of nd.attrs) {
    if (a.key === "__use" && a.value.t === "class") out.push(a.value.v);
    if (a.key === "class" && a.value.t === "ident") out.push(a.value.v);
    if (a.key === "class" && a.value.t === "class") out.push(a.value.v);
  }
  return out;
}
function collectTags(nd) {
  const tags = [];
  const t = nd.attrs.find((a) => a.key === "tags");
  if (t && t.value.t === "list") {
    for (const v of t.value.v) if (v.t === "ident") tags.push(v.v);
  }
  return tags;
}
const DARK_INK = "#1e1e1e";
const LIGHT_INK = "#e3e3e3";
function applyDarkInk(style, mode) {
  if (mode !== "dark") return;
  const solidLightFill = style.fillStyle === "solid" && isLightColor(style.fill ?? null);
  const ink = solidLightFill ? DARK_INK : LIGHT_INK;
  if (style.textColor === void 0) style.textColor = ink;
  if (style.stroke === void 0 && solidLightFill) style.stroke = DARK_INK;
}
function buildNodeStyle(attrs, tokens, _mode) {
  const style = {};
  const out = { style };
  for (const a of attrs) {
    const v = a.value;
    switch (a.key) {
      case "stroke":
      case "color": {
        const c = resolveColor(v, tokens, "stroke");
        if (c) style.stroke = c;
        break;
      }
      case "fill":
      case "bg":
      case "bgColor":
      case "background": {
        const c = resolveColor(v, tokens, "fill");
        style.fill = c;
        break;
      }
      case "fillStyle": {
        const fs = mapFillStyle(v);
        if (fs) style.fillStyle = fs;
        break;
      }
      case "strokeWidth": {
        const w = mapStrokeWidth(v);
        if (w != null) style.strokeWidth = w;
        break;
      }
      case "strokeStyle": {
        const ss = mapStrokeStyle(v);
        if (ss) style.strokeStyle = ss;
        break;
      }
      case "roughness": {
        const r2 = mapRoughness(v);
        if (r2 != null) style.roughness = r2;
        break;
      }
      // --- rough.js shape tuning (see scene/types.ts RoughTuning). All four
      // are optional and default to rough.js's own behaviour, so a diagram
      // that names none of them draws exactly as it always has.
      case "bowing": {
        const b = mapBowing(v);
        if (b != null) style.bowing = b;
        break;
      }
      case "jitter":
      case "maxRandomnessOffset": {
        if (v.t === "num") style.maxRandomnessOffset = v.v;
        break;
      }
      case "preserveVertices":
      case "pinCorners": {
        const b = mapBool(v);
        if (b != null) style.preserveVertices = b;
        break;
      }
      case "disableMultiStroke":
      case "singleStroke": {
        const b = mapBool(v);
        if (b != null) style.disableMultiStroke = b;
        break;
      }
      case "roundness":
      case "radius":
        if (v.t === "num") style.roundness = v.v;
        break;
      case "font":
        if (v.t === "ident") style.fontFamily = FONT_MAP[v.v] ?? "hand";
        break;
      case "fontSize":
        if (v.t === "num") style.fontSize = v.v;
        break;
      case "textColor": {
        const c = resolveColor(v, tokens, "stroke");
        if (c) style.textColor = c;
        break;
      }
      case "textAlign":
        if (v.t === "ident") style.textAlign = v.v;
        break;
      case "opacity":
        if (v.t === "num") style.opacity = v.unit === "%" ? v.v : v.v <= 1 ? v.v * 100 : v.v;
        break;
      case "shape":
        if (v.t === "ident") out.shape = v.v;
        else if (v.t === "call" && v.name === "custom") out.shape = `custom:${v.args[0]?.t === "str" ? v.args[0].v : ""}`;
        break;
      case "label":
      case "text":
        if (v.t === "str") out.label = v.v;
        else if (v.t === "bool" && !v.v) out.label = "";
        break;
      case "at":
        if (v.t === "tuple" && v.v[0]?.t === "num" && v.v[1]?.t === "num") {
          out.x = v.v[0].v;
          out.y = v.v[1].v;
        }
        break;
      case "pin":
        if (v.t === "bool") out.pinned = v.v;
        break;
      case "size":
        if (v.t === "tuple" && v.v[0]?.t === "num" && v.v[1]?.t === "num") {
          out.w = v.v[0].v;
          out.h = v.v[1].v;
        }
        break;
      case "w":
      case "width":
        if (v.t === "num") out.w = v.v;
        break;
      case "h":
      case "height":
        if (v.t === "num") out.h = v.v;
        break;
    }
  }
  if (out.pinned === void 0 && out.x != null) out.pinned = true;
  return out;
}
function buildGroupStyle(attrs, tokens) {
  const style = {};
  const stroke = attrs.find((a) => a.key === "stroke" || a.key === "color");
  if (stroke) {
    const c = resolveColor(stroke.value, tokens, "stroke");
    if (c) style.stroke = c;
  }
  const fill = attrs.find((a) => a.key === "fill" || a.key === "bg");
  if (fill) style.fill = resolveColor(fill.value, tokens, "fill");
  return style;
}
function buildEdgeStyle(gl, attrs, tokens, _mode) {
  const style = {
    strokeStyle: gl.strokeStyle,
    startArrowhead: gl.startArrowhead,
    endArrowhead: gl.endArrowhead
  };
  if (gl.animation) style.animation = gl.animation;
  if (gl.strokeWidthMul) style.strokeWidth = 1.4 * gl.strokeWidthMul;
  let routing;
  for (const a of attrs) {
    const v = a.value;
    switch (a.key) {
      case "stroke":
      case "color": {
        const c = resolveColor(v, tokens, "stroke");
        if (c) style.stroke = c;
        break;
      }
      case "strokeWidth": {
        const w = mapStrokeWidth(v);
        if (w != null) style.strokeWidth = w;
        break;
      }
      case "strokeStyle": {
        const ss = mapStrokeStyle(v);
        if (ss) style.strokeStyle = ss;
        break;
      }
      case "roughness": {
        const r2 = mapRoughness(v);
        if (r2 != null) style.roughness = r2;
        break;
      }
      // --- rough.js shape tuning (see scene/types.ts RoughTuning). All four
      // are optional and default to rough.js's own behaviour, so a diagram
      // that names none of them draws exactly as it always has.
      case "bowing": {
        const b = mapBowing(v);
        if (b != null) style.bowing = b;
        break;
      }
      case "jitter":
      case "maxRandomnessOffset": {
        if (v.t === "num") style.maxRandomnessOffset = v.v;
        break;
      }
      case "preserveVertices":
      case "pinCorners": {
        const b = mapBool(v);
        if (b != null) style.preserveVertices = b;
        break;
      }
      case "disableMultiStroke":
      case "singleStroke": {
        const b = mapBool(v);
        if (b != null) style.disableMultiStroke = b;
        break;
      }
      case "startArrow":
      case "startArrowhead": {
        const ah = mapArrowhead(v);
        if (ah) style.startArrowhead = ah;
        break;
      }
      case "endArrow":
      case "endArrowhead": {
        const ah = mapArrowhead(v);
        if (ah) style.endArrowhead = ah;
        break;
      }
      case "animate":
      case "animation": {
        const an = mapAnimation(v);
        if (an) {
          style.animation = an.kind;
          if (an.speed) style.animationSpeed = an.speed;
        }
        break;
      }
      case "curve":
      case "routing": {
        const r2 = mapRouting(v);
        if (r2) routing = r2;
        break;
      }
      case "opacity":
        if (v.t === "num") style.opacity = v.unit === "%" ? v.v : v.v <= 1 ? v.v * 100 : v.v;
        break;
      case "fontSize":
        if (v.t === "num") style.fontSize = v.v;
        break;
      case "textColor": {
        const c = resolveColor(v, tokens, "stroke");
        if (c) style.textColor = c;
        break;
      }
      case "labelBg": {
        const c = resolveColor(v, tokens, "fill");
        style.labelBg = c;
        break;
      }
    }
  }
  return { style, routing };
}
function endpointAnchor(e) {
  if (e.uv) return `@${e.uv[0]},${e.uv[1]}`;
  if (e.sub && e.sub !== "label" && e.sub !== "text") return e.sub;
  return void 0;
}
function ensureInline(scene, nd, tokens, mode, styleFor) {
  if (scene.nodes.some((n) => n.id === nd.id)) return;
  const layered = styleFor("node", nd.classes, nd.attrs);
  const built = buildNodeStyle(layered, tokens);
  applyDarkInk(built.style, mode);
  scene.nodes.push(
    makeNode({
      id: nd.id,
      shape: mapShape(built.shape ?? nd.shape),
      label: built.label ?? nd.label ?? nd.id,
      style: built.style,
      x: built.x,
      y: built.y,
      w: built.w,
      h: built.h,
      pinned: built.pinned,
      mode
    })
  );
}
function applyMeta(scene, attrs, tokens) {
  for (const a of attrs) {
    if (a.key === "title" && a.value.t === "str") scene.meta.title = a.value.v;
    if (a.key === "background" || a.key === "bg") {
      const c = resolveColor(a.value, tokens, "fill");
      if (c) scene.meta.background = c;
    }
  }
}
function resolveLayoutKind(kind, scene) {
  if (!kind) {
    const anyUnpinned = scene.nodes.some((n) => !n.pinned);
    return anyUnpinned ? "dag" : "manual";
  }
  if (getLayoutPlugin(kind)) return kind;
  const map = {
    dag: "dag",
    tree: "dag",
    flow: "dag",
    force: "dag",
    grid: "grid",
    radial: "radial",
    free: "manual",
    manual: "manual"
  };
  return map[kind] ?? "dag";
}
function valueToPlain(v, tokens) {
  switch (v.t) {
    case "num":
      return v.v;
    case "str":
    case "ident":
    case "color":
    case "class":
      return v.v;
    case "bool":
      return v.v;
    case "token": {
      const t = tokens.get(v.v);
      return t ? valueToPlain(t, tokens) : void 0;
    }
    case "tuple":
    case "list":
      return v.v.map((x) => valueToPlain(x, tokens));
    default:
      return void 0;
  }
}
function annotationTargetFromEndpoint(e) {
  if (!e) return { ref: null };
  return { ref: e.id, part: e.sub };
}
function annotationFromCmd(cmd, tokens, origin) {
  const colorAttr = cmd.attrs.find((a) => a.key === "color");
  const colorPlain = colorAttr ? resolveColor(colorAttr.value, tokens, "stroke") ?? String(valueToPlain(colorAttr.value, tokens)) : void 0;
  const options = {};
  for (const a of cmd.attrs) {
    if (a.key === "color") continue;
    options[a.key] = valueToPlain(a.value, tokens);
  }
  let members;
  if (cmd.targetList && cmd.targetList.t === "list") {
    members = cmd.targetList.v.map((v) => v.t === "ident" ? v.v : v.t === "ref" ? v.sub ? `${v.id}.${v.sub}` : v.id : "").filter(Boolean);
    options.members = members;
  }
  let target = cmd.targetList ? { ref: members?.[0] ?? null } : annotationTargetFromEndpoint(cmd.target);
  const targetAttr = cmd.attrs.find((a) => a.key === "target");
  if (targetAttr) {
    const tv = targetAttr.value;
    const ref = tv.t === "str" || tv.t === "ident" ? tv.v : tv.t === "ref" ? tv.sub ? `${tv.id}.${tv.sub}` : tv.id : void 0;
    if (ref) {
      target = { ref };
      delete options.target;
    }
  }
  const defaultColor = cmd.kind === "highlight" ? resolveMarker(void 0) : cmd.kind === "spotlight" ? "#000000" : "#1971c2";
  return {
    id: `an_${cmd.span.start}_${cmd.kind}`,
    kind: cmd.kind,
    target,
    text: cmd.text,
    color: colorPlain ?? defaultColor,
    options,
    z: 0,
    origin
  };
}
function expandTargetId(id, scene) {
  const members = vizItemMembers(scene, id);
  if (!members.length) return [id];
  return members.includes(id) ? members : [id, ...members];
}
function resolveTargetIds(v, scene, diags) {
  const checked = (id) => {
    if (diags && !targetExists(scene, id)) {
      diags.warn("W-STEP-TARGET", `timeline target '${id}' matches no element`, { line: 1, col: 1, start: 0, end: 0 }, { hint: "check the id — viz items are addressed as <blockId>.<itemId>" });
    }
    return expandTargetId(id, scene);
  };
  switch (v.t) {
    case "ident": {
      if (v.v === "all") return [...scene.nodes.map((n) => n.id), ...scene.edges.map((e) => e.id)];
      if (v.v === "nodes") return scene.nodes.map((n) => n.id);
      if (v.v === "edges") return scene.edges.map((e) => e.id);
      if (v.v === "groups") return scene.groups.map((g) => g.id);
      return checked(v.v);
    }
    case "ref": {
      if (v.sub) {
        const joined = `${v.id}.${v.sub}`;
        if (targetExists(scene, joined)) return expandTargetId(joined, scene);
      }
      return checked(v.id);
    }
    case "class": {
      const cls = v.v;
      return scene.nodes.filter((n) => {
        const d = n.data ?? {};
        return d.classes?.includes(cls) || d.tags?.includes(cls);
      }).map((n) => n.id);
    }
    case "list":
      return v.v.flatMap((x) => resolveTargetIds(x, scene, diags));
    case "str":
      return checked(v.v);
    default:
      return [];
  }
}
function beatToStep(b, idx, scene, tokens, timelineProps, diags) {
  const step = {
    id: b.id || `beat_${idx}`,
    name: b.title ?? b.id,
    annotations: [],
    reveal: [],
    hide: []
  };
  for (const item of b.items) {
    switch (item.type) {
      case "camera":
        step.camera = cameraDirective(item, scene, tokens, timelineProps, diags);
        break;
      case "annotate":
        for (const c of item.commands) {
          const a = annotationFromCmd(c, tokens, "script");
          if (a) step.annotations.push(a);
        }
        break;
      case "annotcmd": {
        const a = annotationFromCmd(item, tokens, "script");
        if (a) step.annotations.push(a);
        break;
      }
      case "reveal":
        for (const c of item.commands) applyRevealToStep(c, scene, step, diags);
        break;
      case "revealcmd":
        applyRevealToStep(item, scene, step, diags);
        break;
      case "stagger":
        for (const c of item.commands) {
          if (c.type === "revealcmd") applyRevealToStep(c, scene, step, diags);
          else {
            const a = annotationFromCmd(c, tokens, "script");
            if (a) step.annotations.push(a);
          }
        }
        break;
      case "prop":
        if (item.key === "narrate" && item.value.t === "str") step.caption = item.value.v;
        if ((item.key === "hold" || item.key === "wait") && item.value.t === "num") {
          step.autoAdvanceMs = item.value.unit === "s" ? item.value.v * 1e3 : item.value.v;
        }
        break;
    }
  }
  return step;
}
function applyRevealToStep(c, scene, step, diags) {
  const ids = c.targets.flatMap((t) => resolveTargetIds(t, scene, diags));
  if (c.verb === "hide" || c.verb === "fade-out" || c.verb === "remove") {
    step.hide.push(...ids);
    return;
  }
  step.reveal.push(...ids);
  const effect = revealEffect(c.with ?? (c.verb !== "show" ? c.verb : void 0));
  if (effect) {
    step.revealFx = step.revealFx ?? {};
    for (const id of ids) step.revealFx[id] = effect;
  }
}
function revealEffect(raw) {
  switch (raw) {
    case "fade-in":
    case "fade":
      return "fade";
    case "pop":
    case "pop-in":
    case "emphasize":
      return "pop";
    case "draw-on":
    case "draw":
      return "draw-on";
    case "sweep":
      return "sweep";
    default:
      return void 0;
  }
}
function cameraDirective(cam, scene, _tokens, timelineProps, diags) {
  const op = cam.op ?? "fit-all";
  const directive = { op: normalizeCamOp(op) };
  if (cam.targets && cam.targets.length) {
    directive.targets = cam.targets.flatMap((t) => resolveTargetIds(t, scene, diags));
  }
  if (cam.zoom != null) directive.zoom = cam.zoom;
  if (cam.pad != null) directive.padding = cam.pad;
  if (cam.pan) directive.center = { x: cam.pan[0], y: cam.pan[1] };
  directive.easing = mapEasing(cam.ease ?? timelineProps.defaultEase);
  if (cam.over != null) directive.durationMs = cam.over;
  return directive;
}
function normalizeCamOp(op) {
  switch (op) {
    case "fit-all":
    case "reset":
      return "fit-all";
    case "fit":
      return "focus";
    case "focus":
      return "focus";
    case "center":
      return "focus";
    case "zoom":
      return "zoom";
    case "pan":
      return "pan";
    case "follow":
      return "focus";
    default:
      return "focus";
  }
}
function compileEdd(source, opts = {}) {
  const { program, diagnostics } = parse(source);
  const { scene } = compileProgram(program, { diagnostics, mode: opts.mode, stylePreset: opts.stylePreset });
  const report = diagnostics.items.map((d) => formatDiagnostic(d, source));
  return { scene, diagnostics, report };
}
const HAND_FONT_WOFF2_DATA_URI = "data:font/woff2;base64,d09GMgABAAAAANtcAA0AAAACfqAAANsCAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP0ZGVE0cGiAGYACHOhEICojDDIazNwuQXAABNgIkA5BYBCAF8SwHm3xbju1xYYy7sd0OAIpS8WVRITvfArcDpBRW0yrYuBoNGwdgevzg5P//85KOMXSkA8Aye/31X6aqSFOjM8yLldTu6uDRvazbyMy9zzwgOKQom/g6a15H3etNifhB1SU3kXgQVsw6e7M0xQm+4QP3vDzRvyYpK7Ba6lJt8H5GV4Xf+EcERLVOkazgxYl3h7PDv+FdjElJVZs7TTRxrr2RZUAZtx6MZOXIlTf6DtDavOv/vvtI4L+peCq+4cnn4emyiLYQELHRxsjcZuWclZsVm7NiTqrgNnuPnmjCgUoQxd53u3tpTX2VhFY9DuFKNR4ho/FgLPjSPINHmGrBMfPo+TrQ/Xc38WQ8hiEpxsolKta8GqM2D/6r/XpvfZm1b8IgRVhHxZgTUmt7/uup6gX8QCoA4DIvm+7/Bxg4sk1iY6xTGpUQoZKDRhH7EZH4vQAEBnNq0lf6SpZlGQKGQMuhwjgwAjvaLSM65Nfe+x7wxumASwfAsqWqLcltnCOahodxOqb/P6f2753zV+9tL0hyp7OxrQGA5SdK6sw4Oe5M2p+PnI29TbYSGwKSJVuOXXCgTYGTAQ4kANdwKoAMD8yzjSG1lSbqpPUt++3aGXuX98JPMVd3kYOQCAceo5A8jPq4mWnA8VObfn/FIsbA8JBAdCakpIHEiQEptVg9qctPV0xPe9vrHi7/f11arv8eRf1nbr8ncp2VYgubCUYOR65OgDBKALGSMCFF2e9PubRe9ecmXdWtJJ6ZxTi0QNlkAbjt/giXa9W16vpePUnVYBA02c7EDabEybhthwZTUn0gv0/3+p6TbjblsxSGFrBPy1Q1mfbeVtr1kWwWhOBBkg+Vza3g/76pfd27XPXbILAVkthO8hLLdmA44fe4Wz3zPDuwmcVHnwtk/ya/ohZYtkUNAoOALNmxMwo4XFV3z4nKJqphbq4kTdICkhZmbtQjBYVNbC4X6OGo3n3X2yl3YOz/M9VsF4q4TJ1jqKjO6fUxdx32z4LcnWUABlTgLJVmKT9iQL4nDHgBAylT4CWKTjHOirY4e4lDOXApp+U5JcqVXeVcuahd1NBV9LuiufKeO3dX1OfK79rSzpVKt639vmVluMa8XSgDoAh0FtLun/kzOic2tta47pb3TEIZmVWj6q6ZkfwZhzw8QA8egQcFCNETugPw/v85X5sUhiynJIFlI3Z8e9MUko/5nHE+0JjS3rx8eM0bAcsOyc1OebbmZZhOTW5udm5y879Wq7sNvIpVyJQiYqFbtGxus2fy5w8yt7hbFZMkbjMkrv1B50iJy0RvGiKl8EjEi3Nttm28ox3VNfEIkVCPdo9kCYLc6T+EQQIHInnzoHkY5hgHz797ne3/L7dbSI7HyBSrukfSOSRjKRRVlakDh5Ecj0XixJgS4TXLWpaBJGgLIwxmJUKk+7rO75qapUspub25DUNwVIEVCGaqMCzj3n78to/FsNd2UYsokxAE9Jaxstaedp/nHQUCjo4fKJAEob1jOau9NX+ZtluLImGQJDByJv7W58quoxXEyj7O/CuT0MM2+95tP26P8gghiAwiInYq4R+OvRUAACAH/npZ0PzWt5/YufDhz7256jFcmUAE5G6CAHSDNBOkhBmAAkAvVg4ASFLBIgBMEcS311N0A3o5BXwGeg0AEj0sSO5rtQJ6wKff+l4ZOq3TCgDYzx4AAH5b/wEAeZdu+N53KawBwDc+eNmGOPs4BBLooVAAACZjbLS7sLHNmPkJSVfYOrXu7Sl71l6+1+0Lh4GknYJTdmacW+fZ/Ynb+7TyAHmkfJNCq8SUt0/3E7bp5Cy32d4iJnn+W6Jl7ifXzd27p+05e+XecECEhaSfojNwbp6nd9zexV0yERnl8uvXTMvH5RHAz/fy6/LLcmCJSRPt/6/3HwE/9vfzpZBJA370Tz88+hwIAA9enduhAHD/8tcfmgzk4SEYXZQ5XZx1fWVFBQDKlE9rKlXNr1qNWnUlTtIkA8B7kzppAPDhvJiXsO/0Z77Nd5ju+H9+zP8j4AIBkCgMfXPPORACoRCtOLALYNkHn+4JgNJKKAONlfLNPfDWdCMOClRo0GHAhAUbAhIOXHjwESBEhBgJUlxwxQ0ZchQoUaFGgxZ3PPDEC2988MUPfwIIJAgdwYQQShjhRBBJFNHEEEscegZGJmYWVvES2CRKkixFqjR26RwyZHLKki1Hrjz5ChQqUqxEKQAYp1uvPtPMMmiJxZZabpkVVlljtbXW2WC9jTbZYputtttph7322Gc/ABg+MoR6LWCRoWr6G1XT2j3mAIARMFCrqQjt+7XPAECttvYr7TZKWf5NX3sPqNM+VB6ty8wYIHO8kGHK2rUN+KWgNLIN4RDlSz/Hzf2/QAgDxppgjH7jTTLZFBMNmAEApptnvrlej3ESDMs8lrFqyTbxY/KOsX6iK7waaxG5TW//d8CBXwDXnyaOWKFHDP+3w4Bk0KUsmdKxg4/hBrF+MEnVFCqdCgcrvLRDeAaqlsdjuEMwEYFUcMY6sMpqehSODsbSUegpK5g8uzw+HdTDSnztsJZ9kD7RDxrWdAwOgHJ+uHEQWFmrsrGHSPMD4sxr7sAgSWo7WJZU7FYFuDS7qqa1vf08ck7eVJI8u19Uu0oWu/HoDT6U4xi8BPdInUBueMfDprK2O1Exo4EowGGyZX/l9oaZ0P/MPeMzolzAeI/h9fJZL6fEiMLR4/DZ9G5R3DjgjBhCDK0nF+rtcJegKWsjbuTG/xnOjy9OjztXp1m9kaiVHjfG2+35kXPTTw2yBm+hPDb3DLw/7fMSpqPUxBNVDS2Ede9i0pwcDVaPyjODQZXof3/5AHJOZuyWJuT4NhdwKkYL6iHM42hbm7mbvR/DaEfU/VD3aWNkjhHAGOHwGL1CF/I34o72rAI8q+iWPmhPAE8HZn6FT9M+p6WpkaYAaXrgCJFEVTGyLoDLOJWQ5euiHZlYqGghAAvhoIXOwmgNTCwWI8TEcGoXl0DIS9NJs8tSAkSViuqiqMIyAz4PBRZxntokNoDNDNZvTTuoj1HNQjBGYKEjtASjwCRjal64JB1hktrjvjIeys+qaWKIywULhp71PibeIl/ZdE6mwjw5hTlM54oypce5/mf8h/mnslR9akjCkyx9xmfhSfoX81SijkaPlE1F6ECqo6QU0knhTiQVepzAqeSdKp5CTomneO00LYqqCBYUZMmxUIHBtAj/omsRVfwA9A8UXSEfEB1G4OVG1DvbIyPijZW+QsZC/+NnwzXsttuwVRdsHHRx0ObBxZK9NaNzMqGONgBw4AJW/24kFwSGXiE4C0ObI0QEHBwpnvKMc6UaAcBBbDBYFAHE+rvx8Rrf5t6QY9zWPd/2Mw32Hqx/bo5BLlwc27ixQHKbu04zHo27lp89ugJovwHQZZIBtiraYuammzp/YlWf2tTZSt2mOJTZ6dbNYYQ5iIc0OdZMGSF71AXIAKT4CMOmZEp308ZSxRldADy1B6GV0KmyBTV3ylrYRpwx4v/5oHmQXTm2r46zevcNLMLaot93tDZ44/pmCa/5/QEdu0PkxixEA5lAsN5GBr5/x7FHjdySJ6peBpn1gfFeYG+lcXK3hkchnxqyBtALsBHi+5QpdUd8bZ0f02poNXggNUCqXpcK5ViVrVhUZTvMhQnModqUo88/7/CDriEAkQVOzJNELBbjo1EjynGBQJH8tmraichIU+rRrcpMma2YzjW3dYMd++AJYMauqMTRZ14UAoLYb16J0/lMbkKIuZGCVHjSZoMZcMeYfUQHJ8C9ReOcwawLnBxhLJc13SGdb9OSQnPMWBU2pUkaFQTpiLcCByUElO2xgStGK3sDxQGWsQKPN13X1UEup5GBC+AKWzulCyOKKkox4YbCRwpJaVnZzceEIGZXp2UXeRqgNFVJyXGgmr4JFSsF6B8mSeJA6CE2kKvDsVdXImK6WPNI6BQiAtjMTzk2hD3QCC2yDreK3dIeNFEPnjapg7ysW5LsOkxXaL1WSvpMwI5BR67vA9ylz4RposXi0i7Pl6E1BQuk9PCt2SF/tICYMSEQdyBz6Uyr9yH4ngsVTxnTki4lAOSPxKJ8UR27zb1/KsD4Pkim/TwPN0AI0vuNkScF3axO8CWeaEGeF41qUBMTch/B+rCLGSiPDFF5S1uU1dp/yssDxD4+rScOG+I5c3ug/4/jfTsoJ9bWreJA9uEeMLa1daqr46rmWxBEEa+LO3IZu9voOTF9WVEJuUoWj8OL9KQvt0VfFnCQJxKy4I9jPmwDpJ3ADepU7PVY7GmHiUDUzHJB4ChYdcfT7vex7AKPH12lkI3ukAkBQr310e/gUf4ML6nqnfF+ch/eFu7XfscKPTaWMqOpv5llWiyGuty/eXyH8irGHbIZWkXWKCSH8iH0AJKeR7+M6mo6sRWexmeB4gMwUZB5RTsHeuXEqq93jvK6weNOAtnjyo6jBrAuCoqmC7EAyEsvDr0IwkPSLs0s/YCJgqURHnqOA/7II1LZLudVWxXl4ShQpjiLjvmT82UXX+kqhRiho7DQUXlPwX9bq1SIe0xZnygT8xhTxESAMbFt8aUsWnhII97W47q5T5g3A+witlMcOuJlqOyQD60pTf0jrS+Pr13WUXcxWR6gwl849mDTPsh9ecXI48BiPiG+rh2VbIjByAG+Gjhwvx2bhhKunuJ4x1P9KMac+lJ14wo1t5jWSVV/GpuO+2zt7nOEZbgISctSfPCEBC0Fi93W6TtPmVvjQgs4lCSYIUgyKTPetL3h6wqo4j+BNOvX+1VZmia5EQsf78NccTzHg2xg7X5yOvzxpWfo+chH2CAxllN3UNoQy9DT6UESBP/oag1I5wC9aoZwtUjSrnp94aaUi+yGRnhqfk9ALUf1OaWV522q+s8Km8c3wyP2UxbqiudRWmQCzTBFmqEK4c7qbsQs0XRFrITrAcSjzwmci2iCFbohpI5n0D9e/3G5U12+bvr1qM54USuWC1rbjg4dMTEhHQSIV849b6uuDtA//i+AMMNKWTcwHsCEmMNZXlNJPFGznOkh8mDGJxW6rZORF0sRqu70qRj0lW9Q2qwoEw/br+bT4Wt2zNaOKtXsqULwj86Z4qmgAgn3CmrOKFp5Lt1YhPK8wUsJ/BgervTzjTlPResyDS1wYNzFBfTUsy/nd6htYR870mSf6UWwmMdEIOx4UYCTt0Y5WJytlZjqcP/y2hkbuhdpapclqIf6C44plflFzGZ96O3QxToYQbsuhnZePWArBDAkyZcEQXocoWrKCjSmTPiykomvu9dM3ICYmIHyHTriO5kCM1a4LgbBbED1lKOsqOHikdYHpgdUa1q03Rl1/V0/y7IU1b6RjKqyojzqIEtO4jgO8ISLOaVBu4So7GYHDBOAcQfQ/WgtQgwdUuAHrVcO/oskq62xpBt+ga0+SMF/JbG5JCR9QjLySzjvPKX5/2HdmckFLd9CvS1weqRFwDANklaXtkAfPycBo0khfaU/VQ0mK1vXCNMJG0RHHEULs7dmzbAS5GfQAMgJDNAWPVwRmNyUFUreGjISX98W0tt6tMkxU2GzxITNcfYgMT3cTANgow289so/FSwLj86mhfg2v7bqnr1vl7M87eTwqvlsTBZ3XRcP6QzSP3nXESNI+pXx/uM5b2sy5sfPMgUCRfEfjjSE4PXlYlMn+331ignbDlRV19BUKV87JV5vBMqXm6Ix4xCpPF5EIOf5KGgsdQt7nw38DT+OTyrylaGtaGwxyB1NEFSCfZw5MT2C8Nm9Kj1B0Oqo3j+aI/n9Luk9M+E5UmtfVaTotdbg/6zo3lN9dJEbeQ6hLbgusgGZv6kr/Wg2yOtGfBBKy7NY2qw50jA7YFVOEse1S3vVrNMfkx/3knJ2S3KISf+Ta9FMLVpMn0o4gbCFjNSmCLFa69fXD51cfAs5x5RPYapWe20Rck5J7YTHw88CN4HpmXJY2naTrJFPJk4CtojNReHSKMqIT21JfBjdADghkp+/0D6zcYJ7e1dLokDjAMtrDU5M2Ahgc+MIZMxyhsoYB1iuZQpyPvw3AnkSzjd18RyIEzcrH27G0WfYOgNCJqRYYt78Be7FBMu0R/KqL9HyvvGo4EWkuFrJ6Y9pWq7QJV9cx7e0mn5AYusQk8woKkPa+t2FVoI4RFU55UubO47tsoNcqJbK6sFwOCnVWvyYhXIB6MDxOKrK2qkyB5Tl0olOFJ9mpIWj8YAd6J1NYfN100pyZwRWKkFRQVRiPqG4CgPB7ku29oi59R5Vd/XpXLxxo8SRlHQjOoHSA1fb3GzW6a7LYIqNXKz+J9VE1YV0HuTOnrMHy6BqP/4xys6nD8J7KJUCE7+vx776uFYfxYSalVTlxMEvi6Lc3xYpXwp7J+BFr8v5U1TNeCarbvYZo+kKDtG7jbTPybMS6THUALIqhJwAmS42sCtBR4tyGw8diRc6aj3EisGDbCs46b4qrqfkNh1SLQH3gjqAMCU+HP9AoEU/LiQQsrB2/emNL/TuL6D5kljd1aQqD18Aicu5AFpKVFbNKvEniI3YdVfSPAAhGfFlD/zV0La8iRe8I0nz/k90gbLHRh6nlUeGrqwkao60rC7T2rr6/wLa2b6/z9+KykDZNzfvnNzws97nV9+QE+Js0s45y6Y1kgpm6GTEvQB20xQRp5TmdOlJkB9yC9geQShRkoyofl0jhHgIm9cz/8i9dYrtyjrrFxxRkUVRiliX1rTLULIKQD5y8oTmNLhcKGWSnYq1iT2b5w4gNo8L32gfEdwM2/JV47+rKZtul7IB4Xr1ckklpkCrJ3bpC0qZbC7FgKqDG3r8vUMpcZyVFQWvFD477sdpV7ERmDyBbkGVhbuFhUwZsb6mHwb91eyYTM+3RYoZDSuqyiTFRk4DVfZ9NnzcY2LL3cEwlAYK6WjG8LgsDuxy9XqOg68aWFN1A4ykXFdACDdoCgrlsXFIlnoU0yWPRpoUoAfhhjDwz88ReH3QYj9CS6T50xMnnZg8FyKK0ak2hnXHcpT3zeHyfTBuAJCREyH/CGmAmeBi4oD48EeKC77pGrc+sqp/vN6h4rG3dWG2SiDEmkd9eYHptMUGIZDuAEZnmEtyhaZuqoZUrpB7fcmeTZn4PJyQtAC1SzBYOBJsIzEhFtJKB8Wl1D3+guAeCAMCfKa5aWICG2tcJGD7ms4WrMrYUFpzoDRZNSvBQ4qGsAoVjY0arTEV5CtMqehvUn+JEgOdJkLsUgc3EXWYpRG1zd7pBWCiWNoOlIcmJ4THAdKBqEWHkAfBzD8oNJQyC2rBGsTpjmGrQnD1VpztsnizQxo8jwmvi+YocMa/SyNctJQWe6/WWhKORIjJ/uDJIVmej8fDr74XrjdFz84RroMh5qU942TSgFTWbscKaeRONangQ1ziFrXUuhvAZPmA+NPFZf+b5KGxMY9w3+HEf8T3REulEVXxhNAa5VX3ac5CWbHLOQBywi9OiAoz1oNPjRHzelB9TTq1f3+B6aukQksM6VtY3Qik2c93oek7S/99hVh+Zsx1aD+NSa+XTKQM4SGlVMz7sfp0jhCEsUAI0UbeY5OWrkUP3eZFMBTPB5R4Fxl2I73DIWCmCFnriHhbTe81sqS4a1tOng9eeLEdfT5ilfc1dadZpuijqJqudO3xbvWFzhEUXkcrSGl3Jh5Vp65aHVObFyEMHd5UVEenrpQZtc6tp9Jz5prqatwBWnVfVPFn30A9ELtCDMzo8ZQRYvu90j+mlbwz0yG1Z2q1kI7+SRRblpbq+RYIBwsvmtrtjhypm7Eqp7YCifBjGXUHIQ7Fw7JsKe18MiMOR04dz4I1HEnZeQ2GYAMBTCFJVcS6AdvtfIjvbZo7+5X8yyXdDFPsQAyY7VkZl1iX2bVFCOsAm02DkxFIWswTAMJivfk41oMje7hBQkyrktIeO7qxUi7bvSpyNgKLDrzNhQkQzDqW9qTM7TFLZ8bU+40oSG6Ohd7DzKRSfvRnSCmKSvWHgvaY5SJRbzaFb3SMBAf4uXtV/qqWo5US0/fy0TExO8S023EQkn1pag0NM1GXhDQgJsQTgooXkY5qad4QfPntE7dWQzb1j29RBzf9hPcSGu7fpblc2kVLnvj7GV+WPaOBGXroOKSjuD9AFMCAqaQrQ69wGsUypanluUwTYPXXz76FNtIVyzuGui2YIWw9EYc7xzwJ5VWbgDmSTMSNM61X611iA9GZaY5iFKDXwxefBxyPf9MsUMW6/m19ygSorzld8lVHqrrqIj5ivCBc919Aut7xgJQs8PXBWFWCDmaf9WUHMklW+grDdpTdl51HRmqqtxYlMbJbLUFiFKFCIJSKVff1LqXnKOUjLbUX8vlIvJz5CwXi0KWpUqb3VptPIvOXZlIr+9D5EwrSOPXHRp36I3ZXKJjYwwyh8yrW8WkcfRqn+7cJfmalfKq1oVcnaa7Ip7LEd0tVO+BRM0MeoYAqTuyu4O05YuOJKGexTv36GA3CMLulw3ptac5mdQ8GB/+YEPdUdY4mfHqBIMJHKSZvKdJy1Q+KkL8XRMoXqLIeQdNRdTlA8Tsoej43QRgrBUlMRpSqyZKC9YdEgCPzFYfmroJVmtq287v4ABwfhm7GKrpm7tjiPnzN5VNM1VsB0UV3cN/DwKhGbZrdgoz3vT41R+zoEDPwcuusIwoSd4qT23ODlW3ZQDGywrPNKkik8GlS68q7M2on2/kTVpeK0W0YD9N1U5zddn3mcVgg/BTiTq1/tO4U6mV/8OTwdCzIkkcPJd2BbJQ/wZ1sJ3qoSiuozxTu1Yv17q7GnCWztzaP9+HFvJXOvqbsKNxtw5te3SabAPYR9QBhU0C5Ki9zKX05qR/TRFTjMNvQqEtdQI6X133upZQNHC/9WsxvknaG8PMR8sKTehUlTodTtrgdUAK9Nzfg+GqrarXWLZBKxHK6uqo3xiiTpgTy6UKQx+taqjupXaE2CwYzYGlhEtYIvhlNyztvDeY2Y8pcKe+ZoVlYjM5Yacxo/fkIGtImnhlzBK93VEE5jyegyxVQLZGPdHjDp+Ry71Q5JfGXDreOmNuHuWPMz7juOKBvXQDi7tFUmGPC36K/FOBRsmYTEmJa2PGJF7wvtKgMrd6D7GSBkMnyuJ2VTlJTZFo+9+EyswwTTFdlslwVnAL1CKZ/KfSI5qsihC/0cP7dS3Wlfk52hV742Bv4EergZ51PjWL9A80yI3WbKDp5PlxHngtEeMfCo2/3PhN6nIDmAHlJl/KiMW+Gt+G6N1N0b3+EGbHM0jYezlYPN+cOEO4Vzz97ZU251pMEUk7MiXfq2r1cZkvkeSNd71nkK3/C8x1MOGX5+MWwatPQByQgPsR1qU4FjCfJYcvrBAOlOFQGizW3wdv6UDCYIS6uIVf/xLgZdjrECCSWZDdq1a/CmdNTY9exL5/30g6wvcAs9I4av1ycA0pUuHSm623IDCUm1ft22irMcJ5WhfHia9lVREOjLMVgmksWFFnv/y4zwIR0LQrCRuVMbJXQvmdkF4JAv6pDecs1q+w6z4siQImgrIZpr16nkSQ1pteYhvt8jEk3VNNzSkTyCK3/GoxrWK+DOO3RWuT1qXbwgjBwP0DcVOrb77eVymTaj9Ah3Slb63MCqiQOmx+PQRUq2Dm4AAnuP9vQhT5bq1EJBwpPh4s+nKx6e4jPmVvTnqvyupEEn4gVTLC3sKKG4Vr9C/NY0rcvbZNMKo9WcbDSP1p3jHml2tBBR50t6kG/T7KTJBCeOJLcuol64BgTgV5olOXzDWxvpweYS5RtlIZatRVR79rYWafKwayI3aA8fqsVgeO002F8+DZtDcjiwjLNzrX22tlUssuyRZo1hQJ/65JRMBfnREpVQtfTYfTubGYgnK4ozBZCvtEx+fxQVDIdeTybyPgoYV7dECbG55uhpcZhvdstpczQ/9ToY6Eah0SKyQyf69DyzgdJVunT0dkT0p4+v3k1bXSjTRl40efIZmrrzjQOBEI44XznyRlmgOxiEk9YZOvbAKqDqbgN6uEAc9nNGahSFE3BnDsLx13gj753kkkajcdn69401pvO5ZDHSzRQp8mHMFA6s4gDsIh6pdtKoCu41BsfaUZf/MmN2zqcsyjsBI0vETyRpec0vZRu9SwmMk8zukb3CYTODOndBsNCTHVpeAtpGTHlgCBypAAs8qoZeIFcfbrQM0D8A/pUgS4RuFeX+lSwUD9Uhf2R35BMAv/uV8wCJuw0tZAhhF9ourZ5KvqY4tABwQ01eRlQVb2F473e48sdXGoa+ulEiW30hHTIRJxbM2IvPKTd732HlM55Xy5yDHFSElkz1C0euY1MCRfvzmhan8024uWpAhEhhu+kfcCCpv0BYhAYkdKq1gyM68p10sJnn5Vsud0GMenRu3P913ue0T/rIBfRWM5Er0Me0UxD5Dk8rEY63Bg5vuFgNnlp7nIUcsWbRYy6QrpXM650q3cq+uBRhVFN0eCCsYH+D6t4TE5q6M7FRrkYlHShV+tWngeMRw+vnOdRj+n1HE7oCBDsufH4Qmrao1hJd9NwOXg0JQwdmM5FJUqqYLVsFvPzh2Z5spD9iCBkYzn/u5GY6v+0szCoHVimWdzmEqJqZUj/rIdOyq8YwUogPw0G2DBdw47s2ZocNYCc47h0NI4XfOyUs5ptsVYVPJ6rU7tMSmnOoDiTTGxJEU3NvoAAQZxAhZiQJs40+iCb4grsDD/S9+yiXpMXGR+dgXhQE+6INPcx2c6S5jNmkZ3t8qU8F6y6OJzhcdFYT4ljUCpYT2OqFceBjtObOC8JFnzwBRhWSKts4uAJXbZXD3AKuBYPncMIDTJzlZ0dWp0TBBL6slEyTbt8hJ/niaB1Fqus5Gg7Bq29MrSUNnXyNb+H1uYuzfusfnhNHO/kHdPGI56JMetQOF30JT3nippxRKsZ/ZTSA6vUtSikC2fZ2YcR0OMJZNlD42I2qzIQ8mdoQ+rExx8T2r8O30HPewrjs0xnZf/vSUY2Bw0MmFk6V9Gy43mdY2bpNkvtvMgaBI8gOn2B2UbMIxermFQhtnqRCrXww7S3AK29OvX9aW8UGLxu50CpbsS9B4uEXKRi0wdyJD2qjjGf6Fep7psNfFv2wL7Rt87UKFF3WT1a9bsWXwrYhCUmJl+x68BDx3ozRsnB6KY3YcSrTqQvlBvo9MjfxnBTk6/BH1P8XGbG54XMxHv4STN9n2Q/4wA5grBdlukABnNeyiIvb+M38Nmv+AMnN8r+PCwr12l9zlpOiG5EzmTLwhIuFwKdHgd7ezWAylt+Lbn4HU5xG7CmoRoZAquk4Zq12Jjk3afTyg7JNIBFva1T0ed7/aPAvCZv78LCGtOrkDzy4UvMPWmf+1tNGYxc3Pel8ONP55xjHWIiw4XAtwjENUTwXTedeCLfO4ehHhhnvTcPmNjyvpYMRG7uAkG6nfJ2n0dUKvO3S/CFy2X0zl1SalCBHFqzTql0eFCgZdU0RBP8JBYTvSqAbTm8A+et8HKKM3NxsQ1FsnKXej8bvhQ+dthk1Y3GGDOqItkoZOuUflw8hhIhIHjFxbw8TXQQmyunCOHRYNxriKbdgcFQGsD5fBBJWyMRaV5HVTV42wvBj/LDO1xJG17e3xJ12brGYdAw9qTkhkrT9EyZJzF8IEp6pabSIU7jJWmvV+i6b/D0COxOvjmqyti3P3Q690AO7PREETPQIiLqzxU8WmECO8Up4mW/GNd+dbdPRwYOFqdzBUsaiDTjDZd1ExWnKny1GTgOfGXtU3YB3iRIqa5H/Scxj4+UcEIaNk3V4mX9mk4xwRIMQTh5wIRtvSJJvLm8T5cjZNaQmACJCXJxSNfk+mPemKgR2oRvzs6aRx+zFLRkQnZbv7o5Hluiqlm+WRnSPwEbMBg5o2cmOTMYFLVINE/ZnS7rkhG6LDU1n0kpEFxHCsgHAzUNr2B3R4Z+GEXxXdVMOEBTCG+GbgEpwac8ncPJErQCHHyBtLC8v4ikggBRTaNK/+roMbTL6xvoRGsmGkJgRhQKkZ9YTXnLc4HXxJjk/DD/mts1b7Nrovk2Ddnl748Yc5nrxGQ5mFHwkHRMVXZX33taQZVD9OJjkeRKz9RJMg+EgPCOpcooHix06PeMqluQWS9D+oPO1i44yOsikRCnEJET5U/KHu5rSYvn8oWxAAYn5sX3LxgV4oLbK75sbS9p+LaQ6ywSKXmT40f+v0DxzVCiqJB05uymzm/5NYI0+U6J5cUx+VTZHZheBL0tUYnXUUQu9zXlO1H0J6LLzrhEaCYoSzkMvN++2YqvfxuMG0/Adq4w+IuQoATL8kqHikY0L9AsjwkfYllrk2MewfzKxrIbotdYHDTFsBMSAvfCGNGK9Y3loJGLCbX5gq+thNTOGdCsn11K+SbYYWtollDRGNMy5LySHwzSdDvdRhydAkVv3nogE2Hxq9Jv0lDTyfXwcnDQ5zab0oBGzBD/LiKRowFvW2MCPowzVTQTgCd4uB7/HCjPGkC+ID5YS16mWAQzWvK/mLB3eQ+2UTkNDfDaYRA+vEfo/LdmDCfMGd4y0ijGz3ZpOslNkXOYUO5xYtaUJ5b2L0MtHBDlb8RSj5Y+RHAjULxnb7L9o+/HxWvM0A639Wwpmrdd9OJGwZbZrEyqwc3BAdGiYnJBuJpaksPgCjr+C5Znjd6TK420T0FXnUk+XX7b4mUVwcusZuQKCnVR87BX1c9qRR4fqDdTOyzRxY6XI1iWKcQTpvfR85WEfulDzGpWDI8etr+u6+c1e12w5joKLV/BQPvfu6lHoQaKw4vA+Uk4Ze6W6uXEQJcTSzQUhIEwh+hEO0vHxBoz8b4S+7NO1YGRx2fcT4KKjAOau3VGdYf74HzzluAY7U5IaeBYBR3UitSXMd7B5zpDDik0iHbgA6qU7OvBlweZkFdcgX6AEuwXQOjez0Litdg5qkOwlOTXuByDYx5IYrLuEPBADbVb6uqEvbGIJa8KK95PsQShl55qlonfXxKC1gMfEaRY5taeSr46wkzW37XVlApov4J770sDSAyDye6ccOUvxWv58f7rJdTVGc/iIEtUHxlxsD9z21GCAMshbKDjBSyH3FBT5/6vZCem4YD8oHzvz6umcG19ODLv/DHMx63ZKsbLkelntN27NpCexMV413C1AiKqIYZ6QkcfzcnkO/BBxBw0w90DRu4tKDKdHF+9+s6XDovzFCaPjAvQncb1xmzdwrqdECqoLrJEiAeGFe8XSbptd3ccY7uIy0uK37mrxN53s8o3iA8vvnNhJWIJAWIazqL3uQ8nSGVjnvUxp0ysTwnE9SlHGg2PPVjT3kCXhpptvWE9h1tfTgdGsl2Vks70FUqJ8z4sfzbccI+QQ+5P6bNciI1poo1SAkeJZ1HjquEoLZSiKmu67YMR19aVB+j8o6STSjAdduvB2ADJsmSy4yStdsTo70fzUPfG2gkjIvkn4yntivJTjigX56zhT/3vT5lhBdtpeY0P347erSJTZeU0+//9/Z408t8uMGPR0yEsO77wXaI3iC0Hp/7d78PAcb+7hXghskyFehi0wTuqnqJvLkC26CV19cTBv9XZuPD3eQyYV7BfQVxDNJv5cAac1TEqWOgXRBF/JOl/F9mY9wNN6jFmKKF8k6ZB2URB3b1eg9YWExM7MC8+6o+Ouk1U6QAhXKf+nqRgH6jPEEIjnrT9hzPbhsyPHL7dwPNWp8vFe3pCOZcYfL6KRyi1xfCzr91n7R5rzAmieiG0wzACqAV1cdRUAKPdRA2DTqQZXHXUOjpSALnsD0PJCYFRLqB4LaZq/cT4+pfaM4dbdRrbZfqRmtQHn1yLKtg1Bl35OMX3mfTacb9UZiCV/lB41pbF/R6yMUO3WMjf4iH5t3fmrmU02uQptVTmJCCL6zhS4PuAgDACDsmZtTApccWXxkfsBi98pEkp+1rteXmNY6eqBX/gmUDPJ9dwUoKSIwS1F4jKWPAjd/H1lfb7vTXlfV+NM1KTV1bGmITlpx+iqEJl8SYcEISra0WR115C7m5Pm4r+EilrWIC73C/phBu5iOZWeNm9jJ5NQot3GdqeI81cD6JSBEohtyZEADZGihlw5o0he3heSwKPaL7CkzA/aTs7t57aZefgSH9yWg3cUGDLtbfaMpyQFgirR6Hi5buaOVso68JyFDo0xBYxTvBhsbXRtfqBYlGIzbaB1Guc0RX5873m7adXidjQkNt6Vj8f8XyhYMvPK8N7FTymuECQ2FAL6teNyhm/NMmKIBsXrcWdyDclIP70FiGiyQNrvFtWHXHV00BpordJvPxArJncr/kIyX7RA2hoSif7kbRrgglAPuP1OGSCMa8SPZNwA5LSfMUwmuOGymsKK8cAbVfhl8AN1HP+hT5ScP3nY5er5XlUaqS8RWJLr6SYSH1y4KuqZ82mkEbWp2jIovRmuZGcc2RTYkO6veiDEQTwymHxRZIG5pgYf/mV9MeUl+tN19AcWNlf3NKHMN/BaiahQCbUkzrj7Vb047fR4kh7IqVxWHJqXv1YMRrb2R9rttCu1NQLduxTXNs34566B709gJJIuazjEiyxrdNPk4ehwHkVd/A7SQ78YjC8Z2gJHBZLh/Pv2jHGN4RYCi96gRGS2G8p4iN8yWvRGAZj8GUt+umrs2bFaAldpB6UvtWHZxgWNpxO2dvOruChexur7SxjnLmJVngJPSbCIf2n6dBaJhjTkdgtzGwSloFaCrbsuMBr0eFkW1Pe0xXlhYkzcXLxQgPi4RJX4v1rQen0Xij2cLoIwj+dkCHPEM7vqUqGeOImW/3xyl/K0TS+yFMvbn7qo+3W71Bk+/fR7u9q1QxmTbvcN7mJjar8B8wLBP/vmSDgwhUuCVY5+wdPzOJxE/xBTA4zhF6EmZPFvcMSkIWT1V5ZNuacbTvFjB7uXLpTsj+V4CkE+fUqCdCE9nLQTNVF3FlQygXTJ6D3zfY1ysYewfHV3rJf6qfNqhu9Ou2WxKw6zZ7/W6J92MUBGpzLp5hIhbD2h/zv6jGlvuHCvknY4yB3wlYKAUwlOaXSo78Vn5TvtwIVYdaNEAS7fjNVSzleeKMn9+XFPNJ0RQWPN+CEOX6MxoemJSIPW7x8NS+7uKSNmdpyaFd0NvYLLlB6eXzt/dUiQlOal6/hLZI/qC6c8RwsP/oM6+FWZ/1Myw5Th+F9j+I0XbygSu1oUynbO/A6NldHu2ltiUVPWOkd7HJqj5ir3kk/Ty2vT34mhFATb2ZZykQWywWfO9/C76AvEQSTE7NRfsLCCVLcQZ0ae7wM1pj6rOJbhAO/1Ex2sm8zO1C2s32O9Lubu/5ghXjrFpqheMtpI5IqVYyrsHkQcE+YkuQlduUvxm4mXNd0JpLeOkEoCcqCIIYwNnRnsr4kw6zbm1x9gvpOYSy31bi14zcOBc66NXCWCvUZ5yMo3IuH/+XvxquzJt+y4/a2JIZU1m0hejzu2KgxxMKPvyswMzVVtzVTuj9SS8c+Ernnzf5KK5V8xfxlUL6vEUofMWrKbHZbW94sc7ncHjE9dwodcpPNh9p5Mu+58t6MxZDPZapmhDi/mKwn2Kmj/T8QRQxlUZrmQacWSiOHL0G8DUEjWOx7Zauun382tiJyk4aw7w7CEokcPdaZiCANnHcuxWpSIY6zQCJQrs/X3bHLZlyKcjs6JfY0M+5W5DkRQAO6hFIv/AUbiAjZ+zr+TOQb889dmnDl99ADWZIPEKwZM7EbtB+lI3aJ06XNl1bQLhbT7tYwuSDo6uuOamO6G0Ween/R3hjTuM0p9qytNp+ln6EXFZRDPO4qUyHmKs25aHGi8JMIjyB721244cZOA2XZ0fcveOXfeUGpeKqjDmjn0+ez3Js85uvsEp9JPFbCLqFX/geR5r8YA4E77eSfhUWLN8gCXq/ETPLOCNYKoTKE9o2o1FPfB57sV/2/fmn5IW6S2Sq/VSmHcbF+/eHV4a+MoA3Wu/fFE1yuLCY8wfx3fP/VMiCKpNRHkjJHUk8HEBu0Wj9S7go91pb1O0OR5QRoHZrd+uCfC9XW3oGh+t0W7wUldiWfQkS6EmRZ6fN/y86sKl7cpmYHQvYy5mYVT0poj5njgmq7rRKGRPc7a4GnfsB0Rbqa/78mtRtG0nOaX9BVDPqvXYxeM0s5XXpWVgkd36EJFvMLUeLCnROfO+ZSJZr/RhhYiIgF7Z8wiSIrUQgeT2Cs+KIuEOtnTqxzAfWzVZFcH4ctRPya/FmikspwvMKJl/57P4/rxWcmqi+lplargetPV63qXYUnXkSwonUNGAHI5W+Itjx0DJazxY0Zc9AKPWuHp9hR699urbJZKODNJwWfTWsJBvRPs6nVwklgAbUyf1LMlP8H52UDethwYo5PI57Pt8cpm14GXbQWKddqSfn9CXLYS5WyMr8qv2XAhW5QjK8t+yHpea3LUDyGTmTF+ZQMCiIrMB+TxeRyUS5svSz6XY4Gsy24w5fPOnWU1cFjAmHxt+vzlKgHHrjKFMXryYOI0lrehd1yvXOT9Be3bE9O5CWPeqD6r8UpixZe4BZJLpV3UzYS/cUdgmIkjI05preyeGDLLDI+f1E0pa17SzDYgVygLV8I/RdFVTr5f9KBz/GaKDuakOeGwQwHrnj3Yi6V8iNsn9fChZpU0IvcV68DB6wvJvzii8JsUJ6Ge7ZRKQ2wmFPwJ2Ll5THltI5g7UnPd2VT6Sh63r4vj4nVzyluy76sJDG3wnYRcO+ThUVtyuctxUOscLlk236XkSZ6iKDQwtxy0mM+WaHAGIF+SIg9iuaffMs/DuQzILB7fh/9cUpY01a0aLkMHQfxxIjhy0M7Lwoi3wJ5NFc6wrzxhk3+OI1Bpf07D2OL3XsXqb3WdQ5tsXvzMTF2KApOfbto6NG1zW/DWhKr3QMveliBON1+GELxwEL7JQRDXYHWP/HwNYmT26qoUgAXNP/VMrAVa6QL5O95G9GbmGs0T6uZVtWI7ZI4+gfRz0MrnQySktE0X0DNMMS7JA+35dvbGFzniPAn0G/teKPs5pKUTuU8nqY8oRyMZAqSjQmcak7PE5U2pDSXV5Q6n+clYoJlof3KgygTCMBXZQhyWeRTQWhIK6VAc64/HFkosYC+RbDhRxNWrs5PxvwhwPZIYe4tNK5Hw7Is1tXpOGAibStOhlkmL/VFhq3a37L9o85iHE6z6y1XTnwPmpyzq3tHmEqxGG0vQFQr1qFEZzsnLF8iiFUsYduY0pLl8mQfsndIMtKCp6sCiO/86jBnF/gON2M846YQKFsRLynOGN4L2UoZU3d1W3/IX3GcPc/I/DMrrd58eWzftl8PlXUjHCgXgUA3NOz+rrQY1ZsB9EW+3gbRg1Iavk91y2E+GLYrGvYVNbOktNVSHml8cBESe2Jm/wNiPeeIrovSVoUJ/jZMuFqg4QBUPAPmHkhlhbELfD+rsuTW/kz1069mERq+6rdk3PHK0PyikanNbbr23CyV3pkLbD49yPeWRqU86aPwzFeX4SRuCQ9mNNUgtPutQRviJ4Tu9ixiAjfiVCa5VIqhUjr+a5hpbhjekNbNgWDB4OJLL/PP1LzNVOAxMGrGvdLeklpQZzk5AYMSdgXBn1J8sodCnLf5SvtL+Y6RaJn4nFe3eeTxybPdyYJRWCfwLqw+0CKuVTPLSrN1Yxf8eidU5tlElEp67X2f1wrBePksiHRmj1/2v2X/5c3p5X/qg0Toif2cXobiW/YXW7Kv5AA/qSC74EvCGIihAmZcwzbyktnKX7cchoq88h0oHAfANvGNHx1NnUXyM5wGbleBA+KFjTt3uNnQp0i9nrEXnVW3Ot24MlBQmdT/GFczdYfUXw9puLGzodIU2iVmZyGeVfmAoFpmMXQlmkHC6gdu3lpCn4HcFwne46w7EmFCEwg6b6KKQeYzWupF1j/UTkv/IEtfFykIXccOJUlLpeSg2ebo/Ic6aX7WWC0ZVvRmwXdj44DGLuyNJhHmX9b35/KFKvHBCjJ3NTWzhiIpFsTKf2XXiuxWLERyxcs4sDaz64IZiKArxMyBGxP0XxeXjfDoT3+4y/d+8gY59OwvJAdH3+BXqt6ELCl3pDwBQ9J9klHT7VeUtSb/SR6QeEiy5GhUq2RjUb9pB8ow+4DpnzsyxzL56R8S04X9b19gMyef6AlurVcPRA5U6CVnZWWJUmoZeKBsogiKVbe744IsnmM/+DkIpoOwBHf3hgjJADDtoCUpRS/N2XlQeMJfDjwXb3elM/Gy/ESJeei3fFGvkeYXmGVSMeVIbMFiwfoHtTfyj1a3jYbBe1+zsdsNQGh2pKYQb/mbDtzy8ekSP1xApA7am3D15Hotut7yytYUuhUlZH5qfHmkltbVKlSpBRfqQNU98kBpKRpJaQh+2skuOq3kWvd2kvNAGeP9J0JjJ/+kUxSpXqnDTkOgIXu6dxv39hPibdsdMT4Pem0O3E4kGsRgmkF0I1ZtbWk1FQAQdbmOISEDDO1WELc/sleBdJdTJFn/MCattmXzMGygo++rrw982ky43zKW4WHVro/PpFBvxLO1BKK9v+bHqddNm8e72E5CqYmTapcHP2d6Aaox+8WjcPdMhApFb3w8am3qeu3raOrtwmkp5IwHn6rEjQ2mYaQrYpMN1dDR+ccB6FJHpCJJifMpPKI4lThotz7A3ieLzFB1qOg8ZQgmwo1iu3B6P5npc6/hQabXcsXNGRuyp6LsBosMVid7MIWyTuvNaw/uR3dp0foWNW4f5YmvMiyjzhjwDxDXc1xUTvybr5pzuCTeemIePC4y+MP/99x5VGcAZruaHwGpf7eUzUGGeQrHmpBANqUw54bvOpGm3TycDxLXeukJBLmwJHRWJa14Ubu4auFhgaLeqQ3u0/l+gGz/oN7KzeeFy+/EzDgNZ+qFu0j0c7hpHzh9ZNnCP5jatlUbkWxe/ZjRLYbfO0lz1fG1YG+Hr4LkQStNvUt1r8hylJthZ9KmEeLmglVG+YeXqWrT7KnOX2N/yyTQ2TmpZ6QWYDaTnHJ8IYMGCqoYyf0P56mzFqjEwOQLCR3d4YDq5hdZPdZfW4uF8fbRgZRddqXFknlkNrqU78yVl+tWGVrYXzjqoqDYJ+uiftN/gmnlVMMdM00IjCQB7a9hQcBCCpCo9ju1AMSPFVf6k4nD/BMebjBWv1qsRddZOmQsoTnVW1HPpr7ZpY63AcwU415v83GD2TesqHybNknqYL6dV2Ul8qjHMjcjvhXMq5wdqNsP6fHO7WsMKR86SoINefUrJkC46yyXNBiTRTXKuuNYVQ4gOmArZUxkTsr+l86eAbJKKipyuG5suelRJYfx4DAYo90w+l8i/6/qSv2L97Lj4026WQH7vJUnTVMAUaMlOKeY93UpZWs7KWmi7EuiEmHeQuBsm8vn2bVyhKqnV6UuAYMgJKiGHtfZxgiTRErmEFTiYmkjxTFSkKZk9afshCiFm3DBsTAnRA6W7XRePwOGWh2UHQVhtQj3P3ES1JGQXZPgwpa1O67aI06vV+rlaOX2pucGnBZ4LVtvKUhz4vt7VyZZa30YJ/uB8BmapkxxO/FUEvLM9kE7wdnqQXxD3i6ZRlXHswODeF2QuwQPODBfM82bnSdegZIBXesxfQFIXa9pSIvPQjEtyvwDXFiLrPQIM4SAy+kKsEMlrgVHpNqXA2kgAFUICs+1RaWc/BMyqhYWweoJQTDXuqP4mRQgG3ZuyrnBsUbXLAZ1OvbSps8s60N8xUrRpFjgtLL5kyT1m8dSjqVo3m7zeS4EkdcAAG7fssGTpiAS88R71/OeH8fBmwPE1dZFRH1af0G9IRFKU/1RA3Jt7olb5+N0PMat02sAFSUqOuS0u88bqg3UvjBKeE0VVtSlt/squXV4lZDMO3TEyURVBNLCxO7YZiWU8HvUx+Rilo+qQeHKSI20w720yd+TLDDrbaG1O3RomUEr0BWbDYbc5rsrZclNCVklcY5FDJKysGJDsT6xozH8rvbNaFSKqt/Mp4nCYodyr3NTVslp3U5TZll082cqKJ83ULmOEqSP0V39V+VINEoLSK3xUezhpEc9Q9Y7Im1Hc5TVk7iYMbJBspiSrnxuytQ41qortZhz+iJYZNPK4VLqUKAeWN2/KEg2Lqn2nCWDB5FemfVApPT7YV5Jx3zSaoQbMqwrK3TkEcPS2My9TP+pKNGZfCE2sz2EGMTpz5uNlzOhfQa2xPVwpu6igeSksJNjiM9YBsfhEbt81vciw+A8yO2t0ET6wMdcZ5GYmOh0KTO8xihvcPrOfuG0SlPWNPx0+TSsYNba+WyhQ1P6Eu8plcEt1OQcP+NmFz6Le5H/q5P43zpAG25qENJmer4iZl/Z5YFtMaMe6F5Jyx+YripTfHyA1OSm0l9WikYL61g6KGfkybqxy4cqFsMaQI7SzSn/cw/mmiPXFsjLyLFWlhVqjG5JwhORMJ9xNNR6cCrvXNMb4TLr4BLRb+t2pQGAPG/+dQq+SPs/+EkYXNCZ7gsEUtpQku1XCqvXK7m+gkUhZb2WDGAZe3VgJopGDYc7xxfVw2GBJdKwUU8+dJmqXdmdfzncP9MqUczBJTMwQEsftOsFScitC9znD/LQV2w9orZt/6SL/dOeeANK2Fw/5vlpe39bfvYFmwmDKk9tXRnicybTi4uJ32PXdJb1U1tz36hivE36Bc6+JG1YyQ/BmDuI0maTzSNVktZGt1bhqxaB1caL9AHk2TLL90UuKbiObiyDchqP1CpO4o5lYCekMv+Z2iFJSh06k2PeX0Ama453HWvUdLBz3YqMVGrWucUqK/22puzitU8OQrts5ak7M5pAMqmnahWtawn/OZeIz/aV/OEpgq8DC3lcptw4BTXEwYl3yrJsYLuXllCsx/7zh8W/pSXIdUYKXzmTKzXAm6XNTTqoh0weEKeDOjx407gsZJIzq0R2JuvabLchFh1VgB9SYMyCXw/b837nmHbrx18+q5cvBHoO2ge0nzZKnlg6QakO/IWD0R2w5eCoapRqk05NQ8FhFfsODOeYmlEbMdmkeaTc4E7lzaYajMcbG8Ra6+Tc/vAXnPet9AHlgCUY7ZsKiQ+RtnG6EKVu3D3bWz+5+/3e2mtwvIjMEx3IEasWlZ2hNJw+WzJMohVH75WstSfo67qko1MaU4Rp6/ALh9dgJKrepiDn2mIliADdh0VQ4gylrUOU7RnhQCssDu37DaL+mcdVRoQOwx+YnAbrT28KL6KvDIgx+eDwUqiNiwvUxXyWE1WzNwHdA5kgmgdGmdvD+lKuHn0lB7KjyW722Fr0BWpFlFdj+jHl3GhIAniNoJWKfJfQnpxHODYkv96gmIG+Ak+gktgrfIFZbm2kYNUE4NDWoXm7UpoCxfJopxw+/ZP5Y5IYAJogh0TWnY6Bmg3UTCoFjwBdz2ldDU1hbr9TAxsLFsZEpU6gxQo8hSdyUOvC+No6wM65cVZbTufAbBaHdTY2t7z3fu6D5J+h7gIn8YQr+VF1vvJJZ3AZYZllB+qiugeMjID80h8H4Wcs3xn3B5dD8y3vOUQLWhqcrBISc0Gb1KUmNyo2yFZBFSsB34sAUTTGJ594UmYJzB2jo1YTSivTA0oZ9coFN4BdxdEWvmf+KVRshhB8hrNGBSvrRmQlHYLWarrK1DTxpZ2d5Rcg7/G97og1lFenFnq37HuUQtkJtMQPUOmetVe6DcU+8Vm11NyvPljd81R/xRqAVydC4QS/bDQdH++EbjzgCc787Fv5t2RjOLbebaj+TgU9iT9s//vv8qgFXZTanNsZ0+Z2KmlgEcrm1PZBYY5fOc+UxFRp3dlQ3NLLpRnnxhQyxc53OH7Si5FYNiC0rYYH4+5GlItyUPMFGcDCqFzWPYgcl5bAAULh0aajqL/F5bG9b7ulxcjv/PQivc9/zURkm2VuYUm7QLIiB/2guXKIeW28pPrNIzSMxVWOzNWE5ux8Vom60WK39sr05t2NPYwNvNkry0Ic0f7xc+X0Tx73ytqC6YlStkfv9G9R/xvOaxCuV7IdoHIYBmNaHbi4OiOhmZA2k3ZrUmVNuvjZSbTPogefeBsiwVIniXhovKAkMIkG/tXCpcNgi7bHR2sh9CuzX4xPmUZ1jjw7H8et7OOULSozBbiYyW8GGHD8xFqHkNbrNjNzxfOAhiLKkw6aMiPLEBpWjXz7m04SFf19Cp8/wVjYfgDG35D+EjlKkXwKwyMS34uIy7cq88NUzX9dFKh/NpWbg4vJGGZxB4GSlhhzP7Vh1dyW+1Bsd4i8F3zI0GbyMyU2jb4unXU0m4wfFuJNJoEsnwBhzt/BTw8hk7gL3m4rbsChvDY9HbkhxKXzAZk/UQLa4XsL1QWWrc/hpUyUpVrXN+RYc47Zu+gMjvnsg9ujarIMSu1LsxM2sfL0un7EBGq+MQWsrgWjfKrQefSZ+nUdk14GkmRwRUuTHsb2vcIm04ynWuvkjkFLcZcG4Y174KvN9XC9Y/75SFKpykxlnN4PN2nvf6d2Xj/3/A1hRwmBEFiHW3G/d6IA5a9FMhFhf9mJNgYv/YgGM2DHa4p7I5D2kb+8vD9lu6X0nBYuEsKNwYyz4V2u9gts58oipu49kDT1fyq7qpfUZZyOuQ0BIFhFtHRNH4RWvBEEyW+uztS1wdR/Q3KLfXp6JzMMiy91ckcgvPRPtnulU6vKHYWNhRXXOrjO4+KkGgXxA7DYKxprQ8mdED19aOZmqEIVk8l31dC4TXbSMtTmxoyF4+IXPWiiqTNlK1MOgpjAp7I2UagxsfS8Xh+SsG3Ec/sWBYxE0EIQLBmyBTva5aRWBV5U0Cv3jXj7yPzcwsJWdUHFkh0TESrA9TjWJ0oHCwIoMbpk15d5KY+iXnCt1nYqYJem/C8IeVm+VTJPS/NmgmW9XSZqrg1G4CUdO4BSVmLjFW0tt3RoJfUmP0O2z2cDe7GMJtCDlCQKuydGK2rZ7934/5UYIBuXUPTxEef1cX50U10z75VWq8RS17pYJ43WlBLkXvrbvfCyTcCE9ldrKdl721s5LNNq3m7lkveP89jFvndSt8o0afm2Ar/LjmOtKgek3SZ2cPNuzgVBk6EyMSb+JzvqX+RnBzhL9KyHu4U4HrXSchKksuQaFWXxEQydUMU2A4JSq4imp7PqsP8Fb+7MwCRqyp0b3NdO6nZoiqlts6J9KWJf6xLH+2sQdvC9ydL8ypNJSUpBwQqU7TniQnO9I9BWrQFxuLoA7bk5Gn9fNi1sVxWefDmzQXZ3qSQQSsa08ZFg7hYIIORkdFQ7YrCnYaLf0qubihXOkXB9XU9uT+7PjS9kmYRJYavy4FvljDNvfcs7wHwmnfkrKfB96TEA+8eGD6nYz3jGMfNm603bjUlugX3GQ0g4DGeoZqdbrGUF8sKnIUSGblbwa5ri6QXw67BZj+D44bnABrAJ+aU1QLgUG0lC0jv4Q1N3hpZVpScOP6Jtsj6GXWPbMNSyQtIMcDUTzjQz9glHs5ogCM6sbXqoXFy897wV3RLVBULnrzaK2E8HHcGnyjdTZrl29t4OpN79A5T+edlpjuBxU94B1BUNFFSNjco0IQ2hNfLwC4g3EvVTHjSxbWu9IyxVmnKfj0qDOOeuAnWY1jJmjGCzeiFDXU/atU5vXJkQvxhcof/MpevjQ+7eMZg0IoJisQoqxoQwr7SiFZ/kOyCEV678FQEg6++DnXA9Qf9Z+SRw6yn7c1E54/j7X0YmTJtfDa9RymJNwc+z7C8EAy7a5jUDs8a336aXZoeYcrcOvisatl23utio1yTUv91jhWuFxbrQK2xldjpmQumm2g7k/oNrkmW7NvR3rnykfaFy86ygt6jK+aphBKAOPVFdVHEtFXtWnfr66pMAwiWKCl+XjT3o1F9/abJdGV/ZgPzWKZ+BLdncgdXU9HhVCB0Otep+6zZeBiSfXGrLd2eUz9F1tvxZba1t8I1wi/0M0/Zhm10jnIKk9ra/giUKg8Sbzw3I+5/8yR/R9RPSrpPkfV2CMKwiiRRFOc8KAtN55RiH9vZNM6nlT4DXia1qcvC0LVk2ODdPPEfoGXxjDrIsFEUj+8YO6xELhuMNoqI4hR/5RAYzEzQLM+bHXOTWjG5u3YxH1Z4Twx5vU5FJOMyp+9eWFwMpTE8QD0D88gro3ZmwSUbAM9wGyDsyHOKVdXgPst7qKs+MZXDXijrmbGlojY5Q/hszhmBcAg+frMB31qNy9M5ErFr5Jyv9U6Z4+jXm6gz70pp3uGvolSTKtCoROjIMQdZZF+eQgW3qqQHJsIBzW9ZJMOSoGFs1GbYFOP8SgUgM5RB4MG7/FPqMycNg4JW4eYT30AEpFACq+ykTa8ju7Ls/5/GqKvXrOsPm2fYKzfrxpVX8lDl61JwA8bJChWLl4NcYq7Efn0BGa+xw/Fx69nOT7aMvEPiXYvjO7dQk8K6GCHt0dAOn4JnCBQ4UpZRB0vxHcP+d5cSio1iknh6jvYrcxvT1QDYqeW/A228ZVT9fPWLd2DYPV6oVLCJetMWpjUpJCHj9CR3dm/xAJGmBe+W/mgTCa21W2bdJU17VIG3uVbLdkpC2JicLCA9ItirfSVvGHAdoueB5DLWgLPwN49Ao/ue9VnH8xcOPbZIEE/9gzC+caeVbAbBBvLFuJLmy9HwtGrI5MGDNbSZiogG2iTvmWuSGRPKbM4JFGKyuHRFOUThpSOpMCxSoObBgmgfNV4+vJluaJvMcwit9IqBNv+P8x24dOYbOotk/BRJ63Dp8WnLAP2CfbFnQDRCAhabYax2oeBO5eh6/fbBpWHRpSnnNYCkMkKEBVB+R4xqE06x1By0eZnQ5yWwy8fSZPSDzsmG6vxcWEaf1gxxsykI+PgdF55/1FaBZiJzCNBXjUdvqwE+3Q70TpiU+iWkKtAAZFkRaThhue2lxdz4T7e293i7ljWAt7OACBA6U6GOAdexKrhQ5JnxU3CgPzD7ojaNKivBIPt+TttYKkK/QampOW0E+phS/znOYbu2xOlkzPY+qorSYzrA4HUwLzgRvcLl0JS8I8klKyx39PwUaDNDb3rknsbC6XWnyM5UDud9o/RAnNTshnxYLVCZXN2X+r6/e6U4qAt1/aeIpSsVT7i3KWttQYadjcMymFcWJHcdHSovIp/aRxFYPWgqVHU8HtpsfEU9xyYC+HN2j3go7mtGzciMwjSTx1+KydvWY7gOLtJ+bnBEK6rBEdHfbrBjW4TvHKYEBEnNG4CWzus0MY0+YHywEkW6RCYmNJjnCXvRWDULqeLfZvKAADtENSIu7NX1rFXbs4HUbknhOPlJxk75WZQRiIv6QN365LuEKrcyDIfAWVLZYg5e8NUJTu/M4KekxBP7ogMAx5zG5sEfIr5nXxT87tQFtUs06MyjpSAglR5FT0l6UDdHKJJjC1dufNbHxIE6+tW1T30MEgMXUkV/Ho6XBdnusvoA37Mo5inbRJB94nikL+AfJKUICvK8pP6PrcfAPaRppTO14E7HfN9LKCnhYJJmyXf4+EGYto84o0TWm8ZbeJz3YmJPRZT2m1FbPUhUjST0ifb2f9u7/jflym1H/Bq0BfpaW63he+mpZQbZoOTIQ15OS+KdnIc8+cd+8u20GMmLO2klk3e5ue+TyuoWrpbLX7ePgONsloU5ypho/oMQIaXSODJfhPA7Na5MFKNPrRa4dSuDlZmYhExYCbF1b0rPjc/+CdVkSdwZbup+x+CWWdqKU2Wq7ncMyyCEu01R6FtBxmLWxjI/oS/rfKXrlFA1Jjq86ZaBpOcUIx9asNS1v1yKxtFg2nT1Vk8N+rcrF6iLO2hNCJS+HFpQFlHMfC0/2l5vFYxEBD36eucaF6cPhYi5TtWelDchqZkcT8va5XpatpliZKR3H+QKZ9jBX7t2Ngwlwuvx7Ke7UPetkiLmMZGeH7P2vr47cIVILjV0diZC2tXwMjn2oEIvwlmM1ta4xu61SKDh3ObbJFcEGBKk+ReksnKPLo5JsxXOWmbpC+JGqmL4cK7hFyRtk7gnCu5P+NMMwqPoGwrx/Uu2CRmmf7623MzyaloMbJ6gXQOEK91xhcltOzfAAoRiMrAPukh0vLsKYvjgL9P0WIzEStO5fB0clEY0ao7Gt+bT1yN2rSectNGrDZUZssuFlpyJlgetxnPkEMztqYBSYmSZQEv1vRM1ghUS35StRtGgRfDaT8QZQcEZMtTHEQY68NvX8669L2Y0mJIk5cVIJ63Jsj55Z/6b3Cp3w7Tjog7RyXcHnDyymwjIVtr5HudvDSBz99C3WjjYul5TDzPX2a74OfrgwgSbTz0EpINWwcOCARF7Lv7gcFk8TMb97kEFRohGy6J/nxK/3u+GqiKP/U9q0Zz/L9784OQ0eN2XbTRuNm6bqJeWSdNDcRTuD8EpytZ1QDYHtv2cIgLqdmz4NFGLumW+QU2MEXYa0rpFprMXMeavva0ewgrUVXlVcsBdYB4VRD7nRDUBpzi3ar0sWVBueokw6nChJfsv9gmIU4AGo2x2xgWgy8Z9AnDQkc3YcUvpqpBXVppvWdmbg9Gghpg4jpi7mtVSx9ShuCCLA0zFH0olaBiUEuOsREQkWs37TDtDFS+bA6rZHoFpNz57c5+Mxdjmno04A6EKkrd757cviO7kd5HqbqQfLDjQOiyRplZJxK67Q1FwgEV+7zEw445T18ix9TX1vtZqx9kE9ommgcLAgyQ2r2bQpPLhjkL+csGCChBwf4NmLefC+QMgR42rEY9rx7ODBFCcE2FdG4F/kCY5h9keRXVfwwaBRS+PMJvo+/+/ij79ywWO8tS549HGjZOKC4xiqO5qbRlz7PKoYySVt0fLQ3DLR8BrQ58uDxk2i98VoswbtMgtNI/Mo7uPTDaQ81gPY3968zGl0TMgRLQWE46gMaF98j7UneXRdjqE0Le09EZa4dP8rkUSRtoj6hMWzZ6jGeA+tFunj4V/53rp5X1UH16DVOuAgw4p0/txbDKKFbGTwvkFeEtmn3dgYWBOlTqRpnLjNeMX3Cu0akXEYRsCe2/lSyi6jgTRGEqwE+dj1wdE76OAAaTH+mDogCVrv1FlK0585S0kRwtKTAHeAG8MkFlPK8+si0CmZ6RJ7+MBoBN58ix8jKK+Cs0E7Uzb5x7l94dLI8HvBDfq5cn8+6FDx3JBzRMM9T92ZAa8YKDoKzNnqYb5RzsIpo5wMUhgv1b0TMtG6R9Ph9PyU1vNqmsTgbAK1qeoHl3Tl7q1Pe97K6cC3bojMWuOExN7sqv6aiVMrYRe6y3jIjAm5gJAp1xWUgv3hEvXUVx1dlggyMhh9TbyFr9pQZS5RBofeQt8/Xb/tLlBRlJUvVjCPMIcXdAq7kl/GAUpK8LY7e9yDWw7QmLcg3jfCBh2pAoA6T/OafXAXEbCobJv53P7e996AnpPnwMV31Bl3NBjiI3aYmC7I35Jd9z5brsDqWQ0mk/zFZsRUK8PZ/9WhCPhyrhvxa2vajtNLzoRm0p3N1gxu1ze+AAwPz96ujtF9D2UunEZhRo6yuB0UZoaHCZRISabOxs0DAWEyZ2bI81kRxsBNc90S7C50iEyIYOPN65JGtwMnFwoQThU6yMZN0dLpXFFZ1D1SM3He5qVibpY4p8pLQUh5LsCZap3ovCnBH6PTJd6dwZ9n3pwFv7zBpM4iQHmrUOrzwJ1ycWbuQAmrrLE1w13DslVKMY8gPMsgAaROpI3MgZmYh2kF5UGDLj0+kJ+1lZoIoIlIBHaLInIbycmgKAspK8iTfa0cVz8X6msmHApZkKXLOc6xc0laK9a4bK8PejgDWOJGuX6mZ5of0B057WHSfT9qKy+Io3Nmf3SkYxAYCUIuQ61Huo6ydyk5kjXDd9PxTdSLqYrImcICuQn8nusJ7YRBYCPVyabtKUljhIUuuvDyJZwUMnLHgKY8Xu23hQJdpfTAQ1wzhnsta2eWTtCn8Ff4cTNwia+5psjHmJDtPtzznnKRJ8oVJXdU3BWQ94t8S8kJkAl0OKvyb/t8XekWz134n81tj4o6uiPStu7M3kThw0yyBPP0GOzeE+cZy0dzfuAxmcMFU27Qk70xnqGh7056eaKi5P0ZbxuYX/Z7wLWboTRAQwKhrftLx/8lNmBBK7EZfNr0cVMS+I8Fl5LDp8nqrPnlNnzZrK28i1vCub0X3diod37ksOzZ16YEdz7isNvm3r6o4A5jGrzxpPSelIrCArbv54Yhytn9J7RNjv7NuG2o04KYkuLnsnGLyNYFHEj45SaltCPszod5iUB8e4irI15fW8dNUEKlIsvIDd/dPG4GePiUxjeM5UpSaib/vNq5bYb8hPy91fs+F33KDUhnzIqnlJQYT/tmUiNwehGf7o6JDUtcoA0LWdmQhT8lfwDbvsci2OwxmRoDlC2igUTrUEElNcjkDcHiAj/fIbq+GzTGCIB6Lni/MeGH/wQyqi4U5IEcIsigaHaGDM5Tl/EiEnJalG2ePzMfiOlFVGPJxz8OXnSVAzhUQfo6vZraolRNIzc4lp8nSOAbQJB3d/OZ+ApkwU2KypSidPQos1z6mQlWwzj4muyaYMYRKv4BZgPT9i97u41zXL4PkHcOAZhJ1CAyAELtl2+DEDgES7WB6fC+EDBdbpAHcWA4F+qhHAat85ftk2LDslmAR2lQ97L6izAIAr8+r7A0jfFxPdYnnDFpv9kxitQLAvZcimVmVPwG8MaxJDm0PiaNp1/esCL4oSvjLhy64x1xGxsh0mRFQAzYD55C1gPMsqsfNRfiizU/XaWZCCu+hFNC2UfBq5Q6wKdBXBDZk4wGuiB0rnu4zIN5vCmGD3vw6glu0wqwIKymVw8QwCclBfYAeJgw4b2Q9xkdeHa5ZNmKsmO5D6q6ZgpK3AdOm++TCzYAZpEgCewof6qdlUYvLj7G71oyDNjTM//Vzd2z/3cztC9OcZI53VDGVI6Dcn23rz0hb93c95VdE9OQ3bqGgIY20yKABoxNjFhqoRt67oLuFLTMI9NgaFc+UDl9+veurEC09uR7ltGF0VPAXFGx7yjOVzzvf5k+7EC7p3n5e2BXwbEUtd+4r4NXVo2Lng1UpWjpPHexKOtfBu+9IKMjBJTQdpTSIAYbGcpiFsHVtg6EwX0FmsHDbhCQP+PavTa8FtvlBndGj6QZNdvxRe2ihqxhg91DuaAA1IA6ucOgDz6o8S9VvnJkySPuU4FWZt1oVYan8XJV57WuOSeMRFymW82WaDlePvsSOWqEPToDK758dsGWXeBlvvvK6H+/mycjD7L3cBUECDNOCsSqi8BHGMP8rf1l3fnK9+m8RH2KYuvptN/Co6jzbu5IFm/MZ1aUWsoWJB5x/2+nXaDnf2kspj5I5fHKxInTYqdcuexX8qLn7TqyOAapBqzRWSs2IH3x2NAioDMkIfdZcV8IHTFnmBcNxZe9ezC78ovlATD29clHqbzzlcsSxRQWdN6UbbFsnLlt0iNH3kf04/KQ2dXcNi//z3gISAyCPEXpLdIqJJmcjF18vu9ySOnZ37t1LXspg3jHAa8HscKnSPlybyCgKVBpKSAoKOyDAP/oCPQa6SwtgFediChfkk7cPeYzYsdKpthP4UrJUbVfeLPnShpbKFl7JPP8A9LsxPfSKFpN+PlDQfikVFqCsX3IjfEiQwbTdX/muno+v9QQCG6D5ZVM9Ju7dIQyAhF6GJpzeFzvRdQLPKD0iX9OppvDFTAW+M/oam+95PJ7Qzy59vm6iHTKh6TR/+mY/+um/KZLYhudL+4oIpNUZsYF1+Naa13ipe1t5hunOBP7m4Gzp8FjCVeu9Ew6H3Q6za92ws3J8rwmcvXFD0B6J5udu+xw7+H9/j6VXK857xTaGhpbfrdOsuDqrnecVMgAQ2CAHPaEAwKAgBJeqOsb7JBfQzMZpQlMfD+nJZ454oz3NCgJPAWPOgydvCCzUoTNqhKsBKmkegF3eoC4EWmWC4CRjM9Z2Z5fZawIiNpJfXhSPrNku/SkRCcPBs9DLfQSPEEL5hvFlWc6NcjivzhuWb7P8bocSrFpAeX3VTdKdvykC3LvkHrdiieZs0M7OyDN3A+x6QH+yyIvmyUmZbB9KmzBN9sQNOmXtv/IjN159ZAeK4DigyqB09OR9B13x+FZui870m0znSAXztddmJSXSDhraAeUUxJxCvbHZGgoCPGew8DEMj2De191AK0kl4eiL5PUBkPgBou+gFVbIwfwSR5BqYuAtEyp21q2Sz99FR00hk7E9IKAbV7Ioa4ogvmyHPcGLR0Qa/yR7vniQqB2gmcY9XKnugzM4cl9dJAcxihksRJDQ1GMS89eIgJ7n5b5UDK7uQ2rum83BjB5/+UPxhbtX6AL/GAEgM6wPJnNZVSenbj6PsGcse9myJWsDc/jlzPW/FZrCT/34Q13X4UQ5dZxFwAlK0JLvmSrWhedOJMjY+0hFyl7AUcO3R2iIjDMBx8DfLF4OAeuFMBLgg9mzsM8ogMCHsEg5vILptZ+s0BOUNfMFYA9jaAvTJj1EVjePISkw10X3WWsme9Aaq+b/J2dCALyIlGyl7n8yLz3aSG3qcw7CcEO6JrT/P1tbh2mbi0vIyD6nvruxqqBtsHJLlUV4c6U2+mmZ2/kfzSu/Lt2FtAgpp3Zqhx/Zryyhcy2tW3iO8wMps/y3bMICMQowoS+3UpGM9NjjNX6ZQgafv7AgQPF5oNYBap0090yNTXRZbuKGrjPDo6OzKxht46Yz+DdA4pPa04cW7GR1CTLE7jNQ2IncZaKEpbgD28c0fu4vW1l3P/85VopBcMx5y7XOa0JJVOYFyuZEs1NSh0DgJd4HZ0tXv67Li6RWybKazdWjN8dynl9jX58e1ClzD15nNnamPlDhTkit6xySS6CQTAGN5QGruQFDpiwzb43Fs3oOtVT/XDyDT66bIa1O8IQ77EkYzXwIoc21wnONvcLBnl0xiMs6EBFxVpinYprv1KU/all+YclvhbTV14B2A2OqO+CeQcBDE0UsVVuGAhCZZJBFsSZcWyCBqSD658G6FJIG0rJ5C44s5rF3P2q2ca4dLITMEFYvdzYdGNXRYAfkO33VWG6G5BbD/yIFlCndMBHWYfp8FTAigyvkPGv0mAO5f6M4yZfVAf9aUgC7UGNzI48brzs49BMzJwhiw8nDn78Izxz4b56sxG1M/OTzRhuQfWKlvrks/OMcc1UegJ0qwT8PA6a5Qg47hDHTeBbW/Ij16ldeBUwOW6mx2t1EJ8wVfE62uJhJXWhmFgAFD0y5hlcqpuwehSDWgkEeqSwfBk+1n306TSEAR2S1JhIAgCv7LLUZE4uvETSCv7+95Mlb36qPdgw3GUWADuw2TCXZXV2iNvTu5JEcPR4j0v7jM4l/FrAWXF1B7TN3uDYuRNDyZZvedU0K0QTUo7GU4+DgCpZaHffEXFPSl/5xSTv17L6051Wh1Wl3198K/7+5VslJx4aZBXkFLa6zcp8S9nvav3FvpRWFRvEsTpxND0wMbu8L3+4C24O/QU0xIJ5iJFrG56opQI1WB7KpZgQCgpysWKoAi3WPUT1Zi11DxF/if9i3a5ZR7f0SZaFaOfOm38BjQs7tSJQs30EYhWuMgl2/ajE0SQMh8qhKk8fuMjFzN5G23bYdOz36tDbjjHIjRZhmnQl7WPHmsB1geMSEEMKB6KG0sltKfA2kgNUtGBoKpzJvvo8tnPtwDT2pZIzuSu7hqX/zfvpvL4KmxIEmI58T8QOrVYktjpw+eWdbPEc4cjsqOvHd+xbm2nvY16wlk+DugfPx6VUUEu4JVRomKvKjNPFoeLAv5+VsBpu9yk0cAmJP3FiRedw6eZ1PSuSeVghUCVSTeat1fZhVncGFCc0NAWxl6GfpZWVxYbRYMvQ0BRLWfgw9/zuvA174tqfvwp0/BL9yrRnRYFkRRC3tQFmPFPO8zZ76TPMpHuFNjd01cHpHjb644MLna5uv9SDAf0TnXh6JjmHk4CfWJq4NYJF1mptiRSPr3YUKj31lgRNQMWvRrRTfd5K41GKDzfF1aj43WiNt8jeTigLYnP86bmgAzoMc1cRn8RDGyksarzCDTSDzH0cipEPfPVzGQ0nCP3za+3qsAqxYOMpEIayR0jBNBbVIvVM4zbvkGPdVLsGLgH+rhZn+q4j91vYDQlPWBQzrYJN7koJpgR7l45N5gNEVv32JT7LMwMvDtwX2f50XKvW7HiDcWFJEEyYCBg0g93yV/UUPYZAp+1DmSQ482jIBtxjUuntRh4aAAeg/DLZXMBrWdgoQDwRYaGYn5moP/q8IjaoXJThlQvP2HZLpFGiIugeP5O0gPJSULUeQgJXLJHiXgmqhcEkyQEJeSb/jV7SNTAN2t4ACx4H+5ZWKVuIR+OUld6AEemRqGiTExROYeAJh+pOOktveOesBL40sPZ0NGak1G94031IRpOsAkuolZQuLqi39D14RQkbhpKZ9PxKtFHUrislz/uZM/sX7PS0B9g7NR6eTbv+37phc2HF+Np2jdUcXxgbmI0HVfkUX+W3PRoXANsv31z7uu0Psu5IDjAfrqM6oG2G9LCn/9gC1Hkh7fzEQO8iHwpWDL6Y50vnrmQmrvk754NnoQuXmjv8tk51fAKta5ljsmM0QEqrxlDhIX4QtY8FpAdu4JYO+uJZzQARCCxMqC0Y3pSjNIT6R4LzutyK+D7tUSOAA4oz8PWgEv64uR3LU5NUGRS+ucDEnfXbIzp+Lb7/JDRKrYk9BTeulelz5mE5gnoBgDTOWE6ssuyl6kFgezc+JGypAEHjo8BLj84l2j8DNlucKA9qhyj+syZ4H5eZEofY7J97wPjEYH4zY3op/2Eyv1U7en5zidZ4Oo9rO8TJieVPo0x+9SBmGsSPh9EUCh6hAlWjp+yPWVg886HWcunAs2nqC8qm9D5o0hXBwTyqFk1U7USlY/4BvCe7JpS1d3uBhYKuWbkCF8xk9tODfhR+DgiDAOgLuhYrE6oKU3wdsmRr//BQbqF7X4NbGAzFmaHqjq7D77UsreVC6YN2YeAFqfmSd3bqQIckoF47BFyzPmtbig9/cVwK4HE1UTot+SmU4bG/Izw8RMLc7VzkxBZhw7hl6une1iL+ziQg2/rl0RlRxQijeqpOlBwlBORMLC5pBgS0FfqCxq5vNGk8zmkiH+k/HmsVjgfogDU9eiupnum/EjE8CFHdBxiSMuBJMCL/cMnJ8tSs3XaKbfjHr8YXU1TVUGxhtTsqNLkCccSezKBeD6cgYaSutoS+pkxjyPgCc33S17is8QsyHTn0GCiqyQgL47y3X3qXUEU2lKphwVz3rf4c66eZZSE150xLdqtOeRRFFT0/w3IDMK+gvnV68XpnbXYlYAa057ZG87a0Og3/Ip6lut1VSahdZUfHqfJ8nfEht1zYm3Z+fdkfRL9tRMdhOX2x9vgYcz/AAUF5VRdKeFpaiGshd5/WOO1NydZvXMWJ/+cpLofz5Rf/Zy7XbPAf7XXXR2fkMK8yaA3INi6aGqJQ8ty5nIO0TDyfchygNRN+D7TzAsENH7R6MJH6cmBehiXQOcx9ZDT7xuJtDfYAcCS87/7krnigceY345E5ZX16OjrQBxWAdm5NwJZRwbtTXGjYkYVJsqaBkLjU8UUfDdHDKoeBTVCqcu2GfCApmVUQYM8E0sAxDW4/u1V8drTrtzLPeRnCAlyPVo6Hl9UTaD0tAXyQiHhjVoWMAg4S9cvrGasZXFT/SI++xLOBixQadcEKWDRWeZA4YTTpKsFUlIucAaLmwpp6LewZqpv07+FPrYF845d7VJxmlyX2aYa/OOepfD6LETq8varqT8/pK1WjE4VQmheXhA7D8z2RhomeYpbTr8THY3rL1I/VE1mmHa3C3RqXo6kil0PcvBJsEiAMG/elZNcv1hOgcoOyss4t68KZmvbSw24pgkQb8zG0e+y7dwcgp0+INlPtPFiwbxNshzx0P1IqJuy2tU8O6pixQz2hXfoqPSwAeAmmwx1wiYBRIIp6WuzMzhSG0UZgxSl+ZthRQ3CTRgRMj5u2U8LbfC67jCnCEjzcGA788LVBQ+fmsUPUaY044B/3wU0sdGtO5fNrwouHvgnqn2ubHfjgU+PybHnprrOZIKdzv84hQtND9M53r+/+/aAbn3hVmQvMJhXkA9XyEBqjxeRguko9qMlqZRuYOcazKPR9L0uUHjB8wR/K0+Jv8K4s3ZCfzK3HFBfCl9p8N+vV5Y1c6HWwYMSE3Tq1R6FMpuIYwLXj3ZQHc2qmcpCOhZ8DneAud7/7S4DZUi4/XwBUXyRJlQlY47b+ZOLFMH6SRkBa2HSYVjpPzKTaMz1/azjBGm+ODjIa3FN/zgwcCNnYeebU+g1VPD+45WAxt2bPFQZ9WC2AJ5PnHQ+nMROZBTH1OQd/dbaAR2ZRnUuUoyXlnbMDMe7hbeWzWHJaPe1hY1fcQPqa30kUY5ZU1r2ZV58RPb5q1uKmMZnjtH3jO4arvhkzSRN+rNQCofRhpdu/oO/eMmVXX8zwHL9YKIc7XBpmfu0nzJuVQD2DNQW/OON0zT8TonVS6uKuWB+QWe3LbgufeuWayGP6j4FlYC8GLpvRlwYt7SaLmcREEOdvhNPhXEqTlAjJRpfZK5cdyUs0lAWSjYeAMYJhtD84mPNzV9WIlnX3h6+t0iW/PSUSpxVZZKL5SseULdMExZs/nnu/+hpQfIm7LQG8cgVcPZys4cxjzI+C/pQ/rKHASvj09mMX+LlrW9B0PlhWzx6o+sBSDv3hLqS2g968m+Boidgibh3V1y44XLrvQX0WHLg2MOzSW+cQBXCyM23cXP1Aeonl0qj75q5LMB7fmTb6+kldjInR4Ja98P2m3/6xOR2oXrUWEBrF551gAGqlY/Xou+1s+0H2Uj6WXyVfCTnlkczKeNKHUYXGwSg0tGsjxY52Ed/RUApjEpBl/JAHtCvbAsejKxRBu30a9E3CtLqSnfmrgXnTW1bYKszLHhlE2ql1N9OcfC/Qy7Lfp0I5I4GdhpO1C8LP3x0ZWFkYvCK4peLrALEB8ogCl4gY3dqyKGNgb1aVF1+iJm+AoyoT4HY8OBHRzcrZWY8AwtD9NCn/NZNfd5ecR3N5g7InuBCTKEY5DH/UI+kYmbBA5mdXhtdPnJccXAJWxHsm+lELwIShemr4Du0bCwv4ZnaQOzt2reNxTTvnVaYA7KPDp3cLit2f608pqobHnToM73gSEbz6RcPblqtDk+FS71WfopcN47SLK0+j0S8+lF8cyk0slf34BqAbcGpaT2cqw7ASou1yBCh2VeoAe/1uhfBzXZhliQCEO0ABpWQxc0w3Hr3vjUOa5CtkY8MxDWOIWpai1gNQEuSf7SLVJ7q9CsHRbYNeuzH7f7xTkcm6eNuxU8zAM7e3fMXSgSqX+HyntAq+lG/1QbKyTaHC4CdKLFABUmn6ljwDPEsA+830nYWX7qdqwo0rpp98Ks+G7QE2jXvhS/cRnXz+w16km6IC4xheeunHdekiya0qMBRIpXauzeWPVcmIgcidGFgsxOj5dO6On9w8T+7nEcn6nKLyXdp4BRVVbTi/qvLfTJE5Uu+syE5RPz9pZ41n1Z48M5ebfWVerDfwni8dwl+mFYpbKSgl3GUsHb+bopjxZUK3ZyefYwKS75YKOQfNMz8rYcBGYkmxEawWGz0qKCBpQmQCLSoj61hqWDyAURgHD++xPIqxmaOibBuqDpB31HIjr1g2eRFMPArYaehVW3Ea4hpeY/GeSvRjzra7Ps85XGtY3rCFejEQ+c9BzyHBthom4zpdMJOzMFgNI0x/XQCUxIHzITG1QRRB72kEfr5CJV1UGrqSysVaW9qrBAJFAk+Ws9Qlx0vDI7PoFO3VBKGVxjYBTJ+ih6B9xuqMzUE52RFkLa1NAHlOJairEl5IcTueg0tcX2hP/MEfNuKKL0XpD0L+nnXGVQATUGnsAnqb+f/+TaMF1oW4FzNuZ3qSr8LHdcah9P0C1vgcJliXmSDbPdn9E0vHLGAlbGJ9ub9A539dJEh7lRfkebxSi/TuzU0FlkzbVg5CFIhatjJttOXUBp3vATqt2tXoxUWnBexRQ4YheL6qI6Fx2Zfa+agh4OkaBolVw5j1y9Fme2EpYKId8iYw7yaL64ycS2MsLONtqM4PSNpGp5/FASrdt0PgImPS4HgaEyzk1YKJzAivmsNLmZ2neMJTID8mHaiXF/u87Xib47nvIy+suFIVndJxc+vsxMOUXDD7kOtCLaPtaObP4Zsm+Y6CyqmBGeZ2cnEax6ICdcn/zILuxmXT66BAwFyiMU5GVpWol0DvIwWMGQCXbQgLcXD9UhuWm3+R2ehzXFE4AkYRwvRGfqzOm0oDW4DsmtTQ29brhwnKyrqBITvc4p2cdPgIKHkpr8FoYk5VNcdQoN2SEF9KAVx6h9Z51b5s+75mflxif9wpnXVz3LDRLh8r6wMoXrW/2VK9h73ZMcTbI0tgC7fSWUcHZcGZfj6C8O7Bsz1K9oEtaJ5UCwTS3pzhWpj4rBa3gIQfjDGvh8cqbzuCFyNUqE+B10VWzBwM3V5ffzvrV9I9nraWAlRJQEcB1TyrMKQ9I8klWnpGYjSdu9W/epbUhlIVQJkFeTruc+ZuyKNRprTg7OQar/TwTrceenh3RnRnCziCklVdaPF3w7mldOjtr8kRrPE4GoK+CQ+d1RxUnKwGx0OfaI/a/LYBKvqQv+YERlhPZQbrYKG//QOrOVh86yIlQH9tjzNuomusd9YQwa+JyyczWa/G3FwCGCzca5rwoFeuq7br6QKfWbpW3yUpxkq3pAhr2WUpNsxg4n4tUGegkAJ+G7jT3JrAd4xH09/savl+4+r4z3/tTIcQGsNW0JjMvfKGbFCMGQOsPQimuyZlmQyInOq6vezOfVMEN4cRUMWpBhfVCFb5acDsKvAjFHh7u+HS6o3AuNLPVmI7MUC3MrQC01ZJ4Bvq5YD39p2GXktb7ah4pIW35fCle+n6kpFhKfYG+Rj6pXzN5T0aEDdRAGC5WB/++2YcRkpWshRf1ZBPBTV5uPf7CDqG5gaEze1M0N6Dn92IuwxWcwQ0JxPz+8RVBo67ATVM9GPACKTWRPp7fir7Rucnfjyu7BlYHILCgHCz8k35U9rV/w1wkqSOLzu7+Z3qR8HwGzs8SrB+5REvNuZt69bbLUWLEv4xriH3gXPIo4Hkzv1GV+KtKOFcqVrvBghkGIMw6AzVJdcn/Kmk5qLDcVzPEQnwG4EGZT40zMwJpdyqPcHZzz/PXfPYmLMpoZKsBNP1JaycppgEP7PVLA/6o6VSbE5YAMvpV4KWUbO9Y91cwAIgC6lN6k6rMobPzn1bmXV/lq+gLYuCNMwi+jdGZ5TqYSgALS8ydRRFOhHSIbdwQkEY8jIbTvUYZZ6S7pg3fEE/2SEvu6r75iP5eji9e3ZyollK0CDBiUkmp+iO//blaQuAtjJGY+KJX8UG68WL8j2E28pKRf5QQyktQdjlQX7uise838AljISn2+LtBzYF8y7sWIOYo6dmjBK5KFM6Nd5Jwa+hSE29aFvs5qBxVQUhEtoT+RwNMJ72puHGl15GMC62LAxpnlLOeT4oj6wy0tk1mHT4COvNkpKrAb8crmCM5HLZc8Akplt/WuDUPVF3q8FBAjYG0IrzxYTdLkpue2CjHEYDHuuBnkPvK4pMFKY+8Pn7TsOz0SlH2yLIaDWaC3WrtqmSZKmPc938E1gDX39Nk/KuR97ZOcPvwNay3yuvMr8w0fEmUcb15oVaKGv42yvJid9evX5171nZ97p5EAeqKb4nEf86oq1dBQ8BJDPEokS2J14kMoKjjcIN8utXMYpTWKmAwF4uKAGdEHkKGYdhTs6D3DQBN/GWytzIdKcREYBnMsKVJ5bbIuYsBFrOu6NTeYGjFj9YAp6LF+xhkil6f+PIvsEjTLHM8MJsj9Ll3aj356ut4D+z7e6hBWNtUav+BluoeCuqr6NxWTr/q2fyEsm0xMfnwUoK+VjRwp8CuPeXcpnPzm5+6Acg0mQGYQ5rz8KSolYkEI/1oYbI0GNswdib5Q6j6lB6txO8DqwcGBZ+KLu4FBDMEaawNBx2L7+4P/U2a+ZmFEzkomMp28WiY0w0iiKlDBMi3stE9vVIMXAM9NLvtsV5c+GcqikOVxq7lkDFOxmunSTGTOYKafg1nyK8Xz7k/vwJy+csz+eyTzBx9wBK9mUG4Vdiv4012TYP0GW8WeinJ8uAVAcw+TUlc2OnmY6CQ6HKA1SOjjUpx5Xvzc44naGKSqLqDW+dZRqEhaH+FrLkaONNo6uiSV7q1wHL6Zf7cQ6KaWl7p4O7skn2GALeCL6SOaE0RQUBmkHue9Uy+rY2Jk1xdBNdHB3yWwhAqkA2ITiw/M2bQlCpaIJ3NAoeq8P/N2p5WRrQDA4cW8ZZjjkro/Hh76MuIqqpDJmCCAKDmpUCgJypc4MZ4DtwJW/hjqUvMCnMxmEBU2VwjWqjbtDenAlDA9tYGBr/BPKGCZ0+FIvve8OkwKM2adwoywKpB/fvbfaWBAa1b9/xNpntPx914TwzQmbQRLXyMNPhHQ46kPOVguswCtcz4juDMiOer0CgTI1C7N/pii1ikNwnJRgyAoT0DAjoKiPd137EDOkQeH/Hs3omk2po5nX5OOMGn0LkvJgfCilXE6k+5v9a2wFNPuieezrUtH5Dkgs1qg1cB4DOQsaMLiyfNJeujhd26Wvww1MqD8v17TzWjlxPvjlZnOSlM4UzE622TCVO++fsX4s1J5obm7UzH/zmeFQbHWxADn8KHbLFiX9llgLS/akp75slzMUcsJ46N1OzZKnnCy0mDPzKDc4tK03IHGKQzZ0rh+hQl7ysIkh1Kp36xA2IGmoF58VWlbbXKav6x/Qw6NzTPPRZMP8/Cam8R5z7w5PCoP5+jD4i5PxBMl6Gn8c53EGCAKxK6MSSc+b1pcg3VUgkTKESL6ANAaahut9bHaciVnKvkswo8j0bXL4D+BlhqnkkHJnqcKRbjazFFO7kBBNGe0xfv8+R45aijwaY82jl5zdkMLH08PQG7QH+emCGjAg08mAGNFQzlPhqSxWG6NzYWrnCAQY1B6owANeVMazwihVOMEsEDg9svi2qlia31KQp+MKoqXFjvvwWXQVl4ONKpoJpE+cmA2/XH7n0W/5Jzt6ZD1+mbBwP23+cFC3m0OPNoxlSgtH4FMbIOxzfaT/KP2Y12lBKKNG4HcP9Rtt+d74GnF+6QSCuGaMOPBqgaoXgcdvhrJsqDMyCqLp9jo8UVioWCiIBJfAzpEsPigO1CzQOz3RYgF6nuvWIz/06E0YBho7KA7ml9mUh6MR29ippgiplKcN9lo9OCdWH/X2Qm0whcS7iIwgq1jAqUbyI7kWUfGCAPY2grthBJzADQePk8ADwP1OoshAzXvlftIzJYlkYbhhmgVgmkRi1q+0ol6yS6P9t5KpVEF4Pnoc4grbTDSutLDF9ERMtQGmyFfsA7Z5mf68LyEcYh0HoRehcMjGQzc2x/UdnVI3x8X5YWLZexlOxks8jIAFdUHo+fjfc0APwxGTrnuXO5YzLGGo9sbOvmxbTQoguplp5CEWlnHhGS++7wCby2JWC3x+ocHTIFYzLP0CgltNGkUuDXMD9AXiNeeZ97XGAYeuEF1Smqn6qaFlHoHIujs35oVwIDNYJRvLlwmnumrfpNeGCSxfItn9CWf8dtSqHNcaPu96SSB0btCZIlPgGWe8Scut0KNd1gVqYqWkyuq/QHbsLuZRfBJx+8mIPV52ueOeBFQxTHLCC9ycmQap3yFJBVd9MAXszWxpWTTXNqjYBuKoszuu+h0bLnSNuhjhUImGCHf9/CPkHJV/GHAugszIEhiCSt4dbVNMGzCRlslJ+qj3JYUCHG70Y+Q1SpniOTNhNkXmbWlWeJk+s6iIwTMsE13B3Z7a4mEWuxFdQYu3XQvrBKGZkUVQNby55gxDzwKqJTRrXnyuxtpjmtDG+iEEQpTM3oHhDufzWoIaroQqHBBSnjBgLwchPxZ2APaVlrFQ2uWW2dFelzxGC9ngDh/h9bk3pmDTjXC0XwOLZjI+ZaYOvSbAOJIsZpyg6GIyFoBKpXBfC+RjMq+DDhyHUU0wjVThkPdQ/+MsvQyL8Rle2zBKvTGIGKSZhLv2vsxuq4luRh51WZXtE/6BHmwWjc4Mz/OQCuAmEATkRHwhyKUbHlSaCH0P1HRl/O8OLkF0IZMQhdDpTFEHWJiWASRIJj6GU20GKElzGOX8RHoChElwpSgCkDUoM8N6+Eig2FxVhvlA5rKLXUaGjIK65+JiBqA2aYnIcnpHhYjYYip2kjWByRc/M3PJ3+yAoAINoCIBMH6vLyMgykcQaggQPaBLvmRYxuEx/N67vaPpYRMBonn/P3ImyWPARs/yJVgaCKNQNQzDoIO70mpmgdvKttSQBMFxYBHLq8ykExS7Cous/78BRzH1FWerrSZNOi2EUksZzqVyVEsyBuNj0KizgSgCWrOz2f5/lCICh0mfKmQvSGciv1bTzzpeZyTSmU1lAFzBTtHvU4J5niRZs2nnMORPUJQIEAaojMfg/Zf757oOD4jYK95w/CINLV9B821b/43t+msVSvsH5E2Gj7ZdviKlgZh6SjrIwBhUF0EFF7q7pIQikhV4HK59yqMdNKp15oW6l1MMzZ1bpMpLQZp/IZsJcDxACm7lgE9MU4+4BCRh2UubyVCpIgc//DnDeF+INs4C7WHUDNxfvzqPMgIFv/7xOCmrUPef85rKbzX1qjmBonDQGeGMJ4jkg39Ex+3Bx9kRG2F5v5E+PyqArA/VVOxIQWLxZ/M90W3c2sj1zjsU3Gy7kmgHerOtxJqHmJGtpwyrbWNrkNFHMqi4G79lP3dFzW8Y9DrDlsxrtVWsuGBo//ONZkhOf4Om+WjCEmsEvVpe2ibXJlA7WFb66sRCCbgYLghPyNseHXnmTn+mP+w3zlmLc4PO69FUg4JYxXEssF5JPm6zE9gerdqXzGSUBpePXk4SI2eHGnUwkZjGcMybW3Yht97hkwxFwxjqBptkdO8we8AQ/Y9hiCWmpD5awIZxbdXAiL+U1r1oxQ2Y6r7MUx1rOcPDjyLvDP5q9JhFvCL2LN7sf4LzPRvos2/UuKo5ssNslKzWpY0X0yw2yksnmXHKySc1E78LyfmDz4MFhDHLLztvYISCY2F3VL+mYy0B+wZQLzJn77q/VQNbOnOwQU2nyyFT/wrDZ1DQwG4Z2dMG8n/AnCu3bQRakHPe4Xwuywd9Ogs44vgOnbOKPPTjXbc2r807Mdf/VaXwUOQI0VtzY7YyAbZS+V64pf93z0iUD4ozn75jUfS//WTENhLmLGMDT43+rVw9VynkXtca8vh46YzPrdmXGkTcPIA0YD7TOSPS8+NlYijzqEVfMyowNNpTWojVZXkl2STN1vHt0Vihzyd6ISKAgEYC+D5txJdn92PhUNgUZVkZMGGnn3XRBdQ/BpkUSwnxR2G46nH9ImoGH14bMm5suNAJXpBimzmKyslicA42CUrOKoqN/1GpfJZoNbU9xSQIYzlpxDY3iTBEiu0exRbqmbfZJxqRO5fxQlgg6aCGvxzh4jLMUwmqcq6g4baZ+luKGotUrns+KDoQbMWd/0sarOSiSCqNcFHUilYxu3QZXXsk9UnKQChOP5JB2tcdYWKMXwDgSbCo3NOobIdrMy2wyiz7A7VFVwKAvCKOXEMUeeAfso4n42diaocXkITib8eaQSjpCBhWAFE9TpqVgTjxKHyJmhqx2o1fxBeZODtiAN4DKL/ykURkYhQpcWou1fbi2IZ5ykIdDzwQY9q8DvAQsxQTMUUFTg5C5J0inzJIi8Pn2KuXt8sD66v0MSLJ+p57OyPZLgFMFPes+0hpZ2vPbO1F+F7HzBfOFb6NYgKdgy2qFXehM0DqF2TXouoqZI5ro4DqlryqJXjP26sqyLTgfB1Qn5kKHsLsQk7jDCS8R2Y1sE8BmyY56pot2IMZC5amB/IdLkd2kG+yQbjiOla2AdSEw8V++Ozs9I0Wb+wA7Mu562TdHqmJncoJhB7/5vmFW0bBQ5vQnmJdgHlUwjr+c6A5oDCpXhwrFGIUWzh+vfKg3BuBrGZSa5dxxkuH0ckeooyCI38tg421aE4wLOAbmMggidp1NFRW7rWA6MbTEXjrndEAipkkPq55JkaSia0DPRg6b+wWgzsXBCnBByk6CBBJNwMHC+Ywc3I5LvvLdWQF7SEN4/7DXEZCYvvfFVPF/Za5RApjKdsXypb7sud28zjtxPnMOH6IjekoYHkGp4bIw6okXzgTmJ4Kx54ePKjgziJmlfIoK6IbmS/vH/R0oEDrPpM8n2lGMYxMRrAIWUUqjwCv2p5zweDhLc/A1rX5WF22ozP0EwBw3kJtYxrhgoN6l8oN6yFReoy9Frzr+0IA0s6g9jkwMXhUo+tOqOtKMn/eF4+3DuDD7m0stx/k97twjXT02B/8G6DaPTqa5pAn7ii7ITBsaLHC7QRnmRX0EOmGfsKXu+/BxhSmmVTnxz9MW/q9dOg6nTPS6Pjwly+jgqM2vil5mvbn0tfjJtjK/SvZkRnC0y0Pm2xdnj2c+ngG7eIIO7J2DAiJZKMZ1fg/PH4vJFxgMC7dJz5/XLqdUR1dm3flTVYUJ0n0SO3TjCofJcGV4cg4d0OFUkApjD3Y0ncr/2A4NojSUbe7xdMeBua+ZHTNWn+YFQk6xf7h6xSbnGvXnbv9ntvj2oRqoAIStYP3UMCN1gtUjzXiDuT03n5KBMeofhx5OPvfvrtBjf6tdFIlSablbI6/Sv3O+9tl5gRGCx4RIHaSBbuR5Siv4cuCONZMNuxVEnE9R1khV6V76rTlurhR/q1clUcDmmKhwFcdcR4wJSmBxnMDzuVHbpjOstg0vPegJFHG6GrM51IenHOA1NCT65K10SvT2BcMT7epMcYqpqcqHlige2kDCVAqUB/cmqAzEnxpFLp8xK7XlmXzexdTooTe4/oPms/tTyf2tCi6HaAHKZ4gLfmMk8eE02/1TtAhmxoYOW664dxVCh+DwnAkGwNHpAMhtYACyhqzPZ8JpUlpVoSWoBGwhry0NWDqtMTMsPlVk8BqbCTnVxWfEB0feXN0zW5syQhx12yMeS90yf6Q2F3cI1WnDhwOjAhxmRNOuA5ca9dlSRDCvr2s4JwXgSD/XGI4h83FCQHcSEeMbDKGXGfyCrrKeFZPy35Tlg9uB+c3VIR2W7FRoqFSQt1VZwIguUL0aeXxTk5KUL4KMFJiQByjBDdZ0SC7R04sm128zFx+kQDBsCc79fffgeS7sDuFRpx9hWmdSIgjhuOe4nut68ulQsZpP6nbcU+TehHB4CHCvv+qoR4kWwmln3zG2A9Yw47oW8VCdSY15z8pJ7gbBtC1Txs8XySxF4jTRqbe65CrVh2Zo1Q7/Ya3q+uzEOH/QMmjPRyPvQ0pFWFl6k9ICp17/Zvxlixjed6ZxvFXsWigA/owGoMK+pR4P5K/Ob4pUrdQXjuFjkAesBhVyiGsw57Vb72ePCWxbp1DldIxjeaFJCjA7jztZ/dfDk94WnlrLNLPqOhn+eAovK0KayHf3uBdZOpS9KHPetCXVZvbD+7zXpV7N/PxYvA34mVs9IiV6EpairWDSY3HLGnWBEgxwpPMW62InMMl150aI7s7AxOQRSeG8YYFRMENdmmVrOJ7m9BOxLbbNKvjg+Bp38rr1nFhIn+SxzVvq0LbWja2Q6WhpGc7xa4CaGQWvskWCjYSkPF+wvvIbf62o9qsqmeWxaQ9yFiIy7uonzI+ksRcm/kX152SF8+AtYtSjXX8kfc6ZYTM0dqHEzMSaNJ8hv7mY1R+D7PNbW1Ntm1mXWFiQexcNWnTGfhNDx+bhX47C1y9zKraxKZTcvEvt35qorK0TzBtYT7/n4l4PfDgfQcHLK6gOtscnAWx07Wbt7qY1o0I/CHhMqJgu0lUj1gTZLFE5htFw1xdlcnGkA5AyKoUrpAFrDUyvAi/FOnFEDQhlIhtAYOl0yDphklS4PRhxT6dZZI0Ro0uK9KJRmizJcL/yk3Pdqmb1UcvJjO0TnNW8mr2nYcp9ekZvrYkFgIAFJJM7ElRGcELO2VviQCs3p1387+RlyDRY5tzYUVbIB3pH49aYYw8CRseKhZMDJ9JNWPF4HRMedL0JkOmgfEBF3Jg0KcR3+plJfv/66+EcsnFzlNCydkHqUIHPz5l6dRWxKy9XHlT40zZ19FXe34SeBFmY74TnPQR3TsEPIDx6h8OB8VBEBy1XUHxUY/SgXjHoRMHt+XjFSc68pMBb3+WAGoGU86mK4dEGp2ALW9T9k8ctMugo+LmDv30/6Qx8dlseEeepXkQGzuqVmdO9d9NiI2/BmwEXH0jtPbOt28KmmmK/fufx0i2x7Jzs3XQuxxmqjgdsx+KfmlDeOrYkPYErezI3/MpugeUrN5EhnLgL2QfJ9Xe8JswTM1gT410pTtKJ5xWvGZS5e48vygcgTjXO/PNYV+hqADoH3dNyK5torMWlxoxj0gXLHvqYazqsmoNPotOPT5YHcshHexBFU9FLv9vGe0VsjYy4ZyzhIZVS3roIhpUHK2v3r5JhrfoeGhMfz1uNG1JC/T0TzJcfCwIYpA9IBu5GVMtAMnhF8NkJ+sbLvT0LH2ywQFRdoNshPTggsY8TBTa0oOh2CefuMG1gJlXYEBFz8KlH8pfjlQbfl+fXCoYlfS0LPXfPK1CHVud7umt5wZCZrARGu4bbvgH54pHphojSdCc3JMc6/2JknIoLJyVbBpWDH2jsWxhnOhvNtCJwEYq8N2LHzSyImQHTZtAoWo8k6Oh/mvgrJbmUtEcZgCavJ+qHSUGZCckVt+DZw9sXO9OVffrAXf38eZjg+t0Jbvq+aWMjCnwj1nzz2vXY6v5bIYsZ2m1DIByk0PxMfNmDxsCKgXR2nfSycJaEKKmT9PY5YjLdHHApsGyWIQql1VYbWw6X/fpGbzOXANlZQ762CgVnSVdTHV/+6UuYZo8o112Vxgw/dwLdD0Nld4vmrYuksxcAGyl4Ilccclr3bYao9ElPPEaBjiF8mGzFphwf5jaPQg2FouVuZEN61CnHOYvmjq2wYO6cRRxfofwMh9/EZ2F6N5SixCYo2auoPtQ9WiDFKa5qM42dYQ74WEnnLivlqcmxDSG2uoWKgZEUOKEaNrc1lgEUK6VEGoFlIvApUM5QUJkn7UDVkoSbToy3gC12RLJAjgWMTueU3lo7T5DzjGtjiCauRvZDcsNd7wnzxXTWxC1OHh7kFdudBxxT2i87UEJuL7tqrR2//Bz1tOtV6ADYs/3eyb+vKCv5EeubD89ULfs45fZYUt0YY5/vPPt1bm75usAXIJFTYTF00VcdWlQtO4s25lZ0/VX4pdUIjEVwbSzyB/3clsLLrNXDhRcIJrmoystc9dN8bRnQoy7F9s9fsKGMCci4gWYmUgyJTTb/DMKH//u7zz8fzk/MnBFRVj3IVDLxeRMfLbgWDONJYf6ikdQ0j8k/Ai9XqgFv3hwpPcNmvsLf3IIBLrda12+ZtBKz8OSEu9f72c7+l5sO83yCxVXKWFBwCfRzE59X7kCRdFF2DZqKmsKHf2HXRPzdbe3uoF0sZQatgCqnMCnu7vCcBrDmWpLYl9IHU1JYXrpBNxkDOAliq0QvdbL31mh7XxhJXeMueEnKMv4dx9ILRPGW66LaeJ2DmfP9CXoLgsv+Gz5vXx6NXMALajP4QaeMSWu4Pa8v3gzAvkrWm8fHLLt7g8a+eT2pYu4VjHnQ53lF+V3W26Ciqs6xqd7fP1mzVp9tG7KfaEgT7T/l9cc9FCFiH79RVZaSHJCCoJiUThtawgJ+8a+inIvluvF+XHnYRQWvoZvQAo/oPd28rb9u8W2LOwXSEXCyCVqxdjR+FHu7RKvCCN6/Yp8ZXzGHEQIf7LrdweUyE4fzupRW2zQgqQVn5LGZ/cPk9cwxCywzNE/aNt+bVLMXp2OjMYeP5V4KMHr0kMA/Z5//cLrxIflVw/tCwf5354+k0hBOcrhUmzo3XEJZ9j6Xc8H/jXMA9Crifakatr0IHoBza+1shssm4OSvNxZCzn6Q6jwkkAGu688fEbfRVKz2NSEvP87TvXLSMyOED4lkb4ObXl0jaHSspdEZnlwU5tu5km3Pofs353A7uUXlEV8kCBc+qt4wdQhEYTE4zNBdW34tbili/jjVlhoNLPld5Ale2s4aNLsRBGA1VjFYSmZ6f9XiNtBjTFWenNfeVls2ITPdniWls2CIlZs1OSH0zB/GKXeHasljfyA6pauhm5/915r4mqBVAubaPaVrV7eiynGBSaUuq8tTK7HR7EzA9qf5kR7hzGNL7PGk27FTgkcr+ZnPoCQ6PmEnsheSx90O65snorP6w4+TJM1q1KPgjp/4cjUXU1W3cy6Txee5p9kMjUV8oqWYAT0++giP/965zt1ZVlr6vlO3e/9lUzxKc+63RTXRiL/mIrNy+YwAgWEnC+wMy4uOU2rG6+EymmBgikhML8zmeBcd7eQBZM83mz/rYDhFA5UQm4ailBJTCUUuBGaJL4yeo8JBK0TT1Ty6htETcRV4Kf4SyEcCZgUgJqUJ4SB9uLhSkrKoHdqNZrBikF0E+BOl1DfXUxRICo5ijE4VDmZDNE07+gllJOPatx1wfYDIgp06iPGqeISLzsMlNa7pq8bAJ+ek7hF0t1ze19yyxdGl06vktJVT2k8OfWlki06ziOS6bD5kJI7x8z2z65AkpsuMCXr6qVXr8eU/WkjpK5KT1Vks6TXr4Zy1wPuBuBSb4w942upT7ZudsH2RkgHvuQ+Mz8msUr0C3y9QGPf8mfa7knNzzi7xYNh++90jNrbkHkjMauYgQAHhG04NSgvOR49lGgsHAJ6gt07ERkUaE791yHpYkBYP8yM58hWTBCVtwnW7nglrBk2FzH6LVIDeguUzXbas3dfJIDfwNiu4ZsPzCTwxYneYwIsj65kosFs92lo+iWrbTDnMfqMURc/AcDdj2tp9nXRygZwOFwh/tbSiugFWD+iMvG0iDuaCaTN5U4Xn/rBP8KL7y0uzkLiHT/nkSjTsOycF1645ZgncqQbdc6ta+3X7/cFls8HBWD9fEiJmvlTWefi+7yblDQ+J5RVEmjv7oH+cEBeRgQOGAZNBe+yPDqmBncJRWRGLUBUyzIRLuHjTvV7RZGC8I5PGBjpkCG7facclQrCLY0SpX7gYBPIAkMqJmPkYomVpwO17t4MkeIk6RB0/9UJqAUy8J5bsqj/TVahjIVaMnyG62QwibPhJTR9k0v+s4It2y+kGiplmaDwRGABlIau+FISv5bwIKTSYYmOuSzf0bCFn/PIA+LYVpZQEl1BkqA1HUEaiCoOsMC0458k1jN4WjNqYCM8eMq4w3hWbgIlrXPSDbdCex60cDWlR5h0EL4FLcBfEjMEYzYOLgVaIokrYvhujn3RHzHSYC6nBWNkVAmnFBGUiybTh0Jy1v3nAAP+e76gcx95kaZQj5cCTPU0M6VgrgK8ZZhesiTmnYwkG2UTCiDTusT/NBvTi4oZyHLs665XCPm+FiM78+UpT1mgm4jXPsIUE9FSbp3T6ccx6hEEfzHY64wCuTpvt0Q8Kno9FM5M4JWkcKAezv78POf0U7/7HIOQX44jDdWX69noWkx7zHV4wXl0Bg+joc6NNsvrqH3BvyHILV8SRN0zgFpuFfb2P+VVtQXmMaqMYxm5C8nrpYN/eGgY5OGlFYSpeu2YxvDBxr00QzZHNniygfurcfVNUOzEjlzlocsGxWxDSwxxYu7+TQW6UlSXw61Z/3GcUZsXQxUtaedSdIxeFPl3wvIGQXGex0ssLJdnzDcZXP7Y019W5uEAvAXECZPocwZcxvixX7dUK+8MWc5QLSc6IzrGKBU3aIiXYSQ+8MfrrP6+A3mHyIb72L/PQvNyb3ujFnsrPLN7PWzGg2+l5Wqv6HhcJkYIIKNUpwSqI2xoH+P8ypY/K5t27mcJx3ThfGa++QCIhXiDMYehgMB6CsecbtSXZkLQbbtINhHA/cVy72jipOryqdyc/s1qZTc/WC9+jp2F5Ca1t7t4cOjmffFTAjucjmwNvjc08KV7KloTGinkHbn9xnD0z0aXwFmJjU+s3IAdAOPRPbfuCaCprKn9Kvo80K9OXMEHdScEY/VzUZa4JZ5C8hjOgbUi48hEjPOlvJ4Qd4xLALZDRS+lpLsMVv09D9lAkDaJ71dT83Roo3bBnKNxzkZoYq7/8WSNtgq8VNomPhFA9rEd5QoC0KIL3wxiohajQ16AWFJ/rAo57ZA/g62P+BLKsKolgJR3GEEInHlLBRpFJuHYk3Q6cOkPFm9asunMn2N/v/P2Pbs9L+3ZW/gXmC07d7wNfvp0RG3q2sqEsSauZ9fe7mYVM4E2GwI9rWeW6CWDLGBLjz8NdEh7sAp5xzv3GEnztbaTwnoceGKcvMwt5NIQGwm7l5Ub1iWce77k74r0xs9tQSr253isuzDTHyFVhlYKpwTXv91AYesxvEeZED2dBFoUFZuFcbU1atHgktOeO3AybFKaRCKYv12NCTF8JByAI5QwXB0MhGpdaMQeltInBGdUzQDYsV8vhIBGXCWtRjkW6pCkHCqHYTKHbdq8lRTLfSJduPVlCezL1r1YrU7yS6xbOJkqHDhWfFcD1l3f+2FhaysCKvDVJJvvREYf7DFARx8nH2fsvdqz/ooAPhOUi3PzUzC3kUaD2vHRGOXXkvIkvpdM8js9LmTBWwBJNunS/sxp4vHarZdr25H7BkRKo9yExOIs4uQuh36Xxg+ZLAF25B0H5pGR/pEXEc/ZzFWOSV3ozBFMeAgoQZBP8szPkh2FWYAYqRAcojbzXPJVFTjiQVTzV+kqaSI1k4xUUHbvAhEC6UyVib+gZS2TJ0e695d+DmjxuJcAAyjvihsIIxtg6bDgDRmDcilYjJiNOASmsXuaKQByzkGyTBQkUnLcWyeYSo1j8d3wVcDCybBPIOmqfwZPty+iEw/eZprp8yxa4T7vLyhOR8oZ+nj0krHr2NUF1mymb0WaUINhpSN71feHafR00ckGtDmFhWDENr8oHMZT4VD6lLlVL1jDAQyAtQ8J+HRccMhIaJUDKKG00w8WyP1M51IaX5VjdB3QOQQbs5wskcRzZ3mniirrEiTsSX6x3GTZoKiQ6rXIJdhuSz3Fbs/5APovcBIM+ZAT8Vc3a099VUXBvvaxs2uQAz9mpkZuWjk1VIvptE1yKm/nOJrg1Drb0Bz0yqh2/G3wX7q/ImFqChu5wTOiCW8DDK0Y/lXTEJpYfEv7hKuV/mEEo43w+qCdcniGHSz7s+dn+ALRN/6hf53ZhUkir2bBel92Kc3P6T5o9gJqzxz4J+IdpWzJqFWmn/3b6vOKWGldJYvdcA+sKGlxVInu+d+ZAgve+xqKwC3uTjY0oNseyhTP61ydZZ0liPbXxId4GsR1ibqVRaH+pWsTySDolikIH7YJAT3paSOPtzS7zrokkJ/xSQuNL4OLa7DQMRnnIcEmRy4lDtHPq8Z8FYMYaJbGCwGEs6rXdRymHmO2hqwja+mPeyML5DOzW852jN+t8xpVCcCPUUj9ZeH74yfr7dAVdxCm34YYo3k8RpY2/ffMBq6kbuCLXnF4OtfiAq45i0j9isZn6wN7ueh13lRck6iJnIQsE584DG3fSdzZ2Qye4lF/4MA0D2zuswiSXVUH/qjHnAbO22bDy6kpbCZv/cXSNKiNwfOXyJgRFmuWiHu1Z/pLoqBn/cvkjMB2Sf3Tf1a+YxsGgX4kOx+nTJrQSKlGTJDBz3vQwPM7M0KElUhX5Dpie0rk1MbS3C4CM6Km2P4F8lpw5Ru4fh6rw5I5KnPP72Pnfdo+7x9WbnYHcy0OfgaCa0xqigQ+Rbiy3YUGFY3LQJCIULRaawERqZeiJaV5qfZZQ37ZTqewGwg4BF18+CP7xr/JgHwLT7tWWCjbNi1b20rAeKWGSoh6WS0XxNMGgYrhutE5PChX7w5Ue3qU43HWK5YAJLd97H8aS0VKh09M9DhQVtz6hExzQpfoFhbmK7IfyDKJeilSzKlw/jaKpGKJEUhlDxiZxrYuHaSHtWB3ScA2aykQEcCuUoEpgC1lLEU90617VRfRBE4WSM82OShLNi6VLNu8poV1deK/qxCwzN4lwdWexiyqHuMV9URzw0Gl8jehfI9WTNqWNWqC7fm7rCop6Dx+dEmq29E6Brl6YSyG8+PDwi+rt6KnRPYeW3VhJJV9YnAxDTuNIfHMrjfiobvoX4k7wBd81C1npbWNu/9J3Ukjjlow9Pkc6nsr4uICqGJkwdJhl4YX02a3XBTRNzYTOCp+fEh1abRDVuiilCshdKQiBCEmFgkrTEQ4UyeGhJMU6HTTXEySBipQ8ot2I5b9WnSYHKpAcYTPzQmhkQpi/l9my4irPm/kaRQ/lLxvrnh64Y2Vf0KLtkwwQhRvoNvbyuMRVq42EFdZrFTN+y+EaT8Z37c53zV2hh2ckkfwGceTIp6KUm7ucgV4HNcdWPuX6WT/fJv+xA//ezYVpg82Vgl/mpgT20igXg9wpaNKzoAL6Y0TIGi5gxEGcYEEhUEQfcIPNxoA4SlC+lcHacwrhur94k8WyIC0ul4h/Kg5lxuxVksmf7l5tGBcWSAtx5cq+B117zElVrPuDNEwwR6S5VrvEz3oXfaRGVAMuju4eqfQ/8gnzjeW34V8Wi+tEU/jq3eQKdvf6wVMGVCzp/NpcwbyV7JaAfYPlx30f7ru1kMn7xTVZfX6V5CvcH7Yqni/huK5s59ut4dXNn4Q1bbo8Ro5J8hG7BcnH/bdo7bpcJrlAttgYKNGaFSyThfVGEzIczKo/45ewoSdb3pYNmtxAU6E8dOHHpFCGg9ljSxrNIAy9WfLqYtwUPAZwU9XdLCx2hWn9DGPqHGmQMle8SrMHPylSOccIfBKRteobnCoPJJbcNrHJLwG+QrR2ad3FdkLroKCJmLMsC26uj9nefZe08bL/T4SG8LOWJITs9NNCWVV8UJHIuD7Tb86inzObu12Jmd+yWKTIxGyRItMxDtlubgoYWEarvcmoX8h5rY8ykr72C5G7xINxE5ARmU/6xl0R5CQ5Mil9RgGC7oXlZT+K207RLgHrb0lNw5kArptrgmAqoOR18EqS39CoTX/f0QwKJ3JJYDyFbK8zS1EB3IARtHBJ1sCh+ChhDtOEHv16FC259FiFglkgJXhD6Gf80hCO6Hc0qRP+tB3BbUHS8Z50ugGV0ESHPKZf7TaEnfGcj4htEmFfPk6JgmEQzh12cvzK7Q112Gh8g9qLM3y8ltAThIXON5OcgLtU/qKwN0vd7CzMZDaGlM7bZzI27aSn5sJGAA5UsNjo5awnO43Depj75+y+QiFZ78ozzHn/XeT4gU1AzxinP4Of5LxuzdSwhfym4ieTOvfV7i3DEE8l6+HRU6rVIZx/uH/mhbb00FhbZpmMF/58wCmGdMZUi/tIkfv5VZ/kZ7iJSgQGTcrRiw75rzbiB7cgeMmjEtxFxH4NQfUYTYwGriEPDt+1G6MZcRliosMcRN4sR2LcjhFIFi5wSllThsIEl/hnvVb4OdTcRLFzSmoUQCFAumTLmhLaiYUXqrSvxDM5rkIWUVBd5wLthQ34YfFhl/Av02GRIXYGlx+oVAEbnSTkbYlkJXMX9gxn25UrLw8KeffozFBWx4S/I2BK7Qzu/eP/1aFFf85muCipFY0THh4NmCuYpqN7FH6S/haon239Tq5iuBrF5SP6PhwJnEtnTNMxhCWj/wNd5yZmztj3p39vPSmgc4pHHZ/J3KV3hCqMhqb8AJaMDELNi35Pn111nU9XVXRtLXX7DcLzcD1E7mHYHWOkUb5hqnXE2f9SxFTKhPQdORd/N9K5T98SM7MAAcsmWd2iUtOEHoN/v0PfwIeP0mr5uPLStWUs3KLtDuV/4bg2tnP1vITQihP86nhODiPcIH6MnoaJ+u+T+/bl0MmJbW6PR2ZfvD8tv4D4544R3+99CkxcNhPkNvMApa+Qdy9DHitcE5+7Pzp+1OeiCb8FPdx75InNWW/bzuQG9yfsShCIubIVEwWfP3b2fhLWTijPYsw3S1GXOyBj87w0H1Zu0D17yI124l6Hey3bLVwPjmz5BG5xpnvf7Mf8qglB+Yw2M1HTQhd9/VzWrO9YU+aHd1fri4zxmxwt+p90qxwrNHl9qe32Or1eOtSmymLb9LIX6DlI3vJ/8/wNSQxyEdDTdtZTqSMyTyITfcgQgMOW7jnVtrY99pvV4+x0qsZ7wVu1m31Oea923UNfCwl4kyITWnv+fogToJY2XTMsr1EDQBd8qCRo7dK9ghL3inCuyX4aA8aiNgHRYs/TDlk5d9fDD5y4XPEvtgxofwf/eLNrdtYlkkTTJqm1NLNnUdFBwAM6ESfh5rK6xoGM/ZW/DZkTMQiH54sibJe/wdMqaDppE5/iIVEbtu9OTJNvTGzQ9uqfbrAWT9LwXlWd10pxjopO9cwSJIbFmwTrsxegNXt6cDF/hSioRYuGa8PAz1IXAmIMOXdhT9RuiI3bk8NgEdvytEIB/pjgQxLYbnQGyQEsB0aS35+7gy27jYgseuCpTmE8lmiGi4i6q9XrQgzdu6XJgiwh/Yq1a07FVCdOq6o7pkiYEap63rn9QEbXBox+NXH8WNOShS/Qf0+3EdMKkpp4Pc/sgWXlg8m4U3Fg8lEMyoB2Ahb+O3xNSM7EY3ujAyybmqMHtOn3b/3mi1dvBSRxd1YgQa5394aN6EpfGRpE844JTFW0SHvVVgm6uIsT6VETz50GMY+SjeG7cnirGTCH9zufM29OebJo+9ARBYCBWZkzUOpmAYz3ODTbWBcBo+yY9l3HfPryCDkoqH3UIIACHE6VDRQU/MIb5tP8LoIgnz57fBvvc0G70DlDaEFL5dfPxmOPclG5/H8Z2/080mBfV4Js9OMkUUocNsp3eSegDxCqeYzUZvs0fscSYadDbsdYdUwe3+mO+ap8WjLVe4wxq8XTASBLskKzkEO+xfyH8MAR3FTaSt+PUc9ydxKMCcqk903Cy6gb7lW6Y9xZCY/JdckHJ7JPn75PQhl4xd7hTZzKdDK725c1klpBGa3IHC79SDOC69KEY9Ol2pSNvd5Dz0bUzRSQ9Lkyj+41bVOR0Iqy7SUXoTfAKx5lza6oeILtg/7Ah5XhLgeEnk5BTMMYjns6821YL8ncOf8DHqDw5hA6xAXi7oMUUAD61rgqJFdKYZm4jlbmbUTSJshZ868Xs28T0VkVRisL1zc6skk19aMcAnIvBUyMY+lbr4p40j5CM6G37RBi7W06Uv8WRrszWpW1iW/z4q9NAUvqygzl5rChkuZIR/mKZdWOYW2j8posiWlW73yDZ3o3YIt0H+P4ovTxoEJwXHVP4DLgDZ9T+fLKtp6KYw3EqCBfsKlaXkO2sZT7Aq8DRItoe6mFzmp8sRypz/v971k41w5qwMVjFL0zAsV3nSOnp3WbXS8nR4uaBKKtMRkRMS7gVN/xtPpUvAJ9rpVPmzFScYTQAQGHf4gqzw68CMj7QCs/AWvonBYrP9FOJhxZfTQeg8I7o6QMm86zFU97+b+vy8lZ4tBR7dXMzh1H3UfbwhC7p7dkJwRKJZMyt6dQaHMNk2TLedeFPm1EV8Ahyk66/9Q5nbyFFebviottnJUijgkFU1z/m8XOzWcMPIj2Kh/9ruWwmEc16CTqhvrm/YEqBMJPZBwEZgc1OLtyGFPVFPlfa9cnbNK4fnXlzcsTMDNL2MRUPw3G2608y3Ud3a58pN166zAtAStK4zYBrxtoc82ETIvj5Rz24j7BVkNfmCCZVwBQrpsY3RI+uS2Xji1/EpLGmXGEot/GtGF6hHA8IpK4ruwhXDuzyTWwTsB05SD4RhnzVyyd1Xw1vWQpOwr6YaLTg7mEQS7qj232h6kpYKrdIae8LY8MK5eOiBzS9kuRWR8YmihaClrFtrES++Xmkhxv9sKI6XoX/opSiOlJlIjZgmIJ3elZwkSHxHrX2PiUtaKpYm8tk6srlkgFZFJYYBUVvQQi7vQAbzJnXTaDIBCaH6aW+VQ5uLzXBGsKWvCYyIOxAKtB+JbE5ZIbBSTCTbhaEQVh9iEjTaFn5S2dheszS+oX+cRrT0904NdiJn42gHPGVeSW4cqxHT66LbgIfJukKeFD/KHUAhY/S0oYMq1Cw9wapFc50THRLDVAdzIL9fdZ3iPLlL9pE1aN468VUmNCUsRHTizyCgio0XEVZnD3innNYp8VQl14kBT0HF73eHZAqKQLI3GJt8zdJ2WcGur1eaPWKzX0h+3+gV5nGXNAiHxv59ss7OsnxVXoZzK5KXoCyHsSEE/x4St+N72ONStuJajKSxjHWmCAnYOXRb/hu3jlzDdweRkYMZFZC1QjVGhlcEQG5y17LPc3jFVFGwsayF7MDh6gjmX8JQYh0MXX4EZ+E26h9/GWsMQwMpikFwmvbPb5hdw+M2Gth5j1365lo+MW3rXq1qZCz+h6ahHoN52PJlH9hIfFzOuVRA5Uf4U7ToC7ELv3XZvSuSnD4TYyX+GWeSd+iBRridMdPBo5TZGACaT7ePIlFNRhOOXYAUPkbBPJIALm+9Ad69S4Thep0VyaaEhWV3BKNNGRi36S8oHLuWNnsYVPhaFBPFeJnGtSBOghcSL/ON0lUpMtveVtJ3PhoheczCFTkrWP960XrL+n99O1YtnlpuYq+/LNf8lLzJUBMQeIOfYeKutcfckWD2bOMwLgF3FY8r9UzsszX2/gGqIGT3LfU3Jbm3eoRQQFCrg1HPlLN5fitomjksn4Rq9FoWEB+60CMSEpNYmEElGVJaQd8mKlT7inMQ6MG3qf/zePbjjX1lJ6Bazl1a1UONR/rFHjVmGdX6norJiMI+IoofekdAAvdwXKMy5lpbcJXyJ7yiHAbaei4CZrKO8DqtOb/5wVhBbPCUrWNMO0PxNH7CralEmh9tRsComxHZuT4qrOZztrbB2dRY5tFuG4rKSGoCEgoSUll8DkqbtYXi0kTsaZDNlSikqizbNKUDhJ8a25FvA87Wc4reMknzlR9sA3ZfNXMartLdsl7/KMGBmWtR/oFxhmd1moQU0hhnsVpSKfIkByxKfQnlZluEzI0BDX8/xT2fEHKaaRlCLKLXBPwFU5efqHXVF0E/ih0JW8gzdHh1Amu9J390YGNa5oSEPcnRmr0o8RIPJIJUprAvnQEDAh6Jh2PyUtSaZI0C5kcdcv3ALV11GaS+l23/GQIQqstTNJOo2aJwp6qp4DeRGOJPdQl4QV96B8P2azTGDgGyUtvsI/vN8Cdu+ozMCV/Iyf/JKg0JjqS0tdYJQXoqxQNMt7wUcx5VY8Ss27HYg1fNVcPLM3ha+cKcFLWebQkNzeKO18cOfKr8Pp3CvE1zibf0Ts2BH50S3CBqD+yF4tj1O0o1JnMhL4WBOl4RXd6R3iJCbTSBRb/ncANITl0048LpOxvQsAumCFk5wdsCvtuDtkhLASqIe3UZwQeVAgMQ3lONBHiHOGsd6SYSnfpai6fpTJcwk8/sFlX0J7Sk5qOx7WrjN6IWVy2wvhj8MmwF7r6lEzRRlx2Bv4nmYLzyuJqfYvNL4wtnIYErbHsozShgq50TQ5wrvcK9EzNU8Wy0leOqQkojzN9QJ27RSH8VWvNLhpFspSN4p4irDf3Q30ZMCzrwbbxVHSl/LE8TpzMzJj4393muf9ld8hgs4uyNK7GSP96ZF0BT6b7nrvm1Y6gpry+MoI/9qCOKgU16fYFyQoTRR7weg7lgHFvGp++EwCRyhDJvS66eg7r3BBP8K69P9atTll4qR5O9WTHQmelZzyEOHIjK0OPTj7SneSwb/SJauCIzRW/7WL0MOTCUuGyBj0hclj0Oa+3ytVCVxDV9kkGSNdclrysEl84pqu25Ht5QQ89raXp6gvfyZhND7zZcFsv4RG0SEUgVAKbBwBcHIGM55X0xsruDOGhJUtH7WEq3h6lRTJpSoZ2RHuUcK6zzeN2M5QGuKnk8sERk4831PnPTlVZy9K9rEddrou+RoZjEF7ge8MBTA4aUWs+wzUP/TJZHdmef9giwyxEku8TARvH6SjsrNP0PiH+4BUsb8t1r8hsBTUp1BfhbEkhdtvunkGufnKdqy+nn+vnTD6CzOtSeGdOnz/MJtTy53cnh8sOLXbx5LjVtDkl9jVVmAEMs3gf+6eswU1rYodHRFjLr6GOawM35Xdv76WWO8DxLj4gjEBXmp6TFpOjCHNYVLeRwrpTdeW2rhefise3+YBeW4NpkCX47MfCWPELDlHx/BleYFD6/BV5oEZ2XnzzBsCmV6EiX7fdzTb6unqUbFBEAxgM62hXfXZiVHh+BP//DD7snGO2LyCrBS1QxlSnRyoKBLO4LF/vhu6NtvCAN9sh3tBfHbHNyqHCOK6VEuyWpPbKIZsIIzHGUpg3h79lr0ZnwIFANcP8eDOByD5neLQax0pJddr2Md7Z7oZA5MFSqI3GQLyODm6qrKeAUzJHkJVnVa6xRWsmmcgp9G8zwIWErfSeT1uD7x8Jiz3HeVlkViGDbcYW0ca/AKtUEoEJVXAmVbpp1V1RDhc1mjo2qhED3UO8KmdMZJt8aU/O9IyNS52ckuVWefr5Ym9h1WJhat7Qr0/8hywPlSfGMKsOXqUI9oEYJuLmwYLD0+gvH8GlAIGNoSCpP5/P9OnuPwVS/LjEytz00sMUbUjInkOItAhoAv+5J0LywW+h+K9It4RGG4J19T5tZzppdG9U706S6aHCTizJd3Yg7K7+QV1+YSkVOq1NcpvWyU7wJNbRtUDWTsYrEvuTaR8gczFG+Bd7Ni/NPDqzy7cZSojs64QMshFQ72aLBkalZr5aIcZNM/IEj6dFMQqnCpK+8uqhGMcafzLaR4jr90cKaH398hmrdQ3rF6Ywti4N0kfoGwF/5wlTFgLsAq/LOjv9xRWilQobgdR4ROBe1uMhq9NCMh0ypFhDaPu6QjbNsEYgV3XLGTL7Naz1zjiWlx4UtDYEc8rnGiOcDQzbaBCzw/wc6sAJlzzp09ZrP0QwjX0lhbxyhOqw8VH9yax80Sj8ij0TJiWwIZcphWQtKuThnAYfHowbFYHZYOD4KhR8aFBfsJtAi4mmOOdVGnrPfLPbyGL+VPGuTZ2Eylbi3gqQFpHKZHN5xu4nHzCNV6zlF6uar9UobKZAe8kIqkylae8HAYXaDBTWEhCb13YHvDYLPE0mnIlKbYmBNT4j63Ij3IGJT5Ks3lJRqevA2ZlGYNwWuf1apBvvzX3IEnF9WHxas372Jq9LfzxEiY2OyJsxJW5OYig0rGy9Ij8zZ6k9rwY1LHVt7aVk3vahT27l+rRMM4wSuVi35G5rvLe+nA//Ke1XyPnDAiotXL6410LElsePnJD0GBVk3FmwEroHb9q74mZc4W9fZ8uSURR9FTqg3BvMpGLYitpTWT2Fcz4cRQgl63M9qG/4rP0wTkyH6FFINUzejUdB5HKePpvV1YeUaPAvMYDBoqB9tdcQ4TBDBitVl8RTImleMcEL2yIEGfkHInGAJHHfpor/yUDRALstG2rXdz/maVptEoy38DxjJj0xbJ9trgKUMmUrOZA7LGsdgxXTc0ICJw1Klbvn4/O5NCAhbX8uyenGB8TVyMMxlAxrC07BmssEFbPmMRP+M5QltQydT/4tDKDMMQPXKML3ncxT4gEXUhREvHSKB+PCE/cyRY98IMGd5JbrzSSwHMTd7yxu6oood5XxMi7nl6Sz6nYzKf3XMF5Fk96imtetPXOPzuPn4MiV+UG1huHS61ME8igUzcsn/2yT0wjDy/rqFCe7eiQPHxTtDAwREwXqA9y2q5eg2nhWUVbwJWtRUSMbxk+9s0g7ypX+rcArqFMQsqH5PA//0VcwcU2BteiLWNtMSaXu73eVg9Kan+1nSU/0lCJbsrka8YNMjyXw8D8IGTUcMhvKbxe3G+3Nh6bYQ0DBMm0g2AykuDt8TWusZ53ULgHgws9u7LQbU1YFjzvlYUKUVfRcR8MBkEEpeJ/XgyMqKvSqe3DogMznIhhFEfI6ZoQzEK7GCM9Zzvs66fVv8adv8Gk+saoPXpYXL1QD2in4PbBfgMVBQOfAhCR6zab6KNLmOUEtB68JctgsdtY6BCvABTVilJYpaK7KE35S+nyNddr5Vku4YPzKlNEAkZnvFWN5mNcTRMBJoAJ+2l87iUhbOA9Uo5kuM1W9JJ84MVtyMliZ/y9Ww3TDup3GgW/9w1X7KZgqySKIHcqGrXyPsmp63joCQIGAAxPV7z18JmQ1KEDs3WSXpdhAQFOsUSJZ2fFWVJqVqp8UsMCKLPiFAWzprllJU7Y31ip9+nV/YqzLm4/ZVHy2VmELifQi73LGJXoUqc651fPEwMXXofOR+qJZ3h/8SUbo3UWGoQ2m2J9vGIMLuV0hwKF0vwBY6nMm4pN9wyJMWqSgxMXMvbGeE/BSnzg391cJdYF2h0XXOgZXlrgY/fOFKwp4iqlebtUm8JbQO1j+4rB6bCR48Urzv7wk/amTwqGx3owkHZ++npAQOQAv4qDoqyJUGwCpr8uz3qqrXJ7YAsEVqQxFfQtiUYMWSKUa88rBR/KT3t3LC6lI8sW00PHgybTRtUZMbOkGz9axNlK41cJayx2HqItqkVt09mrtSv0I4NnLhpyv3dHlCoC6WJ1strgpMUDjS0KbszcQamTPNJ/pBmtTQydPKObx3VhayCDSO1Kv6G3GLGyIjJe1ybJJ4KgAg8LoWdfqZeKJVQzBEP0ynDz/8NGLlsxs/2YyY8Veuw+rA9IoVhGJv42YjbRcX8TNgLjBxCZDHNgCm9kz8Y7+eoMtl5dlPv1k78hsvfvD733/6CyVflN0+2CWwKv/H8YKWpOjo81YrQTosMKhIIM82yYDXZTZQq7q91RIKT9XRE39/RMRKM5lWY5nV4bwfdCk7DWE/Z/pcD6zKwt3JkE5zT49JbUSBSnGhKUwoxVJofu6DqOT2LpxmSz64fXwGKyV10my5jO9fRRm30UCeqekNqOdxiwgW9+AyCfS1VFixtyPTQ2uYlhCvv78BNvIXvNdFVOWfDCbsG1o+MAspWlvZgeeOREgluhOqEUplBsiZ2JQGL12HmWZCS4NBT4E6G5+MhFGDWbtzcmLcZqttUc3hoKQcazokpFnqvaVbJ1XQxzFe0vHlZBTeIO49Pk0U4kGSoT44p1O9oXJQNBE7oDmlfyuHtnWRzlqxebmucaaw/PCIYx2BvGYP69ZgYtwyvK86gBoL6fxHItc2eTzFhQOLv/zr+5e7dx80igmktOrspaG3jNU0WV/0fN1nAnkcOYrq9oVCmQMPrX0E4YzUKI18C2feAXwc6SkpBf9fmIFG2g3Zwa5MNf4HF5PCBDiigE/pYqNztaJvE3/uWCpnnzS0iE5Z3o2oFNxeggAlFyTmkSVKZ+EE0fjf/tIGsivzzHCD7wkbl5AsUq12i2YJ0kof5EerDwb1E57bchsefVaZdLC9R7u2ewPP82zPnjMHuc/5e8uJKHdZiV66nO5OXyvSpiZpSVtEndYBnhxVIrRP+CtyBjhMc8SlxhsXtHZKjrmLDR+ZXNSmbHiKnfyW3vwjhsQZ26O5OyFvgmGxnZ2jF2iik0uwkL8uKf6VpE5+WEx3tKwCs4dks8dXmhbUxmTjEA75dvvxtTGwq7toq/RJ/drDVP4n7sXalJB58HpF+tmmeCq4MS2Mn0MLyYNkdb4WreHRayC+H1If6kLdk5JrhzLa/WzW+QwaEgZColWzSBwaEagPOvGsss+eMBv+pDdnrp/0yXWUBdhTe6nk6RHnb9Kzj+AtPD4nfnqNRugPppSwSu+aOB6+wYaLErJY0+FDOBMJ1StJ3BVI3dccHT32LFstHCBtfrAbgmG/KsEu+Qtr/O8LFvBZe5Shqp2tRh2vTx/XkgCOR5BvgowGyK7C9QVCVm03IGI+6vcLcckCMGOd4wRMIai7TEDxmOtwXchQFWT9D54GnUWe7ERJA2lDMfyKZHUEZz0ArUMK3jWF40r9TZh1g84Qwq7lYkUx4WKOuZSUgWYxY3NeHdYjA0PvbQlQaN56ndHdayGV4TMcDKibvpP/NDitERvP9kAJPLzmboGTgDLmTgDJDcTl2iIWzufmkIH3UGVurFAtSXrLZLWpi/e3yQkE9Jv635XmhCFjpVTNm0fybIXKc4QSS9eXuZzzh0Hk+RrgJtccX75Qu7j0n9zq6+0LRytpxzgOMSaFUA01T7aZ7MxXKKlavI8uou0mdnhrosB7PaQW1X0X2JNcwoTPCZqph7jTMHllQjgIRZ7zbEwN56fOpRXYIraOD45ma4i/PUa7USXmgNlbLTGIh4ocKoS17/X+a43ePn0Kz8Q4nJNwcf9Lu7ZcvULvokqT99S0WBpAr2WpfiM7igsGnHCtmrDmH589gIDbVxQ2ZJ5KKIzYAVZyUxTSDDdZfbyqP0uhcHj5y1PmR67m2cfTcdjKhFPrcoxzUDHCNKLWCWlnm1xg7zDt7NlwcvFwCJjS/43n/us4uN2HResr9b5/Bu7nnyO51poPKq6qbzPxQBOAiCCo5RaVqgoSht16ybJropzpatCREl/17oICkfdzN4k01cuVDwGCs8JbaPOxilOQbEevAZu/xbFyVS3vzBQ0pd3NT6Gg7R+m9JVCa1RjwX3dUiXY5uLZgBJlYn7C8RtGxzGzcbxKJ3xG3MALNMv/QtdEhnG6Ldy3hps73niaZ7gBavIfQscgtHmMcXysCDNkw+Z9259CKf7B/szQH+oN02T+93ZPcT04UCOrBAdv2COsCHHprjNKDQvsRCmdEr/cut3D5ZlnV5ootqRynJPssGWAsp8vxHu8ZoPIKpfCYp1qAmPI+AxpMRJTWRfjlqg86QpCFMe2raxbMRA5gAGjiuszo/XAtxxQX+gSIMjdySvwZyFo+3u6fY9fphgyGpcFnmhD9xmncMj7WLGtSgzk0L9NvmKSi/yp6w9GBzxDgnlFlVT/Ac4tPF0bF/U00j/duHAeIkzhQmDdhJdBkFj0XzPI721mVOEkRVj28V9YPatiCpHpEXhWhFKaxkj+bIDGe0gKnkCtlOaCshPyKLrqoI9Rii3buK8gcQe4+EoSoO5pjxF2EBfR8mArJnIa5UDpzQuC2JSqQXAGWfaaUaWEqKlHmZHSqluhJLw/iA3ovRirMZHUDiP01C4kDVYqECIhMfQslxnpQ2T4p8Y4DPAYcuLWYxrzgiK9bbWGSEPsabF0kcgj1q9WTqdLbPllknrn1TlVl0tUM22HOn5YfWRoEQ4GYNgnoKyPtlNgtgo2z5u1/C4Xcov2iS9h1OqYHkEZNxMoqsTWNmMJRAFgyB+tSaz2+nd67fHMnjJb4rHzwjMnKfikyLxdoBLyf4N5rhZ8uvjI8p0/5DF7RzPUr8l4RV+KebQj7sFCmU5H8iL09w3HIkKLObTPZoB5OD7t8Y55oiAA3u3qnjj6nO2JsGauiJpdz0h2wOexoA48/8/JqNs3yblHztNmpWvSOjNktglKRkrM4I4QT6Mxuy1XfiFnq6omEhBaWPaKyzLhpJzh95luDiIRrXonPT7T5lHaNntyLbggBP4MMPH4oAbG3gCnbRjJFpzLAv7k/k8RAAgF/iN1hFUoGE4UWbKmZ4n0vSgwuEPjFq+1D3ph7b5sYpiy77WerJ0BFA/FoWzqR+obkxq32+5A8Rcw5wBGvmKgRKqidjlQdV5yHK2xA4cnpcFdPXU7iMX8TesIARXBRJFfB4/DaRR2mdx5z7wg6wvHJzoPZ9K5YTA9e5WE1yxpzPwHhg+pHuaf4Z7gPzIMFHLvsXFjHIaFwQ7u3tmc53+a6m2q5DCXtXsi9CbHrA94uxUAsdKWdecK3pvRq5h+Ll4XrgbAEAxAdsQ/4Z7pHaAvomrfZkspnX5MUBYzd7DcWg3AVUrHvVkyi2r0+5x0BwZcMmlcbyJ6kFukocIniES+3QkU6dyiEAnUILK4cgpxOFUA1ghEfToYqwsX37YLqre6tLKyvAJbRuanhN8mKUJRMGUdAPoJ4hY/CyuNQr81vt4WpcAAPBfC/6ck081CrnMBFa46txnhY/IZLNhejYMkO3xSrB3eeiSiydFskUakSSpxR08sOJ3NsUpIJ6V8KkdUZS2Z4V7lgvm+EvAAM9fRgZUoolIkguS97haIBwJ0Lv0Dp7JyyyztuyX8/sUERSMee1rzispYR3okBSpDE+zGdR65dLDfWJUHflEhPYOhJFsEHE3+4v5GoqavPF9G1Hm/bG+YYn+AIFbSuyXapHoilM8jnB3s0ajaVyElUlxYEU+tG9lPm0LmwLhR8rkOTXhDPywmPLArJERDVNH6c30bGSG1VBxAeTSsV24vmgItoqz+I4GLt32f9Hyjbl8hvMfunQcDW3wa9rlJJB9Wm3PNIHgWCMIczs626YMkrq83+OclYyNNrf5ZpULV3EzvfgI6x3w7OWSaODjVNEjp2pZCWnmsXDHSsKCRSmEU8MLDdpUYpHZl0A/3fglSkbLCBgky3aJAl/NuAGm+InGTljSeggt0LqLFDmm39DjDlT/u2S3g+R4a5z3WgUK0bZdrUsOFD6VqxN0QAPKgIqYoSzpNRwtC46VqNjlrKZGM85CRa8X2jl46ygJFo9szobAMGazPNRubxT27gu490YFv7eIh/zbspkfg0jHV5Kk34VeAfRMjD/UbjNk4w6sE5Bpf7QWww+3A/XuQGUzf5Ayp7YdrbZDwBNX388mWCXcDcvCWBysGnpoMRPGBDC/i1GZKFn+/OaJsFiaiD9Fz+W8v3IDXIemkQJ8ZD8X8eP1JzxRoUrZtyqiTCEcN2KFRwHU/+dT7pxZPlxuS4GRmj5TYc3712o082FnLC8dFjAEoLzmQds1e2n+QgaqMrVnV7cIzXTZQJOO4c+6neIIWV/yd1zLRSsVlWVLcdc57ryDjEYta4eO+QuVu01yBMNhrAcDyRdQTXM5CgUvMgJl7UOpYch0APcFFyF/jOTXpgl8s6UiT5jNighTuJa4r4r255D9fOc6Mp+GrOHyd/Fs5b//2qpID/0ns1cAAGZeakZLbc6mLrIeGSpguNwiEVx7hgEgjC6cpE6sd5vG34veDYECCDkz+aJ4Ejuw9lauqeHKDvcEHKJnQOC/uVxIX6RBt/YutFxaQ3DGan0XzpBnyizn0DsYnEPa2CAFoDKibAI2LcldNDknlquuG9UiANUimr/7O6Y/C44lyE4xuMsF0V4pyYZIg4Kkr1BokfkqOXyLAwrIHB1Lp2VLVnA4z4BDktP8WChkElf/u+IoD0EBFJpVRKYqAd5v3IkIbdzFi3FXIA42vb05ZkMp3bz2ojN+nisYpyBkiXK0VoTY6hGZu1YzIxi1FIb0zmUMcAUmyhEtM3LWhpPoBlUlq/ejRqV9G2pBHH3K1AiyfsyjtR2AaVKvUal7KhmMy+fPGMgbvMZ1vMlnm5eEv+YpqFZ4UgZizxBhtOuY5qZhwTPxdpg6lrGLpmb2ZXcX+0vwbRLjYsMzeLZxclptbgdzZ5yOLvdFwHdTKEA3RYMqyYIsxWVpe+6Fxt+/Pbs0MkMbhaIz+jKcGaa//hR35Sado3OWRZMjg6NTQqjZWqmfl6x9oSiV+QuF+8YU7vPLa2pAbS7buwgJpoCMHKNCgJiwk83L7MK+iOX9d1k8FZxFqqDaVNaNA4ohVKQYQgUq4yHe66cXXCqgULgEEVKhEJjOfhgLQsySNxZowmXUsd0gQ7pWaGLBDTt7QyL2DW76uJsS3OlfwQVtXjUQLSISonXs9mPIWn87dX4KYaVPrHJUX5vw8KK7QCFlld8OIdRTmUentBi8mDEkL9/nM9UhKjiT99kwvZx0DEvt7dbCME/1Y85D4T8DQbpQJZMH4CG0Ecw2oMQL22d+GI5MDKUbFTo2mZFLFm6j2PwgoSfZ3RZUNogUujTZNK+U5tuYVOWX0Pe+5ThMAVCSINclCA+OpVBM108fImTYeCNsRjcFI9CriLizgp56bUIKhOmL+LjKifPaOsxbm1YGRn4yRRPTcQYrrQYYRG/GIT2WdrH0vQgAIBwDLiGY8EdilL2LjEZ7fUuHyNjrjyQ3yYxQPCKelKSHhH4f9Kohcqv0ol2XwWC8WHcBpf82yPBac10oScXhCAK1jEQHJNio7gVR87QHAMW6YNzY1NzpQJeORVDi5hZKX+E24VUBdx2yznrOEn4q11XEbwyokwSbX2x1IEmlT2bi6ugxUVwQFhLmI79L2ZA12CWKz+7BCqR0ictMW90HBdNPzo4JmsNRleVjsKXtP9UjsfQOQeDghm4UTrdYN6u3TR6jiaM6T1MiC+vyePvDr8WwBKsYjKteRm8+kzeX3zXZqWHvxjIA2zyQA9ViDCNZpLAkC2AtNf4sRhwuY8xfVPr7PUc9j9sVauXC7SNoQD2DLmupL1ffy08GfY8uNMRmEyI4CFAQQtQex4pFP0HSjrOPBp85R+MxDhq7F0JjubYP8Z1lSj1XrNmar00jx17Dc6ZxMb0NGvD6RcI1T3Mg2Ewi0sDsjWcZdfbqfsk3QK34ym7lFXa+9eRIO7vnme/UIsf+xxihWgIBwqdfb3vfVOmy2LKTNAbLsvPoxBBAl904boV8fI6nDGM1QAdZcerOOkkkVxDAK8Xpg0drgKDPr6xgTVZYIK+quZqu9hgDeizIxWBBnBWooyWONCSAsSDK/g7Do97KfKyhw/HK+CKmFx/jwawXibhKdLLRTvBwEiAoudWxlXXh/Gr3AwqN2D2xJACu2rytlUF4f2l8fmUja5+InDvGlC3mvTUfGtLOHu5u0F54nhXpUm3Mxs2CmIPJkj9HMnVmKxKeiAcsLvJl8lD+fiqY3/TRogerdKn/2XN43NfoiejC6DrNQKwmKmpLgzFUa6KkwwHJyknBc3DdirL7gWMylzvZe7uQmYXPRoy1qsUFGDJ5FIZzBSJtggg4/dVQ/JV3xLymV7ty8z1gVsK8iikDSHZc28LAoU/aFisgblk+SxuzhjGKAS2BV3APusqfvHvzFootpSNuzqnaMcAA17lIQj0NshBhd7UOGNbJrKNMUa20o0K37uHo0HUP5VNVHf+gT7JlUiESxA36WvrSAOEgR4wF4RyLB5fmVQw4hBAdRUXPsBrbWihQy9yro2oS8bS4RVPN7spawjfUjtcpwgbjaQDPTcZT7nxQEfU0GXvGGR3MDVuarfnwaztR5ioATgxJm/Jkz9up6S0wlqncjaxCwzMqCGg6VGIBwTFQhAVQmOAS30+yMpVhHzOwgQhI1uTQyWUBI2UO0BJ39Q7IQxNw8oYbBGKyolBKFmYttajjkM5y5Tvvr5O6xRmADnRHlbnV0y7wRtHz3h34/HqZYsVDI0E9tPmgRChGtXGpHxDCn4VS6ZLo95xeZPne7gD3ASmMguaAAqI7O3W1CwKqjWR/tQhvuGvMjhBLXMZzGhCkanTcnCQBjO2n/kzreS2JjWGPylhTuehm+V0xg5akH+8953a6MljYxNlqWh5bn9BxoPo/wCTyufV5imPpcyAC3WSKqdOQp8UFQSDcSAsi2piYT9SJq/sD+S6jZQzXVdifWIHGn+80WiM4Vd004R9vFsLGVoX4e/37P/dDnAkcAJqob5BZf1+3rMqh/KfOM8ByL9U/oSADH3WCd1Q3RQuO0QgCxTOjmqPjA8tQBlUeOioWOeZ9t88fdp29JXYr59YL7vl6tha2ALcWzpiwxamG2WgqPm3EAmJWC4fbF8fSmZHJOwkItMWHfNJ2r47tuRsCy4IGgvYv2M+1W1rEAJcI594On5o0QZ28mcOr/zhlKOw59K4zf/CCntQLY++jg5A4AkCiucGnWDODH/WFEhUjc1PWpD9ItMzcPUqmyNa9eKU0XqrpDnyV/yxk1xP4RsJMojgIAjq+5ulBIF/r5CSXcgbHooBdxaIX5FBRqkbP37DeS1HfiaSkiGHcsGTjwx/jvz3XzF3zZoyFCfiXanxlIHocoqrZz09YTtVjob/EqKT61gc6eQebOLCqNHho1qoEH1SFHUzvyEdy9YiKRE8VYJVn7NWDhMm/RsjWF8ct7qLZLmy6kfwVIwUJjh3gN3lEYAvquUxlwH7oqx6Mk9j/OIxzTRaIDMNiVhgsPt7+ufIc3fode6TkyfytF1vzY6oUsauMZe6214d8TLmfaABqhLiqYC3Qw/MxL152eDyJVkn9/it8ssKC9WFeP5och/b/tfJNZ+0hrGymWkvCOGW2AR13ezY+L83yNK04zZB+zm7Zvksm2KMtfxgfCc4lHOKG4cPWPYiHY+/HamgPRjXu6/d02m1skradYsY+Pv0hF8ctwTE3DHlbOlBk5H3QcjiLn2NGbQ0Ukl3b6kmg1JBW8hfvwY3dk/SGALuQw/0q60x1JfxbW+w9R8PQH9VVXgcRuQr1GYup4ZUZvnIQAqsV5g4sYRVsEibwWdLt8QkWI4vEJSWZoflICHJhxXbo0xEuQy+Q6L4Kr84BHJnpNrZWWWOSd34UbAuGuAMyt32+HKBDUz6CQaho+RY4DL3VhOdGvzkD2PFfCDclNwYaFqqSzvmqctLm6KM/m89P48Mm2n1Wh9IhIWNuo62nZihkptCZsb0scjJxuiw7TMHTm0Re2YA7aFDaOh0Sn6FE82rV+7o2aVMUVnA52ZwmGvOHzsmqjZpPKCGGvAZBI50Ve8w7Un42L23U0OEJCfQwVwfGyi0yrAeJhfMCXE65DMGWEMu1k3fxxD9g9fTrzNGlyXO/q+YHf2RQoefnyAewXU/y398Q14io8GjQBfY6JzSnQKqNmR/5kFxn4ft3SrQaixfpfvv/f9bXRdhAt9xBcCXuM9G7v0hWhpQ3lI0HcgQAK3B8EBA60JcOYx96J+2CZD98+c6zbT1wLrQq6OsS3gSon7IXSkZ7xiCgLgKQdWS+4SLl9FHw7QBtG70oV7wMABmKwiLRQy/57lzS4FfJ16VfMrG7H+8egV2HQC95NIRaGuIKkEddec7yy8UoPSSuCxYCECMa298ReCHXvsBOznaRPbc3XK3ENf/CPyEWgQoFY5Pe+hHLF8TcwdqQv0+6704kLwO3l4hzIvAf4hS9sMthMmwCulS4dyjA0SlhAVhew2naPxixLIOxzcoY8NhAcITZMMEpgz5eUMa4FyRxZvYz/kFuzno7cJqKHrfIS4SUxKmq9Fdgy8GKPy3XYbLaqVlRShrAqxx6F2AdxtlgvAKRG0KbJg/3zfQ/4fsWkbseIAjsb2H0XjCgx+15HhSVGqYO+jDBEjs9At83pFC8APR0ntuEQt6Wj5+AvR1bsKoGdHjnwtEx71Pzs57lMtr4NXImSxCq7Uf/AkzUrI7DTr1IV+AMuL5P2pyiPRvNhoL1K8oufR/UlggwCeUqZAyIc3ewhmUzsQF/SBhDIn0QXvYfRCBPej4vloEMI05g33BQmNKYG2wV85le/IeGlXaD+40dTkFnum9M9X0ftpa121KIGJqcP0MzYEwofEtw/BH772xXRxIISuupmvOkJy9PRB1tJ3O72DV3bDvvlTTi2IIxzhws2N0JkFmLQv/YM0msnqeVtKx0HvI/gdOEd2cmZ2P24VDZotTquwuH29cA/l9Tg81fjg6Il/dCQGIcPC2N7qfid43k55ZG+yV19VzSVaHHPC0rZmRfiDxrKxeDRsKcWob7PbngscAKsKA+C02su+oVbeqX1H8A9p3ghnKdWJ747jONg07wigboMUXxA2KLvovTUJ0i2lo3XukBV8hERZcwUveRz24C4ut2qUwwZ8zyeQtip/Q3UGmS4/d3IYDeKvOE/0oQZyFK11JWFdVIAA8BvEPfP/tc0zMoA9Qd2F4GN56VGdqdxqN469JH6O4Gb8JaHHbVxdu3bi6tM3NfW5DGcqHf4/w58+Pmr7FjF3QCRa1XVk+M9C0eEFTu1U5wm1YPkLGPOUSo4L2cJRIXD+sHNc3fawXNyXRATBCvsk/grN7wcAbZsElL6y3EFbKXvHoMOHU9KELBFEB0rf4491/xfcp5uPe9tm/SDzB348Qr8b7gszqbMFoPsWMesKGZDQEEPhb/yfklUDAJ6qCdqxI+VyLcMvHLhDhdhz/xxoY8GhGJ8eLp5dwfNv/9aOmhfu0f6L+7E7ExWUwdLC1hNzpFzu61XZAyXzdehlF8NU5eIlMl1eNkgy3WGrvgLzZ4Yl953mPIJlpbEOb6Wi+VtJcvWfwW8/4BQJpReBoRG7lxalr0tXIdTV3F0OV4Xe98WsIQOscLPbPTzaF7SjSDxb3CcMXsO1JjwGSfEnmN1RAAGgV3p0nGmkNCLhafwg3hwOXQe8SCMZVEDivwHibBIHudChsD8Jg+QJOcGUo8DsW1DooGoZbio5kTZiMUoN59BueebGQ3FEBMOAaNaxuAAFhcBIEiztgsrzvNhptBMXNhTBcPAenpi8oeDUvqeUWGt0nRSd4HgSjrgVhXvhGlhry/6+z539F600MdbqZbgf9VpjL88SRY8dh5qZ4vtAGBjY36nzz6X4t5igPYV0y9nwQ1lRTpsiutpCl7GTecy7Nk1k6hjNuijnKgyiAn9rwsYPCHIjVvG0mBq0ut6tWHsWfn82UYuxcbhqvfman0vqWbHdDFgM2Qz2OEJ3srGpD9MhUOwjmW1hzftm9jXt6ug25g9d8q2xDlxc2w0X26tHR8YE7uYUndeVWHz09BeSsV2798FKcZZb4dBZmlK7VLCvJ7vMKgIn3Xk64ED0qkVHrbBZ17Rj5fklq48nv+h9Tq5oCUz9Bs6YoqMZAkRXgVw6o6IuapTM/i+dLP/vlbx/IYBne7d04LIfjiwcmnVVfWHVx/4HixdYM/BiI3go4dDd67MjZAkCtn1usG6jrnicFW5esK86rQJPenbmRudByx8BkCBfg8L7d1iTDNhCO47f15OVuyNKRqtfgM5CCuFZvEaSFSUyJybnU5k0AswppxYcqN1L1Zd5XVd7MeQJjHgPkowJyt9TD8h85N+BN31qFdbS/0APpuZGqP9LbQzyWFB7/97zDFEbw0BYTPcRF0m1gsfL7Jdi0RZ7T9KI9S9gagx1scuD/65FLlf8ebMUYauNOiBkmGvDFHT1yftekNUdbEiEThoigEfurM8/acmxtrJtLGP2mUdooeEFhpns7wqBdi25JDmxrjQHRroJZ94x9JUz7j3N+S1pYbUqE5MGgfXvv9DnqCpPcKCv8N7usairAvCwUnzLAQN/QcdptYKaUW5G0RaCdZ1RFpviNIpN82yOJvtJKVi/rFfDgIq6rQAWg8dMOEgBY6/59rTFqwKeiTa4HFKuHNSnlgGTqZOLVvv5Fp7O+1n6eQgyonscKBJGYi+YIgcKw6e0QmvEoshMeTjZUGTFWHlyvituWvrDqKNioM44FMZTzaXUXBWRt4JgITkiwXSmJnU7m7jp1l6qNzC2V1dpK1QYicBheTEGdEbgvFhotqat2bOH11wNc7t1OszlDi4EEyPJa6RsoEKP5QV8eDwdCaHq4yCkUo0XiHlt2dQ9bCQQKONjihRdB5+M5C5iWy/VwLB72E1CUtWcAJuoKzmQGTQ1eigFIKuiaWVHkolOiECDoFFnmR83vIpnG6H/pgS+SgMygVix41kREPVMMY4BcQsAt6lQkIwKgMJtaeD4XjnJcSgqA3np3zqGfasKBtrYJKTH4n5jdH4hyWpXX7e8LvjKWfUWh1WzBI4KgXGokpIM2S5t2uhDPIUlvwDoS1JF/z17IHL240Iq1ZjKHf1MkgGbLCvmdHDJV1zuQG1QZfsViob8xkgqmQuwZTEQ1jJYKpDG/7as4to4ENArwQCvoJx90taGwIq2b6nEEox0h/y5QdBuzoiU0tCbJNz4AcJ2osds4D5E8IFnQ0FEDnSm1r/2pKM2s0lnI3/EefBoUrfs39Tf2elzhWMs6lIeDVFacYuQakMz9iExNFbIZ5HrxhjcZB5HW6EIyQzgmKO7lQJIrfDoQtj93PnBCT1TCgSreKJYZDBiSazKQiNLn4Ah3CHqF680IhYfiVDNIL4u5StFpvWy0kWrV9l2V9VKRyeNU1rZjyL79CW4EBO0SDLDAeMDHOBKAKznr5Uy0cTRmpvM5JI9GRQBoYu/GNgKLJaWwQT8DEr7uW5aFbuVoGzHam9osJZs0L+jHemGjw4plLW7oDBq3h11X/qGWc2Uc/fAyEF2bvh2vXZaRfxzt6nTAuaRekyKF+BpEjPMDyc91EZLrGRueZuVVT7itwtms4qcF5gRbW90lXcXeQLj0FyRIKm+tG8/ocSlrRBzi0vHB7Lr9JmdMxd7Uysi3OoSjnT6AzQxr5E5YMiqtMafV1nzTgDTaZVVY/mQn5mtPy6WUN6h5/Dw7xnnII8gq8IOExMAtDKfvnWGTwKJrsQUJOXCcCBfGG8ryOPDdzFGbCPceFf4xt0o9+4KzmMu//YPju67Wdsg8Mp+W2zmrD7GExUUxDoP1UPFBFUpajHfWRnMB3swd42OUp9LO3j7GKaJChGj+mPZiomx4A1cNt7rKd2DyvCm61v3p2ZGvmK9m4mOnyXFOHZZTf+BCGRvK1JfANYwICI9Aab3/VC1mQeORPDWwBKX22li0MCh0dOZaor3zAY/6toI5En9PzkHPZOqdwNzgbjpy0rpEbtkkhKb7fqcw31GGmC09U8/e055gtwNOe0+TwjH4RCPMJqdOqRK5l2MNu/0D1VQ3hihjKfJDidV4pzQEFV4jq0ojRUaOcjwn60faTfuCRkbou0Qbs3+6c3mLADmzieRiALUk8fD3XVMosn8YG6CnBXrn+HwkwzX4icLabxdBmhCmdwAniC8GFS0jAeXcbY7fVDgalGXeiQP76/Bd2NDKvFjcff13wdVziU+EU+ozxyl2XJfo4Mt1gB44U8TbkA7JqLw3mNrTn61qycI7A/hZdq/HwIqXzRwa2LvwF0I06kYJhP/mGrtElpNT57//hIrfMap4yel97lGw49suYa+15Ix+dZ4+dblurRlUvsizjVH+B1+gYgkXeg9Sl7548Xre18LviR12McTqdt8OfdEHTVCyzSyXeaXbXc+XI3yfD0OyVOzLKd65KkyDrlGcAZq84FjxHnUn4ISGIEH9ZR9JNf9SKSawg3e7kMHWeKXLNlt815FSbClYIx0v+mI9ykSguwEuXexk6kvVemUdjXTTNMeSppp0yYHOL98jGI0PGsuCyQ5wRikZLS8/YjYAghwWw/Y5kKI4bA07azwIY/iN7ksKIEliwSBxs0QlB+3zCXVhdQyzYAPpoislYOioEkX4G0RecCpa8HcHjdemqbWCwTn8SYgRALhr/OKDrCpy7gEl9AI0SCJqo7N+ERzocMkPYxRJmnafS8Hok+sOGcaNQgShYCbjgOlE9klut8yIPRfnEbO71I4NCfJJ/x0YIpACFUVa0nc09+bArClSWh6/0yQJZDGhSC0gfW6iIglCuSogBLmqnb5P6fLxgUKMnH5Hwlc8LXkytRJInMjCeq13BPr0QbzobuBbSSjRuJU1BrSgr3A/hPw86Qo2bLYs8kEO+giMO/sYPTy5wA8NkKVfXqr/0iRmdHMXMkhrYWcQOmq9KD+Lv7kfzrECKAnH15xqB+JThY0oNQChDWYCnOxFlZFAhVYAX4c9kkxTyNqIBEG+AJxashoBFwVfhkBcKLbcAG2JyCAigFRFll+zKF2XyJuQxAuJUiwqoRFEZsUp5Ngb3A+R/HlpkCFxaERWFZFpQomGVWj3dSPxrEJoxQUxpg5oLViiVpInu0rPCilW0TWLnKBLhgoEGVdVaR5f8KYrG2WuyVa5UZZLXpWg3OrwXkwTZiPJBIM2Cc8Im5M4VAJUVqpMTNJVbYLih4j0Sk9664GuVCHFlWhM2c4FlTbRIx81MUdKsd9IZUQcuHQVzgUIRtMguZWlHdkkAl6Jv1QgaDPZm9qQl1sYgbpRcpfwm/DVZe1+Be9KHK4BC6pYylIWNi7dhDWHcL/LzvVHLhKtsjAtiHPAxeLi1gSNIwp6LKQauIRAiZl4SPgvgST2Y9gCwNpiBwsK5S6EjFOBCUqloAdaYUVkuDfsPINEAS3dW3lXYcCJz88CYO7LwkIDbhXhMcZsEwnyD+vbDmXFFgGxLoduEeRzzbJxncCvSCHgzNueR4X0DW3uAgm0Nzzvng7VKR7X7oV8OCGpJtppiTV5ccQm9JWpEfocCfqvAKYjTdswOJFF781M0tpKLHtIaGCxLAx3IbtsoEJsdREaK8xrIZP1ei19ITXzyc+pozIBBM2LI0B0384ntn4DNnuU1BEVZ/oRH+wCfn0HgqRhf4uQcEBKGLAFLj6UAsBl38e+eNHx/d8BAcRw56jR+8gqwZqNtJ8ABbXXQqBtIZzRN4EBS7uqPnrPq6bRLMYKktCLGnSNwFWPD8tb1Zq9MHFgk2Ej8vruzwBm5HauMkEZPk7tkLGPnAMzLkplB/D0Bmy5hbuIEkZJLk/c/OLIw9lVIFI3ei9SIHlWPVy7QBdLhxcQiZ94RMiGd3QRPC3a1/IzWjKcjxJJKMIENioAf2xEMU2ScpEK4lnlhNFYSM8N4QH1LKNR74jZOvqYAhQAN1P+eVDCSJfMsDPCxPau+gAwZBAvbyETIxJAXbDAkp0vaeNlZFB1pBxYaqIjABZiMq+spDAYg2UYJtBTC1s9kuE4aN4sjwqsU50WV9MPmw9NcG1Y2e6Kin7QQU6bUR5MK7m9po2VyQnYWjTavZD3kXND6If6ggDvFmbzQpdZ0Bv12N8S0XgYQdTL6BjiMKyV4qm5OHFQiK+4mSXD0G0C1CG7dpuA5DbeV7AnREjmozvA1sdhrmueCcdfzwk8EzyG1oHmYDtO7B7/kR3xdYOdBqCD+K6qBmVxPOKgw/j1AG60chAtpNz4BqRr9jFZ4kV7yWj49VeaaHe+Eq+PWZquxXTi8guuUC4Qk8nTwGv7b/P4P3GriPSRs8tOIWZ3hGd8qyAu01UQqiPnw01OpaAg/kfHKnd6oP9i/8ISIx4FkS+Ix8Dox5eB+5M988aWTs/FwBhH+ILiEoKYHIPXxy7iFiPuISqBZ/BLQw/J3MQ1z93fu2MYBnxyh0qwIBThFTJ3DfVJ0tiVVvRQCAjFuWyVk+QHhRQ99ScU17VgaVmlCC0xrng1YQ9Zc2k1SMfIfDwEvW/RaNbaWX7SyR8XV+kLdlJv6KSfE53ARFgspPO+yjx2d3KFx/p6rcCeSOAKGAkRQ74WRKtElfr+P/5B6fw0xRmBzzs4mnSfFr0Mre4DA3/BL/PK+O54cz2HPBn+s+tDgElu6zHLO+9NDQWO+dNbS2zw0QefrLDZGadsobQ3D0A+l37a0876w3m/u+CFKldcdMlW1d6Y4bqrrqnxyj8mqlNriGGGGm6ZERq+XKdNXzD5KVq1ealdpw4jjTbKPsuNNUaXcf722oGHAmCYlu3E/4Tq/h2Hrlc+JiEq5jUfwuJgPCAQSWTxfr4mo0pISknLyCKoHE3eAl2hvxuBigymkrKKqpq6hiZLq94QrKOrB4AQ+bpPYARi29rR+pu9SPH/i0Sm9N1/HptCaHQGk8XmcHl8XCAUiSVSmVyh7CBMpdb01BKu0xuMJrPF2k2dQqnSyjQRdofT5fZ4fX44AolCY7A4PIFIIlOoNDqDyWJzuDy+QCgSS6QyuUKpUmu0Or3BaCo0W6w2O3sHRydnF1c3dw9PL28fXwKRRKZQaXQGk8XmcHl8gVAklkh9fGVyhVKl1mh1eoPRZLZYbXaH0+X2eL31znsffPTJZ18A+Uqvb4Y04eyFBagSHhL6D26/TnjwESBEhBjJ6FgmyubifCgUS+XxSnVicmp6xh6JwZId0RTsbGKkeuNS0lyN71m9UF+4uJj9Yx268ZNzQXXYx+lKWzkCx1VMSHNZdXYozoZKNQjm4mzInuz7C/kQ5WXa6PjF8kVvUe5PWXPGp1GcLbksyngr5duUksRN+ShLFamYSMdjsYWkVaaKkoYs0Yp86/orxfSdtgrtMsZPvkDwLj/rBLT6vF3n5WXrt5sM3Lg0LdWl1cAGlAqqKtcIlHoUwR+oN/9PNtpbVg/LCM5HC0V39bRsbnJbanlaLEPWcmnO27DcH9scDKOIeheXHyhaJN3Q7wRdzMnT8TG0yq1BKy76TyGv360vr3ddyvcJ9RrDOFPd1NySgFfjYzGGyf5iXT8pjCOtDQTHbGkMVWdvOa0O36lMDWQMKpOhLRk46LYMgf0wsyhhsJpVW22o6frT7risv2iT4auV8ul4rw1P+zSUFZcRsiiucLuU97Cs6czx5GczyGKr/DXH4/S232GpWqklpddUPB40ZK76Aes7xQUz12OHuZOJG+ilZcDbMdeyj7tZiKLXNW1/H0nH25mIlC2DHK7LSqxrqVm17Gu7ZGAgaX0q21tH7hmI/DxDsVZNic2AaMCz0sxfgK0ycb1Lovq1NKl4VZNzZluPZlGL25YbBFrU4p3y6xxPmJwggzKoTPHus8UgEX7u7yoC9NqqNMv/9KQ4X8m7NJnyeOqfhW7Ah1JtW9OYNbt1VRBroOcYvN4rAn1bdGHvBcrMbbruBbqsEoaQzmQ4QaRuQQARTjCYLHY83+tWIXGueq31YwxAhBMMJotNUhyuemvQAQAAAAAAAAAAABBCCCGEEEIIIYQIIYQQQgghhBBC1u0YQIQTDCaLTVJc9dYiq9qynVU7SXLsrZ7erzVK0W1ciY1n1ae+WsYu9amldanjksFedq5MD0OWbkchyTVL1vZDlttGrCoj/KBIp7YKMkQwhr6xhlap/YRmuPyZ917pX6zR/f74vZQdHC74/R+b0fvAEi54MwA=";
const SVG_NS$3 = "http://www.w3.org/2000/svg";
function embeddedFontCss() {
  const src = `url(${HAND_FONT_WOFF2_DATA_URI}) format("woff2")`;
  return `
@font-face { font-family: "Excalifont"; src: ${src}; }
@font-face { font-family: "Virgil"; src: ${src}; }`;
}
function renderSceneToSVGString(renderer, scene, opts = {}) {
  const padding = opts.padding ?? 40;
  const box = expandBBox(sceneBBox(scene), padding);
  const rect = bboxToRect(Number.isFinite(box.minX) ? box : { minX: 0, minY: 0, maxX: 400, maxY: 300 });
  const clone = renderer.svg.cloneNode(true);
  clone.querySelector(".edd-world")?.removeAttribute("transform");
  clone.querySelector(".edd-layer-screen")?.remove();
  clone.querySelectorAll(".edd-hidden").forEach((el) => el.remove());
  clone.setAttribute("viewBox", `${rect.x} ${rect.y} ${rect.w} ${rect.h}`);
  clone.setAttribute("width", String(rect.w));
  clone.setAttribute("height", String(rect.h));
  clone.style.removeProperty("position");
  clone.style.removeProperty("inset");
  clone.style.width = "";
  clone.style.height = "";
  const bg2 = clone.querySelector(".edd-bg");
  const bgColor = opts.background === void 0 ? scene.meta.background || scene.theme.background : opts.background;
  if (bg2) {
    if (bgColor) {
      bg2.setAttribute("x", String(rect.x));
      bg2.setAttribute("y", String(rect.y));
      bg2.setAttribute("width", String(rect.w));
      bg2.setAttribute("height", String(rect.h));
      bg2.setAttribute("fill", bgColor);
    } else {
      bg2.remove();
    }
  }
  if (opts.embedFont !== false) {
    const css = embeddedFontCss();
    if (css) {
      const style = document.createElementNS(SVG_NS$3, "style");
      style.textContent = css;
      clone.insertBefore(style, clone.firstChild);
    }
  }
  let out = new XMLSerializer().serializeToString(clone);
  if (!/^<svg[^>]*\sxmlns=/.test(out)) out = out.replace(/^<svg/, `<svg xmlns="${SVG_NS$3}"`);
  return '<?xml version="1.0" encoding="UTF-8"?>\n' + out;
}
async function exportSVGString(renderer, scene, opts = {}) {
  return renderSceneToSVGString(renderer, scene, opts);
}
async function exportPNGBlob(renderer, scene, opts = {}) {
  const scale = opts.scale ?? 2;
  const svg = await exportSVGString(renderer, scene, { ...opts, background: opts.background === void 0 ? scene.theme.background : opts.background });
  const box = expandBBox(sceneBBox(scene), opts.padding ?? 40);
  const rect = bboxToRect(Number.isFinite(box.minX) ? box : { minX: 0, minY: 0, maxX: 400, maxY: 300 });
  const blobUrl = URL.createObjectURL(new Blob([svg], { type: "image/svg+xml" }));
  try {
    const img = await loadImage(blobUrl);
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(rect.w * scale));
    canvas.height = Math.max(1, Math.round(rect.h * scale));
    const ctx = canvas.getContext("2d");
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    return await new Promise((resolve, reject) => canvas.toBlob((b) => b ? resolve(b) : reject(new Error("toBlob failed")), "image/png"));
  } finally {
    URL.revokeObjectURL(blobUrl);
  }
}
function loadImage(url) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = url;
  });
}
function download(filename, data, type = "text/plain") {
  const blob = typeof data === "string" ? new Blob([data], { type }) : data;
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1e3);
}
async function downloadSVG(renderer, scene) {
  const svg = await exportSVGString(renderer, scene);
  download(`${slug(scene)}.svg`, svg, "image/svg+xml");
}
async function downloadPNG(renderer, scene) {
  const blob = await exportPNGBlob(renderer, scene);
  download(`${slug(scene)}.png`, blob);
}
function downloadJSON(scene) {
  download(`${slug(scene)}.json`, JSON.stringify(scene, null, 2), "application/json");
}
function slug(scene) {
  return (scene.meta.title ?? "edododraw").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "edododraw";
}
let registered = false;
function registerBuiltinShapes() {
  if (registered) return;
  registered = true;
  registerShape("star", (rc, rect, style) => {
    const g = document.createElementNS("http://www.w3.org/2000/svg", "g");
    const cx = rect.x + rect.w / 2;
    const cy = rect.y + rect.h / 2;
    const outer = Math.min(rect.w, rect.h) / 2;
    const inner = outer * 0.42;
    const pts = [];
    for (let i = 0; i < 10; i++) {
      const r2 = i % 2 === 0 ? outer : inner;
      const a = -Math.PI / 2 + i * Math.PI / 5;
      pts.push([cx + Math.cos(a) * r2, cy + Math.sin(a) * r2]);
    }
    g.appendChild(rc.polygon(pts, nodeRoughOptions(style, true)));
    return g;
  });
  registerShape("speech-bubble", (rc, rect, style, data) => {
    const g = document.createElementNS("http://www.w3.org/2000/svg", "g");
    const { x, y, w, h } = rect;
    const bodyH = h * 0.78;
    const r2 = Math.min(14, bodyH * 0.3);
    const right = data?.dir === "right";
    const tx = right ? x + w * 0.72 : x + w * 0.28;
    const tip = [right ? x + w * 0.86 : x + w * 0.14, y + h];
    const d = [
      `M${x + r2},${y}`,
      `H${x + w - r2}`,
      `Q${x + w},${y} ${x + w},${y + r2}`,
      `V${y + bodyH - r2}`,
      `Q${x + w},${y + bodyH} ${x + w - r2},${y + bodyH}`,
      `H${tx + w * 0.09}`,
      `L${tip[0]},${tip[1]}`,
      `L${tx - w * 0.05},${y + bodyH}`,
      `H${x + r2}`,
      `Q${x},${y + bodyH} ${x},${y + bodyH - r2}`,
      `V${y + r2}`,
      `Q${x},${y} ${x + r2},${y}`,
      "Z"
    ].join(" ");
    g.appendChild(rc.path(d, nodeRoughOptions(style, true)));
    return g;
  });
  registerShape("starburst", (rc, rect, style, data) => {
    const g = document.createElementNS("http://www.w3.org/2000/svg", "g");
    const cx = rect.x + rect.w / 2;
    const cy = rect.y + rect.h / 2;
    const spikes = Math.max(8, Math.min(24, Number(data?.spikes ?? 12)));
    const pts = [];
    for (let i = 0; i < spikes * 2; i++) {
      const f = i % 2 === 0 ? 1 : 0.74;
      const a = -Math.PI / 2 + i * Math.PI / spikes;
      pts.push([cx + Math.cos(a) * (rect.w / 2) * f, cy + Math.sin(a) * (rect.h / 2) * f]);
    }
    g.appendChild(rc.polygon(pts, nodeRoughOptions(style, true)));
    return g;
  });
  registerShape("ribbon", (rc, rect, style) => {
    const g = document.createElementNS("http://www.w3.org/2000/svg", "g");
    const { x, y, w, h } = rect;
    const tail = Math.min(w * 0.14, h * 1.2);
    const dip = h * 0.18;
    const opts = nodeRoughOptions(style, true);
    g.appendChild(rc.polygon([[x, y + dip], [x + tail, y + dip], [x + tail, y + h + dip], [x, y + h + dip], [x + tail * 0.45, y + h / 2 + dip]], opts));
    g.appendChild(rc.polygon([[x + w - tail, y + dip], [x + w, y + dip], [x + w - tail * 0.45, y + h / 2 + dip], [x + w, y + h + dip], [x + w - tail, y + h + dip]], opts));
    g.appendChild(rc.polygon([[x + tail, y + dip], [x + tail + h * 0.35, y], [x + tail, y]], nodeRoughOptions(style, false)));
    g.appendChild(rc.polygon([[x + w - tail, y + dip], [x + w - tail - h * 0.35, y], [x + w - tail, y]], nodeRoughOptions(style, false)));
    g.appendChild(rc.rectangle(x + tail * 0.7, y, w - tail * 1.4, h, opts));
    return g;
  });
  registerShape("paper-fold", (rc, rect, style) => {
    const g = document.createElementNS("http://www.w3.org/2000/svg", "g");
    const { x, y, w, h } = rect;
    const f = Math.min(w, h) * 0.22;
    g.appendChild(
      rc.polygon(
        [
          [x, y],
          [x + w - f, y],
          [x + w, y + f],
          [x + w, y + h],
          [x, y + h]
        ],
        nodeRoughOptions(style, true)
      )
    );
    g.appendChild(rc.polygon([[x + w - f, y], [x + w - f, y + f], [x + w, y + f]], nodeRoughOptions(style, false)));
    return g;
  });
}
registerBuiltinShapes();
const SVG_NS$2 = "http://www.w3.org/2000/svg";
function edgeRoughOptions(style, tune = {}) {
  const k = tune.roughnessScale ?? 1;
  const opts = {
    stroke: style.stroke,
    strokeWidth: style.strokeWidth,
    roughness: style.roughness * k,
    seed: style.seed,
    bowing: style.bowing ?? 1,
    preserveVertices: style.preserveVertices ?? false,
    disableMultiStroke: style.disableMultiStroke ?? false,
    maxRandomnessOffset: (style.maxRandomnessOffset ?? DEFAULT_MAX_RANDOMNESS_OFFSET) * k
  };
  if (style.strokeStyle === "dashed") opts.strokeLineDash = [9, 9];
  else if (style.strokeStyle === "dotted") opts.strokeLineDash = [1.6, 6];
  return opts;
}
function resolveEndpoints(scene, edge) {
  const fromNode = edge.from.node ? getNode(scene, edge.from.node) : void 0;
  const toNode = edge.to.node ? getNode(scene, edge.to.node) : void 0;
  const fromCenter = fromNode ? rectCenter(nodeRect(fromNode)) : edge.from.point ?? { x: 0, y: 0 };
  const toCenter = toNode ? rectCenter(nodeRect(toNode)) : edge.to.point ?? { x: 0, y: 0 };
  let a = fromNode ? resolveAnchor(fromNode, edge.from.anchor, toCenter) : fromCenter;
  let b = toNode ? resolveAnchor(toNode, edge.to.anchor, fromCenter) : toCenter;
  if (fromNode && (!edge.from.anchor || edge.from.anchor === "auto")) a = resolveAnchor(fromNode, void 0, b);
  if (toNode && (!edge.to.anchor || edge.to.anchor === "auto")) b = resolveAnchor(toNode, void 0, a);
  return { a, b };
}
function routePoints(edge, a, b) {
  switch (edge.routing) {
    case "straight":
      return [a, b];
    case "curved": {
      const mid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const len = Math.hypot(dx, dy) || 1;
      const nx = -dy / len;
      const ny = dx / len;
      const par = edge.data?.parallel;
      let bow;
      if (par && par.count > 1) {
        bow = (par.index - (par.count - 1) / 2) * 38;
      } else {
        bow = Math.min(70, len * 0.16);
      }
      return [a, { x: mid.x + nx * bow, y: mid.y + ny * bow }, b];
    }
    case "orthogonal":
    case "elbow": {
      const dx = Math.abs(b.x - a.x);
      const dy = Math.abs(b.y - a.y);
      const mid = dx > dy ? [{ x: (a.x + b.x) / 2, y: a.y }, { x: (a.x + b.x) / 2, y: b.y }] : [{ x: a.x, y: (a.y + b.y) / 2 }, { x: b.x, y: (a.y + b.y) / 2 }];
      return [a, ...mid, b];
    }
    default:
      return [a, b];
  }
}
function centerlinePath(points, routing) {
  if (points.length < 2) return "";
  if (routing === "curved" && points.length === 3) {
    const [a, c, b] = points;
    return `M${a.x},${a.y} Q${c.x},${c.y} ${b.x},${b.y}`;
  }
  if (routing === "elbow" && points.length >= 3) {
    let d = `M${points[0].x},${points[0].y}`;
    const r2 = 10;
    for (let i = 1; i < points.length - 1; i++) {
      const p = points[i];
      const prev = points[i - 1];
      const next = points[i + 1];
      const v1 = norm(sub(prev, p));
      const v2 = norm(sub(next, p));
      const p1 = { x: p.x + v1.x * r2, y: p.y + v1.y * r2 };
      const p2 = { x: p.x + v2.x * r2, y: p.y + v2.y * r2 };
      d += ` L${p1.x},${p1.y} Q${p.x},${p.y} ${p2.x},${p2.y}`;
    }
    const last = points[points.length - 1];
    d += ` L${last.x},${last.y}`;
    return d;
  }
  return "M" + points.map((p) => `${p.x},${p.y}`).join(" L");
}
function sub(a, b) {
  return { x: a.x - b.x, y: a.y - b.y };
}
function norm(v) {
  const l = Math.hypot(v.x, v.y) || 1;
  return { x: v.x / l, y: v.y / l };
}
function dagreRoute(scene, edge) {
  const raw = edge.points;
  if (!raw || raw.length < 3) return null;
  if (edge.data?.parallel) return null;
  const fromNode = edge.from.node ? getNode(scene, edge.from.node) : void 0;
  const toNode = edge.to.node ? getNode(scene, edge.to.node) : void 0;
  const firstBend = raw[1];
  const lastBend = raw[raw.length - 2];
  const a = fromNode ? resolveAnchor(fromNode, edge.from.anchor, firstBend) : raw[0];
  const b = toNode ? resolveAnchor(toNode, edge.to.anchor, lastBend) : raw[raw.length - 1];
  return [a, ...raw.slice(1, -1), b];
}
function smoothPath(points) {
  if (points.length < 3) return "M" + points.map((p) => `${p.x},${p.y}`).join(" L");
  let d = `M${points[0].x},${points[0].y}`;
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[i - 1] ?? points[i];
    const p1 = points[i];
    const p2 = points[i + 1];
    const p3 = points[i + 2] ?? p2;
    const c1x = p1.x + (p2.x - p0.x) / 6;
    const c1y = p1.y + (p2.y - p0.y) / 6;
    const c2x = p2.x - (p3.x - p1.x) / 6;
    const c2y = p2.y - (p3.y - p1.y) / 6;
    d += ` C${c1x},${c1y} ${c2x},${c2y} ${p2.x},${p2.y}`;
  }
  return d;
}
function drawBase(rc, points, edge, smooth, tune) {
  const opts = edgeRoughOptions(edge.style, tune);
  if (smooth && points.length >= 3) {
    return rc.curve(points.map((p) => [p.x, p.y]), opts);
  }
  if (points.length === 2) {
    return rc.line(points[0].x, points[0].y, points[1].x, points[1].y, opts);
  }
  return rc.linearPath(points.map((p) => [p.x, p.y]), opts);
}
function drawArrowhead(rc, kind, tip, angle, style, tune = {}) {
  if (!kind || kind === "none") return null;
  const size = 11 + style.strokeWidth * 2.4;
  const k = tune.roughnessScale ?? 1;
  const opts = {
    stroke: style.stroke,
    strokeWidth: style.strokeWidth,
    // The clamp keeps a head legible on a very sketchy edge; the zoom
    // compensation then applies to the CLAMPED value, so screen-space jitter
    // stays constant through a punch-in.
    roughness: Math.min(style.roughness, 1) * k,
    seed: style.seed,
    bowing: style.bowing ?? 1,
    preserveVertices: style.preserveVertices ?? false,
    disableMultiStroke: style.disableMultiStroke ?? false,
    maxRandomnessOffset: (style.maxRandomnessOffset ?? DEFAULT_MAX_RANDOMNESS_OFFSET) * k
  };
  const filledOpts = { ...opts, fill: style.stroke, fillStyle: "solid" };
  const back = (dist2, spread) => ({
    x: tip.x - Math.cos(angle - spread) * dist2,
    y: tip.y - Math.sin(angle - spread) * dist2
  });
  const back2 = (dist2, spread) => ({
    x: tip.x - Math.cos(angle + spread) * dist2,
    y: tip.y - Math.sin(angle + spread) * dist2
  });
  switch (kind) {
    case "arrow": {
      const p1 = back(size, 0.42);
      const p2 = back2(size, 0.42);
      return rc.linearPath(
        [
          [p1.x, p1.y],
          [tip.x, tip.y],
          [p2.x, p2.y]
        ],
        opts
      );
    }
    case "triangle": {
      const p1 = back(size, 0.42);
      const p2 = back2(size, 0.42);
      return rc.polygon(
        [
          [tip.x, tip.y],
          [p1.x, p1.y],
          [p2.x, p2.y]
        ],
        filledOpts
      );
    }
    case "triangle-outline": {
      const p1 = back(size, 0.42);
      const p2 = back2(size, 0.42);
      return rc.polygon(
        [
          [tip.x, tip.y],
          [p1.x, p1.y],
          [p2.x, p2.y]
        ],
        opts
      );
    }
    case "bar": {
      const p1 = {
        x: tip.x - Math.cos(angle + Math.PI / 2) * size * 0.6,
        y: tip.y - Math.sin(angle + Math.PI / 2) * size * 0.6
      };
      const p2 = {
        x: tip.x + Math.cos(angle + Math.PI / 2) * size * 0.6,
        y: tip.y + Math.sin(angle + Math.PI / 2) * size * 0.6
      };
      return rc.line(p1.x, p1.y, p2.x, p2.y, opts);
    }
    case "dot":
    case "circle": {
      const r2 = size * 0.42;
      const c = { x: tip.x - Math.cos(angle) * r2, y: tip.y - Math.sin(angle) * r2 };
      return rc.circle(c.x, c.y, r2 * 2, kind === "dot" ? filledOpts : opts);
    }
    case "circle-outline": {
      const r2 = size * 0.42;
      const c = { x: tip.x - Math.cos(angle) * r2, y: tip.y - Math.sin(angle) * r2 };
      return rc.circle(c.x, c.y, r2 * 2, opts);
    }
    case "diamond":
    case "diamond-outline": {
      const r2 = size * 0.55;
      const c = { x: tip.x - Math.cos(angle) * r2, y: tip.y - Math.sin(angle) * r2 };
      const perp = angle + Math.PI / 2;
      const pts = [
        [tip.x, tip.y],
        [c.x + Math.cos(perp) * r2 * 0.6, c.y + Math.sin(perp) * r2 * 0.6],
        [c.x - Math.cos(angle) * r2, c.y - Math.sin(angle) * r2],
        [c.x - Math.cos(perp) * r2 * 0.6, c.y - Math.sin(perp) * r2 * 0.6]
      ];
      return rc.polygon(pts, kind === "diamond" ? filledOpts : opts);
    }
    case "crow": {
      const spread = 0.5;
      const p1 = back(size, spread);
      const p2 = back2(size, spread);
      const mid = back(size, 0);
      const g = document.createElementNS(SVG_NS$2, "g");
      g.appendChild(rc.line(tip.x, tip.y, p1.x, p1.y, opts));
      g.appendChild(rc.line(tip.x, tip.y, p2.x, p2.y, opts));
      g.appendChild(rc.line(tip.x, tip.y, mid.x, mid.y, opts));
      return g;
    }
    default:
      return null;
  }
}
function angleOf(from, to) {
  return Math.atan2(to.y - from.y, to.x - from.x);
}
function animationOverlay(edge, centerline, len) {
  const kind = edge.style.animation;
  if (!kind || kind === "none") return null;
  const p = document.createElementNS(SVG_NS$2, "path");
  p.setAttribute("d", centerline);
  p.setAttribute("fill", "none");
  p.setAttribute("class", `edd-anim edd-anim-${kind}`);
  p.setAttribute("pointer-events", "none");
  const speed = edge.style.animationSpeed || 1;
  const sw = edge.style.strokeWidth;
  const stroke = edge.style.stroke;
  const style = p.style;
  style.setProperty("--edd-len", String(Math.max(1, Math.round(len))));
  style.setProperty("--edd-speed", String(speed));
  const plugin = getArrowAnimation(kind);
  if (plugin) {
    p.setAttribute("stroke", stroke);
    p.setAttribute("stroke-width", String(sw * 1.2));
    p.setAttribute("stroke-linecap", "round");
    plugin.apply(p, edge, { length: len, speed });
    return p;
  }
  switch (kind) {
    case "flow":
    case "dash-march":
    case "electric": {
      p.setAttribute("stroke", stroke);
      p.setAttribute("stroke-width", String(sw * (kind === "electric" ? 1.6 : 1.2)));
      const dash = kind === "electric" ? "2 7" : "10 8";
      p.setAttribute("stroke-dasharray", dash);
      p.setAttribute("stroke-linecap", "round");
      style.animationDuration = `${(kind === "electric" ? 0.5 : 0.9) / speed}s`;
      break;
    }
    case "draw-on": {
      p.setAttribute("stroke", stroke);
      p.setAttribute("stroke-width", String(sw * 1.3));
      p.setAttribute("stroke-linecap", "round");
      p.setAttribute("stroke-dasharray", String(len));
      style.setProperty("--edd-dashoffset", String(len));
      style.animationDuration = `${1.4 / speed}s`;
      break;
    }
    case "comet": {
      p.setAttribute("stroke", stroke);
      p.setAttribute("stroke-width", String(sw * 2.2));
      p.setAttribute("stroke-linecap", "round");
      const seg = Math.max(24, len * 0.14);
      p.setAttribute("stroke-dasharray", `${seg} ${len}`);
      p.style.filter = "drop-shadow(0 0 4px currentColor)";
      p.style.color = stroke;
      style.animationDuration = `${1.6 / speed}s`;
      break;
    }
    case "pulse": {
      p.setAttribute("stroke", stroke);
      p.setAttribute("stroke-width", String(sw * 1.2));
      style.animationDuration = `${1.3 / speed}s`;
      break;
    }
    case "gradient-flow": {
      p.setAttribute("stroke", "url(#eddFlowGradient)");
      p.setAttribute("stroke-width", String(sw * 2.4));
      p.setAttribute("stroke-linecap", "round");
      style.animationDuration = `${1.2 / speed}s`;
      break;
    }
    default:
      return null;
  }
  return p;
}
function pathLength(points) {
  let len = 0;
  for (let i = 1; i < points.length; i++) len += Math.hypot(points[i].x - points[i - 1].x, points[i].y - points[i - 1].y);
  return len;
}
function renderEdge(rc, scene, edge, opts = {}) {
  const g = document.createElementNS(SVG_NS$2, "g");
  g.setAttribute("data-edge", edge.id);
  g.setAttribute("class", "edd-edge");
  g.style.opacity = String(edge.style.opacity / 100);
  const routed = dagreRoute(scene, edge);
  let points;
  let smooth;
  if (routed) {
    points = routed;
    smooth = true;
  } else {
    const { a, b } = resolveEndpoints(scene, edge);
    points = routePoints(edge, a, b);
    smooth = edge.routing === "curved" && points.length === 3;
  }
  const centerline = smooth ? smoothPath(points) : centerlinePath(points, edge.routing);
  const len = pathLength(points);
  g.appendChild(drawBase(rc, points, edge, smooth, opts));
  const endTangent = angleOf(points[points.length - 2], points[points.length - 1]);
  const startTangent = angleOf(points[1], points[0]);
  const endHead = drawArrowhead(rc, edge.style.endArrowhead, points[points.length - 1], endTangent, edge.style, opts);
  if (endHead) g.appendChild(endHead);
  const startHead = drawArrowhead(rc, edge.style.startArrowhead, points[0], startTangent, edge.style, opts);
  if (startHead) g.appendChild(startHead);
  const overlay = opts.static ? null : animationOverlay(edge, centerline, len);
  if (overlay) g.appendChild(overlay);
  if (opts.nonScalingStroke) applyNonScalingStroke(g);
  return { group: g, points, centerline, length: len };
}
const SVG_NS$1 = "http://www.w3.org/2000/svg";
function renderCharacterNode(rc, scene, node, doc, paintText, tune = {}) {
  const preset = tunePreset(effectivePreset(scene.meta.style, scene.theme.mode), scene.meta.rough);
  const emitted = emitCharacterNode(node, preset, scene.theme.mode);
  const body = doc.createElementNS(SVG_NS$1, "g");
  body.setAttribute("class", "edd-character");
  const parts = [...emitted.nodes].sort((a, b) => a.z - b.z);
  for (const part of parts) {
    try {
      if (part.shape === "text") {
        if (!part.label) continue;
        const align = part.style.textAlign;
        const cx = align === "left" ? part.x : align === "right" ? part.x + part.w : part.x + part.w / 2;
        const t = paintText(part.label, cx, part.y + part.h / 2, part.style.fontSize, part.style.textColor, part.style.fontFamily, align, part.style.fontWeight);
        if (part.style.opacity < 100) t.style.opacity = String(part.style.opacity / 100);
        body.appendChild(t);
        continue;
      }
      const g = renderShapeBody(rc, part.shape, { x: part.x, y: part.y, w: part.w, h: part.h }, part.style, part.data, tune);
      body.appendChild(g);
    } catch (err) {
      console.warn("character part render failed", node.id, part.id, err);
    }
  }
  const labelCy = node.y + node.h - emitted.labelH / 2;
  return { body, labelCy, labelColor: characterInk(node.style.textColor, preset) };
}
function renderIconNode(rc, scene, node, doc, tune = {}) {
  const preset = tunePreset(effectivePreset(scene.meta.style, scene.theme.mode), scene.meta.rough);
  const body = doc.createElementNS(SVG_NS$1, "g");
  body.setAttribute("class", "edd-icon");
  const glyph = iconNodeGlyph(node);
  if (glyph.d) {
    const visual = Math.min(3, Math.max(1.8, glyph.size / 18));
    const style = {
      ...node.style,
      // line art on the canvas — same visibility guard as a character's ink
      stroke: characterInk(node.style.stroke, preset),
      fill: null,
      fillStyle: "none",
      strokeWidth: (node.style.strokeWidth > 2 ? Math.min(3.2, node.style.strokeWidth) : visual) * (glyph.viewBox / glyph.size),
      roughness: Math.min(0.8, node.style.roughness)
    };
    body.appendChild(renderShapeBody(rc, "path", { x: glyph.x, y: glyph.y, w: glyph.size, h: glyph.size }, style, { d: glyph.d, vw: glyph.viewBox, vh: glyph.viewBox }, tune));
  }
  return { body, labelCy: node.y + node.h - glyph.labelH / 2, labelColor: characterInk(node.style.textColor, preset) };
}
const EXCALIFONT_FAMILY = "Excalifont";
const FONT_FAMILY = {
  hand: '"Excalifont", "Virgil", "Segoe Print", "Comic Sans MS", cursive',
  normal: '"Nunito", "Assistant", system-ui, -apple-system, sans-serif',
  code: '"Cascadia Code", "Cascadia", ui-monospace, "SF Mono", Menlo, monospace',
  serif: 'Georgia, "Iowan Old Style", "Times New Roman", serif'
};
const CSS = `
/* Hand-drawn font is embedded (base64) so it works with zero external files —
   in the app, in exported SVGs, and in any host app using the npm package. */
@font-face {
  font-family: "Excalifont";
  src: url("${HAND_FONT_WOFF2_DATA_URI}") format("woff2");
  font-weight: normal;
  font-style: normal;
  font-display: swap;
}
@font-face {
  font-family: "Virgil";
  src: url("${HAND_FONT_WOFF2_DATA_URI}") format("woff2");
  font-weight: normal;
  font-style: normal;
  font-display: swap;
}
/* "normal" and "code" diagram fonts fall back to the host's system sans/mono
   (no external files) — the engine embeds only the hand-drawn font it needs. */

/* ---- animated arrows -------------------------------------------------- */
.edd-anim { pointer-events: none; }

@keyframes edd-march {
  to { stroke-dashoffset: -18; }
}
.edd-anim-flow,
.edd-anim-dash-march {
  animation-name: edd-march;
  animation-timing-function: linear;
  animation-iteration-count: infinite;
}
@keyframes edd-electric {
  to { stroke-dashoffset: -9; }
}
.edd-anim-electric {
  animation-name: edd-electric;
  animation-timing-function: steps(3);
  animation-iteration-count: infinite;
}
@keyframes edd-draw-on {
  from { stroke-dashoffset: var(--edd-dashoffset, 1000); }
  to { stroke-dashoffset: 0; }
}
.edd-anim-draw-on {
  animation-name: edd-draw-on;
  animation-timing-function: ease-in-out;
  animation-iteration-count: infinite;
  animation-direction: alternate;
}
@keyframes edd-comet {
  from { stroke-dashoffset: calc(var(--edd-len) * 1px); }
  to { stroke-dashoffset: calc(var(--edd-len) * -0.14px); }
}
.edd-anim-comet {
  animation-name: edd-comet;
  animation-timing-function: linear;
  animation-iteration-count: infinite;
}
@keyframes edd-pulse {
  0%, 100% { opacity: 0.15; stroke-width: inherit; }
  50% { opacity: 0.85; }
}
.edd-anim-pulse {
  animation-name: edd-pulse;
  animation-timing-function: ease-in-out;
  animation-iteration-count: infinite;
}
@keyframes edd-gradient-flow {
  to { stroke-dashoffset: -30; }
}
.edd-anim-gradient-flow {
  stroke-dasharray: 16 10;
  animation-name: edd-gradient-flow;
  animation-timing-function: linear;
  animation-iteration-count: infinite;
}

/* ---- timeline visibility --------------------------------------------- */
.edd-node, .edd-edge { transition: opacity 0.45s ease; }
.edd-hidden { opacity: 0 !important; pointer-events: none; }

/* ---- annotation reveals ---------------------------------------------- */
@keyframes edd-fade-in {
  from { opacity: 0; }
  to { opacity: 1; }
}
@keyframes edd-marker-sweep {
  from { clip-path: inset(0 100% 0 0); }
  to { clip-path: inset(0 0 0 0); }
}
@keyframes edd-pop-in {
  0% { transform: scale(0.6); opacity: 0; }
  70% { transform: scale(1.06); opacity: 1; }
  100% { transform: scale(1); opacity: 1; }
}
.edd-reveal-fade { animation: edd-fade-in 0.4s ease both; }
.edd-reveal-sweep { animation: edd-marker-sweep 0.5s ease-out both; }
.edd-reveal-pop { animation: edd-pop-in 0.45s cubic-bezier(0.34,1.56,0.64,1) both; transform-box: fill-box; transform-origin: center; }

@media (prefers-reduced-motion: reduce) {
  .edd-anim, .edd-reveal-fade, .edd-reveal-sweep, .edd-reveal-pop { animation: none !important; }
}

/* ---- static (deterministic) mode --------------------------------------
   SvgRenderer { static: true }: no wall-clock CSS at all, so frame-screenshot
   consumers (Remotion, Puppeteer, export) never catch a transition or
   animation mid-flight. Motion is host-driven (setRevealProgress, camera). */
.edd-static, .edd-static * { transition: none !important; animation: none !important; }
`;
const styledDocs = /* @__PURE__ */ new WeakSet();
function ensureEngineStyles(doc = document) {
  if (styledDocs.has(doc) && doc.getElementById("edd-engine-styles")) return;
  if (!doc.getElementById("edd-engine-styles")) {
    const style = doc.createElement("style");
    style.id = "edd-engine-styles";
    style.textContent = CSS;
    doc.head.appendChild(style);
  }
  styledDocs.add(doc);
}
function whenFontsReady(doc = document) {
  ensureEngineStyles(doc);
  const fonts = doc.fonts;
  if (!fonts) return Promise.resolve();
  const sizes = [`16px "${EXCALIFONT_FAMILY}"`, `32px "${EXCALIFONT_FAMILY}"`];
  const loads = typeof fonts.load === "function" ? sizes.map((s) => fonts.load(s)) : [];
  return Promise.all([...loads, fonts.ready]).then(() => void 0).catch(() => void 0);
}
const SVG_NS = "http://www.w3.org/2000/svg";
const REVEAL_EFFECT_CLASS = {
  fade: "edd-reveal-fade",
  pop: "edd-reveal-pop",
  sweep: "edd-reveal-sweep",
  // `draw-on` is a real stroke-by-stroke drawing — only a frame-driven host can
  // play it (setRevealProgressAll). The interactive player has no wall-clock
  // stroke animation, so it degrades to the sweep wipe (its behaviour before
  // "draw-on" became a distinct revealFx value).
  "draw-on": "edd-reveal-sweep"
};
class SvgRenderer {
  container;
  /** True when constructed with `{ static: true }` — see SvgRendererOptions. */
  isStatic;
  /** See SvgRendererOptions.annotations. */
  paintsAnnotations;
  /** See SvgRendererOptions.nonScalingStroke. */
  nonScalingStroke;
  svg;
  defs;
  bg;
  world;
  layers;
  screenLayer;
  rc;
  camera = { cx: 0, cy: 0, zoom: 1 };
  viewport = { w: 800, h: 600 };
  scene = null;
  roughnessScale = 1;
  constructor(container, options = {}) {
    this.container = container;
    this.isStatic = options.static ?? false;
    this.paintsAnnotations = options.annotations ?? true;
    this.nonScalingStroke = options.nonScalingStroke ?? false;
    this.roughnessScale = clampScale(options.roughnessScale ?? 1);
  }
  /** The render-time rough knobs, as every draw call wants them. */
  roughTune() {
    return { roughnessScale: this.roughnessScale, nonScalingStroke: this.nonScalingStroke };
  }
  /** Current roughness scale — see `setRoughnessScale()`. */
  getRoughnessScale() {
    return this.roughnessScale;
  }
  /**
   * Scale every `roughness` and `maxRandomnessOffset` by `k` and repaint.
   *
   * rough.js perturbs geometry in WORLD units and the camera is a
   * `scale(zoom)` on the world group, so on-screen jitter is `zoom x world
   * jitter`: a punch-in magnifies the scratchiness along with the drawing. A
   * frame-driven host cancels that by passing `k = 1/zoom`.
   *
   * Regenerating strokes is a full re-render (single-digit ms for a normal
   * diagram, but not free), so QUANTISE the zoom — e.g.
   * `k = 1 / 2 ** Math.round(Math.log2(zoom))` — and this will regenerate a
   * handful of times per composition instead of once per frame. Calling it
   * with the value it already has is a no-op, so quantised callers are safe to
   * call it every frame.
   *
   * Seeds are untouched, so the strokes stay deterministic: the same scene at
   * the same scale always draws identically.
   */
  setRoughnessScale(k) {
    const next = clampScale(k);
    if (next === this.roughnessScale) return;
    this.roughnessScale = next;
    if (this.scene) this.render(this.scene);
  }
  /**
   * Apply this renderer's stroke policy to a subtree someone else painted into
   * one of its layers (the annotation layer does exactly that). No-op unless
   * `nonScalingStroke` is on.
   */
  applyStrokePolicy(root) {
    if (this.nonScalingStroke) applyNonScalingStroke(root);
  }
  mount() {
    registerBuiltinShapes();
    ensureEngineStyles(this.container.ownerDocument);
    const doc = this.container.ownerDocument;
    const svg = doc.createElementNS(SVG_NS, "svg");
    svg.setAttribute("class", this.isStatic ? "edd-canvas edd-static" : "edd-canvas");
    svg.style.position = "absolute";
    svg.style.inset = "0";
    svg.style.width = "100%";
    svg.style.height = "100%";
    svg.style.display = "block";
    svg.style.userSelect = "none";
    svg.style.touchAction = "none";
    this.svg = svg;
    this.defs = doc.createElementNS(SVG_NS, "defs");
    this.defs.innerHTML = this.defsMarkup();
    svg.appendChild(this.defs);
    this.bg = doc.createElementNS(SVG_NS, "rect");
    this.bg.setAttribute("class", "edd-bg");
    this.bg.setAttribute("x", "0");
    this.bg.setAttribute("y", "0");
    this.bg.setAttribute("width", "100%");
    this.bg.setAttribute("height", "100%");
    this.bg.setAttribute("fill", "#ffffff");
    svg.appendChild(this.bg);
    this.world = doc.createElementNS(SVG_NS, "g");
    this.world.setAttribute("class", "edd-world");
    svg.appendChild(this.world);
    this.layers = {};
    for (const name of ["grid", "groups", "edges", "nodes", "annotations", "live"]) {
      const g = doc.createElementNS(SVG_NS, "g");
      g.setAttribute("class", `edd-layer edd-layer-${name}`);
      this.world.appendChild(g);
      this.layers[name] = g;
    }
    this.screenLayer = doc.createElementNS(SVG_NS, "g");
    this.screenLayer.setAttribute("class", "edd-layer-screen");
    svg.appendChild(this.screenLayer);
    this.rc = rough$1.svg(svg);
    this.container.appendChild(svg);
    this.measure();
    this.applyCamera(this.camera);
  }
  destroy() {
    this.annotationLayerCache = null;
    this.svg?.remove();
  }
  defsMarkup() {
    return `
      <linearGradient id="eddFlowGradient" x1="0" y1="0" x2="1" y2="0" gradientUnits="objectBoundingBox">
        <stop offset="0" stop-color="#4dabf7"/>
        <stop offset="0.4" stop-color="#22b8cf"/>
        <stop offset="0.7" stop-color="#845ef7"/>
        <stop offset="1" stop-color="#4dabf7"/>
      </linearGradient>
      <filter id="eddSoftGlow" x="-30%" y="-30%" width="160%" height="160%">
        <feGaussianBlur stdDeviation="2.2" result="b"/>
        <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
      </filter>
    `;
  }
  /** Read the container size; call on mount + resize. */
  measure() {
    const c = this.container;
    let w = c.clientWidth;
    let h = c.clientHeight;
    if (!w || !h) {
      const rect = c.getBoundingClientRect();
      w = w || rect.width;
      h = h || rect.height;
    }
    this.viewport = { w: Math.max(1, w), h: Math.max(1, h) };
    return this.viewport;
  }
  /**
   * State the viewport explicitly instead of measuring the container.
   *
   * `measure()` reads `clientWidth`/`clientHeight`, which a frame-driven host
   * often cannot rely on: Remotion mounts a composition inside a 0x0
   * off-screen wrapper during the layout pass, so a `measure()` call from a
   * `useLayoutEffect` sees 0x0 and pins the camera viewport at 1x1 — every
   * later `applyCamera` then translates by half a pixel and the diagram lands
   * in the top-left corner. Such a host knows the real size already
   * (Remotion's `useVideoConfig()`), so it should say so.
   *
   * Non-finite or non-positive dimensions are clamped to 1, exactly as
   * `measure()` clamps them. Re-applies the current camera so the world
   * transform matches the new viewport immediately.
   */
  setViewport(size) {
    const w = Number.isFinite(size.w) ? size.w : 0;
    const h = Number.isFinite(size.h) ? size.h : 0;
    this.viewport = { w: Math.max(1, w), h: Math.max(1, h) };
    this.applyCamera(this.camera);
    return { ...this.viewport };
  }
  getViewportSize() {
    return { ...this.viewport };
  }
  getCamera() {
    return { ...this.camera };
  }
  applyCamera(cam) {
    this.camera = cam;
    const { w, h } = this.viewport;
    const t = `translate(${w / 2} ${h / 2}) scale(${cam.zoom}) translate(${-cam.cx} ${-cam.cy})`;
    this.world.setAttribute("transform", t);
  }
  worldToScreen(p) {
    const { w, h } = this.viewport;
    return {
      x: (p.x - this.camera.cx) * this.camera.zoom + w / 2,
      y: (p.y - this.camera.cy) * this.camera.zoom + h / 2
    };
  }
  screenToWorld(p) {
    const { w, h } = this.viewport;
    return {
      x: (p.x - w / 2) / this.camera.zoom + this.camera.cx,
      y: (p.y - h / 2) / this.camera.zoom + this.camera.cy
    };
  }
  getLayer(name) {
    return this.layers[name];
  }
  /** Show/hide nodes+edges for timeline reveal. `hidden` = ids to fade out. */
  applyVisibility(hidden) {
    const els = this.svg.querySelectorAll("[data-node],[data-edge]");
    els.forEach((el) => {
      const id = el.getAttribute("data-node") ?? el.getAttribute("data-edge");
      if (id && hidden.has(id)) el.classList.add("edd-hidden");
      else el.classList.remove("edd-hidden");
    });
  }
  /**
   * Play a per-beat reveal animation (`fade` | `pop` | `sweep`) on the named
   * element groups. Clears any prior reveal classes first and forces a reflow so
   * re-entering the same beat restarts the animation. `fx` = id -> effect.
   */
  playReveal(fx) {
    if (this.isStatic) return;
    const classes = ["edd-reveal-fade", "edd-reveal-pop", "edd-reveal-sweep"];
    const els = this.svg.querySelectorAll("[data-node],[data-edge]");
    els.forEach((el) => el.classList.remove(...classes));
    if (!fx || !Object.keys(fx).length) return;
    void this.svg.getBoundingClientRect();
    els.forEach((el) => {
      const id = el.getAttribute("data-node") ?? el.getAttribute("data-edge");
      const cls = id ? REVEAL_EFFECT_CLASS[fx[id]] : void 0;
      if (cls) el.classList.add(cls);
    });
  }
  /**
   * Drive a hand-drawn "draw-on" reveal of one element from host code: strokes
   * sweep on in draw order (stroke-dashoffset), then labels fade in. `id` is a
   * node id, edge id, or viz-item key ("block.item" — all member elements sweep
   * as one continuous drawing). `progress` is 0..1; ≥1 restores the untouched
   * rendering (original dash patterns included), ≤0 hides the element. Built
   * for frame-driven hosts (Remotion, capture pipelines) — pair with
   * `{ static: true }` so no wall-clock CSS competes with it.
   */
  setRevealProgress(id, progress) {
    const esc = cssEscape(id);
    const groups = this.svg.querySelectorAll(`[data-node="${esc}"],[data-edge="${esc}"],[data-viz-item="${esc}"]`);
    if (!groups.length) return;
    const p = Math.max(0, Math.min(1, progress));
    const strokes = [];
    const texts = [];
    groups.forEach((g) => {
      g.querySelectorAll("path,line,polyline,polygon,circle,ellipse,rect").forEach((el) => strokes.push(el));
      g.querySelectorAll("text").forEach((el) => texts.push(el));
    });
    const sweep = Math.min(1, p / 0.85);
    const lens = strokes.map(strokeLength);
    const total = lens.reduce((a, b) => a + b, 0) || 1;
    let done = 0;
    strokes.forEach((el, i) => {
      const len = lens[i];
      const local = Math.max(0, Math.min(1, (sweep * total - done) / len));
      done += len;
      if (progress >= 1) {
        restoreStroke(el);
        return;
      }
      const hasStroke = (el.getAttribute("stroke") ?? "") !== "none";
      if (!hasStroke) {
        el.style.opacity = String(local);
        return;
      }
      if (el.getAttribute("data-edd-dash") === null) {
        el.setAttribute("data-edd-dash", el.getAttribute("stroke-dasharray") ?? "");
      }
      el.setAttribute("stroke-dasharray", String(len));
      el.setAttribute("stroke-dashoffset", String(len * (1 - local)));
      el.style.opacity = local > 0 ? "" : "0";
    });
    const fade = Math.max(0, Math.min(1, (p - 0.7) / 0.3));
    texts.forEach((el) => {
      el.style.opacity = progress >= 1 ? "" : String(fade);
    });
  }
  /**
   * Batch form of {@link setRevealProgress} for frame-driven hosts, and the
   * ONLY safe one when frames are produced out of order (Remotion seeks, a
   * scrubber, a re-render worker).
   *
   * `setRevealProgress` MUTATES an element's dash pattern and only restores it
   * at `p >= 1`, so a frame that simply stops mentioning an id leaves that
   * element frozen mid-draw forever. This method takes the whole picture at
   * once: every drawable in the SVG that the map does NOT mention is restored
   * to `1` (fully drawn), so the DOM is always a total function of the map —
   * the same map always yields the same frame, whatever ran before it.
   *
   * Pass `0` to keep something un-drawn; omit an id to mean "finished".
   *
   *   renderer.setRevealProgressAll({ api: 0.4, db: 0 });   // everything else = done
   *
   * Ids are node ids, edge ids, and viz-item keys (`"block.item"`). Partial
   * progress wins over the implied restore when both address the same element
   * (a viz item and the nodes inside it), so nesting behaves as authored.
   */
  setRevealProgressAll(map) {
    const ids = /* @__PURE__ */ new Set();
    this.svg.querySelectorAll("[data-node],[data-edge],[data-viz-item]").forEach((el) => {
      for (const attr2 of ["data-node", "data-edge", "data-viz-item"]) {
        const id = el.getAttribute(attr2);
        if (id) ids.add(id);
      }
    });
    for (const id of Object.keys(map)) ids.add(id);
    const partial = [];
    for (const id of ids) {
      const p = map[id];
      if (p == null || p >= 1) this.setRevealProgress(id, 1);
      else partial.push(id);
    }
    for (const id of partial) this.setRevealProgress(id, map[id]);
    this.svg.querySelectorAll('[style=""]').forEach((el) => el.removeAttribute("style"));
  }
  render(scene) {
    this.scene = scene;
    ensurePluginStyles(this.container.ownerDocument);
    const bgColor = scene.meta.background || scene.theme.background;
    this.bg.setAttribute("fill", "transparent");
    this.container.style.backgroundColor = bgColor;
    for (const name of ["groups", "edges", "nodes"]) this.layers[name].replaceChildren();
    for (const group of scene.groups) {
      if (!group.frame) continue;
      const els = this.renderGroupFrame(scene, group);
      if (els) this.layers.groups.appendChild(els);
    }
    const edges = [...scene.edges].sort((a, b) => a.z - b.z);
    for (const edge of edges) {
      try {
        const r2 = renderEdge(this.rc, scene, edge, { static: this.isStatic, ...this.roughTune() });
        if (edge.label) r2.group.appendChild(this.edgeLabel(scene, edge, r2.points));
        this.applyVizTags(r2.group, edge.data);
        this.layers.edges.appendChild(r2.group);
      } catch (err) {
        console.warn("edge render failed", edge.id, err);
      }
    }
    const nodes = [...scene.nodes].sort((a, b) => a.z - b.z);
    for (const node of nodes) {
      try {
        this.layers.nodes.appendChild(this.renderNode(scene, node));
      } catch (err) {
        console.warn("node render failed", node.id, err);
      }
    }
    if (this.paintsAnnotations) this.annotationLayer().render(scene, scene.annotations, false);
  }
  /** The scene the last `render()` painted (null before the first one). */
  getScene() {
    return this.scene;
  }
  annotationLayerCache = null;
  /** Lazily-built layer for the always-on annotations painted by render(). */
  annotationLayer() {
    return this.annotationLayerCache ??= new AnnotationLayer(this);
  }
  /** Cache of gradient-fill defs created this mount: spec -> def id. */
  gradientIds = /* @__PURE__ */ new Map();
  /**
   * Turn a `linear-gradient(#from,#to)` fill (emitted by gradient style
   * presets) into an SVG <linearGradient> def and return a url() reference.
   * Plain fills pass through untouched.
   */
  resolveGradientFill(fill) {
    if (!fill || !fill.startsWith("linear-gradient(")) return fill;
    const cached = this.gradientIds.get(fill);
    if (cached) return `url(#${cached})`;
    const inner = fill.slice("linear-gradient(".length, -1);
    const parts = inner.split(",").map((s) => s.trim());
    const [from, to] = parts.length >= 2 ? [parts[parts.length - 2], parts[parts.length - 1]] : [parts[0], parts[0]];
    const id = `eddGrad${this.gradientIds.size}`;
    const doc = this.container.ownerDocument;
    const grad = doc.createElementNS(SVG_NS, "linearGradient");
    grad.setAttribute("id", id);
    grad.setAttribute("x1", "0");
    grad.setAttribute("y1", "0");
    grad.setAttribute("x2", "0");
    grad.setAttribute("y2", "1");
    for (const [offset, color] of [
      ["0", from],
      ["1", to]
    ]) {
      const stop = doc.createElementNS(SVG_NS, "stop");
      stop.setAttribute("offset", offset);
      stop.setAttribute("stop-color", color);
      grad.appendChild(stop);
    }
    this.defs.appendChild(grad);
    this.gradientIds.set(fill, id);
    return `url(#${id})`;
  }
  /** Surface viz-item membership as DOM attributes so hosts can select one
   *  data item's elements as a unit: [data-viz-item="loads.intrinsic"]. */
  applyVizTags(g, data) {
    const item = data?.vizItem;
    const role = data?.vizRole;
    if (item) g.setAttribute("data-viz-item", item);
    if (role) g.setAttribute("data-viz-role", role);
  }
  renderNode(scene, node) {
    const doc = this.container.ownerDocument;
    const g = doc.createElementNS(SVG_NS, "g");
    g.setAttribute("data-node", node.id);
    g.setAttribute("class", "edd-node");
    this.applyVizTags(g, node.data);
    g.style.opacity = String(node.style.opacity / 100);
    if (node.shape === "character") {
      const paintText = (...args) => this.textBlock(...args);
      const { body: body2, labelCy, labelColor } = renderCharacterNode(this.rc, scene, node, doc, paintText, this.roughTune());
      g.appendChild(body2);
      if (node.label) {
        g.appendChild(this.textBlock(node.label, node.x + node.w / 2, labelCy, node.style.fontSize, labelColor, node.style.fontFamily, "center", node.style.fontWeight));
      }
      return g;
    }
    if (node.shape === "icon") {
      const { body: body2, labelCy, labelColor } = renderIconNode(this.rc, scene, node, doc, this.roughTune());
      g.appendChild(body2);
      if (node.label) {
        g.appendChild(this.textBlock(node.label, node.x + node.w / 2, labelCy, node.style.fontSize, labelColor, node.style.fontFamily, "center", node.style.fontWeight));
      }
      return g;
    }
    const fill = this.resolveGradientFill(node.style.fill);
    const style = fill === node.style.fill ? node.style : { ...node.style, fill };
    const body = renderShapeBody(this.rc, node.shape, { x: node.x, y: node.y, w: node.w, h: node.h }, style, node.data, this.roughTune());
    g.appendChild(body);
    if (node.label) {
      const align = node.style.textAlign;
      const cx = align === "left" ? node.x : align === "right" ? node.x + node.w : node.x + node.w / 2;
      const below = labelBelow(node.shape);
      const lines = node.label.split("\n").length;
      const lineHeight = node.style.fontSize * 1.25;
      const blockHalf = (lines - 1) * lineHeight / 2;
      const vAlign = node.style.verticalAlign;
      let cy;
      if (below) cy = node.y + node.h + node.style.fontSize;
      else if (vAlign === "top") cy = node.y + node.style.fontSize * 0.75 + blockHalf;
      else if (vAlign === "bottom") cy = node.y + node.h - node.style.fontSize * 0.75 - blockHalf;
      else cy = node.y + node.h / 2;
      g.appendChild(this.textBlock(node.label, cx, cy, node.style.fontSize, node.style.textColor, node.style.fontFamily, align, node.style.fontWeight));
    }
    return g;
  }
  textBlock(text, cx, cy, fontSize, color, family, align = "center", weight) {
    const doc = this.container.ownerDocument;
    const t = doc.createElementNS(SVG_NS, "text");
    const lines = text.split("\n");
    const lineHeight = fontSize * 1.25;
    const anchor = align === "left" ? "start" : align === "right" ? "end" : "middle";
    t.setAttribute("text-anchor", anchor);
    t.setAttribute("font-family", FONT_FAMILY[family] ?? family);
    t.setAttribute("font-size", String(fontSize));
    if (weight) t.setAttribute("font-weight", String(weight));
    t.setAttribute("fill", color);
    t.setAttribute("dominant-baseline", "middle");
    t.style.whiteSpace = "pre";
    const startY = cy - (lines.length - 1) * lineHeight / 2;
    lines.forEach((line, i) => {
      const tspan = doc.createElementNS(SVG_NS, "tspan");
      tspan.setAttribute("x", String(cx));
      tspan.setAttribute("y", String(startY + i * lineHeight));
      tspan.textContent = line;
      t.appendChild(tspan);
    });
    return t;
  }
  edgeLabel(scene, edge, points) {
    const doc = this.container.ownerDocument;
    const g = doc.createElementNS(SVG_NS, "g");
    const mid = points[Math.floor(points.length / 2)] ?? points[0];
    const fontSize = edge.style.fontSize;
    const padX = 6;
    const estW = edge.label.length * fontSize * 0.55 + padX * 2;
    if (edge.style.labelBg) {
      const rect = doc.createElementNS(SVG_NS, "rect");
      rect.setAttribute("x", String(mid.x - estW / 2));
      rect.setAttribute("y", String(mid.y - fontSize * 0.85));
      rect.setAttribute("width", String(estW));
      rect.setAttribute("height", String(fontSize * 1.7));
      rect.setAttribute("rx", "4");
      rect.setAttribute("fill", edge.style.labelBg);
      rect.setAttribute("opacity", "0.92");
      g.appendChild(rect);
    }
    g.appendChild(this.textBlock(edge.label, mid.x, mid.y, fontSize, edge.style.textColor, edge.style.fontFamily, "center"));
    return g;
  }
  renderGroupFrame(scene, group) {
    const doc = this.container.ownerDocument;
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const id of group.members) {
      const n = scene.nodes.find((x) => x.id === id);
      if (!n) continue;
      minX = Math.min(minX, n.x);
      minY = Math.min(minY, n.y);
      maxX = Math.max(maxX, n.x + n.w);
      maxY = Math.max(maxY, n.y + n.h);
    }
    if (!Number.isFinite(minX)) return null;
    const pad = 26;
    const g = doc.createElementNS(SVG_NS, "g");
    g.setAttribute("data-group", group.id);
    const stroke = group.style.stroke ?? "#adb5bd";
    const rectEl = this.rc.path(
      `M${minX - pad},${minY - pad} h${maxX - minX + pad * 2} v${maxY - minY + pad * 2} h${-(maxX - minX + pad * 2)} Z`,
      { ...sceneRoughOptions(scene, 0.8, this.roughnessScale), stroke, strokeWidth: 1.2, seed: 42, strokeLineDash: [6, 6], fill: group.style.fill ?? void 0, fillStyle: "solid" }
    );
    g.appendChild(rectEl);
    if (this.nonScalingStroke) applyNonScalingStroke(rectEl);
    if (group.label) {
      g.appendChild(this.textBlock(group.label, minX - pad + 4, minY - pad - 2, 15, stroke, "hand", "left"));
    }
    return g;
  }
}
function clampScale(k) {
  return Number.isFinite(k) && k > 0 ? k : 1;
}
function cssEscape(s) {
  const css = globalThis.CSS;
  if (css?.escape) return css.escape(s);
  return s.replace(/["\\]/g, "\\$&");
}
function strokeLength(el) {
  const geo = el;
  if (typeof geo.getTotalLength === "function") {
    try {
      const len = geo.getTotalLength();
      if (Number.isFinite(len) && len > 0) return len;
    } catch {
    }
  }
  return 120;
}
function restoreStroke(el) {
  const orig = el.getAttribute("data-edd-dash");
  if (orig !== null) {
    if (orig === "") el.removeAttribute("stroke-dasharray");
    else el.setAttribute("stroke-dasharray", orig);
    el.removeAttribute("data-edd-dash");
  }
  el.removeAttribute("stroke-dashoffset");
  el.style.opacity = "";
}
function computeHiddenAt(steps, index) {
  const hidden = /* @__PURE__ */ new Set();
  for (let s = 0; s <= Math.min(index, steps.length - 1); s++) {
    const step = steps[s];
    for (const id of step.reveal ?? []) hidden.delete(id);
    for (const id of step.hide ?? []) hidden.add(id);
  }
  return hidden;
}
function stepStateAt(scene, index) {
  const steps = scene.steps ?? [];
  const i = Math.min(index, steps.length - 1);
  const step = i >= 0 ? steps[i] : null;
  let effectiveCamera;
  for (let s = i; s >= 0; s--) {
    if (steps[s].camera) {
      effectiveCamera = steps[s].camera;
      break;
    }
  }
  return {
    index: i,
    step,
    stepName: step?.name ?? "Overview",
    caption: step?.caption ?? "",
    hidden: [...computeHiddenAt(steps, i)],
    revealFx: step?.revealFx ?? {},
    annotations: [...scene.annotations, ...step?.annotations ?? []],
    camera: step?.camera,
    effectiveCamera,
    autoAdvanceMs: step?.autoAdvanceMs
  };
}
function resolveCameraDirective(scene, directive, viewport, opts = {}) {
  const fitAll = () => cameraForBBox(sceneBBox(scene), viewport, { ...opts, padding: directive?.padding ?? opts.padding ?? 80 });
  if (!directive) return fitAll();
  switch (directive.op) {
    case "focus":
    case "focus-group": {
      const box = elementsBBox(scene, directive.targets ?? []);
      if (!Number.isFinite(box.minX)) return fitAll();
      const cam = cameraForBBox(box, viewport, { ...opts, padding: directive.padding ?? opts.padding ?? 90, maxZoom: opts.maxZoom ?? 4 });
      if (directive.zoom != null) cam.zoom = directive.zoom;
      return cam;
    }
    case "zoom": {
      const cur = opts.current ?? fitAll();
      return { ...cur, zoom: directive.zoom ?? cur.zoom };
    }
    case "pan": {
      const cur = opts.current ?? fitAll();
      return { cx: directive.center?.x ?? cur.cx, cy: directive.center?.y ?? cur.cy, zoom: cur.zoom };
    }
    default:
      return fitAll();
  }
}
class TimelinePlayer {
  renderer;
  controller;
  annotations;
  scene = null;
  steps = [];
  idx = -1;
  playing = false;
  timer;
  onChange;
  constructor(renderer, controller, annotations) {
    this.renderer = renderer;
    this.controller = controller;
    this.annotations = annotations;
  }
  get hasTimeline() {
    return this.steps.length > 0;
  }
  load(scene) {
    this.pause();
    this.scene = scene;
    this.steps = scene.steps ?? [];
    this.idx = -1;
    this.renderer.applyVisibility(/* @__PURE__ */ new Set());
    this.annotations.render(scene, scene.annotations, false);
    this.emit();
  }
  emit() {
    const step = this.idx >= 0 ? this.steps[this.idx] : void 0;
    this.onChange?.({
      index: this.idx,
      total: this.steps.length,
      caption: step?.caption ?? "",
      stepName: step?.name ?? "Overview",
      playing: this.playing
    });
  }
  async goto(i, animate = true) {
    if (!this.scene || i < 0 || i >= this.steps.length) return;
    this.idx = i;
    const step = this.steps[i];
    const scene = this.scene;
    this.renderer.applyVisibility(computeHiddenAt(this.steps, i));
    if (animate) this.renderer.playReveal(step.revealFx);
    this.annotations.render(scene, [...scene.annotations, ...step.annotations], animate);
    this.emit();
    if (step.camera) {
      await this.runCamera(step, animate);
    }
  }
  async runCamera(step, animate) {
    const scene = this.scene;
    const cam = step.camera;
    const opts = { durationMs: animate ? cam.durationMs : 0, easing: cam.easing, padding: cam.padding };
    switch (cam.op) {
      case "fit-all":
        await this.controller.fitAll(scene, opts);
        break;
      case "focus":
        await this.controller.focus(scene, cam.targets ?? [], { ...opts, zoom: cam.zoom });
        break;
      case "zoom": {
        const cur = this.controller.current;
        await this.controller.animateTo({ ...cur, zoom: cam.zoom ?? cur.zoom }, opts);
        break;
      }
      case "pan": {
        const cur = this.controller.current;
        await this.controller.animateTo({ cx: cam.center?.x ?? cur.cx, cy: cam.center?.y ?? cur.cy, zoom: cur.zoom }, opts);
        break;
      }
      default:
        await this.controller.fitAll(scene, opts);
    }
  }
  next() {
    if (this.idx < this.steps.length - 1) void this.goto(this.idx + 1);
  }
  prev() {
    if (this.idx > 0) void this.goto(this.idx - 1);
    else if (this.idx === 0) {
      this.idx = -1;
      this.load(this.scene);
      void this.controller.fitAll(this.scene);
    }
  }
  restart() {
    this.pause();
    void this.goto(0);
  }
  play() {
    if (!this.hasTimeline) return;
    this.playing = true;
    if (this.idx < 0) void this.goto(0).then(() => this.scheduleNext());
    else this.scheduleNext();
    this.emit();
  }
  scheduleNext() {
    window.clearTimeout(this.timer);
    if (!this.playing) return;
    if (this.idx >= this.steps.length - 1) {
      this.playing = false;
      this.emit();
      return;
    }
    const dwell = this.steps[this.idx]?.autoAdvanceMs ?? 3200;
    this.timer = window.setTimeout(async () => {
      if (!this.playing) return;
      await this.goto(this.idx + 1);
      this.scheduleNext();
    }, dwell);
  }
  pause() {
    this.playing = false;
    window.clearTimeout(this.timer);
    this.emit();
  }
  dispose() {
    this.pause();
  }
}
const MERMAID_INSTALL_HINT = 'the optional peer dependency @excalidraw/mermaid-to-excalidraw is not installed — run `npm i @excalidraw/mermaid-to-excalidraw` to enable `mermaid """ … """` blocks (the rest of the diagram renders without it)';
let _parse = null;
async function loadParser() {
  if (!_parse) {
    let mod;
    try {
      mod = await import("@excalidraw/mermaid-to-excalidraw");
    } catch {
      throw new Error(MERMAID_INSTALL_HINT);
    }
    if (typeof mod?.parseMermaidToExcalidraw !== "function") throw new Error(MERMAID_INSTALL_HINT);
    _parse = mod.parseMermaidToExcalidraw;
  }
  return _parse;
}
async function isMermaidAvailable() {
  try {
    await loadParser();
    return true;
  } catch {
    return false;
  }
}
function shapeFor(el) {
  switch (el.type) {
    case "ellipse":
      return "ellipse";
    case "diamond":
      return "diamond";
    case "rectangle":
      return el.roundness ? "round-rectangle" : "rectangle";
    default:
      return "rectangle";
  }
}
async function convertMermaid(definition, mode = "light") {
  const parse2 = await loadParser();
  const { elements } = await parse2(definition, { themeVariables: { fontSize: "20px" } });
  const nodes = [];
  const edges = [];
  const nodeIds = /* @__PURE__ */ new Set();
  for (const el of elements) {
    if (el.type === "arrow" || el.type === "line") continue;
    if (el.type === "text" && !el.id) continue;
    const id = el.id ?? `m_${nodes.length}`;
    if (nodeIds.has(id)) continue;
    const label = el.label?.text ?? el.text ?? "";
    const node = makeNode({
      id,
      shape: el.type === "text" ? "text" : shapeFor(el),
      label,
      x: el.x ?? 0,
      y: el.y ?? 0,
      w: el.width && el.width > 0 ? el.width : void 0,
      h: el.height && el.height > 0 ? el.height : void 0,
      pinned: true,
      mode,
      style: {
        ...el.strokeColor ? { stroke: el.strokeColor } : {},
        ...el.backgroundColor && el.backgroundColor !== "transparent" ? { fill: el.backgroundColor } : {}
      },
      data: { source: "mermaid" }
    });
    nodes.push(node);
    nodeIds.add(id);
  }
  let seq = 0;
  for (const el of elements) {
    if (el.type !== "arrow" && el.type !== "line") continue;
    const from = el.start?.id;
    const to = el.end?.id;
    if (!from || !to || !nodeIds.has(from) || !nodeIds.has(to)) continue;
    edges.push(
      makeEdge({
        id: el.id ?? `me${seq++}_${from}_${to}`,
        from,
        to,
        label: el.label?.text ?? "",
        mode,
        style: {
          strokeStyle: el.strokeStyle === "dashed" ? "dashed" : "solid",
          strokeWidth: el.strokeWidth === 4 ? 2.6 : 1.4,
          endArrowhead: el.type === "line" ? "none" : "arrow"
        },
        data: { source: "mermaid" }
      })
    );
  }
  if (nodes.length) {
    const minX = Math.min(...nodes.map((n) => n.x));
    const minY = Math.min(...nodes.map((n) => n.y));
    for (const n of nodes) {
      n.x -= minX - 40;
      n.y -= minY - 40;
    }
  }
  return { nodes, edges };
}
function injectMermaid(scene, frag) {
  for (const n of frag.nodes) {
    const ex = scene.nodes.find((x) => x.id === n.id);
    if (ex) {
      ex.x = n.x;
      ex.y = n.y;
      ex.w = n.w;
      ex.h = n.h;
      ex.pinned = true;
      if (ex.shape === "rectangle") ex.shape = n.shape;
      if (!ex.label) ex.label = n.label;
    } else {
      scene.nodes.push(n);
    }
  }
  for (const e of frag.edges) {
    if (!scene.edges.some((x) => x.id === e.id)) scene.edges.push(e);
  }
}
function extractMermaidBlocks(source) {
  const blocks = [];
  const re = /mermaid\s*"""([\s\S]*?)"""/g;
  let m;
  while ((m = re.exec(source)) !== null) {
    blocks.push(m[1].replace(/^\n/, ""));
  }
  return blocks;
}
const EDIT_TOOLS = /* @__PURE__ */ new Set(["select", "hand", "rect", "ellipse", "diamond", "text", "arrow"]);
const ANNOT_MAP = {
  highlight: "highlight",
  underline: "underline",
  "mark-box": "box",
  "mark-circle": "circle",
  point: "arrow",
  note: "text"
};
class EdodoDraw {
  container;
  opts;
  renderer;
  controller;
  annotations;
  player;
  live;
  edit;
  mode = "edit";
  scene;
  source = "";
  renderSeq = 0;
  hasFitted = false;
  fitOnce = false;
  listeners = /* @__PURE__ */ new Map();
  textInput = null;
  closeInput = null;
  colorScheme = null;
  stylePreset = null;
  hasRendered = false;
  cleanup = [];
  // Diagram-edit history (source snapshots). Every direct-manipulation edit
  // rounds through the source, so undo/redo is just a stack of past sources.
  editUndoStack = [];
  editRedoStack = [];
  constructor(container, options = {}) {
    this.container = container;
    this.opts = {
      interactive: options.interactive ?? true,
      grid: options.grid ?? true,
      autoFit: options.autoFit ?? true,
      padding: options.padding ?? 80,
      static: options.static ?? false,
      startHidden: options.startHidden ?? false
    };
    if (getComputedStyle(container).position === "static") container.style.position = "relative";
    container.style.overflow = "hidden";
    this.renderer = new SvgRenderer(container, { static: this.opts.static });
    this.renderer.mount();
    this.scene = compileEdd("scene {}").scene;
    this.controller = new CameraController(this.renderer);
    this.annotations = new AnnotationLayer(this.renderer);
    this.player = new TimelinePlayer(this.renderer, this.controller, this.annotations);
    this.live = new LiveAnnotationController(this.renderer, () => this.scene);
    this.edit = new EditController(this.renderer, {
      getScene: () => this.scene,
      getSource: () => this.source,
      onSource: (next) => this.applyEdit(next),
      onState: (s) => this.emitEditState(s),
      onRequestRename: (id, current, screen) => this.showRenameInput(id, current, screen),
      onCursor: (c) => {
        this.container.style.cursor = c;
      }
    });
    this.player.onChange = (s) => this.emit("state", s);
    this.live.onChange = (s) => this.emit("live", s);
    this.live.onRequestText = (id, world) => this.showTextInput(id, world);
    this.controller.onFrame = (cam) => this.onCameraFrame(cam);
    if (this.opts.interactive) this.bindInteraction();
  }
  onCameraFrame(cam) {
    if (this.opts.grid) this.updateGrid(cam);
    this.edit.render();
  }
  /** Apply a source edit from direct manipulation. Records the pre-edit source
   *  on the undo stack, keeps `source` fresh for chained edits, and notifies the
   *  host, which re-renders (single render). */
  applyEdit(next) {
    if (next === this.source) return;
    this.editUndoStack.push(this.source);
    if (this.editUndoStack.length > 200) this.editUndoStack.shift();
    this.editRedoStack = [];
    this.source = next;
    this.emit("edit", next);
    this.emitEditState();
  }
  /** Undo the last diagram edit (move/resize/add/delete/rename/style/…). */
  editUndo() {
    const prev = this.editUndoStack.pop();
    if (prev === void 0) return false;
    this.editRedoStack.push(this.source);
    this.source = prev;
    this.emit("edit", prev);
    this.emitEditState();
    return true;
  }
  /** Redo the last undone diagram edit. */
  editRedo() {
    const next = this.editRedoStack.pop();
    if (next === void 0) return false;
    this.editUndoStack.push(this.source);
    this.source = next;
    this.emit("edit", next);
    this.emitEditState();
    return true;
  }
  /** Clear the diagram-edit history (e.g. when loading a fresh document). */
  clearEditHistory() {
    this.editUndoStack = [];
    this.editRedoStack = [];
    this.emitEditState();
  }
  emitEditState(s) {
    const base = s ?? this.edit.state();
    this.emit("editstate", { ...base, canUndo: this.editUndoStack.length > 0, canRedo: this.editRedoStack.length > 0 });
  }
  on(event, cb) {
    if (!this.listeners.has(event)) this.listeners.set(event, /* @__PURE__ */ new Set());
    this.listeners.get(event).add(cb);
    return () => this.listeners.get(event)?.delete(cb);
  }
  emit(event, payload) {
    this.listeners.get(event)?.forEach((cb) => cb(payload));
  }
  // ---- render -------------------------------------------------------------
  /**
   * Compile + render EDodoDraw source. Async because a `mermaid` block may need
   * the (lazy-loaded) Mermaid runtime. Safe to call on every keystroke; stale
   * runs are discarded.
   */
  async render(source) {
    if (source !== this.source && (this.editUndoStack.length || this.editRedoStack.length)) {
      this.editUndoStack = [];
      this.editRedoStack = [];
      this.emitEditState();
    }
    this.source = source;
    const seq = ++this.renderSeq;
    const { scene, diagnostics } = compileEdd(source, { mode: this.colorScheme ?? void 0, stylePreset: this.stylePreset ?? void 0 });
    let diags = diagnostics.items;
    const blocks = extractMermaidBlocks(source);
    if (blocks.length) {
      diags = diags.filter((d) => d.code !== "W-MERMAID-SYNC");
      for (const body of blocks) {
        try {
          injectMermaid(scene, await convertMermaid(body, scene.theme.mode));
        } catch (err) {
          const msg = err.message ?? String(err);
          const missing = msg.includes(MERMAID_INSTALL_HINT) || /mermaid-to-excalidraw/.test(msg);
          diags = [
            ...diags,
            {
              severity: "error",
              code: "M-PARSE",
              message: `mermaid: ${msg}`,
              hint: missing ? "npm i @excalidraw/mermaid-to-excalidraw" : "check the mermaid syntax of this block",
              line: 1,
              col: 1,
              start: 0,
              end: 0
            }
          ];
        }
      }
      if (scene.nodes.every((n) => n.pinned)) scene.meta.layout = "manual";
      applyOverrides(scene);
    }
    if (seq !== this.renderSeq) return { scene, diagnostics: diags };
    this.scene = scene;
    this.hasRendered = true;
    this.renderer.render(scene);
    this.player.load(scene);
    if (this.opts.startHidden) {
      this.renderer.applyVisibility(/* @__PURE__ */ new Set([...scene.nodes.map((n) => n.id), ...scene.edges.map((e) => e.id)]));
      this.annotations.clear();
    }
    this.renderer.measure();
    if (this.opts.autoFit && (!this.hasFitted || this.fitOnce)) this.fit(false);
    else this.updateGrid(this.controller.current);
    this.hasFitted = true;
    this.fitOnce = false;
    this.live.render();
    this.edit.render();
    this.emit("diagnostics", diags);
    this.emit("render", { scene, diagnostics: diags });
    return { scene, diagnostics: diags };
  }
  /**
   * Render a programmatic Scene directly (skip the DSL). Pair with
   * `vizToScene()` / `runViz()` / hand-built Scene IR to create diagrams on
   * the fly. Note: direct-manipulation editing round-trips through `.edd`
   * source, so canvas edits are inert for scenes rendered this way — use
   * `render()`/`appendSource()` when you need the code round-trip.
   */
  renderScene(scene) {
    this.renderSeq++;
    this.source = "";
    this.scene = scene;
    this.hasRendered = true;
    this.renderer.render(scene);
    this.player.load(scene);
    if (this.opts.startHidden) {
      this.renderer.applyVisibility(/* @__PURE__ */ new Set([...scene.nodes.map((n) => n.id), ...scene.edges.map((e) => e.id)]));
      this.annotations.clear();
    }
    this.renderer.measure();
    if (this.opts.autoFit && (!this.hasFitted || this.fitOnce)) this.fit(false);
    else this.updateGrid(this.controller.current);
    this.hasFitted = true;
    this.fitOnce = false;
    this.live.render();
    this.edit.render();
    this.emit("render", { scene, diagnostics: [] });
  }
  /**
   * Append a DSL fragment to the current source and re-render — grow a
   * diagram at runtime while keeping the text as the single source of truth:
   *   await edd.appendSource(`annotate { circle-mark api "hot path" }`);
   */
  appendSource(fragment) {
    const base = this.source.trimEnd();
    return this.render(base ? `${base}
${fragment}` : fragment);
  }
  getScene() {
    return this.scene;
  }
  getSource() {
    return this.source;
  }
  /**
   * Force light/dark rendering, overriding the diagram's declared theme. Affects
   * the canvas background, the dotted grid, and the diagram's default ink
   * (strokes/text adapt for contrast on the dark canvas; explicit colors are
   * kept). Pass `null` to fall back to the DSL's own theme. Re-renders the
   * current source. Cheap and idempotent — no-ops if the scheme is unchanged.
   */
  setColorScheme(mode) {
    if (this.colorScheme === mode) return;
    this.colorScheme = mode;
    if (this.hasRendered) void this.render(this.source);
  }
  getColorScheme() {
    return this.colorScheme;
  }
  /**
   * Force a style preset by name (see docs/STYLES_GUIDE), overriding the
   * diagram's `meta { style: … }`. Pass `null` to fall back to the source's own
   * declaration. Re-renders the current source; unknown names warn and keep the
   * classic look.
   */
  setStylePreset(name) {
    if (this.stylePreset === name) return;
    this.stylePreset = name;
    if (this.hasRendered) void this.render(this.source);
  }
  getStylePreset() {
    return this.stylePreset;
  }
  // ---- camera -------------------------------------------------------------
  fit(animate = true) {
    this.renderer.measure();
    const cam = cameraForBBox(sceneBBox(this.scene), this.renderer.getViewportSize(), { padding: this.opts.padding });
    if (animate) void this.controller.animateTo(cam);
    else this.controller.setImmediate(cam);
  }
  focus(ids, opts) {
    return this.controller.focus(this.scene, ids, opts);
  }
  zoomBy(factor) {
    this.controller.zoomBy(factor);
  }
  reset() {
    this.fit(true);
  }
  get camera() {
    return this.controller;
  }
  // ---- timeline -----------------------------------------------------------
  play() {
    this.player.play();
  }
  pause() {
    this.player.pause();
  }
  next() {
    this.player.next();
  }
  prev() {
    this.player.prev();
  }
  goto(i) {
    void this.player.goto(i);
  }
  restart() {
    this.player.restart();
  }
  get timeline() {
    return this.player;
  }
  // ---- frame-driven choreography (video / capture hosts) -------------------
  /** Pure render-state for step `index` (-1 = overview) — no clock, no DOM. */
  stepState(index) {
    return stepStateAt(this.scene, index);
  }
  /**
   * Apply a StepState instantly (no tweens): visibility, annotations, and the
   * step's sticky camera. Call per frame with states from stepState() to drive
   * the timeline's own semantics frame-accurately (pair with {static: true};
   * interpolate cameras yourself via mixCameras() for magic-move).
   */
  applyStepState(state) {
    this.renderer.applyVisibility(new Set(state.hidden));
    this.annotations.render(this.scene, state.annotations, false);
    if (state.effectiveCamera) {
      const cam = resolveCameraDirective(this.scene, state.effectiveCamera, this.renderer.getViewportSize(), { current: this.controller.current });
      this.controller.setImmediate(cam);
    }
  }
  /**
   * Host-driven draw-on: sweep an element's strokes on, then fade its labels.
   * `id` = node id, edge id, or viz-item key ("block.item"); `p` = 0..1.
   */
  setRevealProgress(id, p) {
    this.renderer.setRevealProgress(id, p);
  }
  /**
   * Batch draw-on, and the ONLY safe form when frames are produced out of order
   * (Remotion seeks, a scrubber): every drawable NOT named in `map` is restored
   * to fully drawn, so the picture is a total function of the map rather than
   * of whatever the previous frame happened to mutate.
   *
   *   edd.setRevealProgressAll({ api: 0.4, db: 0 });  // everything else = done
   */
  setRevealProgressAll(map) {
    this.renderer.setRevealProgressAll(map);
  }
  /**
   * Resolve once the embedded hand-drawn font is decoded — wire it to your
   * host's "hold this frame" primitive (Remotion's `delayRender`), or a
   * headless capture will screenshot with fallback metrics and shifted text.
   */
  whenFontsReady() {
    return whenFontsReady(this.container.ownerDocument);
  }
  /** The renderer this facade owns — for engine-level calls the facade doesn't wrap. */
  get view() {
    return this.renderer;
  }
  /** Hide/show elements directly (ids to hide; others become visible). */
  applyVisibility(hiddenIds) {
    this.renderer.applyVisibility(new Set(hiddenIds));
  }
  // ---- tools (diagram-edit + annotation) ----------------------------------
  /** Select the active tool. Edit tools (select/hand/rect/ellipse/diamond/
   *  text/arrow) manipulate the diagram; annotation tools (highlight/underline/
   *  mark-box/mark-circle/point/note) overlay annotations. */
  setTool(tool) {
    if (EDIT_TOOLS.has(tool)) {
      this.mode = "edit";
      this.edit.setTool(tool);
      this.container.style.cursor = this.baseCursor();
    } else if (tool in ANNOT_MAP) {
      this.mode = "annotate";
      this.edit.clearSelection();
      this.live.setTool(ANNOT_MAP[tool]);
      this.container.style.cursor = "crosshair";
    }
  }
  /** Resting cursor for the active edit tool (hover overrides it live). */
  baseCursor() {
    const t = this.edit.getTool();
    if (t === "hand") return "grab";
    if (t === "select") return "default";
    return "crosshair";
  }
  /** Fit the whole diagram on the next render (used when loading an example). */
  fitNext() {
    this.fitOnce = true;
  }
  get editor() {
    return this.edit;
  }
  applyStyle(id, style) {
    this.edit.applyStyle(id, style);
  }
  /** Apply a style to several nodes in one undo step. */
  applyStyleMany(ids, style) {
    this.edit.applyStyleMany(ids, style);
  }
  duplicateSelected() {
    this.edit.duplicateSelected();
  }
  deleteSelected() {
    this.edit.deleteSelected();
  }
  renameSelected() {
    this.edit.requestRenameSelected();
  }
  // ---- undo / redo --------------------------------------------------------
  /** Undo the current mode's last action (diagram edit, or annotation). */
  undo() {
    if (this.mode === "edit") this.editUndo();
    else this.live.undo();
  }
  redo() {
    if (this.mode === "edit") this.editRedo();
    else this.live.redo();
  }
  clearAnnotations() {
    this.live.clear();
  }
  /** Serialize live annotations into an `annotate { … }` block. */
  annotationsToCode() {
    return this.live.commitToCode();
  }
  get annotator() {
    return this.live;
  }
  // ---- export -------------------------------------------------------------
  toSVG() {
    return exportSVGString(this.renderer, this.scene);
  }
  /** Synchronous `toSVG()` — nothing in the export path awaits (the font is
   *  embedded, not fetched), so it is safe inside a React `useMemo`. */
  toSVGSync(opts) {
    return renderSceneToSVGString(this.renderer, this.scene, opts);
  }
  toPNG() {
    return exportPNGBlob(this.renderer, this.scene);
  }
  toJSON() {
    return this.scene;
  }
  downloadSVG() {
    return downloadSVG(this.renderer, this.scene);
  }
  downloadPNG() {
    return downloadPNG(this.renderer, this.scene);
  }
  downloadJSON() {
    downloadJSON(this.scene);
  }
  // ---- lifecycle ----------------------------------------------------------
  resize() {
    this.renderer.measure();
    this.renderer.applyCamera(this.renderer.getCamera());
    this.updateGrid(this.controller.current);
    this.edit.render();
    this.live.render();
  }
  destroy() {
    for (const fn of this.cleanup) fn();
    this.cleanup = [];
    this.closeInput?.(false);
    this.textInput?.remove();
    this.edit.dispose();
    this.player.dispose();
    this.renderer.destroy();
    this.listeners.clear();
  }
  // ---- internals ----------------------------------------------------------
  updateGrid(cam) {
    if (!this.opts.grid) return;
    const { w, h } = this.renderer.getViewportSize();
    const cell = 26 * cam.zoom;
    const c = this.container;
    if (cell < 7) {
      c.style.backgroundImage = "none";
      return;
    }
    const dot2 = this.scene.theme.gridColor;
    c.style.backgroundImage = `radial-gradient(circle, ${dot2} 1px, transparent 1px)`;
    c.style.backgroundSize = `${cell}px ${cell}px`;
    c.style.backgroundPosition = `${-cam.cx * cam.zoom + w / 2}px ${-cam.cy * cam.zoom + h / 2}px`;
  }
  localPoint(e) {
    const rect = this.container.getBoundingClientRect();
    const sx = rect.width > 0 ? (this.container.clientWidth || rect.width) / rect.width : 1;
    const sy = rect.height > 0 ? (this.container.clientHeight || rect.height) / rect.height : 1;
    return { x: (e.clientX - rect.left) * sx, y: (e.clientY - rect.top) * sy };
  }
  bindInteraction() {
    const host = this.container;
    const add = (t, fn, opts) => {
      host.addEventListener(t, fn, opts);
      this.cleanup.push(() => host.removeEventListener(t, fn, opts));
    };
    const ro = new ResizeObserver(() => this.resize());
    ro.observe(host);
    this.cleanup.push(() => ro.disconnect());
    add("wheel", (e) => {
      e.preventDefault();
      this.player.pause();
      this.controller.zoomBy(Math.exp(-e.deltaY * 16e-4), this.localPoint(e));
      this.live.render();
    }, { passive: false });
    let dragging = false;
    let lx = 0;
    let ly = 0;
    add("pointerdown", (e) => {
      if (e.button !== 0) return;
      const local = this.localPoint(e);
      const world = this.renderer.screenToWorld(local);
      const handled = this.mode === "edit" ? this.edit.pointerDown(world, local, { shift: e.shiftKey }) : this.live.pointerDown(world, local);
      if (handled) {
        host.setPointerCapture(e.pointerId);
        return;
      }
      dragging = true;
      lx = e.clientX;
      ly = e.clientY;
      host.setPointerCapture(e.pointerId);
      host.style.cursor = "grabbing";
    });
    add("pointermove", (e) => {
      const local = this.localPoint(e);
      const world = this.renderer.screenToWorld(local);
      if (this.mode === "edit") this.edit.pointerMove(world, local);
      else this.live.pointerMove(world);
      if (!dragging) return;
      this.player.pause();
      this.controller.panByScreen(e.clientX - lx, e.clientY - ly);
      lx = e.clientX;
      ly = e.clientY;
      this.live.render();
      this.edit.render();
    });
    add("pointerup", (e) => {
      const world = this.renderer.screenToWorld(this.localPoint(e));
      if (this.mode === "edit") this.edit.pointerUp(world);
      else this.live.pointerUp(world);
      dragging = false;
      try {
        host.releasePointerCapture(e.pointerId);
      } catch {
      }
      host.style.cursor = this.mode === "edit" ? this.baseCursor() : "crosshair";
    });
    add("dblclick", (e) => {
      if (this.mode !== "edit") return;
      this.edit.dblclick(this.renderer.screenToWorld(this.localPoint(e)));
    });
    const onKey = (e) => {
      const t = e.target;
      const tag = t?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || t?.isContentEditable || t?.closest?.("[contenteditable='true'], .cm-editor")) return;
      const meta = (e.metaKey || e.ctrlKey) && !e.altKey;
      if (meta) {
        const k = e.key.toLowerCase();
        if (k === "z") {
          if (this.mode === "annotate") {
            if (this.live.handleKey(e)) e.preventDefault();
            return;
          }
          if (e.shiftKey ? this.editRedo() : this.editUndo()) e.preventDefault();
          return;
        }
        if (k === "y") {
          if (this.mode === "edit" && this.editRedo()) e.preventDefault();
          return;
        }
        if (this.mode === "edit") {
          if (k === "d") {
            if (this.edit.duplicateSelected()) e.preventDefault();
            return;
          }
          if (k === "c") {
            if (this.edit.copySelected()) e.preventDefault();
            return;
          }
          if (k === "v") {
            if (this.edit.paste()) e.preventDefault();
            return;
          }
          if (k === "a") {
            this.edit.selectAll();
            e.preventDefault();
            return;
          }
        }
        return;
      }
      if (this.mode === "edit" && this.edit.handleKey(e)) {
        e.preventDefault();
        return;
      }
      if (this.live.handleKey(e)) e.preventDefault();
    };
    window.addEventListener("keydown", onKey);
    this.cleanup.push(() => window.removeEventListener("keydown", onKey));
    host.style.cursor = "grab";
  }
  /** Inline text editor for renaming a node (double-click / new node). */
  showRenameInput(id, current, screen) {
    const dark = this.scene.theme.mode === "dark";
    this.openInlineInput({
      value: current,
      placeholder: "label…",
      screen,
      style: {
        background: dark ? "#23262d" : "#ffffff",
        color: dark ? "#e6e7ea" : "#1e1e1e",
        textAlign: "center",
        zIndex: "30",
        minWidth: "80px"
      },
      onCommit: (v) => this.edit.applyRename(id, v)
    });
  }
  showTextInput(id, world) {
    this.openInlineInput({
      value: "note",
      screen: this.renderer.worldToScreen(world),
      style: { background: "#fff9db", color: "#5c3d00", zIndex: "20" },
      onCommit: (v) => this.live.setText(id, v)
    });
  }
  /**
   * Shared inline text-entry field (used for rename + sticky notes). One code
   * path so the create/focus/commit/teardown lifecycle is race-free: the blur
   * listener is detached before removal and every settle is idempotent, so
   * dismissing one input to open another can't double-remove a DOM node.
   */
  openInlineInput(opts) {
    this.closeInput?.(false);
    const input = this.container.ownerDocument.createElement("input");
    input.value = opts.value;
    if (opts.placeholder) input.placeholder = opts.placeholder;
    Object.assign(
      input.style,
      {
        position: "absolute",
        left: `${opts.screen.x}px`,
        top: `${opts.screen.y}px`,
        transform: "translate(-50%, -50%)",
        font: '16px "Excalifont", "Virgil", cursive',
        padding: "4px 8px",
        border: "2px solid #6741d9",
        borderRadius: "6px",
        outline: "none"
      },
      opts.style ?? {}
    );
    let settled = false;
    const settle = (commit) => {
      if (settled) return;
      settled = true;
      input.removeEventListener("blur", onBlur);
      const value = input.value;
      if (this.closeInput === settle) this.closeInput = null;
      if (this.textInput === input) this.textInput = null;
      if (input.parentNode) input.parentNode.removeChild(input);
      if (commit) opts.onCommit(value);
    };
    const onBlur = () => settle(true);
    input.addEventListener("keydown", (e) => {
      e.stopPropagation();
      if (e.key === "Enter") {
        e.preventDefault();
        settle(true);
      } else if (e.key === "Escape") {
        e.preventDefault();
        settle(false);
      }
    });
    input.addEventListener("blur", onBlur);
    this.container.appendChild(input);
    this.textInput = input;
    this.closeInput = settle;
    input.focus();
    input.select();
  }
}
export {
  cameraForCenter as $,
  AnnotationLayer as A,
  LiveAnnotationController as B,
  CHARACTER_LABEL_GAP as C,
  DiagnosticBag as D,
  EdodoDraw as E,
  FILL_PALETTE as F,
  MERMAID_INSTALL_HINT as G,
  HAND_CLEAN_DARK_PRESET as H,
  ICON_LABEL_GAP as I,
  SvgRenderer as J,
  VizContext as K,
  LIGHT_THEME as L,
  MARKER_PALETTE as M,
  addEdge as N,
  addNode as O,
  applyLayout as P,
  applyOverrides as Q,
  bboxCenter as R,
  STROKE_PALETTE as S,
  TimelinePlayer as T,
  bboxOfPoints as U,
  VIZ_ALIASES as V,
  bboxSize as W,
  bboxToRect as X,
  bboxUnion as Y,
  borderPointToward as Z,
  cameraForBBox as _,
  routePoints as a,
  listCharacterNodes as a$,
  characterNodeBox as a0,
  characterNodeSpec as a1,
  clamp$3 as a2,
  compileEdd as a3,
  computeHiddenAt as a4,
  contrastInk as a5,
  convertMermaid as a6,
  darken as a7,
  defaultEdgeStyle as a8,
  defaultNodeSize as a9,
  getGroup as aA,
  getLayoutPlugin as aB,
  getNode as aC,
  getShapePlugin as aD,
  getViz as aE,
  groupBBox as aF,
  hashString as aG,
  hitTestEdge as aH,
  hitTestNode as aI,
  iconEntry as aJ,
  iconNodeBox as aK,
  iconNodeGlyph as aL,
  iconNodeSpec as aM,
  iconPath as aN,
  injectMermaid as aO,
  isEmptyBBox as aP,
  isLightColor as aQ,
  isMermaidAvailable as aR,
  itemsOf as aS,
  lerp$3 as aT,
  lighten as aU,
  listAnnotationPlugins as aV,
  listArrowAnimations as aW,
  listCharacterAccessories as aX,
  listCharacterEmotions as aY,
  listCharacterFx as aZ,
  listCharacterHair as a_,
  defaultNodeStyle as aa,
  deleteElements as ab,
  dist as ac,
  downloadJSON as ad,
  downloadPNG as ae,
  downloadSVG as af,
  drawCharacter as ag,
  easingByName as ah,
  edgeBBox as ai,
  edgeRoughOptions as aj,
  elementBBox as ak,
  elementsBBox as al,
  ellipseBorderToward as am,
  emitCharacterNode as an,
  emptyBBox as ao,
  ensureEngineStyles as ap,
  ensurePluginStyles as aq,
  expandBBox as ar,
  exportPNGBlob as as,
  exportSVGString as at,
  extractMermaidBlocks as au,
  formatDiagnostic as av,
  getAnnotationPlugin as aw,
  getArrowAnimation as ax,
  getCharacterPose as ay,
  getEdge as az,
  presetTheme as b,
  styleNode as b$,
  listCharacterPoses as b0,
  listCharacterShirts as b1,
  listIconNodes as b2,
  listIcons as b3,
  listLayoutPlugins as b4,
  listReferencePresets as b5,
  listShapePlugins as b6,
  listStyleChoices as b7,
  listStylePresets as b8,
  listViz as b9,
  rectToBBox as bA,
  registerAnnotation as bB,
  registerArrowAnimation as bC,
  registerCharacterAccessory as bD,
  registerCharacterEmotion as bE,
  registerCharacterFx as bF,
  registerCharacterHair as bG,
  registerCharacterPose as bH,
  registerCharacterShirt as bI,
  registerIcon as bJ,
  registerLayout as bK,
  registerShape as bL,
  registerStylePreset as bM,
  registerViz as bN,
  registerVizAlias as bO,
  renameNode as bP,
  renderSceneToSVGString as bQ,
  renderSceneWithAnnotations as bR,
  resolveAnchor as bS,
  resolveCameraDirective as bT,
  resolveFill as bU,
  resolveMarker as bV,
  resolveStroke as bW,
  roleStyle as bX,
  roughTuning as bY,
  sceneBBox as bZ,
  stepStateAt as b_,
  listVizAliases as ba,
  listVizItems as bb,
  listVizTemplates as bc,
  luma as bd,
  makeEdge as be,
  makeNode as bf,
  measureBlock as bg,
  measureCharacterNode as bh,
  measureText as bi,
  mix as bj,
  mixCameras as bk,
  nodeBBox as bl,
  nodeRect as bm,
  nodeRectOf as bn,
  optBool as bo,
  optNum as bp,
  optStr as bq,
  pairedStrokeForFill as br,
  paletteColor as bs,
  parseHex as bt,
  pointInRect as bu,
  presetDeclaresRoughTuning as bv,
  presetEdgeDefaults as bw,
  presetNodeDefaults as bx,
  rampOpacity as by,
  rectCenter as bz,
  centerlinePath as c,
  toHex as c0,
  tunePreset as c1,
  vizItemMembers as c2,
  whenFontsReady as c3,
  withAlpha as c4,
  wrapText as c5,
  writeOverrides as c6,
  dagreRoute as d,
  effectivePreset as e,
  runViz as f,
  getStylePreset as g,
  emptyScene as h,
  CHARACTER_NODE_DEFAULT_HEIGHT as i,
  CLASSIC_COLOR_PRESET as j,
  CLASSIC_DARK_PRESET as k,
  CLASSIC_PRESET as l,
  CLASSIC_ROUGH_PRESET as m,
  CameraController as n,
  DARK_THEME as o,
  pathLength as p,
  EASINGS as q,
  resolveEndpoints as r,
  smoothPath as s,
  EXCALIFONT_FAMILY as t,
  EditController as u,
  FONT_FAMILY as v,
  HAND_CLEAN_PRESET as w,
  HAND_FONT_WOFF2_DATA_URI as x,
  ICON_NODE_DEFAULT_SIZE as y,
  ICON_VIEWBOX as z
};
//# sourceMappingURL=EdodoDraw-nvsraggA.js.map
